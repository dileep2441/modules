## Local values

```terraform
locals {
  timeout_duration      = "2h"
  cl_app_gateway_subnet = var.cl_app_gateway_deploy_subnet ? azurerm_subnet.cl_app_gateway_subnet[0] : null
  cl_app_gateway        = var.set_private_ip_listener ? azurerm_application_gateway.cl_app_gateway_peninsula[0] : azurerm_application_gateway.cl_app_gateway_island[0]

  # IP configurations
  gateway_ip_configuration_name          = "gw-ip-conf"
  frontend_ip_configuration_name_private = "private-ip"
  frontend_ip_configuration_name_public  = "public-ip"

  # Frontend configurations
  frontend_port_http_name  = "frontend-port-80"
  frontend_port_http       = 80
  frontend_port_https_name = "frontend-port-443"
  frontend_port_https      = 443


  # Listener configurations
  https_listener_peninsula = {
    name                           = "https-listener-private"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_private
    frontend_port_name             = local.frontend_port_https_name
    protocol                       = "Https"
    ssl_certificate_name           = "frontend_ssl_cert"
  }
  http_listener_peninsula = {
    name                           = "http-listener-private"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_private
    frontend_port_name             = local.frontend_port_http_name
    protocol                       = "Http"
  }
  https_listener_island = {
    name                           = "https-listener-public"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_public
    frontend_port_name             = local.frontend_port_https_name
    protocol                       = "Https"
    ssl_certificate_name           = "frontend_ssl_cert"
  }
  http_listener_island = {
    name                           = "http-listener-public"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_public
    frontend_port_name             = local.frontend_port_http_name
    protocol                       = "Http"
  }
  ssl_certificate_name = "frontend_ssl_cert"

  redirect_configuration_peninsula = {
    name                 = "http-to-https-redirect-private"
    redirect_type        = "Permanent"
    target_listener_name = local.https_listener_peninsula.name
  }

  redirect_configuration_island = {
    name                 = "http-to-https-redirect-public"
    redirect_type        = "Permanent"
    target_listener_name = local.https_listener_island.name
  }

  # Backend  configurations
  backend_address_pool_name = "backend-address-pool"

  backend_http_settings = {
    name                  = "backend-https-settings"
    cookie_based_affinity = "Disabled"
    port                  = 443
    protocol              = "Https"
  }

  # Routing rules configurations
  request_routing_rule_peninsula_http_to_https = {
    name                        = "http-to-https-rule-private"
    rule_type                   = "Basic"
    http_listener_name          = local.http_listener_peninsula.name
    redirect_configuration_name = local.redirect_configuration_peninsula.name
  }
  request_routing_rule_peninsula_https = {
    name                       = "backend-https-rule-private"
    rule_type                  = "Basic"
    http_listener_name         = local.https_listener_peninsula.name
    backend_address_pool_name  = local.backend_address_pool_name
    backend_http_settings_name = local.backend_http_settings.name
  }
  request_routing_rule_island_http_to_https = {
    name                        = "http-to-https-rule-public"
    rule_type                   = "Basic"
    http_listener_name          = local.http_listener_island.name
    redirect_configuration_name = local.redirect_configuration_island.name
  }
  request_routing_rule_island_https = {
    name                       = "backend-https-rule-public"
    rule_type                  = "Basic"
    http_listener_name         = local.https_listener_island.name
    backend_address_pool_name  = local.backend_address_pool_name
    backend_http_settings_name = local.backend_http_settings.name
  }
}
```
## Usage

1. Deploy Application Gateway with an existing Web Application Firewall Polcies

```terraform
module "cl_app_gateway" {
  source                                      = "../tf-azure-component-library/components/cl_application_gateway"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  set_private_ip_listener                     = <true/false>
  cl_app_gateway_firewall_policy_id           = confirm with a cloudops the ID of the Web Application Firewall Policy in order to associate the application gateway
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["70.0.0.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS
  cl_app_gateway_nsg_rules = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_app_gateway_additional_probes = {
    portal_health_probe = {
      name                = "apim-portal-probe"
      host                = "portal.azisapinp.amr.kpmg.com"
      path                = "/internal-status-0123456789abcdef"
      interval            = 30
      timeout             = 300
      unhealthy_threshold = 8
      protocol            = "Https" 
    }
  }
  cl_app_gateway_additional_backend_address_pool = {
    kauth_backend_address_pool = {
      name  = "kauth-backend-address-pool"
      fqdns = [module.cl_app_service_app_k_auth.cl_app_service.default_site_hostname]
    }           
  }
  cl_app_gateway_additional_http_settings = {
    kauth_http_settings = {
      name                                = "kauth-https-settings"
      request_timeout                     = 180
      probe_name                          = "https-probe"
      pick_host_name_from_backend_address = true
      host_name                           = null 
    }   
  }
  cl_app_gateway_additional_http_listener = {
    kauth_http_listener = {
      name                  = "kauth-http-listener-public"
      protocol              = "Http"
      host_name             = "kauth.dev.taxdigital.kpmg.com.br"
      frontend_port_name    = "frontend-port-80"
      ssl_certificate_name  = null      
    }       
  }
  cl_app_gateway_additional_route_rules = {
    kauth_http_to_https_route_rule = {
      name                        = "kauth-http-to-https-rule-public"
      rule_type                   = "Basic"
      backend_address_pool        = null
      http_listener_name          = "kauth-http-listener-public"
      backend_http_settings_name  = null
      redirect_configuration_name = "kauth-http-to-https-redirect"
    } 
  }
  cl_app_gateway_additional_redirect_configurations = {
    kauth_http_settings = {
      name                  = "kauth-http-to-https-redirect"
      redirect_type         = "Permanent"
      target_listener_name  = "kauth-https-listener-public"
    }    
  }
  cl_app_gateway_rewrite_rules = [
    {
        name = "test",
        rule_sequence = 100,
        conditions = [
          {
            variable    = "HTTP header"
            pattern     = "(https?):VV.*azurewebsites\.net(.*)$"
            ignore_case = false
            negate      = false
          }
        ],
        request_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        response_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        urls  = [
          {
            path          = "/article.aspx"
            query_string  = "id={var_uri_path_1}"
            reroute       = "/page.aspx"
          }
        ]
    }
]       
}

```

2. Deploy Application Gateway with a new Web Application Firewall Polcies

```terraform
resource "azurerm_web_application_firewall_policy" "web_application_firewall_policy" {
  name                = "${var.env}-${var.postfix}-wafpolicy"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  location            = var.location

    custom_rules {
    name      = "DenyAccess"
    priority  = 1
    rule_type = "MatchRule"

    match_conditions {
      match_variables {
        variable_name = "RemoteAddr"
      }

      operator           = "GeoMatch"
      negation_condition = false
      match_values       = ["RU","BY"]
    }

    action = "Block"
  }

    policy_settings {
    enabled                     = true
    mode                        = "Detection"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.1"
    }
  }
}

module "cl_app_gateway" {
  source                                      = "../tf-azure-component-library/components/cl_application_gateway"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  set_private_ip_listener                     = <true/false>
  cl_app_gateway_firewall_policy_id           = azurerm_web_application_firewall_policy.web_application_firewall_policy.id
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["70.0.0.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS
  cl_app_gateway_routing_rule_rule_name       = var.cl_app_gateway_routing_rule_rule_name
  cl_app_gateway_routing_rule_rule_type       = var.cl_app_gateway_routing_rule_rule_type
  cl_app_gateway_routing_rule_rule_listener_name        = var.cl_app_gateway_routing_rule_rule_listener_name
  cl_app_gateway_routing_rule_backend_address_pool_name = var.cl_app_gateway_routing_rule_backend_address_pool_name
  cl_app_gateway_routing_rule_backend_http_settings_name= var.cl_app_gateway_routing_rule_backend_http_settings_name
  cl_app_gateway_nsg_rules = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_app_gateway_additional_probes = {
    portal_health_probe = {
      name                = "apim-portal-probe"
      host                = "portal.azisapinp.amr.kpmg.com"
      path                = "/internal-status-0123456789abcdef"
      interval            = 30
      timeout             = 300
      unhealthy_threshold = 8
      protocol            = "Https" 
    }
  }
  cl_app_gateway_additional_backend_address_pool = {
    kauth_backend_address_pool = {
      name  = "kauth-backend-address-pool"
      fqdns = [module.cl_app_service_app_k_auth.cl_app_service.default_site_hostname]
    }           
  }
  cl_app_gateway_additional_http_settings = {
    kauth_http_settings = {
      name                                = "kauth-https-settings"
      request_timeout                     = 180
      probe_name                          = "https-probe"
      pick_host_name_from_backend_address = true
      host_name                           = null 
    }   
  }
  cl_app_gateway_additional_http_listener = {
    kauth_http_listener = {
      name                  = "kauth-http-listener-public"
      protocol              = "Http"
      host_name             = "kauth.dev.taxdigital.kpmg.com.br"
      frontend_port_name    = "frontend-port-80"
      ssl_certificate_name  = null      
    }       
  }
  cl_app_gateway_additional_route_rules = {
    kauth_http_to_https_route_rule = {
      name                        = "kauth-http-to-https-rule-public"
      rule_type                   = "Basic"
      backend_address_pool        = null
      http_listener_name          = "kauth-http-listener-public"
      backend_http_settings_name  = null
      redirect_configuration_name = "kauth-http-to-https-redirect"
    } 
  }
  cl_app_gateway_additional_redirect_configurations = {
    kauth_http_settings = {
      name                  = "kauth-http-to-https-redirect"
      redirect_type         = "Permanent"
      target_listener_name  = "kauth-https-listener-public"
    }    
  }
  cl_app_gateway_rewrite_rules = [
    {
        name = "test",
        rule_sequence = 100,
        conditions = [
          {
            variable    = "HTTP header"
            pattern     = "(https?):VV.*azurewebsites\.net(.*)$"
            ignore_case = false
            negate      = false
          }
        ],
        request_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        response_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        urls  = [
          {
            path          = "/article.aspx"
            query_string  = "id={var_uri_path_1}"
            reroute       = "/page.aspx"
          }
        ]
    }
]       
}
```
## Notes

You will need to store a base64 certificate and cert password in jenkins credentials used by JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX and JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS variables.
Some modifications on JenkinsFile will be required to import this Credentials variables.

The powershell command converts your pfx certificate file to base64 format:
```powershell
$fileContentBytes = get-content '<yourcertificate.pfx>' -Encoding Byte [System.Convert]::ToBase64String($fileContentBytes) | Out-File 'certbase64.txt'
```

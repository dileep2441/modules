<!-- BEGIN_TF_DOCS -->

# Azure Function App Component

A function app lets you group Azure functions as a logical unit for easier management, deployment, scaling, and sharing of resources.
(Azure Function is a serverless compute service that enables user to run event-triggered code without having to provision or manage infrastructure.)
This component will deploy an Azure Function App resource in either Windows or Linux flavors. It will also deploy a storage account, private endpoints, and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-functions/functions-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.cl_function_app_sa_atp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_app_service_virtual_network_swift_connection.cl_function_app_network_connection_integration_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service_virtual_network_swift_connection) | resource |
| [azurerm_data_protection_backup_instance_blob_storage.cl_function_app_storage_account_protected_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_instance_blob_storage) | resource |
| [azurerm_function_app.cl_function_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/function_app) | resource |
| [azurerm_monitor_diagnostic_setting.cl_function_app_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_function_app_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_function_app_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_function_app_storage_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.cl_function_app_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_function_app_always_on"></a> [cl\_function\_app\_always\_on](#input\_cl\_function\_app\_always\_on) | (Optional) Should the app be loaded at all times? | `bool` | `false` | no |
| <a name="input_cl_function_app_asp_id"></a> [cl\_function\_app\_asp\_id](#input\_cl\_function\_app\_asp\_id) | (Required) App Service Plan ID used by the function app. | `any` | n/a | yes |
| <a name="input_cl_function_app_auth_settings_default_provider"></a> [cl\_function\_app\_auth\_settings\_default\_provider](#input\_cl\_function\_app\_auth\_settings\_default\_provider) | (Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter. | `any` | `null` | no |
| <a name="input_cl_function_app_auth_settings_enabled"></a> [cl\_function\_app\_auth\_settings\_enabled](#input\_cl\_function\_app\_auth\_settings\_enabled) | (Optional) Enable or disable Authentication Settings | `string` | `"true"` | no |
| <a name="input_cl_function_app_auth_settings_runtime_version"></a> [cl\_function\_app\_auth\_settings\_runtime\_version](#input\_cl\_function\_app\_auth\_settings\_runtime\_version) | (Optional) The runtime version of the Authentication/Authorization module | `any` | `null` | no |
| <a name="input_cl_function_app_auth_settings_unauthenticated_client_action"></a> [cl\_function\_app\_auth\_settings\_unauthenticated\_client\_action](#input\_cl\_function\_app\_auth\_settings\_unauthenticated\_client\_action) | (Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage. | `any` | `null` | no |
| <a name="input_cl_function_app_client_cert_mode"></a> [cl\_function\_app\_client\_cert\_mode](#input\_cl\_function\_app\_client\_cert\_mode) | (Optional) The mode of the Function App's client certificates requirement for incoming requests.  Possible values are Required and Optional. | `string` | `"Optional"` | no |
| <a name="input_cl_function_app_cors_allowed_origins"></a> [cl\_function\_app\_cors\_allowed\_origins](#input\_cl\_function\_app\_cors\_allowed\_origins) | (Optional) A list of origins which should be able to make cross-origin calls. * can be used to allow all calls. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_cl_function_app_diagnostics"></a> [cl\_function\_app\_diagnostics](#input\_cl\_function\_app\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "FunctionAppLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_function_app_dns_alt_server"></a> [cl\_function\_app\_dns\_alt\_server](#input\_cl\_function\_app\_dns\_alt\_server) | Custom DNS service for app service routing. | `string` | `"168.63.129.16"` | no |
| <a name="input_cl_function_app_dns_server"></a> [cl\_function\_app\_dns\_server](#input\_cl\_function\_app\_dns\_server) | Custom DNS service for app service routing. | `string` | `"168.63.129.16"` | no |
| <a name="input_cl_function_app_dotnet_framework_version"></a> [cl\_function\_app\_dotnet\_framework\_version](#input\_cl\_function\_app\_dotnet\_framework\_version) | (Optional) The version of the .net framework's CLR used in this function app. Possible values are v4.0 (including .NET Core 2.1 and 3.1), v5.0 and v6.0. Defaults to v4.0. | `string` | `"v6.0"` | no |
| <a name="input_cl_function_app_ftps_state"></a> [cl\_function\_app\_ftps\_state](#input\_cl\_function\_app\_ftps\_state) | (Optional) State of FTP / FTPS service for this function app. Possible values include: AllAllowed, FtpsOnly and Disabled. | `string` | `"Disabled"` | no |
| <a name="input_cl_function_app_http2_enabled"></a> [cl\_function\_app\_http2\_enabled](#input\_cl\_function\_app\_http2\_enabled) | (Optional) Is HTTP2 Enabled on this function app? | `bool` | `true` | no |
| <a name="input_cl_function_app_https_only"></a> [cl\_function\_app\_https\_only](#input\_cl\_function\_app\_https\_only) | (Optional) Booolean to toggle if the function app can only be accessed via HTTPS. | `bool` | `true` | no |
| <a name="input_cl_function_app_identity_ids"></a> [cl\_function\_app\_identity\_ids](#input\_cl\_function\_app\_identity\_ids) | UserAssigned Identities ID to add to Function App. Mandatory if type is UserAssigned | `list(string)` | `null` | no |
| <a name="input_cl_function_app_identity_type"></a> [cl\_function\_app\_identity\_type](#input\_cl\_function\_app\_identity\_type) | Add an Identity (MSI) to the logic app. Possible values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_function_app_integration_subnet_id"></a> [cl\_function\_app\_integration\_subnet\_id](#input\_cl\_function\_app\_integration\_subnet\_id) | (Required) The ID of the integration subnet the function app will be associated to (the subnet must have a service\_delegation configured for Microsoft.Web/serverFarms). | `any` | n/a | yes |
| <a name="input_cl_function_app_log_analytics_workspace_id"></a> [cl\_function\_app\_log\_analytics\_workspace\_id](#input\_cl\_function\_app\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_function_app_min_tls_version"></a> [cl\_function\_app\_min\_tls\_version](#input\_cl\_function\_app\_min\_tls\_version) | (Optional) The minimum supported TLS version for the function app. | `string` | `"1.2"` | no |
| <a name="input_cl_function_app_os_type"></a> [cl\_function\_app\_os\_type](#input\_cl\_function\_app\_os\_type) | (Optional) The function app os type. Enter 'linux' for Linux and leave null for Windows. For linux, you will need to set cl\_app\_service\_plan\_reserved to true and cl\_app\_service\_plan\_os\_type to FunctionApp in the app service plan component. | `string` | `null` | no |
| <a name="input_cl_function_app_pe_subnet_ids"></a> [cl\_function\_app\_pe\_subnet\_ids](#input\_cl\_function\_app\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_cl_function_app_postfix"></a> [cl\_function\_app\_postfix](#input\_cl\_function\_app\_postfix) | (Required) The bespoke name of the app you are deploying. | `any` | n/a | yes |
| <a name="input_cl_function_app_rg_name"></a> [cl\_function\_app\_rg\_name](#input\_cl\_function\_app\_rg\_name) | (Required) The resource group to deploy the function app into. | `any` | n/a | yes |
| <a name="input_cl_function_app_settings"></a> [cl\_function\_app\_settings](#input\_cl\_function\_app\_settings) | (Optional) Variables passed as environment variables | `map` | `{}` | no |
| <a name="input_cl_function_app_storage_account_allow_nested_items_public_access"></a> [cl\_function\_app\_storage\_account\_allow\_nested\_items\_public\_access](#input\_cl\_function\_app\_storage\_account\_allow\_nested\_items\_public\_access) | (Optional) Allow or disallow nested items within this Account to opt into being public. | `bool` | `false` | no |
| <a name="input_cl_function_app_storage_account_backup_policy_id"></a> [cl\_function\_app\_storage\_account\_backup\_policy\_id](#input\_cl\_function\_app\_storage\_account\_backup\_policy\_id) | The azure blob storage backup policy id from the backup vault. | `any` | `null` | no |
| <a name="input_cl_function_app_storage_account_backup_vault"></a> [cl\_function\_app\_storage\_account\_backup\_vault](#input\_cl\_function\_app\_storage\_account\_backup\_vault) | The blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_function_app_storage_account_backup_vault_id"></a> [cl\_function\_app\_storage\_account\_backup\_vault\_id](#input\_cl\_function\_app\_storage\_account\_backup\_vault\_id) | The id of blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_function_app_storage_account_blob_retention_days"></a> [cl\_function\_app\_storage\_account\_blob\_retention\_days](#input\_cl\_function\_app\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_function_app_storage_account_bypass"></a> [cl\_function\_app\_storage\_account\_bypass](#input\_cl\_function\_app\_storage\_account\_bypass) | (Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. | `list(string)` | <pre>[<br>  "None"<br>]</pre> | no |
| <a name="input_cl_function_app_storage_account_diagnostics"></a> [cl\_function\_app\_storage\_account\_diagnostics](#input\_cl\_function\_app\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_function_app_storage_account_enable_backup"></a> [cl\_function\_app\_storage\_account\_enable\_backup](#input\_cl\_function\_app\_storage\_account\_enable\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_function_app_storage_account_ip_rules"></a> [cl\_function\_app\_storage\_account\_ip\_rules](#input\_cl\_function\_app\_storage\_account\_ip\_rules) | (Optional) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed. | `list(string)` | `[]` | no |
| <a name="input_cl_function_app_storage_account_kind"></a> [cl\_function\_app\_storage\_account\_kind](#input\_cl\_function\_app\_storage\_account\_kind) | (Optional)  Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. | `string` | `"StorageV2"` | no |
| <a name="input_cl_function_app_storage_account_network_default_action"></a> [cl\_function\_app\_storage\_account\_network\_default\_action](#input\_cl\_function\_app\_storage\_account\_network\_default\_action) | (Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow. | `string` | `"Deny"` | no |
| <a name="input_cl_function_app_storage_account_pe_subnet_ids"></a> [cl\_function\_app\_storage\_account\_pe\_subnet\_ids](#input\_cl\_function\_app\_storage\_account\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_cl_function_app_storage_account_replication_to_LRS"></a> [cl\_function\_app\_storage\_account\_replication\_to\_LRS](#input\_cl\_function\_app\_storage\_account\_replication\_to\_LRS) | If set to true, it overrides the replication to LRS | `bool` | `false` | no |
| <a name="input_cl_function_app_storage_account_rg_name"></a> [cl\_function\_app\_storage\_account\_rg\_name](#input\_cl\_function\_app\_storage\_account\_rg\_name) | (Required) The resource group to deploy the storage account needed for the function app. | `any` | n/a | yes |
| <a name="input_cl_function_app_storage_account_subnet_ids"></a> [cl\_function\_app\_storage\_account\_subnet\_ids](#input\_cl\_function\_app\_storage\_account\_subnet\_ids) | (Required) A list of resource ids for subnets. | `list(string)` | `[]` | no |
| <a name="input_cl_function_app_storage_account_tier"></a> [cl\_function\_app\_storage\_account\_tier](#input\_cl\_function\_app\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for the function app audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_cl_function_app_support_cors_credentials"></a> [cl\_function\_app\_support\_cors\_credentials](#input\_cl\_function\_app\_support\_cors\_credentials) | (Optional) Are credentials supported?. | `bool` | `false` | no |
| <a name="input_cl_function_app_use_32_bit_worker_process"></a> [cl\_function\_app\_use\_32\_bit\_worker\_process](#input\_cl\_function\_app\_use\_32\_bit\_worker\_process) | (Optional) Should the function app run in 32 bit mode, rather than 64 bit mode? | `bool` | `true` | no |
| <a name="input_cl_function_app_version"></a> [cl\_function\_app\_version](#input\_cl\_function\_app\_version) | (Optional) The runtime version associated with the Function App. Defaults to ~1 | `string` | `"~4"` | no |
| <a name="input_cl_function_app_vnet_route_server"></a> [cl\_function\_app\_vnet\_route\_server](#input\_cl\_function\_app\_vnet\_route\_server) | (Optional) Should all outbound traffic to have Virtual Network Security Groups and User Defined Routes applied. | `number` | `1` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
    cl_storage_account_blob_properties           = (var.cl_function_app_storage_account_enable_backup ? false : true)
    cl_function_app_storage_account_name_no_dash = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
    cl_function_app_storage_account_infra_encryption_enabled = (var.cl_function_app_storage_account_kind == "StorageV2" || (var.cl_function_app_storage_account_kind == "BlockBlobStorage" && var.cl_function_app_storage_account_tier == "Premium") ? true : false)
    cl_function_app_storage_account_replication_to_LRS    = (var.cl_function_app_storage_account_replication_to_LRS || var.env == "nprd-pr"  ? true : false ) 
    cl_function_app_storage_account_replication_type      = (var.cl_function_app_storage_account_tier != "Premium" ? "GRS" : "LRS")
    cl_function_app_storage_account_modify_name = {
        "sbox-pr" = "sboxpr"
        "nprd-pr" = "nprdpr"
        "nprd-dr" = "nprddr"
        "prod-pr" = "prodpr"
        "prod-dr" = "proddr"
        "nprod-pr" = "nprodpr"
    }

    cl_function_app_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.us"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.us"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.us"]
    }

    cl_function_app_storage_account_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    }

}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_function_app"></a> [cl\_function\_app](#output\_cl\_function\_app) | n/a |
| <a name="output_cl_function_app_storage_account"></a> [cl\_function\_app\_storage\_account](#output\_cl\_function\_app\_storage\_account) | Outputs ********************************************************************************************** |
| <a name="output_cl_function_app_storage_account_private_endpoint"></a> [cl\_function\_app\_storage\_account\_private\_endpoint](#output\_cl\_function\_app\_storage\_account\_private\_endpoint) | n/a |
| <a name="output_cl_function_app_storage_account_protected_blob"></a> [cl\_function\_app\_storage\_account\_protected\_blob](#output\_cl\_function\_app\_storage\_account\_protected\_blob) | n/a |
| <a name="output_cl_funtion_app_private_endpoint"></a> [cl\_funtion\_app\_private\_endpoint](#output\_cl\_funtion\_app\_private\_endpoint) | n/a |


## Usage
#### Linux Function App (function app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_app_service_plan_gov"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_app_service_plan_os_type                               = var.app_service_plan_os_type
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  tags                                                      = var.tags
}


module "cl_function_app" {
  source                                     = "../dn-tads_tf-azure-component-library/components/cl_function_app_gov"
  env                                        = var.env
  postfix                                    = var.postfix
  location                                   = var.location
  tags                                         = var.tags
  cl_function_app_postfix                    = "testapp"
  cl_function_app_rg_name                    = module.cl_app_service_plan.cl_app_service_plan_rg
  cl_function_app_storage_account_rg_name    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_function_app_asp_id                     = module.cl_app_service_plan.cl_app_service_plan.id
  cl_function_app_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_function_app_os_type                    = "linux"
  cl_function_app_version                    = "~3"
  cl_function_app_integration_subnet_id      = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  cl_function_app_storage_account_subnet_ids = var.cl_function_app_storage_account_subnet_ids
  cl_function_app_storage_account_enable_backup      = true
  cl_function_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_function_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_function_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_function_app_cors_allowed_origins       = ["https://example"]
}
```
#### Windows Function App (function app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_app_service_plan_gov"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_app_service_plan_os_type                                  = var.app_service_plan_os_type
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_app_service_plan_storage_account_nsg_flow_log_id          = var.cl_app_service_plan_storage_account_nsg_flow_log_id
  tags                                                      = var.tags
}


module "cl_function_app" {
  source                                     = "../dn-tads_tf-azure-component-library/components/cl_function_app_gov"
  env                                        = var.env
  postfix                                    = var.postfix
  location                                   = var.location
  tags                                         = var.tags
  cl_function_app_postfix                    = "testapp"
  cl_function_app_rg_name                    = module.cl_app_service_plan.cl_app_service_plan_rg
  cl_function_app_storage_account_rg_name    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_function_app_asp_id                     = module.cl_app_service_plan.cl_app_service_plan.id
  cl_function_app_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_function_app_pe_subnet_ids              = [azurerm_subnet.test_subnet.id]
  cl_function_app_integration_subnet_id      = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  cl_function_app_storage_account_subnet_ids = var.cl_function_app_storage_account_subnet_ids
  cl_function_app_storage_account_enable_backup      = true
  cl_function_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_function_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_function_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_function_app_cors_allowed_origins        = ["https://example"]
}


```
<!-- END_TF_DOCS -->
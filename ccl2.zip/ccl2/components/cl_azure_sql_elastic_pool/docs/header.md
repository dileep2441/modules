# Azure SQL Elastic Pool

Azure SQL Database elastic pools are a simple, cost-effective solution for managing and scaling multiple databases that have varying and unpredictable usage demands. 
The databases in an elastic pool are on a single server and share a set number of resources at a set price.
This component will deploy an Azure SQL Elastic Pool and diagnostic settings. 

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/database/elastic-pool-overview
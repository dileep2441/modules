<!-- BEGIN_TF_DOCS -->

# Azure Backup Component

Azure Backup Server is a backup option for both on-premises and cloud-based workloads in Azure storage. 
This resource leverages vaults (recovery service vaults and backup vaults) in order to store data such as backup copies, recovery points, and backup policies. 
This specific component deploys the Backup Service Vault, VM Backup Policy and diagnostics settings for the Azure Backup.

For more information, please visit: https://docs.microsoft.com/en-us/azure/backup/backup-overview 

For more information, please visit: https://docs.microsoft.com/en-us/azure/backup/backup-overview 



## Resources

| Name | Type |
|------|------|
| [azurerm_backup_policy_file_share.cl_azure_backup_policy_fileshare](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_policy_file_share) | resource |
| [azurerm_backup_policy_vm.cl_azure_backup_policy_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_policy_vm) | resource |
| [azurerm_data_protection_backup_policy_blob_storage.cl_azure_backup_blob_sa_backup_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_policy_blob_storage) | resource |
| [azurerm_data_protection_backup_vault.cl_azure_backup_blob_sa_backup_vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_vault) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_backup_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_azure_backup_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_recovery_services_vault.cl_azure_backup_sv](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/recovery_services_vault) | resource |
| [azurerm_resource_group.cl_azure_backup_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_backup_define_private_dns_zone_ids"></a> [cl\_azure\_backup\_define\_private\_dns\_zone\_ids](#input\_cl\_azure\_backup\_define\_private\_dns\_zone\_ids) | If local var centralized private dns zone is not available, pass in the dns zone id of what you'd like to use | `any` | `null` | no |
| <a name="input_cl_azure_backup_deploy_rsv"></a> [cl\_azure\_backup\_deploy\_rsv](#input\_cl\_azure\_backup\_deploy\_rsv) | If true, deploy rsv. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_diagnostics"></a> [cl\_azure\_backup\_diagnostics](#input\_cl\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_azure_backup_enable_blob_storage_backup"></a> [cl\_azure\_backup\_enable\_blob\_storage\_backup](#input\_cl\_azure\_backup\_enable\_blob\_storage\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_enable_file_storage_backup"></a> [cl\_azure\_backup\_enable\_file\_storage\_backup](#input\_cl\_azure\_backup\_enable\_file\_storage\_backup) | (Optional) Toggle the file storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_enable_vm_backup"></a> [cl\_azure\_backup\_enable\_vm\_backup](#input\_cl\_azure\_backup\_enable\_vm\_backup) | (Optional) Toggle the vm backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_log_analytics_workspace_id"></a> [cl\_azure\_backup\_log\_analytics\_workspace\_id](#input\_cl\_azure\_backup\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_backup_private_dns_zone_ids_exists"></a> [cl\_azure\_backup\_private\_dns\_zone\_ids\_exists](#input\_cl\_azure\_backup\_private\_dns\_zone\_ids\_exists) | Set to true if centralized private dns zone ids are available for use for backup | `bool` | `true` | no |
| <a name="input_cl_azure_backup_retention_daily_count"></a> [cl\_azure\_backup\_retention\_daily\_count](#input\_cl\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_cl_azure_backup_rsv_allowed_subnets"></a> [cl\_azure\_backup\_rsv\_allowed\_subnets](#input\_cl\_azure\_backup\_rsv\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this RSV. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_backup_time"></a> [cl\_azure\_backup\_time](#input\_cl\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_cl_azure_backup_timezone"></a> [cl\_azure\_backup\_timezone](#input\_cl\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  cl_azure_backup_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ugv.backup.windowsazure.us"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ugv.backup.windowsazure.us"]
    "prod-dr" = ["/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ugt.backup.windowsazure.us"]
  }
  timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_backup_blob_sa_backup_policy"></a> [cl\_azure\_backup\_blob\_sa\_backup\_policy](#output\_cl\_azure\_backup\_blob\_sa\_backup\_policy) | n/a |
| <a name="output_cl_azure_backup_blob_sa_backup_vault"></a> [cl\_azure\_backup\_blob\_sa\_backup\_vault](#output\_cl\_azure\_backup\_blob\_sa\_backup\_vault) | n/a |
| <a name="output_cl_azure_backup_diagnostic_setting"></a> [cl\_azure\_backup\_diagnostic\_setting](#output\_cl\_azure\_backup\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_backup_policy_fileshare"></a> [cl\_azure\_backup\_policy\_fileshare](#output\_cl\_azure\_backup\_policy\_fileshare) | n/a |
| <a name="output_cl_azure_backup_policy_vm"></a> [cl\_azure\_backup\_policy\_vm](#output\_cl\_azure\_backup\_policy\_vm) | n/a |
| <a name="output_cl_azure_backup_private_endpoint"></a> [cl\_azure\_backup\_private\_endpoint](#output\_cl\_azure\_backup\_private\_endpoint) | n/a |
| <a name="output_cl_azure_backup_rg"></a> [cl\_azure\_backup\_rg](#output\_cl\_azure\_backup\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_backup_sv"></a> [cl\_azure\_backup\_sv](#output\_cl\_azure\_backup\_sv) | n/a |


## Usage
# Backups for VMs
```terraform
 // Azure Backup
 // IMPORTANT - contributor role on RSV managed identity must be assigned bby cloudops for the following RGs (in order to successfully create RSV private endpoint): spoke vnet rg, rg where pe is to be created and private dns zone rg.
// https://docs.microsoft.com/en-us/azure/backup/private-endpoints
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  tags     = var.tags
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv       = true
  cl_azure_backup_enable_vm_backup = true
  cl_azure_backup_rsv_allowed_subnets        = var.cl_azure_backup_rsv_allowed_subnets
}
//**********************************************************************************************
```

# Backups for File Storage
```terraform
 // Azure Backup
 // IMPORTANT - contributor role on RSV managed identity must be assigned bby cloudops for the following RGs (in order to successfully create RSV private endpoint): spoke vnet rg, rg where pe is to be created and private dns zone rg.
// https://docs.microsoft.com/en-us/azure/backup/private-endpoints
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  tags     = var.tags
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv                 = true
  cl_azure_backup_enable_file_storage_backup = true
  cl_azure_backup_rsv_allowed_subnets        = var.cl_azure_backup_rsv_allowed_subnets
}
//**********************************************************************************************
```

# Backups for Blob Storage
```terraform
 // Azure Backup
// IMPORTANT: Must assign the blob storage backup vault "Storage Account Backup Contributor" role on the blob storage account. 
// https://docs.microsoft.com/en-us/azure/backup/blob-backup-configure-manage#grant-permissions-to-the-backup-vault-on-storage-accounts 
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  tags     = var.tags
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_backup_enable_blob_storage_backup = true
}
//**********************************************************************************************
```

 
<!-- END_TF_DOCS -->
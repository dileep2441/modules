
## Usage   UPDATE BELOW ONCE TAD IS RECIEVED

```terraform
// Deploy Postgres Server
//**********************************************************************************************
module "cl_postgresdb" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_postgres_sql_server_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_postgres_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_postgres_sql_server_admin_login                          = "adminsql"
  cl_postgres_sql_server_admin_password                       = "Abc1234567890."
  cl_postgres_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_postgres_sql_server_network_rg                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_postgres_sql_server_vnet_id                              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  cl_postgres_sql_server_vnet_name                            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_postgres_sql_server_pe_subnet_id                         = azurerm_subnet.cl_private_endpoint_subnet.id
  cl_postgres_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.cl_azure_private_dns_zone_db.id]
}
//**********************************************************************************************

// Deploy Postgres database
//**********************************************************************************************
module "cl_postgresdatabase" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_postgres_sql_database_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_postgres_sql_server_resource_group_name       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_postgres_sql_server                           = module.cl_postgresdb.cl_postgres_sql_server.name
  cl_postgres_sql_database_postfix                 = "dbname"
}
//**********************************************************************************************

// Deploy Azure DNS Private Zone for db.
// This allows to connect to the DB via dns name.
// **********************************************************************************************
resource "azurerm_private_dns_zone" "cl_azure_private_dns_zone_db" {
  name                = "privatelink.postgres.database.usgovcloudapi.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
}
//**********************************************************************************************

// Link DB DNS zone to Virtual Network
// ************************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "cl_linkdnstosubnet_db" {
  name                  = "linkdb"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cl_azure_private_dns_zone_db.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
}
//**********************************************************************************************

// Deploy Subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "cl_private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  address_prefixes                                   = ["60.0.3.0/24"]
  enforce_private_link_endpoint_network_policies     = true
}
//**********************************************************************************************
```

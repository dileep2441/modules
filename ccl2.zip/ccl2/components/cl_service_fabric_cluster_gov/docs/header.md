# Service Fabric cluster Component

Azure Service Fabric is a distributed system platform that makes it easy to package, deploy and manage scalable and reliable microservices and containers.
This component will deploy just the Azure Service Fabric Cluster.

For more information, please visit: https://learn.microsoft.com/en-us/azure/service-fabric/

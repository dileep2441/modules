<!-- BEGIN_TF_DOCS -->

# Service Fabric cluster Component

Azure Service Fabric is a distributed system platform that makes it easy to package, deploy and manage scalable and reliable microservices and containers.
This component will deploy just the Azure Service Fabric Cluster.

For more information, please visit: https://learn.microsoft.com/en-us/azure/service-fabric/



## Resources

| Name | Type |
|------|------|
| [azurerm_service_fabric_cluster.cl_service_fabric_cluster](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_fabric_cluster) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_service_fabric_active_directory_enabled"></a> [cl\_service\_fabric\_active\_directory\_enabled](#input\_cl\_service\_fabric\_active\_directory\_enabled) | n/a | `bool` | `false` | no |
| <a name="input_cl_service_fabric_active_directory_tenant_id"></a> [cl\_service\_fabric\_active\_directory\_tenant\_id](#input\_cl\_service\_fabric\_active\_directory\_tenant\_id) | n/a | `string` | `""` | no |
| <a name="input_cl_service_fabric_application_ports"></a> [cl\_service\_fabric\_application\_ports](#input\_cl\_service\_fabric\_application\_ports) | n/a | <pre>object({<br>  start_port = number<br>  end_port   = number<br>  })</pre> | `null` | no |
| <a name="input_cl_service_fabric_client_application_id"></a> [cl\_service\_fabric\_client\_application\_id](#input\_cl\_service\_fabric\_client\_application\_id) | n/a | `string` | `""` | no |
| <a name="input_cl_service_fabric_client_cert_thumbprint"></a> [cl\_service\_fabric\_client\_cert\_thumbprint](#input\_cl\_service\_fabric\_client\_cert\_thumbprint) | n/a | `string` | `null` | no |
| <a name="input_cl_service_fabric_client_endpoint_port"></a> [cl\_service\_fabric\_client\_endpoint\_port](#input\_cl\_service\_fabric\_client\_endpoint\_port) | n/a | `number` | `2020` | no |
| <a name="input_cl_service_fabric_cluster_application_id"></a> [cl\_service\_fabric\_cluster\_application\_id](#input\_cl\_service\_fabric\_cluster\_application\_id) | n/a | `string` | `""` | no |
| <a name="input_cl_service_fabric_cluster_code_version"></a> [cl\_service\_fabric\_cluster\_code\_version](#input\_cl\_service\_fabric\_cluster\_code\_version) | n/a | `string` | `"9.1.1436.9590"` | no |
| <a name="input_cl_service_fabric_cluster_image_type"></a> [cl\_service\_fabric\_cluster\_image\_type](#input\_cl\_service\_fabric\_cluster\_image\_type) | Image types, possible values are Windows and Linux | `string` | `"Windows"` | no |
| <a name="input_cl_service_fabric_cluster_postfix"></a> [cl\_service\_fabric\_cluster\_postfix](#input\_cl\_service\_fabric\_cluster\_postfix) | (Required) A string that is appended to the end of the cluster name to identify it. | `string` | n/a | yes |
| <a name="input_cl_service_fabric_cluster_reliability_level"></a> [cl\_service\_fabric\_cluster\_reliability\_level](#input\_cl\_service\_fabric\_cluster\_reliability\_level) | (Required) Reliability Level possible None,Broze,Silver,Gold,Platinum | `string` | `"Silver"` | no |
| <a name="input_cl_service_fabric_cluster_resource_group_name"></a> [cl\_service\_fabric\_cluster\_resource\_group\_name](#input\_cl\_service\_fabric\_cluster\_resource\_group\_name) | (Required) Service Fabric Cluster Resource Group Name | `string` | n/a | yes |
| <a name="input_cl_service_fabric_diagnostics"></a> [cl\_service\_fabric\_diagnostics](#input\_cl\_service\_fabric\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "OperationalLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_service_fabric_ephemeral_ports"></a> [cl\_service\_fabric\_ephemeral\_ports](#input\_cl\_service\_fabric\_ephemeral\_ports) | n/a | <pre>object({<br>  start_port = number<br>  end_port   = number<br>  })</pre> | `null` | no |
| <a name="input_cl_service_fabric_http_endpoint_port"></a> [cl\_service\_fabric\_http\_endpoint\_port](#input\_cl\_service\_fabric\_http\_endpoint\_port) | n/a | `number` | `80` | no |
| <a name="input_cl_service_fabric_managed_endpoint"></a> [cl\_service\_fabric\_managed\_endpoint](#input\_cl\_service\_fabric\_managed\_endpoint) | Management endpoint for the cluster | `string` | n/a | yes |
| <a name="input_cl_service_fabric_node_durability_level"></a> [cl\_service\_fabric\_node\_durability\_level](#input\_cl\_service\_fabric\_node\_durability\_level) | n/a | `string` | `"Silver"` | no |
| <a name="input_cl_service_fabric_primary_node_count"></a> [cl\_service\_fabric\_primary\_node\_count](#input\_cl\_service\_fabric\_primary\_node\_count) | n/a | `number` | `5` | no |
| <a name="input_cl_service_fabric_reverse_proxy_cert_thumbprint"></a> [cl\_service\_fabric\_reverse\_proxy\_cert\_thumbprint](#input\_cl\_service\_fabric\_reverse\_proxy\_cert\_thumbprint) | n/a | `string` | `null` | no |
| <a name="input_cl_service_fabric_reverse_proxy_port"></a> [cl\_service\_fabric\_reverse\_proxy\_port](#input\_cl\_service\_fabric\_reverse\_proxy\_port) | n/a | `number` | `null` | no |
| <a name="input_cl_service_fabric_reverse_proxy_x509_store_name"></a> [cl\_service\_fabric\_reverse\_proxy\_x509\_store\_name](#input\_cl\_service\_fabric\_reverse\_proxy\_x509\_store\_name) | n/a | `string` | `"My"` | no |
| <a name="input_cl_service_fabric_thumbprint"></a> [cl\_service\_fabric\_thumbprint](#input\_cl\_service\_fabric\_thumbprint) | n/a | `string` | `null` | no |
| <a name="input_cl_service_fabric_x509_store_name"></a> [cl\_service\_fabric\_x509\_store\_name](#input\_cl\_service\_fabric\_x509\_store\_name) | n/a | `string` | `"My"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to the resource | `map(string)` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_service_fabric_cluster"></a> [cl\_service\_fabric\_cluster](#output\_cl\_service\_fabric\_cluster) | Outputs ********************************************************************************************** |


## Usage   UPDATE BELOW ONCE TAD IS RECIEVED

```terraform
// Deploy Postgres Server
//**********************************************************************************************
module "cl_postgresdb" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_postgres_sql_server_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_postgres_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_postgres_sql_server_admin_login                          = "adminsql"
  cl_postgres_sql_server_admin_password                       = "Abc1234567890."
  cl_postgres_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_postgres_sql_server_network_rg                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_postgres_sql_server_vnet_id                              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  cl_postgres_sql_server_vnet_name                            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_postgres_sql_server_pe_subnet_id                         = azurerm_subnet.cl_private_endpoint_subnet.id
  cl_postgres_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.cl_azure_private_dns_zone_db.id]
}
//**********************************************************************************************

// Deploy Postgres database
//**********************************************************************************************
module "cl_postgresdatabase" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_postgres_sql_database_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_postgres_sql_server_resource_group_name       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_postgres_sql_server                           = module.cl_postgresdb.cl_postgres_sql_server.name
  cl_postgres_sql_database_postfix                 = "dbname"
}
//**********************************************************************************************

// Deploy Azure DNS Private Zone for db.
// This allows to connect to the DB via dns name.
// **********************************************************************************************
resource "azurerm_private_dns_zone" "cl_azure_private_dns_zone_db" {
  name                = "privatelink.postgres.database.usgovcloudapi.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
}
//**********************************************************************************************

// Link DB DNS zone to Virtual Network
// ************************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "cl_linkdnstosubnet_db" {
  name                  = "linkdb"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cl_azure_private_dns_zone_db.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
}
//**********************************************************************************************

// Deploy Subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "cl_private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  address_prefixes                                   = ["60.0.3.0/24"]
  enforce_private_link_endpoint_network_policies     = true
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->

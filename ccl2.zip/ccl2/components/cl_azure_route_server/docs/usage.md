## Usage

```terraform
// Deploy Azure Route Server
//**********************************************************************************************
  module "cl_azure_route_server" {
     source                                    = "../dn-tads_tf-azure-component-library/components/cl_azure_route_server"
     env                                       = var.env
     postfix                                   = var.postfix
     location                                  = var.location
     suffix                                    = var.suffix
     cl_azure_route_server_rg_name             = var.cl_azure_route_server_rg_name
     cl_azure_routeserver_vnet_rg_name         = var.cl_azure_routeserver_vnet_rg_name
     cl_azure_routeserver_vnet_name            = var.cl_azure_routeserver_vnet_name
     cl_azure_routeserver_subnet_prefix        = ["10.X.X.X/27"]
     cl_azure_routeserver_deploy_subnet        = true
     cl_azure_routeserver_bgp_connections      = var.cl_azure_routeserver_bgp_connections
  }
//**********************************************************************************************
```
## Local values

```terraform
locals {
  timeout_duration             = "2h"
  cl_azure_route_server_rg     = var.cl_azure_route_server_deploy_rg ? azurerm_resource_group.cl_azure_route_server_rg[0].name : var.cl_azure_route_server_rg_name
  cl_azure_route_server_subnet = var.cl_azure_routeserver_deploy_subnet ? azurerm_subnet.cl_azure_routeserver_subnet[0].id : var.cl_azure_route_server_subnet_id
}
```


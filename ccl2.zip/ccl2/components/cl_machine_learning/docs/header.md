# Azure Machine Learning workspace

**Azure Machine Learning** is a cloud service for accelerating and managing the machine learning project lifecycle. Machine learning professionals, data scientists, and engineers can use it in their day-to-day workflows: Train and deploy models, and manage MLOps.

You can create a model in Azure Machine Learning or use a model built from an open-source platform, such as Pytorch, TensorFlow, or scikit-learn. MLOps tools help you monitor, retrain, and redeploy models.

**Workspaces** are places to collaborate with colleagues and group related work. For example, experiments, jobs, datasets, components, and inference endpoints.

We recommend creating a workspace per project. While a workspace can be used for multiple projects, limiting it to one project per workspace allows for cost reporting accrued to a project level. It also allows you to manage configurations like datastores in the scope of each project.

## Working with a workspace
Machine learning tasks read and/or write artifacts to your workspace.

- Run an experiment to train a model - writes job run results to the workspace.
- Use automated ML to train a model - writes training results to the workspace.
- Register a model in the workspace.
- Deploy a model - uses the registered model to create a deployment.
- Create and run reusable workflows.
- View machine learning artifacts such as jobs, pipelines, models, deployments.
- Track and monitor models.
- You can share assets between workspaces using Azure Machine Learning registries (preview).




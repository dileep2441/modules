<!-- BEGIN_TF_DOCS -->

# Postgresql Server Component

Azure Database for PostgreSQL Single Server is a fully managed database service. 
This server platform is designed to handle most of the database management functions such as patching, backups, high availability, security with minimal user configuration and control. 
This component will deploy Azure Postgresql Server, private endpoint and diagnostic settings for the server.

For more information, please visit: https://docs.microsoft.com/en-us/azure/postgresql/overview 



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_postgres_sql_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_postgresql_server.cl_postgres_sql_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_server) | resource |
| [azurerm_private_endpoint.cl_postgresql_server_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_postgres_sql_server_admin_login"></a> [cl\_postgres\_sql\_server\_admin\_login](#input\_cl\_postgres\_sql\_server\_admin\_login) | (Required) Login to authenticate to PostgreSQL Server | `string` | n/a | yes |
| <a name="input_cl_postgres_sql_server_admin_password"></a> [cl\_postgres\_sql\_server\_admin\_password](#input\_cl\_postgres\_sql\_server\_admin\_password) | (Required) Password to authenticate to PostgreSQL Server | `string` | n/a | yes |
| <a name="input_cl_postgres_sql_server_auto_grow_enabled"></a> [cl\_postgres\_sql\_server\_auto\_grow\_enabled](#input\_cl\_postgres\_sql\_server\_auto\_grow\_enabled) | (Optional) Enable grow database as needed. | `bool` | `false` | no |
| <a name="input_cl_postgres_sql_server_backup_retention_days"></a> [cl\_postgres\_sql\_server\_backup\_retention\_days](#input\_cl\_postgres\_sql\_server\_backup\_retention\_days) | (Optional) Number of backup retention days. | `number` | `21` | no |
| <a name="input_cl_postgres_sql_server_diagnostic"></a> [cl\_postgres\_sql\_server\_diagnostic](#input\_cl\_postgres\_sql\_server\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "PostgreSQLLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_postgres_sql_server_geo_redundant_backup_enabled"></a> [cl\_postgres\_sql\_server\_geo\_redundant\_backup\_enabled](#input\_cl\_postgres\_sql\_server\_geo\_redundant\_backup\_enabled) | (Optional) Enable or disable georedundant backup. | `bool` | `false` | no |
| <a name="input_cl_postgres_sql_server_log_analytics_workspace_id"></a> [cl\_postgres\_sql\_server\_log\_analytics\_workspace\_id](#input\_cl\_postgres\_sql\_server\_log\_analytics\_workspace\_id) | (Required) The ID for the network resources | `any` | n/a | yes |
| <a name="input_cl_postgres_sql_server_pe_subnet_ids"></a> [cl\_postgres\_sql\_server\_pe\_subnet\_ids](#input\_cl\_postgres\_sql\_server\_pe\_subnet\_ids) | (Required) The subnet ids where the private endoint will be created. | `list` | `[]` | no |
| <a name="input_cl_postgres_sql_server_private_dns_zone_ids"></a> [cl\_postgres\_sql\_server\_private\_dns\_zone\_ids](#input\_cl\_postgres\_sql\_server\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_postgres_sql_server_public_network_access_enabled"></a> [cl\_postgres\_sql\_server\_public\_network\_access\_enabled](#input\_cl\_postgres\_sql\_server\_public\_network\_access\_enabled) | (Optional) Enable or disable access from public network. | `bool` | `false` | no |
| <a name="input_cl_postgres_sql_server_resource_group_name"></a> [cl\_postgres\_sql\_server\_resource\_group\_name](#input\_cl\_postgres\_sql\_server\_resource\_group\_name) | (Required) Specifies the Azure SQL Server resource group | `any` | n/a | yes |
| <a name="input_cl_postgres_sql_server_sku_name"></a> [cl\_postgres\_sql\_server\_sku\_name](#input\_cl\_postgres\_sql\_server\_sku\_name) | PostgreSQL SKU Name | `string` | `"GP_Gen5_4"` | no |
| <a name="input_cl_postgres_sql_server_ssl_enforcement_enabled"></a> [cl\_postgres\_sql\_server\_ssl\_enforcement\_enabled](#input\_cl\_postgres\_sql\_server\_ssl\_enforcement\_enabled) | (Optional) Enable or disable ssl. | `bool` | `true` | no |
| <a name="input_cl_postgres_sql_server_ssl_minimal_tls_version_enforced"></a> [cl\_postgres\_sql\_server\_ssl\_minimal\_tls\_version\_enforced](#input\_cl\_postgres\_sql\_server\_ssl\_minimal\_tls\_version\_enforced) | (Optional) Minimun version of TLS. | `string` | `"TLS1_2"` | no |
| <a name="input_cl_postgres_sql_server_storage"></a> [cl\_postgres\_sql\_server\_storage](#input\_cl\_postgres\_sql\_server\_storage) | PostgreSQL Storage in MB | `string` | `"10240"` | no |
| <a name="input_cl_postgres_sql_server_version"></a> [cl\_postgres\_sql\_server\_version](#input\_cl\_postgres\_sql\_server\_version) | PostgreSQL Server version to deploy | `string` | `"11"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_postgres_sql_diagnostic_setting"></a> [cl\_postgres\_sql\_diagnostic\_setting](#output\_cl\_postgres\_sql\_diagnostic\_setting) | n/a |
| <a name="output_cl_postgres_sql_server"></a> [cl\_postgres\_sql\_server](#output\_cl\_postgres\_sql\_server) | Outputs ********************************************************************************************** |
| <a name="output_cl_postgres_sql_server_private_endpoint"></a> [cl\_postgres\_sql\_server\_private\_endpoint](#output\_cl\_postgres\_sql\_server\_private\_endpoint) | n/a |

## Usage

```terraform
// Deploy Postgres Server
//**********************************************************************************************
module "cl_postgres_sql_server" {
  source                                                      = "../tf-azure-component-library/components/cl_postgres_sql_server"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  cl_postgres_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_postgres_sql_server_admin_login                          = "adminsql"
  cl_postgres_sql_server_admin_password                       = "Abc1234567890."
  cl_postgres_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_postgres_sql_server_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_postgres_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.cl_azure_private_dns_zone_db.id]
}
//**********************************************************************************************


// Deploy Azure DNS Private Zone for db.
// This allows to connect to the DB via dns name.
// **********************************************************************************************
resource "azurerm_private_dns_zone" "cl_azure_private_dns_zone_db" {
  name                = "privatelink.postgres.database.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}
//**********************************************************************************************

// Link DB DNS zone to Virtual Network
// ************************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "cl_linkdnstosubnet_db" {
  name                  = "linkdb"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cl_azure_private_dns_zone_db.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//**********************************************************************************************

// Deploy Subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "cl_private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                   = ["60.0.3.0/24"]
  enforce_private_link_endpoint_network_policies     = true
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
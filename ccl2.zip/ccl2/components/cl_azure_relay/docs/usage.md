

## Usage

```terraform
module "cl_azure_relay" {
  source                                   = "../dn-tads_tf-azure-component-library/components/cl_azure_relay_gov"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  //Common variables
  cl_azure_relay_rg_name     = var.azure_relay_rg_name
  cl_azure_relay_postfix     = var.azure_relay_postfix
  cl_azure_relay_allowed_ips = var.azure_relay_allowed_ips
  //Namespace specific variables
  cl_azure_relay_ns_sku_name    = var.azure_relay_ns_sku_name
  cl_azure_relay_ns_auth_listen = var.azure_relay_ns_auth_listen
  cl_azure_relay_ns_auth_send   = var.azure_relay_ns_auth_send
  cl_azure_relay_ns_auth_manage = var.azure_relay_ns_auth_manage
  //Hybrid Connection Specific variables
  cl_azure_relay_hybrid_connections = var.azure_relay_hybrid_connections
  // Private Endpoint Variables
  cl_azure_relay_allowed_subnets      = var.azure_relay_allowed_subnets
  cl_azure_relay_private_dns_zone_ids = var.azure_relay_private_dns_zone_ids
  // Diagnostics variables
  cl_azure_relay_log_analytics_workspace_id = azurerm_log_analytics_workspace.log_analytics_workspace.id
  cl_azure_relay_diagnostics                = var.azure_relay_diagnostics
  //Org Specific Variables
  tags = var.tags
}
```
<!-- BEGIN_TF_DOCS -->

# Azure Relay Component

The Azure Relay service enables you to securely expose services that run in your corporate network to the public cloud. You can do so without opening a port on your firewall, or making intrusive changes to your corporate network infrastructure.

The relay service supports the following scenarios between on-premises services and applications running in the cloud or in another on-premises environment.
- Traditional one-way, request/response, and peer-to-peer communication
- Event distribution at internet-scope to enable publish/subscribe scenarios
- Bi-directional and unbuffered socket communication across network boundaries

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-relay/



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_azure_relay_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_azure_relay_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_relay_hybrid_connection.cl_azure_relay_hyb_conn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/relay_hybrid_connection) | resource |
| [azurerm_relay_hybrid_connection_authorization_rule.cl_azure_relay_hyb_conn_auth](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/relay_hybrid_connection_authorization_rule) | resource |
| [azurerm_relay_namespace.cl_azure_relay_ns](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/relay_namespace) | resource |
| [azurerm_relay_namespace_authorization_rule.cl_azure_relay_ns_auth](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/relay_namespace_authorization_rule) | resource |
| [azurerm_resource_group.cl_azure_relay_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_relay_allowed_subnets"></a> [cl\_azure\_relay\_allowed\_subnets](#input\_cl\_azure\_relay\_allowed\_subnets) | (Required) The id of the relay subnet id. | `list(string)` | n/a | yes |
| <a name="input_cl_azure_relay_deploy_rg"></a> [cl\_azure\_relay\_deploy\_rg](#input\_cl\_azure\_relay\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the Azure Relay Service. | `bool` | `true` | no |
| <a name="input_cl_azure_relay_diagnostics"></a> [cl\_azure\_relay\_diagnostics](#input\_cl\_azure\_relay\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "HybridConnectionsEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_relay_hybrid_connections"></a> [cl\_azure\_relay\_hybrid\_connections](#input\_cl\_azure\_relay\_hybrid\_connections) | (Optional) Define hybrid connections for the Azure Relay namespace. | <pre>map(object({<br>    name                          = string<br>    requires_client_authorization = bool<br>    connection_metadata           = string<br>    connection_auth_listen        = bool<br>    connection_auth_send          = bool<br>    connection_auth_manage        = bool<br><br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_relay_log_analytics_workspace_id"></a> [cl\_azure\_relay\_log\_analytics\_workspace\_id](#input\_cl\_azure\_relay\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_relay_ns_auth_listen"></a> [cl\_azure\_relay\_ns\_auth\_listen](#input\_cl\_azure\_relay\_ns\_auth\_listen) | (Optional) Grants listen access to this Authorization Rule | `bool` | `false` | no |
| <a name="input_cl_azure_relay_ns_auth_manage"></a> [cl\_azure\_relay\_ns\_auth\_manage](#input\_cl\_azure\_relay\_ns\_auth\_manage) | (Optional) Grants manage access to this Authorization Rule | `bool` | `false` | no |
| <a name="input_cl_azure_relay_ns_auth_send"></a> [cl\_azure\_relay\_ns\_auth\_send](#input\_cl\_azure\_relay\_ns\_auth\_send) | (Optional) Grants send access to this Authorization Rule | `bool` | `false` | no |
| <a name="input_cl_azure_relay_ns_sku_name"></a> [cl\_azure\_relay\_ns\_sku\_name](#input\_cl\_azure\_relay\_ns\_sku\_name) | (Required) The name of the SKU to use | `string` | `"Standard"` | no |
| <a name="input_cl_azure_relay_postfix"></a> [cl\_azure\_relay\_postfix](#input\_cl\_azure\_relay\_postfix) | (Required) The postfix value to be used for diferenciating resources created in azure | `string` | `"AZ-RELAY_DEFAULT"` | no |
| <a name="input_cl_azure_relay_private_dns_zone_ids"></a> [cl\_azure\_relay\_private\_dns\_zone\_ids](#input\_cl\_azure\_relay\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_relay_rg_name"></a> [cl\_azure\_relay\_rg\_name](#input\_cl\_azure\_relay\_rg\_name) | (Optional) The name of the resource group in which to create the Azure Relay Namespace. | `any` | `null` | no |
| <a name="input_cl_private_endpoint_subresource_names"></a> [cl\_private\_endpoint\_subresource\_names](#input\_cl\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "namespace"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_azure_relay_rg_name     = var.cl_azure_relay_deploy_rg ? azurerm_resource_group.cl_azure_relay_rg[0].name : var.cl_azure_relay_rg_name
  cl_azure_relay_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.usgovcloudapi.net"]
  }
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_relay_diagnostic_setting"></a> [cl\_azure\_relay\_diagnostic\_setting](#output\_cl\_azure\_relay\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_relay_hyb_conn"></a> [cl\_azure\_relay\_hyb\_conn](#output\_cl\_azure\_relay\_hyb\_conn) | n/a |
| <a name="output_cl_azure_relay_hyb_conn_auth"></a> [cl\_azure\_relay\_hyb\_conn\_auth](#output\_cl\_azure\_relay\_hyb\_conn\_auth) | n/a |
| <a name="output_cl_azure_relay_ns"></a> [cl\_azure\_relay\_ns](#output\_cl\_azure\_relay\_ns) | Outputs *********************************************************** |
| <a name="output_cl_azure_relay_ns_auth"></a> [cl\_azure\_relay\_ns\_auth](#output\_cl\_azure\_relay\_ns\_auth) | n/a |
| <a name="output_cl_azure_relay_private_endpoint"></a> [cl\_azure\_relay\_private\_endpoint](#output\_cl\_azure\_relay\_private\_endpoint) | n/a |



## Usage

```terraform
module "cl_azure_relay" {
  source                                   = "../dn-tads_tf-azure-component-library/components/cl_azure_relay_gov"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  //Common variables
  cl_azure_relay_rg_name     = var.azure_relay_rg_name
  cl_azure_relay_postfix     = var.azure_relay_postfix
  cl_azure_relay_allowed_ips = var.azure_relay_allowed_ips
  //Namespace specific variables
  cl_azure_relay_ns_sku_name    = var.azure_relay_ns_sku_name
  cl_azure_relay_ns_auth_listen = var.azure_relay_ns_auth_listen
  cl_azure_relay_ns_auth_send   = var.azure_relay_ns_auth_send
  cl_azure_relay_ns_auth_manage = var.azure_relay_ns_auth_manage
  //Hybrid Connection Specific variables
  cl_azure_relay_hybrid_connections = var.azure_relay_hybrid_connections
  // Private Endpoint Variables
  cl_azure_relay_allowed_subnets      = var.azure_relay_allowed_subnets
  cl_azure_relay_private_dns_zone_ids = var.azure_relay_private_dns_zone_ids
  // Diagnostics variables
  cl_azure_relay_log_analytics_workspace_id = azurerm_log_analytics_workspace.log_analytics_workspace.id
  cl_azure_relay_diagnostics                = var.azure_relay_diagnostics
  //Org Specific Variables
  tags = var.tags
}
```
<!-- END_TF_DOCS -->
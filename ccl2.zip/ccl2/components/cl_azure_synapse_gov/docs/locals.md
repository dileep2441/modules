## Local values

```terraform
locals {
  timeout_duration = "2h" 
  cl_azure_synapse_sql_private_dns_zone_id = {
    "nprd-pr"  = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.sql.azuresynapse.usgovcloudapi.net"]
    "prod-pr"  = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.sql.azuresynapse.usgovcloudapi.net"]
    "prod-dr"  = ["/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.sql.azuresynapse.usgovcloudapi.net"]
  }
  cl_azure_synapse_dev_private_dns_zone_id = {
    "nprd-pr"  = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.dev.azuresynapse.usgovcloudapi.net"]
    "prod-pr"  = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.dev.azuresynapse.usgovcloudapi.net"]
    "prod-dr"  = ["/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.dev.azuresynapse.usgovcloudapi.net"]
  }
  cl_azure_synapse_storage_account_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
  }
}
```


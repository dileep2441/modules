
## Information
## Enabled extended auditing policy to Azure Synpase Workspace and Sql Pool's:
```terraform
1. Deploy the infrastructure to Azure Synpase
3. Before to deploy the extended_auditing_policy, with a Admin CloudOps request the role assignment to the Storage Account created for audit in component Azure Synapse
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/ to manage identity for Azure Synapse name
4. Add the variable to enabled the deploy for the extended_auditing_policy in Azure Synapse Workspace and Sql Pool's
   
   cl_azure_synapse_enabled_audit_security_logs = true
```
## Usage
```terraform
module "cl_azure_synapse" {
  source                                                = "../dn-tads_tf-azure-component-library/components/cl_azure_synapse_gov"
  env                                                   = var.env
  postfix                                               = var.postfix
  location                                              = var.location
  tags                                                    = var.tags
  cl_azure_synapse_postfix                              = "tst"
  cl_azure_synapse_resource_group_name                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_azure_synapse_virtual_network_id                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  cl_azure_synapse_subnet_id                            = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
  cl_azure_synapse_keyvault_id                          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_keyvault[0].cl_keyvault.id
  cl_azure_synapse_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_synapse_storage_data_lake_gen2_filesystem_id = module.cl_datalake.cl_datalake_filesystem.id
  cl_azure_synapse_storage_account_allowed_ips          = var.cl_azure_synapse_storage_account_allowed_ips
  cl_azure_synapse_keyvault_secret_expiry_date          = "2111-12-31T00:00:00Z"
  cl_azure_synapse_storage_account_subnet_ids           = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
  cl_azure_synapse_firewall_rules                       = {
  allow_internal_usage = {
      start_ip = "x.x.x.x"
        end_ip   = "x.x.x.x"
  }
} 
  cl_azure_synapse_sql_pool                             = {
        pool1 = {
          name                 = "dedicatedpool01"
          sku_name             = "DW300c"
          create_mode          = "Default"
          collation            = "SQL_Latin1_General_CP1_CI_AS"
          data_encrypted       = "true"
          }
  }

  #this is an example if the project requiere to integrate a resource with a manage private endpoint
  #Resources availables to integrate with Azure Synapse: Azure Blob Storage, Azure Cosmos DB(MongoDB API),Azure Cosmos DB (SQL API), Azure Data Explorer (Kusto),Azure Data Lake Storage Gen2, Azure Database for MariaDB, Azure Database for MySQL, Azure Database for PostgreSQL, Azure Event Hubs, Azure File Storage, Azure Funtion, Azure Key Vault, Azure Machine Learning, Azure Monitor Private Link Scope, Azure Queue Storage, Azure SQL Database, Azure Sql Database Managed Instance, Azure Search, Azure Synapse Analytics, Azure Table Storage, Cognitive Services, Microsoft Purview and Private Link Service
  cl_azure_synapse_manage_private_endpoint = {
    manage_pe_1 = {
        name = "dlsa"
        target_resource_id = "/subscriptions/b4978763-1ea7-4bae-b6ad-01df69b38dad/resourceGroups/rg-nprd-pr-gov-dlab-data/providers/Microsoft.Storage/storageAccounts/sansgnprdprgovdlabgvnp"
        subresource_name = "blob"
    }
  }
}
```

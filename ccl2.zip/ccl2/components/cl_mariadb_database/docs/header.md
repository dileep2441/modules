# Azure Database for MariaDB servers

Azure Database for MariaDB is a relational database service based on the open-source MariaDB Server engine. 
It's a fully managed database as a service offering that can handle mission-critical workloads with predictable performance and dynamic scalability.  
This component deploys just the mariadb database.

For more information, please visit: https://docs.microsoft.com/en-us/azure/mariadb/ 

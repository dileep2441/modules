## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```


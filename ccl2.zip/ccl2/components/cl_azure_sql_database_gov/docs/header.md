# Azure SQL Database Component

Azure SQL Database is a fully managed platform as a service (PaaS) database engine that handles most of the database management functions such as upgrading, patching, backups, and monitoring without user involvement. 
This component will deploy an Azure SQL Database, audit policy and a diagnostic settings for the Azure SQL Database.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview

# TF Remote State Storage Account Selected Network Access & PE
```terraform
This component code is to enable selected netowrk access and PE connection on terraform remote state storage account.
```
## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_azure_bastion_rg  = var.cl_azure_bastion_enable ? azurerm_resource_group.cl_azure_bastion_rg[0].name : var.cl_azure_bastion_rg_name
  cl_azure_bastion_sku = var.cl_azure_bastion_centralized_enable ? "Standard" : "Basic" 
   az_bastion_public_ip_diagnotics_settingss = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
```
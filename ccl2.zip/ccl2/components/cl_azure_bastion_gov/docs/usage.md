

## Usage

```terraform
// Azure Bastion Centralized
//**********************************************************************************************
module "sharedsvcs_azure_bastion" {
  source                        = "../dn-tads_tf-azure-component-library/components/cl_azure_bastion_gov"
  env                           = var.env
  postfix                       = var.postfix
  location                      = var.location
  tags                          = var.tags
  cl_azure_bastion_enable       = true
  cl_azure_bastion_centralized_enable = true
  cl_azure_bastion_vnet_name    = azurerm_virtual_network.sharedsvcs_vnet.name
  cl_azure_bastion_vnet_rg_name = azurerm_resource_group.sharedsvcs_rg_network.name
  cl_azure_bastion_subnet_prefix = var.sharedsvcs_bastion_sub_address_prefix
  cl_azure_bastion_log_analytics_workspace_id                    = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_bastion_storage_account_nsg_flow_log_id               = var.cl_azure_bastion_storage_account_nsg_flow_log_id
  cl_azure_bastion_nsg_flow_log_postfix                          = var.cl_azure_bastion_nsg_flow_log_postfix 
}
//**********************************************************************************************
```
<!-- BEGIN_TF_DOCS -->

# Azure Bastion Component

Azure Bastion allows to RDP/SSH into a virtual machine without the need for a public IP on the VM (thus enforces secure access). 
This component will create an Azure Bastion and deploy the following for that resource: NSG, NSG inbound & outbound rules, additional security rules and diagnostic settings.

For more information, please visit:  https://docs.microsoft.com/en-us/azure/bastion/bastion-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_bastion_host.cl_azure_bastion_host](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/bastion_host) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_bastion_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_bastion_pip_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_azure_bastion_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowAzureCloudOutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowAzureLoadBalancerInbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowBastionCommunication](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowBastionHostCommunication](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowGatewayManagerInbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowGetSesssion](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowHttpsInbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowSshRdpOutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_watcher_flow_log.cl_azure_bastion_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_public_ip.cl_azure_bastion_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_resource_group.cl_azure_bastion_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subnet.cl_azure_bastion_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_azure_bastion_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_bastion_centralized_enable"></a> [cl\_azure\_bastion\_centralized\_enable](#input\_cl\_azure\_bastion\_centralized\_enable) | (Required) Enable the creation of a centralized bastion | `bool` | `false` | no |
| <a name="input_cl_azure_bastion_core_sa_enabled"></a> [cl\_azure\_bastion\_core\_sa\_enabled](#input\_cl\_azure\_bastion\_core\_sa\_enabled) | (Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs. | `bool` | `true` | no |
| <a name="input_cl_azure_bastion_diagnostics"></a> [cl\_azure\_bastion\_diagnostics](#input\_cl\_azure\_bastion\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "BastionAuditLogs"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_azure_bastion_enable"></a> [cl\_azure\_bastion\_enable](#input\_cl\_azure\_bastion\_enable) | (Required) Enable the creation for azure bastion | `bool` | `true` | no |
| <a name="input_cl_azure_bastion_log_analytics_workspace_id"></a> [cl\_azure\_bastion\_log\_analytics\_workspace\_id](#input\_cl\_azure\_bastion\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_bastion_nsg_flow_log_postfix"></a> [cl\_azure\_bastion\_nsg\_flow\_log\_postfix](#input\_cl\_azure\_bastion\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | n/a | yes |
| <a name="input_cl_azure_bastion_nsg_rules"></a> [cl\_azure\_bastion\_nsg\_rules](#input\_cl\_azure\_bastion\_nsg\_rules) | (Optional) Define additional NSG rules for bastion subnet. | <pre>map(object({<br>    name                         = string<br>    priority                     = number<br>    direction                    = string<br>    access                       = string<br>    protocol                     = string<br>    source_port_range            = string<br>    source_port_ranges           = list(string)<br>    destination_port_range       = string<br>    destination_port_ranges      = list(string)<br>    source_address_prefix        = string<br>    source_address_prefixes      = list(string)<br>    destination_address_prefix   = string<br>    destination_address_prefixes = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_bastion_nsg_sa_allowed_pe_subnet_ids"></a> [cl\_azure\_bastion\_nsg\_sa\_allowed\_pe\_subnet\_ids](#input\_cl\_azure\_bastion\_nsg\_sa\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_bastion_nsg_sa_allowed_vnet_subnet_ids"></a> [cl\_azure\_bastion\_nsg\_sa\_allowed\_vnet\_subnet\_ids](#input\_cl\_azure\_bastion\_nsg\_sa\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_bastion_rg_name"></a> [cl\_azure\_bastion\_rg\_name](#input\_cl\_azure\_bastion\_rg\_name) | (Optional) Resource Group Name | `string` | `null` | no |
| <a name="input_cl_azure_bastion_scale_units"></a> [cl\_azure\_bastion\_scale\_units](#input\_cl\_azure\_bastion\_scale\_units) | (Optional) The number of scale units with which to provision the Bastion Host. Possible values are between 2 and 50. Defaults to 2. | `string` | `"2"` | no |
| <a name="input_cl_azure_bastion_storage_account_nsg_flow_log_id"></a> [cl\_azure\_bastion\_storage\_account\_nsg\_flow\_log\_id](#input\_cl\_azure\_bastion\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_cl_azure_bastion_subnet_prefix"></a> [cl\_azure\_bastion\_subnet\_prefix](#input\_cl\_azure\_bastion\_subnet\_prefix) | (Required) The prefix of the azure bastion subnet. | `any` | n/a | yes |
| <a name="input_cl_azure_bastion_subnet_service_endpoints"></a> [cl\_azure\_bastion\_subnet\_service\_endpoints](#input\_cl\_azure\_bastion\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet | `list` | `[]` | no |
| <a name="input_cl_azure_bastion_vnet_name"></a> [cl\_azure\_bastion\_vnet\_name](#input\_cl\_azure\_bastion\_vnet\_name) | (Required) The name of the core vnet required for the azure bastion subnet. | `any` | n/a | yes |
| <a name="input_cl_azure_bastion_vnet_rg_name"></a> [cl\_azure\_bastion\_vnet\_rg\_name](#input\_cl\_azure\_bastion\_vnet\_rg\_name) | (Required) The name of the core vnet resource group name. | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_azure_bastion_rg  = var.cl_azure_bastion_enable ? azurerm_resource_group.cl_azure_bastion_rg[0].name : var.cl_azure_bastion_rg_name
  cl_azure_bastion_sku = var.cl_azure_bastion_centralized_enable ? "Standard" : "Basic" 
   az_bastion_public_ip_diagnotics_settingss = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_bastion_diagnostic_setting"></a> [cl\_azure\_bastion\_diagnostic\_setting](#output\_cl\_azure\_bastion\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_bastion_host"></a> [cl\_azure\_bastion\_host](#output\_cl\_azure\_bastion\_host) | n/a |
| <a name="output_cl_azure_bastion_nsg"></a> [cl\_azure\_bastion\_nsg](#output\_cl\_azure\_bastion\_nsg) | n/a |
| <a name="output_cl_azure_bastion_nsgrule_AllowAzureCloudOutbound"></a> [cl\_azure\_bastion\_nsgrule\_AllowAzureCloudOutbound](#output\_cl\_azure\_bastion\_nsgrule\_AllowAzureCloudOutbound) | n/a |
| <a name="output_cl_azure_bastion_nsgrule_AllowAzureLoadBalancerInbound"></a> [cl\_azure\_bastion\_nsgrule\_AllowAzureLoadBalancerInbound](#output\_cl\_azure\_bastion\_nsgrule\_AllowAzureLoadBalancerInbound) | n/a |
| <a name="output_cl_azure_bastion_nsgrule_AllowGatewayManagerInbound"></a> [cl\_azure\_bastion\_nsgrule\_AllowGatewayManagerInbound](#output\_cl\_azure\_bastion\_nsgrule\_AllowGatewayManagerInbound) | n/a |
| <a name="output_cl_azure_bastion_nsgrule_AllowHttpsInbound"></a> [cl\_azure\_bastion\_nsgrule\_AllowHttpsInbound](#output\_cl\_azure\_bastion\_nsgrule\_AllowHttpsInbound) | n/a |
| <a name="output_cl_azure_bastion_nsgrule_AllowSshRdpOutbound"></a> [cl\_azure\_bastion\_nsgrule\_AllowSshRdpOutbound](#output\_cl\_azure\_bastion\_nsgrule\_AllowSshRdpOutbound) | n/a |
| <a name="output_cl_azure_bastion_pip"></a> [cl\_azure\_bastion\_pip](#output\_cl\_azure\_bastion\_pip) | n/a |
| <a name="output_cl_azure_bastion_rg"></a> [cl\_azure\_bastion\_rg](#output\_cl\_azure\_bastion\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_bastion_subnet"></a> [cl\_azure\_bastion\_subnet](#output\_cl\_azure\_bastion\_subnet) | n/a |



## Usage

```terraform
// Azure Bastion Centralized
//**********************************************************************************************
module "sharedsvcs_azure_bastion" {
  source                        = "../dn-tads_tf-azure-component-library/components/cl_azure_bastion_gov"
  env                           = var.env
  postfix                       = var.postfix
  location                      = var.location
  tags                          = var.tags
  cl_azure_bastion_enable       = true
  cl_azure_bastion_centralized_enable = true
  cl_azure_bastion_vnet_name    = azurerm_virtual_network.sharedsvcs_vnet.name
  cl_azure_bastion_vnet_rg_name = azurerm_resource_group.sharedsvcs_rg_network.name
  cl_azure_bastion_subnet_prefix = var.sharedsvcs_bastion_sub_address_prefix
  cl_azure_bastion_log_analytics_workspace_id                    = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_bastion_storage_account_nsg_flow_log_id               = var.cl_azure_bastion_storage_account_nsg_flow_log_id
  cl_azure_bastion_nsg_flow_log_postfix                          = var.cl_azure_bastion_nsg_flow_log_postfix 
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
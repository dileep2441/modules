<!-- BEGIN_TF_DOCS -->

# Azure Database for MariaDB servers

Azure Database for MariaDB is a relational database service based on the open-source MariaDB Server engine.
It's a fully managed database as a service offering that can handle mission-critical workloads with predictable performance and dynamic scalability.
This component will deploy the MariaDB server, configures the vnet rules, firewall rules, private endpoint and diagnostic settings for that resource.

For more information, please visit: https://docs.microsoft.com/en-us/azure/mariadb/overview



## Resources

| Name | Type |
|------|------|
| [azurerm_mariadb_configuration.cl_mariadb_server_config](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mariadb_configuration) | resource |
| [azurerm_mariadb_server.cl_mariadb_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mariadb_server) | resource |
| [azurerm_monitor_diagnostic_setting.cl_mariadb_server_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_mariadb_server_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_mariadb_server_administrator_login"></a> [cl\_mariadb\_server\_administrator\_login](#input\_cl\_mariadb\_server\_administrator\_login) | (Required) Login to authenticate for the MariaDB Server. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_cl_mariadb_server_administrator_password"></a> [cl\_mariadb\_server\_administrator\_password](#input\_cl\_mariadb\_server\_administrator\_password) | (Required) The Password associated with the administrator\_login for the MariaDB Server. | `string` | n/a | yes |
| <a name="input_cl_mariadb_server_auto_grow"></a> [cl\_mariadb\_server\_auto\_grow](#input\_cl\_mariadb\_server\_auto\_grow) | Whether autogrow is true | `bool` | `true` | no |
| <a name="input_cl_mariadb_server_backup_retention_days"></a> [cl\_mariadb\_server\_backup\_retention\_days](#input\_cl\_mariadb\_server\_backup\_retention\_days) | Backup retention days for the server, supported values are between 7 and 35 days. | `number` | `7` | no |
| <a name="input_cl_mariadb_server_create_mode"></a> [cl\_mariadb\_server\_create\_mode](#input\_cl\_mariadb\_server\_create\_mode) | (Optional) The creation mode. Can be used to restore or replicate existing servers. Possible values are Default, Replica, GeoRestore, and PointInTimeRestore. Defaults to Default. | `string` | `"Default"` | no |
| <a name="input_cl_mariadb_server_creation_source_server_id"></a> [cl\_mariadb\_server\_creation\_source\_server\_id](#input\_cl\_mariadb\_server\_creation\_source\_server\_id) | (Optional) For creation modes other than Default, the source server ID to use | `string` | `null` | no |
| <a name="input_cl_mariadb_server_diagnostic"></a> [cl\_mariadb\_server\_diagnostic](#input\_cl\_mariadb\_server\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "MySqlSlowLogs",<br>    "MySqlAuditLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_mariadb_server_geo_redundant_backup"></a> [cl\_mariadb\_server\_geo\_redundant\_backup](#input\_cl\_mariadb\_server\_geo\_redundant\_backup) | Enable Geo-redundant or not for server backup. Valid values for this property are Enabled or Disabled, not supported for the basic tier. | `bool` | `true` | no |
| <a name="input_cl_mariadb_server_log_analytics_workspace_id"></a> [cl\_mariadb\_server\_log\_analytics\_workspace\_id](#input\_cl\_mariadb\_server\_log\_analytics\_workspace\_id) | (Required) The ID for the network resources | `string` | n/a | yes |
| <a name="input_cl_mariadb_server_mariadb_configurations"></a> [cl\_mariadb\_server\_mariadb\_configurations](#input\_cl\_mariadb\_server\_mariadb\_configurations) | (Optional) Array for mariadb configurations. | <pre>map(object({<br>    name  = string<br>    value = string<br>  }))</pre> | <pre>{<br>  "configuration_1": {<br>    "name": "audit_log_enabled",<br>    "value": "ON"<br>  },<br>  "configuration_2": {<br>    "name": "audit_log_events",<br>    "value": "CONNECTION,GENERAL"<br>  }<br>}</pre> | no |
| <a name="input_cl_mariadb_server_pe_subnet_ids"></a> [cl\_mariadb\_server\_pe\_subnet\_ids](#input\_cl\_mariadb\_server\_pe\_subnet\_ids) | (Required) The subnet ids where the private endoint will be created. | `list(string)` | n/a | yes |
| <a name="input_cl_mariadb_server_postfix"></a> [cl\_mariadb\_server\_postfix](#input\_cl\_mariadb\_server\_postfix) | (Required) A string that is appended to the end of the the MariaDB Server name to identify it. | `string` | n/a | yes |
| <a name="input_cl_mariadb_server_private_dns_zone_ids"></a> [cl\_mariadb\_server\_private\_dns\_zone\_ids](#input\_cl\_mariadb\_server\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_mariadb_server_resource_group_name"></a> [cl\_mariadb\_server\_resource\_group\_name](#input\_cl\_mariadb\_server\_resource\_group\_name) | (Required) Specifies the Azure Database for MariaDB servers resource group | `string` | n/a | yes |
| <a name="input_cl_mariadb_server_restore_point_in_time"></a> [cl\_mariadb\_server\_restore\_point\_in\_time](#input\_cl\_mariadb\_server\_restore\_point\_in\_time) | (Optional) When create\_mode is PointInTimeRestore, specifies the point in time to restore from creation\_source\_server\_id. | `string` | `null` | no |
| <a name="input_cl_mariadb_server_server_version"></a> [cl\_mariadb\_server\_server\_version](#input\_cl\_mariadb\_server\_server\_version) | Specifies the version of MariaDB to use. | `string` | `"10.3"` | no |
| <a name="input_cl_mariadb_server_sku_name"></a> [cl\_mariadb\_server\_sku\_name](#input\_cl\_mariadb\_server\_sku\_name) | Specifies the SKU Name for this MariaDB Server. tier + family + cores pattern  B\_Gen4\_1, GP\_Gen5\_8, GP\_Gen5\_2 | `string` | `"GP_Gen5_2"` | no |
| <a name="input_cl_mariadb_server_ssl_enforcement"></a> [cl\_mariadb\_server\_ssl\_enforcement](#input\_cl\_mariadb\_server\_ssl\_enforcement) | Specifies if SSL should be enforced on connections. Possible values are true and false. | `bool` | `true` | no |
| <a name="input_cl_mariadb_server_storage_mb"></a> [cl\_mariadb\_server\_storage\_mb](#input\_cl\_mariadb\_server\_storage\_mb) | Max storage allowed for a server. Possible values are:<br>      - between 5120 MB(5GB) and 1048576 MB(1TB) for the Basic SKU<br>      - between 5120 MB(5GB) and 4194304 MB(4TB) for General Purpose/Memory Optimized SKUs | `number` | `5120` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to apply to all resources | `map(string)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_mariadb_server"></a> [cl\_mariadb\_server](#output\_cl\_mariadb\_server) | MariaDB server |
| <a name="output_cl_mariadb_server_diagnostic_setting"></a> [cl\_mariadb\_server\_diagnostic\_setting](#output\_cl\_mariadb\_server\_diagnostic\_setting) | n/a |
| <a name="output_cl_mariadb_server_private_endpoint"></a> [cl\_mariadb\_server\_private\_endpoint](#output\_cl\_mariadb\_server\_private\_endpoint) | n/a |
| <a name="output_cl_mariadb_server_server_fqdn"></a> [cl\_mariadb\_server\_server\_fqdn](#output\_cl\_mariadb\_server\_server\_fqdn) | FQDN of MariaDB server |


## Usage

```terraform
//**********************************************************************************************
resource "azurerm_subnet" "cl_mariadb_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.AzureActiveDirectory"]
}

resource "azurerm_private_dns_zone" "mariadb_private_dns_zone" {
  name                = "privatelink.mariadb.database.usgovcloudapi.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "mariadb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-mariadb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.mariadb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
    tags                = var.tags
}

module "cl_mariadb_server" {
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_mariadb_server_gov"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  suffix                                                 = var.suffix
   tags                                                  = var.tags
  cl_mariadb_server_postfix                              = "global"
  cl_mariadb_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_mariadb_server_administrator_login                  = "adminmariadb"
  cl_mariadb_server_administrator_password               = "Abc1234567890."
  cl_mariadb_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_mariadb_server_nacl_allowed_subnets                 = [azurerm_subnet.cl_mariadb_private_subnet.id]
  cl_mariadb_server_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_mariadb_server_vnet_rules                           = [azurerm_subnet.cl_mariadb_private_subnet.id]  
  cl_mariadb_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.mariadb_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "mariadb_private_dns_record" {
  name                 = "${var.env}-${var.postfix}-mariadb-pe-record"
  zone_name            = azurerm_private_dns_zone.mariadb_private_dns_zone.name
  resource_group_name  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ttl                  = 600
  records              = module.cl_mariadb_server.cl_mariadb_server_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                 = var.tags
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
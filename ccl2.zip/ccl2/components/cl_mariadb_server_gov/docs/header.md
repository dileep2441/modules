# Azure Database for MariaDB servers

Azure Database for MariaDB is a relational database service based on the open-source MariaDB Server engine.
It's a fully managed database as a service offering that can handle mission-critical workloads with predictable performance and dynamic scalability.
This component will deploy the MariaDB server, configures the vnet rules, firewall rules, private endpoint and diagnostic settings for that resource.

For more information, please visit: https://docs.microsoft.com/en-us/azure/mariadb/overview

## Usage

### Deploy App Service with vnet integration subnet

```terraform
module "cl_windows_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_windows_app_service_plan_gov"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_windows_app_service_plan_app_postfix                           = var.asp_postfix
  cl_windows_app_service_plan_deploy_integration_subnet             = true
  cl_windows_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_windows_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_windows_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_windows_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_windows_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_windows_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_windows_app_service_plan_os_type                                  = var.app_service_plan_kind
  cl_windows_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_windows_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_windows_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "app_service_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "app_service_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.app_service_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}


module "cl_windows_app_service" {
  source                                                      = "../dn-tads_tf-azure-component-library/components/cl_windows_app_service_gov"
  env                                                         = var.env
  postfix                                                     = "gov-crwx-a"
  location                                                    = var.location
  suffix                                                      = "gvnpa"
  cl_windows_app_service_plan_deploy_integration_subnet       = true
  cl_windows_app_service_integration_subnet_id                = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id 
  cl_windows_app_service_client_affinity_enabled              = false
  cl_windows_app_service_pe_subnet_ids                        = [data.azurerm_subnet.private_link_subnet.id]
  cl_windows_app_service_app_postfix                          = "walxar"
  cl_windows_app_service_rg_name                              = module.cl_app_service_plan.cl_app_service_plan_rg[0].name
  cl_windows_app_service_asp_id                               = module.cl_app_service_plan.cl_app_service_plan.id
  cl_windows_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  #cl_windows_app_service_diagnostics                          = var.app_service_diagnostics
  #cl_windows_app_service_settings                             = var.app_service_settings
  cl_windows_app_service_private_dns_zone_ids                 = [data.azurerm_private_dns_zone.app_service_private_dns_zone.id]
  cl_windows_app_service_cors_allowed_origins                 = [""]

  //Site_Config

  #cl_app_service_default_documents                           = var.app_service_default_documents
  #cl_app_service_use_32_bit_worker_process                   = var.app_service_use_32_bit_worker_process  
  tags                                                        = var.tags
  cl_windows_app_service_remote_debugging_enabled             = true
 }

resource "azurerm_private_dns_a_record" "app_service_private_dns_record" {
  name                                         = "${var.env}-${var.postfix}-app-service-int-pe-record"
  zone_name                                    = azurerm_private_dns_zone.app_service_private_dns_zone.name
  resource_group_name                          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                                          = var.app_service_private_record_ttl
  records                                      = module.cl_windows_app_service.cl_windows_app_service_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                                         = var.tags
}
```
### Deploy App Service for Containers with vnet integration subnet (Azure Container Registry and repository images should be already in place)
```terraform

module "cl_azure_container_registry" {
    source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry_gov"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
    suffix                                                      = var.suffix
    tags                                                         = var.tags
    cl_azure_container_registry_rg_name                         = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_allowed_vnet_ids                = [data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id]
    cl_azure_container_registry_content_trust_enabled           = false
    cl_azure_container_registry_admin_enabled                   = true
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
}

module "cl_windows_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_windows_app_service_plan_gov"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_windows_app_service_plan_app_postfix                           = var.asp_postfix
  cl_windows_app_service_plan_deploy_integration_subnet             = true
  cl_windows_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_windows_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_windows_app_service_plan_integration_subnet_prefix             = var.app_service_integration_subnet_prefix
  cl_windows_app_service_plan_int_subnet_user_defined_nsg_rules     = var.app_service_nsg_rules
  cl_windows_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_windows_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_windows_app_service_plan_os_type                                  = var.app_service_plan_kind
  cl_windows_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_windows_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_windows_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "app_service_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "app_service_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.app_service_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}


module "cl_windows_app_service" {
  source                                              = "../dn-tads_tf-azure-component-library/components/cl_windows_app_service_gov"
  env                                                 = var.env
  postfix                                             = var.postfix
  location                                            = var.location
  suffix                                              = var.suffix
  cl_windows_app_service_plan_deploy_integration_subnet       = true
  cl_windows_app_service_integration_subnet_id                = var.cl_windows_app_service_plan_deploy_integration_subnet ? module.cl_windows_app_service_plan.cl_windows_app_service_plan_integration_subnet.id : null
  cl_windows_app_service_client_affinity_enabled              = var.app_service_client_affinity_enabled
  cl_windows_app_service_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_windows_app_service_app_postfix                          = var.app_service_app_postfix
  cl_windows_app_service_rg_name                              = module.cl_windows_app_service_plan.cl_windows_app_service_plan_rg.name
  cl_windows_app_service_asp_id                               = module.cl_windows_app_service_plan.cl_windows_app_service_plan.id
  cl_windows_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_windows_app_service_diagnostics                          = var.app_service_diagnostics
  cl_windows_app_service_settings                             = var.app_service_settings
  cl_windows_app_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.app_service_private_dns_zone.id]

  //Site_Config

  cl_windows_app_service_default_documents                    = var.app_service_default_documents
  cl_windows_app_service_use_32_bit_worker_process            = var.app_service_use_32_bit_worker_process  


  //cl_windows_app_service_acr_username can be any other user with access to pull and push images into and from ACR. Not only the admin user from ACR.
  cl_windows_app_service_is_docker        = true
  cl_windows_app_service_acr_login_server = module.cl_azure_container_registry.cl_azure_container_registry.login_server
  cl_windows_app_service_acr_username     = module.cl_azure_container_registry.cl_azure_container_registry_admin_username
  cl_windows_app_service_acr_password     = module.cl_azure_container_registry.cl_azure_container_registry_admin_password
  cl_windows_app_service_acr_image        = "myapp:latest"

    // Connection Strings in variable cl_windows_app_service_connection_strings
  cl_windows_app_service_connection_strings = {
      connection_string = {
        name      = "sa_peninsula_connection"
        type      = "Custom"
        value     = var.cl_b2c_manager_app_service_connection_string_value
      }
    }

    tags                            = var.tags
 }


resource "azurerm_private_dns_a_record" "app_service_private_dns_record" {
  name                                         = "${var.env}-${var.postfix}-app-service-int-pe-record"
  zone_name                                    = azurerm_private_dns_zone.app_service_private_dns_zone.name
  resource_group_name                          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                                          = var.app_service_private_record_ttl
  records                                      = module.cl_windows_app_service.cl_windows_app_service_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                                         = var.tags
}
```

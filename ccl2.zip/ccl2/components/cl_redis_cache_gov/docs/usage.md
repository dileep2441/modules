
## Usage

```terraform
// Azure Redis Cache
//**********************************************************************************************
 module "cl_redis_cache" {
  source                                    = "../dn-tads_tf-azure-component-library/components/cl_redis_cache_gov"
  cl_redis_cache_enable                     = true
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  tags                                            = var.tags
  cl_redis_cache_resource_group_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_redis_cache_postfix                    = "app1"
  cl_redis_cache_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_redis_cache_allowed_subnets            = var.cl_redis_cache_allowed_subnets
  }
//***************************************************************************************************
```
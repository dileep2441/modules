## Usage

```terraform
## Deploy Azure Cosmos DB API for MongoDB
resource "azurerm_private_dns_zone" "cosmosdb_private_dns_zone" {
  name                = "privatelink.mongo.cosmos.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "cosmosdb_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-cosmosdb-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_cosmosdb" {
  source   = "../tf-azure-component-library/components/cl_cosmosdb"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_cosmosdb_resource_group_name         = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_cosmosdb_log_analytics_workspace_id  = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_cosmosdb_allowed_subnet = azurerm_subnet.test_subnet.id
  cl_cosmosdb_private_dns_zone_ids = [azurerm_private_dns_zone.cosmosdb_private_dns_zone.id]
  cl_cosmosdb_failover_location    = var.cosmosdb_failover_location
}
```
```terraform
## Deploy Azure Cosmos DB's core
resource "azurerm_private_dns_zone" "cosmosdb_private_dns_zone" {
  name                = "privatelink.documents.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "cosmosdb_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-cosmosdb-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_cosmosdb" {
  source                                 = "../tf-azure-component-library/components/cl_cosmosdb"
  env                                    = var.env
  postfix                                = var.postfix
  location                               = var.location
  cl_cosmosdb_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_cosmosdb_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_cosmosdb_allowed_subnet             = azurerm_subnet.private_link_subnet.id
  cl_cosmosdb_private_dns_zone_ids       = var.cosmosdb_private_dns_zone_ids
  cl_cosmosdb_kind                       = "GlobalDocumentDB"
  cl_cosmosdb_capabilities               = ["EnableServerless"]
  tags                                   = var.tags
}
```
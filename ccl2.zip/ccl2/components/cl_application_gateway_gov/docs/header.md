# Azure Application Gateway Component

Azure Application Gateway is a web traffic load balancer that manages traffic to your web applications via application layer load balancing.
This means creating routing rules for traffic based on the attributes of an HTTP request (ex: URL based routing).
This specific component deploys an Application Gateway it's associated Public IPs, Route Table, NSGs, Log Analytics and Diagnostics Settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/application-gateway/overview

# Azure Kubernetes services Node Pools Component

Multiple Node Pools are only supported when the Kubernetes Cluster is using Virtual Machine Scale Sets. 
The type of Default Node Pool for the Kubernetes Cluster must be VirtualMachineScaleSets to attach multiple node pools.

For more information, please visit: https://docs.microsoft.com/en-us/azure/aks/use-multiple-node-pools 

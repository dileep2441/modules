## Usage

```terraform
module "cl_cdn_frontdoor" {
    source                    = "../tf-azure-component-library/components/cl_cdn_frontdoor"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_azure_container_registry_rg_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cdn_frontdoor_sku_name = var.cl_cdn_frontdoor_sku_name
    cl_cdn_frontdoor_session_affinity_enabled = var.cl_cdn_frontdoor_session_affinity_enabled
    cl_cdn_frontdoor_custom_domain_name = var.cl_cdn_frontdoor_custom_domain_name
    cl_cdn_frontdoor_waf_mode = var.cl_cdn_frontdoor_waf_mode
}
```
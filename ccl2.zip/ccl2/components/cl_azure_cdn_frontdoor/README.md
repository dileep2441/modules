<!-- BEGIN_TF_DOCS -->

# Content Delivery Network (CDN)

A content delivery network (CDN) is a distributed network of servers that can efficiently deliver 	web content to users. A CDN store cached content on edge servers in point-of-presence (POP) 	locations that are close to end users, to minimize latency. 

For more information, please visit: https://learn.microsoft.com/en-us/azure/cdn/cdn-overview

# Azure Front Door (AFD)

Azure Front Door is Microsoft’s modern cloud Content Delivery Network (CDN) that provides fast, reliable, and secure access between your users and your applications’ static and dynamic web content across the globe. Azure Front Door delivers your content using Microsoft’s global edge network with hundreds of global and local points of presence (PoPs) distributed around the world close to both your enterprise and consumer end users.

For more information, please visit: https://learn.microsoft.com/en-us/azure/frontdoor/front-door-overview

```
The following cdn/frontdoor contains two different sku´s : Standard and premium
...



## Resources

| Name | Type |
|------|------|
| [azurerm_cdn_frontdoor_custom_domain.cl_cdn_frontdoor_custom_domain](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_custom_domain) | resource |
| [azurerm_cdn_frontdoor_endpoint.cl_cdn_frontdoor_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_endpoint) | resource |
| [azurerm_cdn_frontdoor_firewall_policy.cl_cdn_frontdoor_firewall_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_firewall_policy) | resource |
| [azurerm_cdn_frontdoor_origin.cl_cdn_frontdoor_origin](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_origin) | resource |
| [azurerm_cdn_frontdoor_origin_group.cl_cdn_frontdoor_origin_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_origin_group) | resource |
| [azurerm_cdn_frontdoor_profile.cl_cdn_frontdoor](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_profile) | resource |
| [azurerm_cdn_frontdoor_route.cl_cdn_frontdoor_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cdn_frontdoor_route) | resource |
| [azurerm_monitor_diagnostic_setting.cl_cdn_frontdoor_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_storage_blob.cl_website](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_blob) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_cdn_front_door_log_analytics_workspace_id"></a> [cl\_cdn\_front\_door\_log\_analytics\_workspace\_id](#input\_cl\_cdn\_front\_door\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_cdn_frontdoor_certificate_name_check_enabled"></a> [cl\_cdn\_frontdoor\_certificate\_name\_check\_enabled](#input\_cl\_cdn\_frontdoor\_certificate\_name\_check\_enabled) | (Required) Specifies whether certificate name checks are enabled for this origin. | `bool` | `true` | no |
| <a name="input_cl_cdn_frontdoor_custom_domain_name"></a> [cl\_cdn\_frontdoor\_custom\_domain\_name](#input\_cl\_cdn\_frontdoor\_custom\_domain\_name) | The host name of the domain. The host\_name field must be the FQDN of your domain. Changing this forces a new Front Door Custom Domain to be created. | `string` | `""` | no |
| <a name="input_cl_cdn_frontdoor_custom_rules"></a> [cl\_cdn\_frontdoor\_custom\_rules](#input\_cl\_cdn\_frontdoor\_custom\_rules) | (Optional) Array for additional health probes. | <pre>list(object({<br>      name                           = string<br>      enabled                        = bool<br>      priority                       = number<br>      rate_limit_duration_in_minutes = number<br>      rate_limit_threshold           = number<br>      type                           = string<br>      action                         = string<br>  <br>      match_conditions               = list(object({<br>        match_variable               = string<br>        operator                     = string<br>        selector                      = string<br>        negation_condition           = bool<br>        transforms                   = list(string)<br>        match_values                 = list(string)<br>      }))<br>    }))</pre> | <pre>[<br>  {<br>    "action": "Block",<br>    "enabled": true,<br>    "match_conditions": [<br>      {<br>        "match_values": [<br>          "windows"<br>        ],<br>        "match_variable": "RequestHeader",<br>        "negation_condition": false,<br>        "operator": "Contains",<br>        "selector": "UserAgent",<br>        "transforms": [<br>          "Lowercase",<br>          "Trim"<br>        ]<br>      }<br>    ],<br>    "name": "Rule1",<br>    "priority": 2,<br>    "rate_limit_duration_in_minutes": 1,<br>    "rate_limit_threshold": 10,<br>    "type": "MatchRule"<br>  }<br>]</pre> | no |
| <a name="input_cl_cdn_frontdoor_deploy_log_analytics"></a> [cl\_cdn\_frontdoor\_deploy\_log\_analytics](#input\_cl\_cdn\_frontdoor\_deploy\_log\_analytics) | (Optional) Boolean to enable application gateway log analytics solution resource creation | `bool` | `true` | no |
| <a name="input_cl_cdn_frontdoor_diagnostics"></a> [cl\_cdn\_frontdoor\_diagnostics](#input\_cl\_cdn\_frontdoor\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "audit",<br>    "allLogs"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_cdn_frontdoor_http_port"></a> [cl\_cdn\_frontdoor\_http\_port](#input\_cl\_cdn\_frontdoor\_http\_port) | http\_port - (Optional) The value of the HTTP port. Must be between 1 and 65535. Defaults to 80. | `number` | `80` | no |
| <a name="input_cl_cdn_frontdoor_https_port"></a> [cl\_cdn\_frontdoor\_https\_port](#input\_cl\_cdn\_frontdoor\_https\_port) | https\_port - (Optional) The value of the HTTPS port. Must be between 1 and 65535. Defaults to 443. | `number` | `443` | no |
| <a name="input_cl_cdn_frontdoor_interval_in_seconds"></a> [cl\_cdn\_frontdoor\_interval\_in\_seconds](#input\_cl\_cdn\_frontdoor\_interval\_in\_seconds) | (Required) Specifies the number of seconds between health probes. Possible values are between 5 and 31536000 seconds (inclusive). | `number` | `100` | no |
| <a name="input_cl_cdn_frontdoor_log_analytics_solutions"></a> [cl\_cdn\_frontdoor\_log\_analytics\_solutions](#input\_cl\_cdn\_frontdoor\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureCdnFrontdoorAnalytics": {<br>    "product": "OMSGallery/AzureCdnFrontdoorAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_cl_cdn_frontdoor_log_analytics_workspace_name"></a> [cl\_cdn\_frontdoor\_log\_analytics\_workspace\_name](#input\_cl\_cdn\_frontdoor\_log\_analytics\_workspace\_name) | (Required) The log analytics workspace name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_cdn_frontdoor_logging_rg_name"></a> [cl\_cdn\_frontdoor\_logging\_rg\_name](#input\_cl\_cdn\_frontdoor\_logging\_rg\_name) | (Required) The resource group for the cdn/frontdoor log analytics solution. | `any` | n/a | yes |
| <a name="input_cl_cdn_frontdoor_managed_rules"></a> [cl\_cdn\_frontdoor\_managed\_rules](#input\_cl\_cdn\_frontdoor\_managed\_rules) | (Optional) Array for managed rules. | <pre>list(object({<br>    type    = string<br>    version = string<br>    action  = string<br>  }))</pre> | <pre>[<br>  {<br>    "action": "Block",<br>    "type": "Microsoft_DefaultRuleSet",<br>    "version": "2.1"<br>  },<br>  {<br>    "action": "Block",<br>    "type": "Microsoft_BotManagerRuleSet",<br>    "version": "1.0"<br>  }<br>]</pre> | no |
| <a name="input_cl_cdn_frontdoor_priority"></a> [cl\_cdn\_frontdoor\_priority](#input\_cl\_cdn\_frontdoor\_priority) | (Optional) Priority of origin in given origin group for load balancing. Higher priorities will not be used for load balancing if any lower priority origin is healthy. Must be between 1 and 5 (inclusive). Defaults to 1. | `number` | `1` | no |
| <a name="input_cl_cdn_frontdoor_rg_name"></a> [cl\_cdn\_frontdoor\_rg\_name](#input\_cl\_cdn\_frontdoor\_rg\_name) | (Required) The resource group to deploy the cdn\_frontdoor into. | `any` | n/a | yes |
| <a name="input_cl_cdn_frontdoor_sample_size"></a> [cl\_cdn\_frontdoor\_sample\_size](#input\_cl\_cdn\_frontdoor\_sample\_size) | (Optional) Specifies the number of samples to consider for load balancing decisions. Possible values are between 0 and 255 (inclusive). Defaults to 4. | `number` | `4` | no |
| <a name="input_cl_cdn_frontdoor_session_affinity_enabled"></a> [cl\_cdn\_frontdoor\_session\_affinity\_enabled](#input\_cl\_cdn\_frontdoor\_session\_affinity\_enabled) | (Optional) Specifies whether session affinity should be enabled on this host. Defaults to true | `bool` | `true` | no |
| <a name="input_cl_cdn_frontdoor_sku_name"></a> [cl\_cdn\_frontdoor\_sku\_name](#input\_cl\_cdn\_frontdoor\_sku\_name) | (Optional) The SKU for the Front Door profile. Possible values include: Standard\_AzureFrontDoor, Premium\_AzureFrontDoor | `string` | `"Premium_AzureFrontDoor"` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_allowed_ip"></a> [cl\_cdn\_frontdoor\_storage\_account\_allowed\_ip](#input\_cl\_cdn\_frontdoor\_storage\_account\_allowed\_ip) | (Optional) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed. | `list(string)` | `[]` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_allowed_pe_subnet_ids"></a> [cl\_cdn\_frontdoor\_storage\_account\_allowed\_pe\_subnet\_ids](#input\_cl\_cdn\_frontdoor\_storage\_account\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_allowed_vnet_subnet_ids"></a> [cl\_cdn\_frontdoor\_storage\_account\_allowed\_vnet\_subnet\_ids](#input\_cl\_cdn\_frontdoor\_storage\_account\_allowed\_vnet\_subnet\_ids) | (Optional) A list of resource ids for subnets. | `list(string)` | `[]` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_bypass"></a> [cl\_cdn\_frontdoor\_storage\_account\_bypass](#input\_cl\_cdn\_frontdoor\_storage\_account\_bypass) | (Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. | `list(string)` | <pre>[<br>  "None"<br>]</pre> | no |
| <a name="input_cl_cdn_frontdoor_storage_account_diagnostics"></a> [cl\_cdn\_frontdoor\_storage\_account\_diagnostics](#input\_cl\_cdn\_frontdoor\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "StorageRead",<br>    "StorageWrite",<br>    "StorageDelete"<br>  ],<br>  "metrics": [<br>    "Transaction"<br>  ]<br>}</pre> | no |
| <a name="input_cl_cdn_frontdoor_storage_account_kind"></a> [cl\_cdn\_frontdoor\_storage\_account\_kind](#input\_cl\_cdn\_frontdoor\_storage\_account\_kind) | (Optional) Defines the type of replication to use for the storage account for the cdn\_frontdoor audit and security logging. | `string` | `"StorageV2"` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_network_default_action"></a> [cl\_cdn\_frontdoor\_storage\_account\_network\_default\_action](#input\_cl\_cdn\_frontdoor\_storage\_account\_network\_default\_action) | (Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow. | `string` | `"Deny"` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_private_dns_zone_ids"></a> [cl\_cdn\_frontdoor\_storage\_account\_private\_dns\_zone\_ids](#input\_cl\_cdn\_frontdoor\_storage\_account\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_replication_type"></a> [cl\_cdn\_frontdoor\_storage\_account\_replication\_type](#input\_cl\_cdn\_frontdoor\_storage\_account\_replication\_type) | (Optional) Defines the type of replication to use for the storage account for the cdn\_frontdoor audit and security logging. | `string` | `"LRS"` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_rg_name"></a> [cl\_cdn\_frontdoor\_storage\_account\_rg\_name](#input\_cl\_cdn\_frontdoor\_storage\_account\_rg\_name) | (Required) The resource group to deploy the storage account needed for the cdn\_frontdoor. | `any` | n/a | yes |
| <a name="input_cl_cdn_frontdoor_storage_account_tier"></a> [cl\_cdn\_frontdoor\_storage\_account\_tier](#input\_cl\_cdn\_frontdoor\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for the cdn\_frontdoor audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_cl_cdn_frontdoor_storage_account_tls_version"></a> [cl\_cdn\_frontdoor\_storage\_account\_tls\_version](#input\_cl\_cdn\_frontdoor\_storage\_account\_tls\_version) | (Optional) The minimum supported TLS version for the storage account. Possible values are TLS1\_0, TLS1\_1, and TLS1\_2. | `string` | `"TLS1_2"` | no |
| <a name="input_cl_cdn_frontdoor_sucessful_samples_requried"></a> [cl\_cdn\_frontdoor\_sucessful\_samples\_requried](#input\_cl\_cdn\_frontdoor\_sucessful\_samples\_requried) | (Optional) Specifies the number of samples within the sample period that must succeed. Possible values are between 0 and 255 (inclusive). Defaults to 3. | `number` | `3` | no |
| <a name="input_cl_cdn_frontdoor_waf_mode"></a> [cl\_cdn\_frontdoor\_waf\_mode](#input\_cl\_cdn\_frontdoor\_waf\_mode) | (Required) The Front Door Firewall Policy mode. Possible values are Detection, Prevention. | `string` | `"Prevention"` | no |
| <a name="input_cl_cdn_frontdoor_weight"></a> [cl\_cdn\_frontdoor\_weight](#input\_cl\_cdn\_frontdoor\_weight) | (Optional) The weight of the origin in a given origin group for load balancing. Must be between 1 and 1000. Defaults to 500. | `number` | `1000` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_host_name"></a> [host\_name](#input\_host\_name) | user define host name | `string` | `""` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_cdn_frontdoor"></a> [cl\_cdn\_frontdoor](#output\_cl\_cdn\_frontdoor) | n/a |
| <a name="output_cl_cdn_frontdoor_storage_account"></a> [cl\_cdn\_frontdoor\_storage\_account](#output\_cl\_cdn\_frontdoor\_storage\_account) | Outputs ********************************************************************************************** |
| <a name="output_cl_cdn_frontdoor_storage_account_private_endpoint"></a> [cl\_cdn\_frontdoor\_storage\_account\_private\_endpoint](#output\_cl\_cdn\_frontdoor\_storage\_account\_private\_endpoint) | n/a |

## Usage

```terraform
module "cl_cdn_frontdoor" {
    source                    = "../tf-azure-component-library/components/cl_cdn_frontdoor"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_azure_container_registry_rg_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cdn_frontdoor_sku_name = var.cl_cdn_frontdoor_sku_name
    cl_cdn_frontdoor_session_affinity_enabled = var.cl_cdn_frontdoor_session_affinity_enabled
    cl_cdn_frontdoor_custom_domain_name = var.cl_cdn_frontdoor_custom_domain_name
    cl_cdn_frontdoor_waf_mode = var.cl_cdn_frontdoor_waf_mode
}
```
<!-- END_TF_DOCS -->
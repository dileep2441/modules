<!-- BEGIN_TF_DOCS -->

# Cognitive Services

Azure Cognitive Services are cloud-based services with REST APIs and client library SDKs available to help you build cognitive intelligence into your applications. You can add cognitive features to your applications without having artificial intelligence (AI) or data science skills. Azure Cognitive Services comprise various AI services that enable you to build cognitive solutions that can see, hear, speak, understand, and even make decisions. Cognitive services provides cognitive understanding are categorized into five main pillars:

-Vision:   Computer Vision, Custom Vision Service, Face

-Speech:   Speech service

-Language: Language Understanding LUIS, QnA Maker, Text Analytics, Translator

-Decision: Anomaly Detector, Content Moderator, Personalizer

-Search:   Bing News Search, Bing Video Search, Bing Web Search, Bing Autosuggest, Bing Custom Search, Bing Entity Search, Bing Image Search, Bing Visual Search, Bing Local Business Search, Bing Spell Check.

For more information, please visit: -https://docs.microsoft.com/en-us/azure/cognitive-services/what-are-cognitive-services 

```
The following table contains the different sku´s for Cognitive Services:

ResourceType          tier Name                   kind Vision
accounts               F0,S1                      ComputerVision
accounts               F0,S0,S1                   Face
accounts               F0,S0                      FormRecognizer

ResourceType          tier Name                   kind Language
accounts               F0,S0                      LUIS
accounts               F0,S0                      LUIS.Authoring
accounts               F0,S0                      QnAMaker
accounts               F0,S1,S2,S3,S4,C2,C3,C4,D3 TextTranslation
accounts               F,S                        TextAnalytics

ResourceType          tier Name                   kind Speech
accounts               F0,S0                      Bing.Speech
accounts               F0,S1,S2,S3,S4             SpeechTranslation

ResourceType          tier Name                   kind Search
accounts               S1,S2,S3,S4,S5,S6.S7,S8    Bing.Search.v7
accounts               S1                         Bing.Autosuggest.v7
accounts               S1                         Bing.CustomSearch
accounts               S1                         Bing.SpellCheck.v7
accounts               F0,S1                      Bing.EntitySearch

ResourceType          tier Name                   kind Decision
accounts               F0,S0                      ContentModerator

ResourceType          tier Name                   kind OpenAI
accounts               S0                         OpenAI
```

In those usages we are deep in the following cognitive services:

*Natural language processing (NLP)* is used for tasks such as sentiment analysis, topic detection, language detection, key phrase extraction, and document categorization. NLP can be use to classify documents, such as labeling documents as sensitive or spam.

1. LUIS: Language Understanding (LUIS) is a cloud-based conversational AI service that applies custom machine-learning intelligence to a user's conversational, natural language text to predict overall meaning, and pull out relevant, detailed information. LUIS provides access through its custom portal, APIs and SDK client libraries. LUIS has Build an enterprise-grade conversational bot, Commerce Chatbot and Controlling IoT devices using a Voice Assistant Scenarios

2. LUIS.Authority: Authoring resource. Allows you to create, manage, train, test, and publish your applications. Create a LUIS authoring resource if you intend to author LUIS apps programmatically or from the LUIS portal. You need to migrate your LUIS account before you link your Azure authoring resources to your application.

3. QNA MAKER: QnA Maker is a cloud-based Natural Language Processing (NLP) service that allows you to create a natural conversational layer over your data. It is used to find the most appropriate answer for any input from your custom knowledge base (KB) of information. QnA Maker imports your content into a knowledge base of question and answer pairs. The import process extracts information about the relationship between the parts of your structured and semi-structured content to imply relationships between the question and answer pairs. You can edit these question and answer pairs or add new pairs.

4. Text Anayltic: The Text Analytics API is a cloud-based service that provides Natural Language Processing (NLP) features for text mining and text analysis, including: sentiment analysis, opinion mining, key phrase extraction, language detection, and named entity recognition. The API is a part of Azure Cognitive Services, a collection of machine learning and AI algorithms in the cloud for your development projects. You can use these features with the REST API version 3.0 or version 3.1-preview, or the client library.

*Optical character recognition (OCR)* allows you to extract printed or handwritten text from images, such as photos of street signs and products, as well as from documents—invoices, bills, financial reports, articles, and more. Microsoft's OCR technologies support extracting printed text in several languages.

1. Computer Vision: The Computer Vision service provides developers with access to advanced algorithms for processing images and returning information. Computer Vision algorithms analyze the content of an image in different ways, depending on the visual features you're interested in.You can use Computer Vision in your application to: Analyze images for insight, Extract text, from images and Generate thumbnails.

2. Form Recognizer: Form Recognizer is a Cognitive Service that lets you identify and extract text, key/value pairs, and table data from documents. With Form Recognizer you can train custom models to extract structured data from your forms and documents.

*Azure OpenAI Service* provides REST API access to OpenAI's powerful language models including the GPT-3, Codex and Embeddings model series. These models can be easily adapted to your specific task including but not limited to content generation, summarization, semantic search, and natural language to code translation. Users can access the service through REST APIs, Python SDK, or our web-based interface in the Azure OpenAI Studio.

#### Note:
For OpenAI kind, it needs AzureRM provider for Terraform version 3.40.0 or later.
It can be specified on Terraform backend:

```terraform
terraform {
  required_version = ">= 1.0"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">= 3.40.0"
    }
  }
}
```



## Resources

| Name | Type |
|------|------|
| [azurerm_cognitive_account.cl_cognitive_services](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cognitive_account) | resource |
| [azurerm_monitor_diagnostic_setting.cl_cognitive_services_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_cognitive_services_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.cl_cognitive_services_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_cognitive_services_deploy_rg"></a> [cl\_cognitive\_services\_deploy\_rg](#input\_cl\_cognitive\_services\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the cognitive services. | `bool` | `true` | no |
| <a name="input_cl_cognitive_services_diagnostic"></a> [cl\_cognitive\_services\_diagnostic](#input\_cl\_cognitive\_services\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string)})` | <pre>{<br>  "logs": [<br>    "Audit",<br>    "RequestResponse",<br>    "trace"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_cognitive_services_fqdns"></a> [cl\_cognitive\_services\_fqdns](#input\_cl\_cognitive\_services\_fqdns) | (Optional) List of FQDNs allowed for the Cognitive Account. | `list(string)` | `null` | no |
| <a name="input_cl_cognitive_services_identity_ids"></a> [cl\_cognitive\_services\_identity\_ids](#input\_cl\_cognitive\_services\_identity\_ids) | UserAssigned Identities ID to add to Cognitive services. Mandatory if type is UserAssigned | `list(string)` | `null` | no |
| <a name="input_cl_cognitive_services_identity_type"></a> [cl\_cognitive\_services\_identity\_type](#input\_cl\_cognitive\_services\_identity\_type) | Add an Identity (MSI) to the cognitive services. Possible values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_cognitive_services_ignore_missing_vnet_service_endpoint"></a> [cl\_cognitive\_services\_ignore\_missing\_vnet\_service\_endpoint](#input\_cl\_cognitive\_services\_ignore\_missing\_vnet\_service\_endpoint) | (Optional) Whether ignore missing vnet service endpoint or not. Default to false. | `bool` | `false` | no |
| <a name="input_cl_cognitive_services_kind"></a> [cl\_cognitive\_services\_kind](#input\_cl\_cognitive\_services\_kind) | (Optional) Changing this forces a new resource to be created ((Required) Specifies the type of Cognitive Service Account that should be created. Possible values are Academic, AnomalyDetector, Bing.Autosuggest, Bing.Autosuggest.v7, Bing.CustomSearch, Bing.Search, Bing.Search.v7, Bing.Speech, Bing.SpellCheck, Bing.SpellCheck.v7, CognitiveServices, ComputerVision, ContentModerator, CustomSpeech, CustomVision.Prediction, CustomVision.Training, Emotion, Face,FormRecognizer, ImmersiveReader, LUIS, LUIS.Authoring, Personalizer, QnAMaker, Recommendations, SpeakerRecognition, Speech, SpeechServices, SpeechTranslation, TextAnalytics, TextTranslation and WebLM). | `string` | `"LUIS"` | no |
| <a name="input_cl_cognitive_services_local_auth_enabled"></a> [cl\_cognitive\_services\_local\_auth\_enabled](#input\_cl\_cognitive\_services\_local\_auth\_enabled) | (Optional) Whether local authentication methods is enabled for the Cognitive Account. Defaults to true, is required i false by Security guideline. | `bool` | `false` | no |
| <a name="input_cl_cognitive_services_log_analytics_workspace_id"></a> [cl\_cognitive\_services\_log\_analytics\_workspace\_id](#input\_cl\_cognitive\_services\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_cognitive_services_metrics_advisor_aad_client_id"></a> [cl\_cognitive\_services\_metrics\_advisor\_aad\_client\_id](#input\_cl\_cognitive\_services\_metrics\_advisor\_aad\_client\_id) | (Optional) The Azure AD Client ID (Application ID). This attribute is only set when kind is MetricsAdvisor. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_cognitive_services_metrics_advisor_aad_tenant_id"></a> [cl\_cognitive\_services\_metrics\_advisor\_aad\_tenant\_id](#input\_cl\_cognitive\_services\_metrics\_advisor\_aad\_tenant\_id) | (Optional) The Azure AD Tenant ID. This attribute is only set when kind is MetricsAdvisor. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_cognitive_services_metrics_advisor_super_user_name"></a> [cl\_cognitive\_services\_metrics\_advisor\_super\_user\_name](#input\_cl\_cognitive\_services\_metrics\_advisor\_super\_user\_name) | (Optional) The super user of Metrics Advisor. This attribute is only set when kind is MetricsAdvisor. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_cognitive_services_metrics_advisor_website_name"></a> [cl\_cognitive\_services\_metrics\_advisor\_website\_name](#input\_cl\_cognitive\_services\_metrics\_advisor\_website\_name) | (Optional) The website name of Metrics Advisor. This attribute is only set when kind is MetricsAdvisor. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_cognitive_services_nacl_allowed_subnets"></a> [cl\_cognitive\_services\_nacl\_allowed\_subnets](#input\_cl\_cognitive\_services\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure cognitive services. | `list(string)` | `[]` | no |
| <a name="input_cl_cognitive_services_nacls_allowed_ip_ranges"></a> [cl\_cognitive\_services\_nacls\_allowed\_ip\_ranges](#input\_cl\_cognitive\_services\_nacls\_allowed\_ip\_ranges) | (Optional) One or more IP Addresses, or CIDR Blocks which should be able to access the Cognitive Account. | `list(string)` | `[]` | no |
| <a name="input_cl_cognitive_services_nacls_default_action"></a> [cl\_cognitive\_services\_nacls\_default\_action](#input\_cl\_cognitive\_services\_nacls\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_rules. Possible values are Allow and Deny. | `string` | `"Deny"` | no |
| <a name="input_cl_cognitive_services_nacls_virtual_network_subnet_ids"></a> [cl\_cognitive\_services\_nacls\_virtual\_network\_subnet\_ids](#input\_cl\_cognitive\_services\_nacls\_virtual\_network\_subnet\_ids) | (Optional) The ID of the subnet which should be able to access this Cognitive Account. | `string` | `""` | no |
| <a name="input_cl_cognitive_services_postfix"></a> [cl\_cognitive\_services\_postfix](#input\_cl\_cognitive\_services\_postfix) | (Required) The bespoke name of the cognitive service you are deploying. | `any` | n/a | yes |
| <a name="input_cl_cognitive_services_private_dns_zone_ids"></a> [cl\_cognitive\_services\_private\_dns\_zone\_ids](#input\_cl\_cognitive\_services\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_cognitive_services_private_endpoint_subresource_names"></a> [cl\_cognitive\_services\_private\_endpoint\_subresource\_names](#input\_cl\_cognitive\_services\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "account"<br>]</pre> | no |
| <a name="input_cl_cognitive_services_public_network_access_enabled"></a> [cl\_cognitive\_services\_public\_network\_access\_enabled](#input\_cl\_cognitive\_services\_public\_network\_access\_enabled) | (Optional) Whether public network access is allowed for the Cognitive Account. Defaults to true. | `bool` | `false` | no |
| <a name="input_cl_cognitive_services_qna_runtime_endpoint"></a> [cl\_cognitive\_services\_qna\_runtime\_endpoint](#input\_cl\_cognitive\_services\_qna\_runtime\_endpoint) | (Optional) A URL to link a QnAMaker cognitive account to a QnA runtime. | `string` | `""` | no |
| <a name="input_cl_cognitive_services_resource_group_name"></a> [cl\_cognitive\_services\_resource\_group\_name](#input\_cl\_cognitive\_services\_resource\_group\_name) | (Required) Specifies the Cognitive Service resource group | `any` | n/a | yes |
| <a name="input_cl_cognitive_services_rg_name"></a> [cl\_cognitive\_services\_rg\_name](#input\_cl\_cognitive\_services\_rg\_name) | (Optional) The name of the cognitive services VM resource group if cl\_cognitive\_services\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_cognitive_services_sku_name"></a> [cl\_cognitive\_services\_sku\_name](#input\_cl\_cognitive\_services\_sku\_name) | (Optional) Specifies the SKU Name (F0, F1, S, S0, S1, S2, S3, S4, S5, S6, P0, P1, and P2) for this Cognitive Service. | `string` | `"S0"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_cognitive_services"></a> [cl\_cognitive\_services](#output\_cl\_cognitive\_services) | Cognitive Service |
| <a name="output_cl_cognitive_services_diagnostic_setting"></a> [cl\_cognitive\_services\_diagnostic\_setting](#output\_cl\_cognitive\_services\_diagnostic\_setting) | Monitor Diagnostic |
| <a name="output_cl_cognitive_services_endpoint"></a> [cl\_cognitive\_services\_endpoint](#output\_cl\_cognitive\_services\_endpoint) | The endpoint used to connect to the Cognitive Service Account. |
| <a name="output_cl_cognitive_services_primary_key"></a> [cl\_cognitive\_services\_primary\_key](#output\_cl\_cognitive\_services\_primary\_key) | The Primary Key used for Search Service Administration. |
| <a name="output_cl_cognitive_services_private_endpoint"></a> [cl\_cognitive\_services\_private\_endpoint](#output\_cl\_cognitive\_services\_private\_endpoint) | n/a |
| <a name="output_cl_cognitive_services_rg"></a> [cl\_cognitive\_services\_rg](#output\_cl\_cognitive\_services\_rg) | Resource Group Cognitive Services |
| <a name="output_cl_cognitive_services_secondary_key"></a> [cl\_cognitive\_services\_secondary\_key](#output\_cl\_cognitive\_services\_secondary\_key) | The Secondary Key used for Search Service Administration. |

## Usage

1. To create a Cognitive Services please send in the following variables the kind required for the cognitive services and the sku for that cognitive services selectecd in the kind variable.

   For example:

   cl_cognitive_services_kind                             = "LUIS"

   cl_cognitive_services_sku_name                         = "S0"
   

2. If you required to use the same resource group for all your cognitive services is necesary to send the variable cl_cognitive_services_deploy_rg in false and confirm the value for the varaible cl_cognitive_services_rg_name, in you need each cognitive service in a different resource group you don´t need to send an additional variable, only confirm the variable cl_cognitive_services_deploy_rg in true.

```terraform
//********************************************************************************************
//Create a single Cognitive Services
//********************************************************************************************
resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_LUIS" {
   source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp"
   cl_cognitive_services_deploy_rg                        = true
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "LUIS"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                = "privatelink.cognitiveservices.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************
//Create NLP Cognitive Servies: 1.) LUIS 2.)  QNA MAKER 3.) Text Anayltics
//********************************************************************************************
resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                                   = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                                   = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                       = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies         = true
  service_endpoints                                      = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_LUIS" {
   source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp"
   cl_cognitive_services_deploy_rg                        = true
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "LUIS"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]  
}

module "cl_cognitive_services_LUIS_authoring" {
   source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp-la"
   cl_cognitive_services_deploy_rg                        = false
   cl_cognitive_services_rg_name                          = module.cl_cognitive_services_LUIS.cl_cognitive_services_rg[0].name
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "LUIS.Authoring"
   cl_cognitive_services_sku_name                         = "F0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_QNA_MAKER" {
   source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp-qna"
   cl_cognitive_services_deploy_rg                        = false
   cl_cognitive_services_rg_name                          = module.cl_cognitive_services_LUIS.cl_cognitive_services_rg[0].name
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "QnAMaker"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
   cl_cognitive_services_qna_runtime_endpoint             = "https://docs.microsoft.com/rest/api/cognitiveservices/qnamaker/knowledgebase"
}

module "cl_cognitive_services_TextAnalytics" {
   source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp-ta"
   cl_cognitive_services_deploy_rg                        = false
   cl_cognitive_services_rg_name                          = module.cl_cognitive_services_LUIS.cl_cognitive_services_rg[0].name
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "TextAnalytics"
   cl_cognitive_services_sku_name                         = "S"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                   = "privatelink.cognitiveservices.azure.com"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************

//********************************************************************************************
//Vision API/OCR Cognitive Services: 1.) Computer Vision 2.) Form Recognizer   
//********************************************************************************************
resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_ComputerVision" {
   source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "cvision"
   cl_cognitive_services_deploy_rg                        = true
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "ComputerVision"
   cl_cognitive_services_sku_name                         = "S1"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_Form_Recognizer" {
   source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "frzer"
   cl_cognitive_services_deploy_rg                        = false
   cl_cognitive_services_rg_name                          = module.cl_cognitive_services_ComputerVision.cl_cognitive_services_rg[0].name
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "FormRecognizer"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                   = "privatelink.cognitiveservices.azure.com"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************

//********************************************************************************************************
//Deploy Cognitive Services: 1.) Speech Service 2.) Anomaly Detector 3.) TextAnalytics 4.) TextTranslation   
//********************************************************************************************************

resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_Speech_service" {
    source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "cnsnlp-sp"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "SpeechServices"
    cl_cognitive_services_sku_name                         = "S0"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_Speech_service_Anomaly_Detector" {
    source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "cnsnlp-ad"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "AnomalyDetector"
    cl_cognitive_services_sku_name                         = "S0"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_TextAnalytics" {
    source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "nlp-ta"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "TextAnalytics"
    cl_cognitive_services_sku_name                         = "S"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_TextTranslation" {
    source                                                 = "../tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "nlp-ta"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "TextTranslation"
    cl_cognitive_services_sku_name                         = "S1"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                   = "privatelink.cognitiveservices.azure.com"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************
```

3. OpenAI

Note: OpenAI is a "kind" of Azure Cognitive services account that is available for AzureRM for TF provider version 3.40.0

```terraform
//********************************************************************************************
module "cl_cognitive_services" {
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  tags                                                   = var.tags
  cl_cognitive_services_postfix                          = var.cognitive_services_postfix
  cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_cognitive_services_resource_group_name              = azurerm_resource_group.cognitive_services.name
  cl_cognitive_services_rg_name                          = azurerm_resource_group.cognitive_services.name
  cl_cognitive_services_deploy_rg                        = true
  cl_cognitive_services_kind                             = "OpenAI"
  cl_cognitive_services_sku_name                         = "S0"  # at the moment (2023/03) this is the only SKU available for OpenAI
  cl_cognitive_services_nacls_default_action             = "Allow"
  cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.private_subnet_vm.id
  cl_cognitive_services_nacl_allowed_subnets             = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet.id]
  cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}
//********************************************************************************************
```
<!-- END_TF_DOCS -->

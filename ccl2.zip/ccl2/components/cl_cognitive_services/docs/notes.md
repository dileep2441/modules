#### Note:
For OpenAI kind, it needs AzureRM provider for Terraform version 3.40.0 or later.
It can be specified on Terraform backend:

```terraform
terraform {
  required_version = ">= 1.0"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">= 3.40.0"
    }
  }
}
```



## Usage

### Deploy App Service Slot with vnet integration subnet

```terraform
module "cl_app_service_plan" {
  source                                                    = "../tf-azure-component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = var.app_service_nsg_rules
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "app_service_private_dns_zone" {
  name                = "privatelink.azurewebsites.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "app_service_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.app_service_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_app_service" {
  source                                              = "../dn-tads_tf-azure-component-library/components/cl_app_service"
  env                                                 = var.env
  postfix                                             = var.postfix
  location                                            = var.location
  cl_app_service_plan_deploy_integration_subnet       = true
  cl_app_service_integration_subnet_id                = var.app_service_plan_deploy_integration_subnet ? module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id : null
  cl_app_service_client_affinity_enabled              = var.app_service_client_affinity_enabled
  cl_app_service_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_app_service_app_postfix                          = var.postfix
  cl_app_service_rg_name                              = module.cl_app_service_plan.cl_app_service_plan_rg
  cl_app_service_asp_id                               = module.cl_app_service_plan.cl_app_service_plan.id
  cl_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_service_diagnostics                          = var.app_service_diagnostics
  cl_app_service_settings                             = var.app_service_settings
  cl_app_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.app_service_private_dns_zone.id]

  //Site_Config
  cl_app_service_linux_fx_version                     = var.app_service_linux_fx_version
  cl_app_service_default_documents                    = var.app_service_default_documents
  cl_app_service_use_32_bit_worker_process            = var.app_service_use_32_bit_worker_process  
  tags                                                = var.tags
 }


module "cl_app_service_slot" {
  source                                              = "../dn-tads_tf-azure-component-library/components/cl_app_service_slot"
  env                                                 = var.env
  postfix                                             = var.postfix
  location                                            = var.location
  cl_app_service_slot_app_postfix                     = "releaseX"
  cl_app_service_slot_app_service                     = module.cl_app_service.cl_app_service
  cl_app_service_plan_deploy_integration_subnet       = true
  cl_app_service_slot_integration_subnet_id           = var.app_service_plan_deploy_integration_subnet ? module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id : null
  cl_app_service_slot_pe_subnet_ids                   = [azurerm_subnet.private_link_subnet.id]
  cl_app_service_slot_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                = var.tags
 }
```
## Local values

```terraform
locals {
    timeout_duration = "2h"
    cl_app_service_slot_rg               = var.cl_app_service_slot_app_service.resource_group_name
    cl_app_service_slot_asp_id           = var.cl_app_service_slot_app_service.app_service_plan_id
    cl_app_service_slot_app_service_name = var.cl_app_service_slot_app_service.name
    cl_app_service_slot_app_service_id   = var.cl_app_service_slot_app_service.id
}
```
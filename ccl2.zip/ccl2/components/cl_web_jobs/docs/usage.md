## Usage

### Deploy Web Jobs with VNet integration subnet
```terraform

// Create the private link subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "private_link_subnet" {
    name                                            =  "${var.env}-${var.postfix}-private-link-sn"
    resource_group_name                             = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    virtual_network_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
    address_prefixes                                = ["10.0.75.0/27"]
    enforce_private_link_endpoint_network_policies  = true
    service_endpoints                               = ["Microsoft.ServiceBus","Microsoft.Storage","Microsoft.KeyVault","Microsoft.AzureCosmosDB","Microsoft.Web"]
}
//********************************************************************************************** 
 
 // Create Private DNS Zone for Azure Storage Account
//**********************************************************************************************
resource "azurerm_private_dns_zone" "storage_account_private_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}
//**********************************************************************************************


// Link the Private Zone with the VNet for App Service
//**********************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "storage_account_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.storage_account_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//**********************************************************************************************


//********************************************************************************************** 
 // Deploys Storage Account for webjobs
//**********************************************************************************************
module "cl_storage_account" {
  source                                          = "../tf-azure-component-library/components/cl_storage_account"
  env                                             = var.env
  postfix                                         = "${var.postfix}"
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.private_link_subnet.id]
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.storage_account_private_dns_zone.id]
 }
//**********************************************************************************************


//**********************************************************************************************
// Create Service Plan for App Service
//**********************************************************************************************
module "cl_app_service_plan" {
  source                                                    = "../tf-azure-component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             =["10.0.75.64/26"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_app_postfix                           = "ale" 
  cl_app_service_plan_kind                                  = "Windows"
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.Storage", "Microsoft.Web"]
}
//**********************************************************************************************


// Create Private DNS Zone for Azure Web Apps
//**********************************************************************************************
resource "azurerm_private_dns_zone" "app_service_private_dns_zone" {
  name                = "privatelink.azurewebsites.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}
//**********************************************************************************************


// Link the Private Zone with the VNet for App Service
//**********************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "app_service_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.app_service_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//**********************************************************************************************


//**********************************************************************************************
// Create Web Jobs
//**********************************************************************************************
module "cl_web_jobs" {
  source                                           = "../tf-azure-component-library/components/cl_web_jobs"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_web_jobs_app_postfix                          = "web-jobs" 
  cl_web_jobs_integration_subnet_id                = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  cl_web_jobs_rg_name                              = module.cl_app_service_plan.cl_app_service_plan_rg.name
  cl_web_jobs_asp_id                               = module.cl_app_service_plan.cl_app_service_plan.id
  cl_web_jobs_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_web_jobs_private_dns_zone_ids                 = [azurerm_private_dns_zone.app_service_private_dns_zone.id]
  cl_web_jobs_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_web_jobs_settings                             = {
    WEBSITE_DNS_SERVER            = "168.63.129.16"
    WEBSITE_VNET_ROUTE_ALL        = "1"
  } 

  //For vanguard subscription please don't send the variable cl_web_jobs_connection_strings and you must to create the following connection strings manually with a CloudOps, in order to avoid error for sensitive values.  
  
  cl_web_jobs_connection_strings = {
    AzureWebJobsDashboard = {
     name = "AzureWebJobsDashboard"
     type = "Custom"
     value = "DefaultEndpointsProtocol=https;AccountName=${module.cl_storage_account.cl_storage_account.name};AccountKey=${module.cl_storage_account.cl_storage_account.primary_access_key};EndpointSuffix=privatelink.blob.core.windows.net"
  }
    AzureWebJobsStorage = {
     name = "AzureWebJobsStorage"
     type = "Custom"
     value = "DefaultEndpointsProtocol=https;AccountName=${module.cl_storage_account.cl_storage_account.name};AccountKey=${module.cl_storage_account.cl_storage_account.primary_access_key};EndpointSuffix=privatelink.blob.core.windows.net"
   }
  }  
 }
//**********************************************************************************************
```
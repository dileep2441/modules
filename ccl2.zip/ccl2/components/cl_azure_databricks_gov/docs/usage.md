

## Usage

```terraform
// Azure Data Bricks
//**********************************************************************************************
module "cl_azure_databricks" {
  source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_databricks_gov"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  tags                                                        = var.tags
  cl_azure_databricks_vnet_address_space                      = ["70.0.0.0/16"]
  cl_azure_databricks_subnet_public_address_prefixes          = ["70.0.1.0/24"]
  cl_azure_databricks_subnet_private_address_prefixes         = ["70.0.64.0/24"]
  cl_azure_databricks_subnet_ssh_source_ip_range              = "60.0.64.0/24"  //add more ips using commas
  cl_azure_databricks_subnet_proxy_source_ip_range            = "60.0.64.0/24"  //add more ips using commas
  cl_azure_databricks_log_analytics_workspace_id              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id //only for premium plan
  cl_azure_databricks_core_sa_enabled                         = true
  cl_azure_databricks_storage_account_nsg_flow_log_id         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
  cl_azure_databricks_nsg_flow_log_postfix                    = var.cl_azure_databricks_nsg_flow_log_postfix 
  cl_azure_databricks_public_nsg_rules = {  
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_azure_databricks_private_nsg_rules = {  
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
}
//**********************************************************************************************
```
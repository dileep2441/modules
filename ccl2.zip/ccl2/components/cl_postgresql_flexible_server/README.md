<!-- BEGIN_TF_DOCS -->

# Azure PostgreSQL - Flexible Server

Azure Database for PostgreSQL flexible server is a fully managed database service designed to provide more granular control and flexibility over database management functions and configuration settings. The service generally provides more flexibility and server configuration customizations based on user requirements. The flexible server architecture allows users to collocate the database engine with the client tier for lower latency and choose high availability within a single availability zone and across multiple availability zones. Azure Database for PostgreSQL flexible server instances also provide better cost optimization controls with the ability to stop/start your server and a burstable compute tier ideal for workloads that don't need full compute capacity continuously. The service supports the community version of PostgreSQL 11, 12, 13, 14, 15 and 16. The service is available in various Azure regions.

For more information, please visit: https://learn.microsoft.com/en-us/azure/postgresql/flexible-server/overview


## Resources

| Name | Type |
|------|------|
| [azurerm_subnet.cl_postgresql_flexible_server_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_postgresql_flexible_server.cl_postgresql_flexible_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server) | resource |
| [azurerm_security_center_subscription_pricing.cl_postgresql_flexible_server_defender](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_postgresql_flexible_server_configuration.security_server_parameters](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server_configuration) | resource |
| [azurerm_monitor_diagnostic_setting.cl_postgresql_flexible_server_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |



## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_postgresql_flexible_server_resource_group_name"></a> [cl\_postgresql\_flexible\_server\_resource\_group\_name](#input\_cl\_postgresql\_flexible\_server\_resource\_group\_name) | (Required) The name of the Resource Group where the PostgreSQL Flexible Server should exist | `string` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_admin_login"></a> [cl\_postgresql\_flexible\_server\_admin\_login](#input\_cl\_postgresql\_flexible\_server\_admin\_login) | (Optional) The Administrator login for the PostgreSQL Flexible Server. Required when create_mode is Default and authentication.password_auth_enabled is true | `string` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_log_analytics_workspace_id"></a> [cl\_postgresql\_flexible\_server\_log\_analytics\_workspace\_id](#input\_cl\_postgresql\_flexible\_server\_log\_analytics\_workspace\_id) | "(Required) The ID for the network resources" | `string` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_vnet_rg_name"></a> [cl\_postgresql\_flexible\_server\_vnet\_rg\_name](#input\_cl\_postgresql\_flexible\_server\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in | `string` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_vnet_name"></a> [cl\_postgresql\_flexible\_server\_vnet\_name](#input\_cl\_postgresql\_flexible\_server\_vnet\_name) | (Required) The name of the core vnet required for the PostgreSQL Flexible Server subnet." | `string` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_subnet_prefix"></a> [cl\_postgresql\_flexible\_server\_subnet\_prefix](#input\_cl\_postgresql\_flexible\_server\_subnet\_prefix) | The prefix of the PostgreSQL Flexible Server subnet with address prefix 0.0.0.0/27 & Only one instance per subnet is recommended | `list(string)` | n/a | yes |


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_postgresql_flexible_server"></a> [cl\_postgresql\_flexible\_server](#output\_cl\_postgresql\_flexible\_server) | n/a |
| <a name="output_cl_postgresql_flexible_server_diagnostic_setting"></a> [cl\_postgresql\_flexible\_server\_diagnostic\_setting](#output\_cl\_postgresql\_flexible\_server\_diagnostic\_setting) | Outputs ********************************************************************************************** |
| <a name="output_cl_postgres_sql_server_private_endpoint"></a> [cl\_postgresql\_flexible\_server\_subnet](#output\_cl\_postgresql\_flexible\_server\_subnet) | n/a |



## Usage

```terraform
// Deploy PostgreSQL - Flexible Server
//**********************************************************************************************
module "cl_postgresql_flexible_server" {
  source                                                   = "../dn-tads_tf-azure-component-library/components/cl_postgresql_flexible_server"
  env                                                      = var.env
  postfix                                                  = var.postfix
  location                                                 = var.location
  cl_postgresql_flexible_server_postfix                    = var.cl_postgresql_flexible_server_postfix
  cl_postgresql_flexible_server_resource_group_name        = var.cl_postgresql_flexible_server_resource_group_name
  cl_postgresql_flexible_server_vnet_rg_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.resource_group_name
  cl_postgresql_flexible_server_vnet_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_postgresql_flexible_server_subnet_prefix              = ["x.x.xx.x/27"]
  cl_postgresql_flexible_server_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_postgresql_flexible_server_private_dns_zone_id        = [var.cl_postgresql_flexible_server_private_dns_zone_id]
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
# Azure App Service Component

App Service is a fully-managed Platform as a Service (PaaS) that lets you deploy and scale web, mobile, and API apps.
This component will deploy an app service in the target app service plan, bind the app service to the integration subnet,
configure a private endpoint, custom domain and diagnostics for the app service.

For more information, please visit: https://docs.microsoft.com/en-us/azure/app-service/overview

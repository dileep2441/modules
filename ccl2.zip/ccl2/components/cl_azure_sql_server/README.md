<!-- BEGIN_TF_DOCS -->

# Azure SQL Server Component

SQL Server on Azure Virtual Machines enables users to use full versions of SQL Server in the cloud without having to manage any on-premises hardware. 
SQL Server virtual machines (VMs) also simplify licensing costs when you pay as you go.
This component will deploy a new Azure SQL Server, storage account for audit & security logging, diagnostic settings for the storage account, storage container, SQL Server audit policy, SQL Server security alert policy, Azure SQL Server security assessment, a private endpoint for Azure SQL Server, firewall rules, vnet rules and logs solutions for Azure SQL Server.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview 

## Information
## Enabled extended auditing policy to Azure Sql Server and enabled integration with AAD:
```terraform
1. For the integration with AAD confirm with the project the admin sql server group name and the object id group name
2. Deploy the infrastructure to Azure Sql Server and Azure Sql Database
3. Before to deploy the extended_auditing_policy, with a Admin cloudops request the role assignment to the Storage Account created for it in component Azure Sql server
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/and select the name for the Azure Sql server created
4. Add the variables to enabled the deploy for the extended_auditing_policy in azure sql server and azure sql database
   
   in module cl_azure_sql_server
   cl_azure_sql_server_audit_enabled              = true

   in module cl_azure_sql_database
   cl_azure_sql_database_audit_enabled             = true
```

## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.cl_azure_sql_server_sa_atp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_data_protection_backup_instance_blob_storage.cl_azure_sql_server_sa_protected_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_instance_blob_storage) | resource |
| [azurerm_log_analytics_solution.cl_azure_sql_server_log_analytics_solution](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_sql_server_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_mssql_firewall_rule.cl_azure_sql_server_firewall_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_firewall_rule) | resource |
| [azurerm_mssql_server.cl_azure_sql_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server) | resource |
| [azurerm_mssql_server_extended_auditing_policy.cl_azure_sql_server_audit_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server_extended_auditing_policy) | resource |
| [azurerm_mssql_server_security_alert_policy.cl_azure_sql_server_alert_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server_security_alert_policy) | resource |
| [azurerm_mssql_server_vulnerability_assessment.cl_azure_sql_server_security_assessment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server_vulnerability_assessment) | resource |
| [azurerm_mssql_virtual_network_rule.cl_azure_sql_server_vnet_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_virtual_network_rule) | resource |
| [azurerm_private_endpoint.cl_azure_sql_server_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_azure_sql_server_storage_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.cl_azure_sql_server_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.cl_azure_sql_server_storage_account_network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_storage_container.cl_azure_sql_server_sa_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_sql_server_administrator"></a> [cl\_azure\_sql\_server\_administrator](#input\_cl\_azure\_sql\_server\_administrator) | (Required) The administrator login name for the new server. Changing this forces a new resource to be created. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_alert_email_enabled"></a> [cl\_azure\_sql\_server\_alert\_email\_enabled](#input\_cl\_azure\_sql\_server\_alert\_email\_enabled) | (Optional) Boolean flag which specifies if the alert is sent to the account administrators or not. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_alert_emails"></a> [cl\_azure\_sql\_server\_alert\_emails](#input\_cl\_azure\_sql\_server\_alert\_emails) | (Optional) Specifies an array of e-mail addresses to which the alert is sent. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_alert_retention_days"></a> [cl\_azure\_sql\_server\_alert\_retention\_days](#input\_cl\_azure\_sql\_server\_alert\_retention\_days) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_cl_azure_sql_server_alert_state"></a> [cl\_azure\_sql\_server\_alert\_state](#input\_cl\_azure\_sql\_server\_alert\_state) | (Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific database server. Allowed values are: Disabled, Enabled. | `string` | `"Enabled"` | no |
| <a name="input_cl_azure_sql_server_audit_enabled"></a> [cl\_azure\_sql\_server\_audit\_enabled](#input\_cl\_azure\_sql\_server\_audit\_enabled) | (Optional) Boolean to enable sql server extended auditing policy resource creation | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_audit_retention_days"></a> [cl\_azure\_sql\_server\_audit\_retention\_days](#input\_cl\_azure\_sql\_server\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `90` | no |
| <a name="input_cl_azure_sql_server_azuread_login_username"></a> [cl\_azure\_sql\_server\_azuread\_login\_username](#input\_cl\_azure\_sql\_server\_azuread\_login\_username) | (Optional) The login username of the Azure AD Administrator of this SQL Server. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_azuread_object_id"></a> [cl\_azure\_sql\_server\_azuread\_object\_id](#input\_cl\_azure\_sql\_server\_azuread\_object\_id) | (Optional) The object id of the Azure AD Administrator of this SQL Server. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_connection_policy"></a> [cl\_azure\_sql\_server\_connection\_policy](#input\_cl\_azure\_sql\_server\_connection\_policy) | (Optional) The connection policy the server will use. Possible values are Default, Proxy, and Redirect. | `string` | `"Default"` | no |
| <a name="input_cl_azure_sql_server_deploy_log_analytics"></a> [cl\_azure\_sql\_server\_deploy\_log\_analytics](#input\_cl\_azure\_sql\_server\_deploy\_log\_analytics) | (Optional) Boolean to enable sql server log analytics solution resource creation | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_disabled_alerts"></a> [cl\_azure\_sql\_server\_disabled\_alerts](#input\_cl\_azure\_sql\_server\_disabled\_alerts) | (Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql\_Injection, Sql\_Injection\_Vulnerability, Access\_Anomaly, Data\_Exfiltration, Unsafe\_Action. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_enabled_sa_diagnostic_settings"></a> [cl\_azure\_sql\_server\_enabled\_sa\_diagnostic\_settings](#input\_cl\_azure\_sql\_server\_enabled\_sa\_diagnostic\_settings) | (Optional) Boolean to enable sa monitor diagnostic setting resource creation | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_firewall_rules"></a> [cl\_azure\_sql\_server\_firewall\_rules](#input\_cl\_azure\_sql\_server\_firewall\_rules) | (Optional) Define additional firewall rules | <pre>map(object({<br>    start_ip                 = string<br>    end_ip                   = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_sql_server_ignore_changes"></a> [cl\_azure\_sql\_server\_ignore\_changes](#input\_cl\_azure\_sql\_server\_ignore\_changes) | (Optional) Specifies an array of e-mail addresses to which the alert is sent. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_log_analytics_solution"></a> [cl\_azure\_sql\_server\_log\_analytics\_solution](#input\_cl\_azure\_sql\_server\_log\_analytics\_solution) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureSQLAnalytics": {<br>    "product": "OMSGallery/AzureSQLAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_cl_azure_sql_server_log_analytics_workspace_id"></a> [cl\_azure\_sql\_server\_log\_analytics\_workspace\_id](#input\_cl\_azure\_sql\_server\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_log_analytics_workspace_name"></a> [cl\_azure\_sql\_server\_log\_analytics\_workspace\_name](#input\_cl\_azure\_sql\_server\_log\_analytics\_workspace\_name) | (Required) The log analytics workspace name for diagnostics. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_logging_rg_name"></a> [cl\_azure\_sql\_server\_logging\_rg\_name](#input\_cl\_azure\_sql\_server\_logging\_rg\_name) | (Required) The resource group for log analytics. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_nacl_allowed_subnets"></a> [cl\_azure\_sql\_server\_nacl\_allowed\_subnets](#input\_cl\_azure\_sql\_server\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure SQL Server. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_password"></a> [cl\_azure\_sql\_server\_password](#input\_cl\_azure\_sql\_server\_password) | (Required) The password associated with the cl\_azure\_sql\_server\_administrator user. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_postfix"></a> [cl\_azure\_sql\_server\_postfix](#input\_cl\_azure\_sql\_server\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_private_dns_zone_ids"></a> [cl\_azure\_sql\_server\_private\_dns\_zone\_ids](#input\_cl\_azure\_sql\_server\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_public_network_access"></a> [cl\_azure\_sql\_server\_public\_network\_access](#input\_cl\_azure\_sql\_server\_public\_network\_access) | (Optional) Whether or not public network access is allowed for this server. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_resource_group_name"></a> [cl\_azure\_sql\_server\_resource\_group\_name](#input\_cl\_azure\_sql\_server\_resource\_group\_name) | (Required) Specifies the Azure SQL Server resource group | `string` | `""` | no |
| <a name="input_cl_azure_sql_server_sa_backup_policy_id"></a> [cl\_azure\_sql\_server\_sa\_backup\_policy\_id](#input\_cl\_azure\_sql\_server\_sa\_backup\_policy\_id) | The azure blob storage backup policy id from the backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_sql_server_sa_backup_vault"></a> [cl\_azure\_sql\_server\_sa\_backup\_vault](#input\_cl\_azure\_sql\_server\_sa\_backup\_vault) | The blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_sql_server_sa_backup_vault_id"></a> [cl\_azure\_sql\_server\_sa\_backup\_vault\_id](#input\_cl\_azure\_sql\_server\_sa\_backup\_vault\_id) | The id of blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_sql_server_sa_enable_backup"></a> [cl\_azure\_sql\_server\_sa\_enable\_backup](#input\_cl\_azure\_sql\_server\_sa\_enable\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_security_email_subscription"></a> [cl\_azure\_sql\_server\_security\_email\_subscription](#input\_cl\_azure\_sql\_server\_security\_email\_subscription) | (Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_security_emails"></a> [cl\_azure\_sql\_server\_security\_emails](#input\_cl\_azure\_sql\_server\_security\_emails) | (Optional) Specifies an array of e-mail addresses to which the scan notification is sent. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_security_enabled"></a> [cl\_azure\_sql\_server\_security\_enabled](#input\_cl\_azure\_sql\_server\_security\_enabled) | (Optional) Boolean to enable sql server extended auditing policy resource creation | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_security_scans"></a> [cl\_azure\_sql\_server\_security\_scans](#input\_cl\_azure\_sql\_server\_security\_scans) | (Optional) Boolean flag which specifies if recurring scans is enabled or disabled. | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_storage_account_blob_retention_days"></a> [cl\_azure\_sql\_server\_storage\_account\_blob\_retention\_days](#input\_cl\_azure\_sql\_server\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_azure_sql_server_storage_account_bypass"></a> [cl\_azure\_sql\_server\_storage\_account\_bypass](#input\_cl\_azure\_sql\_server\_storage\_account\_bypass) | (Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. | `list(string)` | <pre>[<br>  "None"<br>]</pre> | no |
| <a name="input_cl_azure_sql_server_storage_account_container_retention_days"></a> [cl\_azure\_sql\_server\_storage\_account\_container\_retention\_days](#input\_cl\_azure\_sql\_server\_storage\_account\_container\_retention\_days) | Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7` | `number` | `7` | no |
| <a name="input_cl_azure_sql_server_storage_account_default_to_oauth_authentication"></a> [cl\_azure\_sql\_server\_storage\_account\_default\_to\_oauth\_authentication](#input\_cl\_azure\_sql\_server\_storage\_account\_default\_to\_oauth\_authentication) | (Optional) Default to Azure Active Directory authorization in the Azure portal when accessing the Storage Account. The default value is false | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_storage_account_diagnostics"></a> [cl\_azure\_sql\_server\_storage\_account\_diagnostics](#input\_cl\_azure\_sql\_server\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "StorageRead",<br>    "StorageWrite",<br>    "StorageDelete"<br>  ],<br>  "metrics": [<br>    "Transaction"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_sql_server_storage_account_ip_rules"></a> [cl\_azure\_sql\_server\_storage\_account\_ip\_rules](#input\_cl\_azure\_sql\_server\_storage\_account\_ip\_rules) | (Optional) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_storage_account_min_tls_version"></a> [cl\_azure\_sql\_server\_storage\_account\_min\_tls\_version](#input\_cl\_azure\_sql\_server\_storage\_account\_min\_tls\_version) | (Optional) Defines the minimum TLS version to use for the data lake storage account. | `string` | `"TLS1_2"` | no |
| <a name="input_cl_azure_sql_server_storage_account_network_default_action"></a> [cl\_azure\_sql\_server\_storage\_account\_network\_default\_action](#input\_cl\_azure\_sql\_server\_storage\_account\_network\_default\_action) | (Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow. | `string` | `"Deny"` | no |
| <a name="input_cl_azure_sql_server_storage_account_pe_subnet_ids"></a> [cl\_azure\_sql\_server\_storage\_account\_pe\_subnet\_ids](#input\_cl\_azure\_sql\_server\_storage\_account\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_cl_azure_sql_server_storage_account_private_dns_zone_ids"></a> [cl\_azure\_sql\_server\_storage\_account\_private\_dns\_zone\_ids](#input\_cl\_azure\_sql\_server\_storage\_account\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_storage_account_replication_type"></a> [cl\_azure\_sql\_server\_storage\_account\_replication\_type](#input\_cl\_azure\_sql\_server\_storage\_account\_replication\_type) | (Optional) Defines the type of replication to use for the storage account for Azure SQL server audit and security logging. | `string` | `"LRS"` | no |
| <a name="input_cl_azure_sql_server_storage_account_subnet_ids"></a> [cl\_azure\_sql\_server\_storage\_account\_subnet\_ids](#input\_cl\_azure\_sql\_server\_storage\_account\_subnet\_ids) | (Optional) A list of resource ids for subnets. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_storage_account_tier"></a> [cl\_azure\_sql\_server\_storage\_account\_tier](#input\_cl\_azure\_sql\_server\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for Azure SQL server audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_cl_azure_sql_server_tls"></a> [cl\_azure\_sql\_server\_tls](#input\_cl\_azure\_sql\_server\_tls) | (Optional) The Minimum TLS Version for all SQL Database and SQL Data Warehouse databases associated with the server. Valid values are: 1.0, 1.1 and 1.2. | `string` | `"1.2"` | no |
| <a name="input_cl_azure_sql_server_version"></a> [cl\_azure\_sql\_server\_version](#input\_cl\_azure\_sql\_server\_version) | (Optional) The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server). | `string` | `"12.0"` | no |
| <a name="input_cl_azure_sql_server_vnet_rules"></a> [cl\_azure\_sql\_server\_vnet\_rules](#input\_cl\_azure\_sql\_server\_vnet\_rules) | (Optional) Define additional virtual network rules | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_vulnerability_enabled"></a> [cl\_azure\_sql\_server\_vulnerability\_enabled](#input\_cl\_azure\_sql\_server\_vulnerability\_enabled) | (Optional) Boolean to enable sql server extended auditing policy resource creation | `bool` | `true` | no |
| <a name="input_cl_private_endpoint_subresource_names"></a> [cl\_private\_endpoint\_subresource\_names](#input\_cl\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "sqlServer"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_storage_account_blob_properties = (var.cl_azure_sql_server_sa_enable_backup ? false : true)
  cl_azure_sql_server_storage_account = {
    "sbox-pr"  = "sboxpr"
    "nprd-pr"  = "nprdpr"
    "nprd-dr"  = "nprddr"
    "prod-pr"  = "prodpr" 
    "prod-dr"  = "proddr"
    "nprod-pr" = "nprodpr"
  }
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_sql_server"></a> [cl\_azure\_sql\_server](#output\_cl\_azure\_sql\_server) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_sql_server_alert_policy"></a> [cl\_azure\_sql\_server\_alert\_policy](#output\_cl\_azure\_sql\_server\_alert\_policy) | n/a |
| <a name="output_cl_azure_sql_server_audit_policy"></a> [cl\_azure\_sql\_server\_audit\_policy](#output\_cl\_azure\_sql\_server\_audit\_policy) | n/a |
| <a name="output_cl_azure_sql_server_firewall_rules"></a> [cl\_azure\_sql\_server\_firewall\_rules](#output\_cl\_azure\_sql\_server\_firewall\_rules) | n/a |
| <a name="output_cl_azure_sql_server_log_analytics_solution"></a> [cl\_azure\_sql\_server\_log\_analytics\_solution](#output\_cl\_azure\_sql\_server\_log\_analytics\_solution) | n/a |
| <a name="output_cl_azure_sql_server_private_endpoint"></a> [cl\_azure\_sql\_server\_private\_endpoint](#output\_cl\_azure\_sql\_server\_private\_endpoint) | n/a |
| <a name="output_cl_azure_sql_server_sa_atp"></a> [cl\_azure\_sql\_server\_sa\_atp](#output\_cl\_azure\_sql\_server\_sa\_atp) | n/a |
| <a name="output_cl_azure_sql_server_sa_protected_blob"></a> [cl\_azure\_sql\_server\_sa\_protected\_blob](#output\_cl\_azure\_sql\_server\_sa\_protected\_blob) | n/a |
| <a name="output_cl_azure_sql_server_security_assessment"></a> [cl\_azure\_sql\_server\_security\_assessment](#output\_cl\_azure\_sql\_server\_security\_assessment) | n/a |
| <a name="output_cl_azure_sql_server_storage_account"></a> [cl\_azure\_sql\_server\_storage\_account](#output\_cl\_azure\_sql\_server\_storage\_account) | n/a |
| <a name="output_cl_azure_sql_server_storage_account_diagnostic_setting"></a> [cl\_azure\_sql\_server\_storage\_account\_diagnostic\_setting](#output\_cl\_azure\_sql\_server\_storage\_account\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_sql_server_storage_account_private_endpoint"></a> [cl\_azure\_sql\_server\_storage\_account\_private\_endpoint](#output\_cl\_azure\_sql\_server\_storage\_account\_private\_endpoint) | n/a |
| <a name="output_cl_azure_sql_server_vnet_rules"></a> [cl\_azure\_sql\_server\_vnet\_rules](#output\_cl\_azure\_sql\_server\_vnet\_rules) | n/a |

## Usage
```terraform

resource "azurerm_private_dns_zone" "sqldb_private_dns_zone" {
  name                = "privatelink.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sqldb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-sqldb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.sqldb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                   = var.tags
}

module "cl_azure_sql_server" {
  source                                           = "../tf-azure-component-library/components/cl_azure_sql_server"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_azuread_login_username       = confirm the ADD group with the sql admins for the project
  cl_azure_sql_server_azuread_object_id            = confirme the group admin sql object id created for variable cl_azure_sql_server_azuread_login_username
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids         = [azurerm_private_dns_zone.sqldb_private_dns_zone.id]
  cl_azure_sql_server_sa_enable_backup             = true
  cl_azure_sql_server_sa_backup_vault_id           = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_azure_sql_server_sa_backup_vault              = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_azure_sql_server_sa_backup_policy_id          = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_azure_sql_server_storage_account_bypass       = ["AzureServices"]
  cl_azure_sql_server_storage_account_ip_rules     = ["199.206.0.0/15"] //Jenkins IP
}
```

## Deploying the SQL Server's storage account with private endpoints

```terraform

resource "azurerm_private_dns_zone" "sqldb_private_dns_zone" {
  name                = "privatelink.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sqldb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-sqldb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.sqldb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  tags                   = var.tags
}

resource "azurerm_private_dns_zone" "blob_private_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "blob_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-blob-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.blob_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  tags                   = var.tags
}

module "cl_azure_sql_server" {
  source                                                   = "../tf-azure-component-library/components/cl_azure_sql_server"
  env                                                      = var.env
  postfix                                                  = var.postfix
  location                                                 = var.location
  cl_azure_sql_server_postfix                              = "global"
  cl_azure_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                        = "sqladmin"
  cl_azure_sql_server_password                             = "Portal123456!"
  cl_azure_sql_server_azuread_login_username               = confirm the ADD group with the sql admins for the project
  cl_azure_sql_server_azuread_object_id                    = confirme the group admin sql object id created for variab
  cl_azure_sql_server_logging_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets                 = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_azure_sql_server_vnet_rules                           = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.sqldb_private_dns_zone.id]
  cl_azure_sql_server_storage_account_private_dns_zone_ids = [azurerm_private_dns_zone.blob_private_dns_zone.id]
  cl_azure_sql_server_storage_account_pe_subnet_ids        = [azurerm_subnet.pe_subnet.id]
  cl_azure_sql_server_storage_account_bypass               = ["AzureServices"]
  cl_azure_sql_server_storage_account_ip_rules             = ["199.206.0.0/15"] //Jenkins IP
}
```
<!-- END_TF_DOCS -->
>>>>>>> origin/staging

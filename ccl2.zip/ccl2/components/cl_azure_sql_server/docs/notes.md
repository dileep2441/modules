## Information
## Enabled extended auditing policy to Azure Sql Server and enabled integration with AAD:
```terraform
1. For the integration with AAD confirm with the project the admin sql server group name and the object id group name
2. Deploy the infrastructure to Azure Sql Server and Azure Sql Database
3. Before to deploy the extended_auditing_policy, with a Admin cloudops request the role assignment to the Storage Account created for it in component Azure Sql server
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/and select the name for the Azure Sql server created
4. Add the variables to enabled the deploy for the extended_auditing_policy in azure sql server and azure sql database
   
   in module cl_azure_sql_server
   cl_azure_sql_server_audit_enabled              = true

   in module cl_azure_sql_database
   cl_azure_sql_database_audit_enabled             = true
```

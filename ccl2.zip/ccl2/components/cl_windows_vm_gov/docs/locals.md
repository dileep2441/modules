## Local values

```terraform
locals {
  timeout_duration     = "2h"
  cl_windows_vm_rg     = var.cl_windows_vm_deploy_rg ? azurerm_resource_group.cl_windows_vm_rg[0].name : var.cl_windows_vm_rg_name
  cl_windows_availability_set_id     = var.cl_windows_deploy_availability_set ? azurerm_availability_set.cl_windows_availability_set[0].name : var.cl_windows_availability_set_id
  cl_windows_vm_subnet = var.cl_windows_vm_deploy_subnet ? azurerm_subnet.cl_windows_vm_subnet[0] : null
  cl_windows_vm_nsg    = var.cl_windows_vm_deploy_subnet_nsg ? azurerm_network_security_group.cl_windows_vm_nsg[0] : null
}
```


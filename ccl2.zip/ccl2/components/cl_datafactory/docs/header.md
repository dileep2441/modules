# Azure DataFactory Component

Azure Data Factory is the cloud-based ETL and data integration service that allows you to create data-driven workflows for orchestrating data movement and transforming data at scale. 
With Azure Data Factory, users can create and schedule data-driven workflows (pipelines) that can ingest data from multiple data stores. 
It allows to build complex ETL processes that transform data visually with data flows or by using compute services such as Azure HDInsight Hadoop, Azure Databricks, and Azure SQL Database.

This component will deploy DataFactory, Self-Hosted IR, Monitor Diagnostics, Log Analytics and Private Endpoint for allowed Subnets.

For more information, please visit: https://docs.microsoft.com/en-us/azure/data-factory/introduction
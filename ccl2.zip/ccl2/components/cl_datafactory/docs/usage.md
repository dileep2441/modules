## Usage

```terraform
resource "azurerm_private_dns_zone" "data_factory_private_dns_zone" {
  name                = var.datafactory_private_dns_zone_name
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "data_factory_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-adf-private-dns-vnet-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.data_factory_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_datafactory" {
    source                                        = "../tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]
}
```
## Usage with VSTS/ADO Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]    

    cl_datafactory_repository_type                = "vsts" 
    cl_datafactory_vsts_account_name              = "organization_name"
    cl_datafactory_vsts_branch_name               = "master"
    cl_datafactory_vsts_project_name              = "migration" 
    cl_datafactory_vsts_repository_name           = "migration"
    cl_datafactory_vsts_root_folder               = "/" 
    cl_datafactory_vsts_tenant_id                 = "z567b2579-xxx-457d-a68e-764775adcb646"
}
```
## Usage with GITHUB Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]

    cl_datafactory_repository_type                = "github" 
    cl_datafactory_github_account_name            = "organization_name"
    cl_datafactory_github_branch_name             = "master"
    cl_datafactory_github_git_url                 = "https://domaingithub.com/" 
    cl_datafactory_github_repository_name         = "migration"
    cl_datafactory_github_root_folder             = "/" 
}

resource "azurerm_private_dns_a_record" "data_factory_private_dns_record" {
  name                = "${var.env}-${var.postfix}-adf-pe-record"
  zone_name           = azurerm_private_dns_zone.data_factory_private_dns_zone.name
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                 = var.datafactory_private_record_ttl
  records             = module.cl_datafactory.azurerm_private_endpoint_datafactory_dataFactory[*].private_service_connection[0].private_ip_address
  tags                = var.tags
}
```
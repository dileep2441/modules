## Usage

``` hcl
 module "cl_azure_dns_resolver" {
   source                                                   = "../dn-tads_tf-azure-component-library/components/cl_azure_dns_private_resolver"
   env                                                      = var.env
   postfix                                                  = var.postfix
   location                                                 = var.location
   cl_azure_dns_resolver_vnet_rg_name                       = azurerm_virtual_network.core_vnet.resource_group_name
   cl_azure_dns_resolver_vnet_name                          = azurerm_virtual_network.core_vnet.name
   cl_azure_dns_resolver_subnet_inbound_prefix              = ["10.102.76.16/28"]
   cl_azure_dns_resolver_subnet_outbound_prefix             = ["10.102.76.0/28"]
   cl_azure_dns_resolver_vnet_id                            = azurerm_virtual_network.core_vnet.id
   cl_azure_dns_resolver_inbound_endpoint_name              = "indtest"
   cl_azure_dns_resolver_outbound_endpoint_name             = "outtest" 
   cl_azure_dns_resolver_dns_forwarding_rulese_name         = "test"
   //The dns resolver forwarding_rule values depends on dns onprem for each environment (US, LATAM, US CH, US LATAM)
   cl_azure_dns_resolver_forwarding_rule_onprem_name        = "onprem-forwarder" 
   cl_azure_dns_resolver_forwarding_rule_onprem_domain_name =  "onprem.com." 
   cl_azure_dns_resolver_forwarding_rule_onprem_ip_address  = "10.36.18.83" 
   cl_azure_dns_resolver_forwarding_rule_onprem_ip_address2 = "10.50.18.83" 
 }
```
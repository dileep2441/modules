# Azure Key Vault Component

Azure Key Vault is a cloud service for securely storing and accessing secrets. 
Key Vault service supports two types of containers: vaults and managed hardware security module (HSM) pools. 
Vaults support storing software and HSM-backed keys, secrets, and certificates. Managed HSM pools only support HSM-backed keys. 
This component will deploy Azure Key Vault, Private Endpoint and diagnostics settings for the Key Vault.

For more information, please visit: https://docs.microsoft.com/en-us/azure/key-vault/general/basic-concepts


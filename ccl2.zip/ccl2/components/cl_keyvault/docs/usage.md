## Usage

```terraform
module "cl_keyvault" {
  source                                   = "../tf-azure-component-library/components/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_keyvault_private_dns_zone_ids         = [var.private_dns_zone_id]
  cl_keyvault_nacl_allowed_subnets         = [azurerm_subnet.test_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
}
```
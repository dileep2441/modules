<!-- BEGIN_TF_DOCS -->

# Azure Key Vault Component

Azure Key Vault is a cloud service for securely storing and accessing secrets. 
Key Vault service supports two types of containers: vaults and managed hardware security module (HSM) pools. 
Vaults support storing software and HSM-backed keys, secrets, and certificates. Managed HSM pools only support HSM-backed keys. 
This component will deploy Azure Key Vault, Private Endpoint and diagnostics settings for the Key Vault.

For more information, please visit: https://docs.microsoft.com/en-us/azure/key-vault/general/basic-concepts




## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.cl_keyvault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |
| [azurerm_log_analytics_solution.cl_keyvault_log_analytics_solution](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_monitor_diagnostic_setting.cl_keyvault_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_keyvault_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_keyvault_allowed_pe_subnet_ids"></a> [cl\_keyvault\_allowed\_pe\_subnet\_ids](#input\_cl\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_cl_keyvault_az_svcs_bypass"></a> [cl\_keyvault\_az\_svcs\_bypass](#input\_cl\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_cl_keyvault_deploy_log_analytics"></a> [cl\_keyvault\_deploy\_log\_analytics](#input\_cl\_keyvault\_deploy\_log\_analytics) | (Optional) Boolean to enable key vault log analytics solution resource creation | `bool` | `true` | no |
| <a name="input_cl_keyvault_diagnostics"></a> [cl\_keyvault\_diagnostics](#input\_cl\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_keyvault_enabled_for_deployment"></a> [cl\_keyvault\_enabled\_for\_deployment](#input\_cl\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_cl_keyvault_enabled_for_disk_encryption"></a> [cl\_keyvault\_enabled\_for\_disk\_encryption](#input\_cl\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_cl_keyvault_enabled_for_template_deployment"></a> [cl\_keyvault\_enabled\_for\_template\_deployment](#input\_cl\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_cl_keyvault_log_analytics_solutions"></a> [cl\_keyvault\_log\_analytics\_solutions](#input\_cl\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_cl_keyvault_log_analytics_workspace_id"></a> [cl\_keyvault\_log\_analytics\_workspace\_id](#input\_cl\_keyvault\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_keyvault_log_analytics_workspace_name"></a> [cl\_keyvault\_log\_analytics\_workspace\_name](#input\_cl\_keyvault\_log\_analytics\_workspace\_name) | (Required) The the log analytics workspace name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_keyvault_logging_rg_name"></a> [cl\_keyvault\_logging\_rg\_name](#input\_cl\_keyvault\_logging\_rg\_name) | (Required) The resource group for the keyvault log analytics solution. | `any` | n/a | yes |
| <a name="input_cl_keyvault_nacl_allowed_ips"></a> [cl\_keyvault\_nacl\_allowed\_ips](#input\_cl\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_cl_keyvault_nacl_allowed_subnets"></a> [cl\_keyvault\_nacl\_allowed\_subnets](#input\_cl\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_cl_keyvault_nacl_default_action"></a> [cl\_keyvault\_nacl\_default\_action](#input\_cl\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_cl_keyvault_postfix"></a> [cl\_keyvault\_postfix](#input\_cl\_keyvault\_postfix) | (Required) The bespoke name of the kv app or project you are deploying. | `any` | n/a | yes |
| <a name="input_cl_keyvault_private_dns_zone_ids"></a> [cl\_keyvault\_private\_dns\_zone\_ids](#input\_cl\_keyvault\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_keyvault_purge_protection_enabled"></a> [cl\_keyvault\_purge\_protection\_enabled](#input\_cl\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_cl_keyvault_rg_name"></a> [cl\_keyvault\_rg\_name](#input\_cl\_keyvault\_rg\_name) | (Required) The resource group for the keyvault. | `any` | n/a | yes |
| <a name="input_cl_keyvault_sku_name"></a> [cl\_keyvault\_sku\_name](#input\_cl\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"premium"` | no |
| <a name="input_cl_keyvault_soft_delete_retention_days"></a> [cl\_keyvault\_soft\_delete\_retention\_days](#input\_cl\_keyvault\_soft\_delete\_retention\_days) | (Optional) The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the default) days. | `number` | `90` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | (Required) The tenant ID that the resources will reside in. | `any` | n/a | yes |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_keyvault"></a> [cl\_keyvault](#output\_cl\_keyvault) | Outputs ********************************************************************************************** |
| <a name="output_cl_keyvault_diagnostic_setting"></a> [cl\_keyvault\_diagnostic\_setting](#output\_cl\_keyvault\_diagnostic\_setting) | n/a |
| <a name="output_cl_keyvault_log_analytics_solution"></a> [cl\_keyvault\_log\_analytics\_solution](#output\_cl\_keyvault\_log\_analytics\_solution) | n/a |
| <a name="output_cl_keyvault_private_endpoint"></a> [cl\_keyvault\_private\_endpoint](#output\_cl\_keyvault\_private\_endpoint) | n/a |

## Usage

```terraform
module "cl_keyvault" {
  source                                   = "../tf-azure-component-library/components/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_keyvault_private_dns_zone_ids         = [var.private_dns_zone_id]
  cl_keyvault_nacl_allowed_subnets         = [azurerm_subnet.test_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
}
```
<!-- END_TF_DOCS -->

## Usage
#### Log Analytics workspace
```terraform
//**********************************************************************************************
#IMPORTANT - ONLY DEPLOY "azurerm_monitor_private_link_scoped_service" IF DEPLOYING IN US (NOT LATAM).
# NOTE - Since the AMPLS is a centralized service in shared services, its required to use a provider to access the AMPLS name (not resource ID). azurerm.shs_us, local.core_sharedsvcs_us_logging_rg & local.core_sharedsvcs_us_log_analytics_private_link_scope_name are already defined in nebula framework.

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_us
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_us_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_us_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
}

module "cl_log_analytics_workspace" {
    source                                                              = "../dn-tads_tf-azure-component-library/components/cl_log_analytics_workspace"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    cl_log_analytics_logging_rg_name                                    = var.cl_log_analytics_logging_rg_name  
}
```
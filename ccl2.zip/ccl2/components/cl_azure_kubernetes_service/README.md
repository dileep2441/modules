<!-- BEGIN_TF_DOCS -->

# Azure Kubernetes service Component

Azure Kubernetes Service (AKS) simplifies deploying a managed Kubernetes cluster in Azure by offloading the operational overhead to Azure. 
As a hosted Kubernetes service, Azure handles critical tasks, like health monitoring and maintenance. 
Since Kubernetes masters are managed by Azure, you only manage and maintain the agent nodes. 
Thus, AKS is free; you only pay for the agent nodes within your clusters, not for the masters.

For more information, please visit: https://docs.microsoft.com/en-us/azure/aks/intro-kubernetes 

```terraform
1. Azure Kubernetes Cluster Egress Traffic UDR Prerequisites:

* Create the following firewall rules with source vnet aks node pool - Restrict egress traffic in Azure Kubernetes Service (AKS) - https://docs.microsoft.com/en-us/azure/aks/limit-egress-traffic

   * *:123 or ntp.ubuntu.com:123 - Required for Network Time Protocol (NTP) time synchronization on Linux nodes.
   * CustomDNSIP:53 - If you're using custom DNS servers, you must ensure they're accessible by the cluster nodes.
   * *.hcp.<location>.azmk8s.io: HTTPS 443 - Required for Node <-> API server communication. Replace <location> with the region where your AKS cluster is deployed.
   * mcr.microsoft.com: HTTPS 443 - Required to access images in Microsoft Container Registry (MCR). This registry contains first-party images/charts (for example, coreDNS, etc.). These images are required for the correct creation and functioning of the cluster, including scale and upgrade operations.
   * *.data.mcr.microsoft.com: HTTPS 443 - Required for MCR storage backed by the Azure content delivery network (CDN).
   * management.azure.com: HTTPS 443 - Required for Kubernetes operations against the Azure API.
   * login.microsoftonline.com: HTTPS 443 - Required for Azure Active Directory authentication.
   * packages.microsoft.com: HTTPS 443 - This address is the Microsoft packages repository used for cached apt-get operations. Example packages include Moby, PowerShell, and Azure CLI.
   * acs-mirror.azureedge.net: HTTPS 443 - This address is for the repository required to download and install required binaries like kubenet and Azure CNI.
   * nvidia.github.io: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * us.download.nvidia.com: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * apt.dockerproject.org: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * ServiceTag - AzureMonitor: HTTPS 443 - This endpoint is used to send metrics data and logs to Azure Monitor and Log Analytics.
   * dc.services.visualstudio.com: HTTPS 443 - This endpoint is used for metrics and monitoring telemetry using Azure Monitor.
   * *.ods.opinsights.azure.com: HTTPS 443 - This endpoint is used by Azure Monitor for ingesting log analytics data.
   * *.oms.opinsights.azure.com: HTTPS 443 - This endpoint is used by omsagent, which is used to authenticate the log analytics service.
   * *.monitoring.azure.com:	HTTPS 443 - This endpoint is used to send metrics data to Azure Monitor.
   * data.policy.core.windows.net: HTTPS 443 - This address is used to pull the Kubernetes policies and to report cluster compliance status to policy service.
   * store.policy.core.windows.net: HTTPS 443 - This address is used to pull the Gatekeeper artifacts of built-in policies.
   * dc.services.visualstudio.com: HTTPS 443 - Azure Policy add-on that sends telemetry data to applications insights endpoint.
   * motd.ubuntu.com:  HTTPS 443 - is a package that makes a call periodically to Canonical servers to get updated news for support and informational purposes.
   * optional rule windows server node pool: HTTPS 443 - onegetcdn.azureedge.net, go.microsoft.com - To install windows-related binaries
   * optional rule windows server node pool: HTTP 80 - *.mp.microsoft.com, www.msftconnecttest.com, ctldl.windowsupdate.com - To install windows-related binaries
   * optional rules: HTTP 80 - security.ubuntu.com, azure.archive.ubuntu.com, changelogs.ubuntu.com - This address lets the Linux cluster nodes download the required security patches and updates.

2. Azure Kubernetes service Component will deploy the following resources:

* Resource Group for Azure Kubernetes Cluster - Optional resource creation
* Private Kubernetes Cluster - A private cluster uses an internal IP address to ensure that network traffic between the API server and node pools remains on a private network only.
* Resource Group Node Pool with the following components
   * Kubelet Managed Indentity
   * Ingress Application Gateway Managed Identity
   * Azure Policy Managed Identity
   * Oms Agent Managed Identity
   * Private endpoint
   * Private DNS zone
   * Kube Api server Network interface subnet node pool
   * Network security group
* Log Analytics Solution
* Monitor Diagnostic Settings - "kube-apiserver","kube-audit","kube-audit-admin","kube-controller-manager","kube-scheduler","cluster-autoscaler","guard"

3. Azure Kubernetes service Component will deploy the resources with the following Configurations:

* Private Cluster Enabled
* Egress traffic userDefinedRouting (UDR)
* Local Account Disabled
* Public fqdn Disabled
* Manage Identity SystemAssigned
* RBAC &  AAD Enabled
* Network Plugins Azure CNI
* Network Policy Azure
* Add-on ingress_application_gateway Enabled
* Add-on oms_agent Enabled 
* Add-onh http application routing Disabled
* Add-on kube_dashboard Disabled
* Default Node Pool Public Ip Disabled
* Default Node Pool only critical addons Enabled
```

#### Note:
To add windows node pool to kubernetes cluster, it needs Terraform version 0.15 or later.
It can be specified on Jenkinsfile:
```jenkinsfile
stage("Terraform *** ") {
    agent {
        docker {
            image 'dn-cloud-docker.artifactory.us.kworld.kpmg.com/azure-terraform-0-15-4:latest'
            ...
```
Specify TF version in `pattern_backend`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```

## Resources

| Name | Type |
|------|------|
| [azurerm_kubernetes_cluster.cl_kubernetes_cluster](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/kubernetes_cluster) | resource |
| [azurerm_log_analytics_solution.cl_kubernetes_log_analytics_solution](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_monitor_diagnostic_setting.cl_kubernetes_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_resource_group.cl_kubernetes_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.cl_kubernetes_rt_default_route_latam](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route.cl_kubernetes_rt_default_route_us](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.cl_kubernetes_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_subnet_route_table_association.cl_kubernetes_rt_associate_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_kubernetes_addon_profile_acilnx_enabled"></a> [cl\_kubernetes\_addon\_profile\_acilnx\_enabled](#input\_cl\_kubernetes\_addon\_profile\_acilnx\_enabled) | (Optional) Is the virtual node addon enabled | `bool` | `false` | no |
| <a name="input_cl_kubernetes_addon_profile_acilnx_subnet_name"></a> [cl\_kubernetes\_addon\_profile\_acilnx\_subnet\_name](#input\_cl\_kubernetes\_addon\_profile\_acilnx\_subnet\_name) | (Optional) The subnet name for the virtual nodes to run. This is required when aci\_connector\_linux enabled argument is set to true. | `string` | `""` | no |
| <a name="input_cl_kubernetes_addon_profile_azure_keyvault_secrets_provider_enabled"></a> [cl\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_enabled](#input\_cl\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_enabled) | (Optional) Is the Azure Keyvault Secrets Providerenabled | `bool` | `true` | no |
| <a name="input_cl_kubernetes_addon_profile_azure_keyvault_secrets_provider_secret_rotation_enabled"></a> [cl\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_secret\_rotation\_enabled](#input\_cl\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_secret\_rotation\_enabled) | (Optional) Is secret rotation enabled | `bool` | `false` | no |
| <a name="input_cl_kubernetes_addon_profile_azure_keyvault_secrets_provider_secret_rotation_interval"></a> [cl\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_secret\_rotation\_interval](#input\_cl\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_secret\_rotation\_interval) | (Optional) The interval to poll for secret rotation. This attribute is only set when secret\_rotation is true and defaults to 2m. | `string` | `"2m"` | no |
| <a name="input_cl_kubernetes_addon_profile_azure_policy_enabled"></a> [cl\_kubernetes\_addon\_profile\_azure\_policy\_enabled](#input\_cl\_kubernetes\_addon\_profile\_azure\_policy\_enabled) | (Optional) Is the Azure Policy for Kubernetes Add On enabled. At this time Azure Policy is not supported in Azure US Government and it is in Public Preview | `bool` | `true` | no |
| <a name="input_cl_kubernetes_addon_profile_http_application_routing_enabled"></a> [cl\_kubernetes\_addon\_profile\_http\_application\_routing\_enabled](#input\_cl\_kubernetes\_addon\_profile\_http\_application\_routing\_enabled) | (Optional) Is HTTP Application Routing Enabled. At this time HTTP Application Routing is not supported in Azure China or Azure US Government. | `bool` | `false` | no |
| <a name="input_cl_kubernetes_addon_profile_ingress_application_gateway_effective_id"></a> [cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_effective\_id](#input\_cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_effective\_id) | (Optional) The ID of the Application Gateway associated with the ingress controller deployed to this Kubernetes Cluster. | `string` | `null` | no |
| <a name="input_cl_kubernetes_addon_profile_ingress_application_gateway_enabled"></a> [cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_enabled](#input\_cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_enabled) | (Optional) Is the Application Gateway ingress controller integrated with this Kubernetes Cluster | `bool` | `false` | no |
| <a name="input_cl_kubernetes_addon_profile_ingress_application_gateway_id"></a> [cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_id](#input\_cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_id) | (Optional) The ID of the Application Gateway integrated with the ingress controller of this Kubernetes Cluster. This attribute is only set when gateway\_id is specified when configuring the ingress\_application\_gateway addon. | `string` | `null` | no |
| <a name="input_cl_kubernetes_addon_profile_ingress_application_gateway_subnet_cidr"></a> [cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_subnet\_cidr](#input\_cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_subnet\_cidr) | (Optional) The subnet CIDR used to create an Application Gateway, which in turn will be integrated with the ingress controller of this Kubernetes Cluster. This attribute is only set when subnet\_cidr is specified when configuring the ingress\_application\_gateway addon. | `string` | `null` | no |
| <a name="input_cl_kubernetes_addon_profile_ingress_application_gateway_subnet_id"></a> [cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_subnet\_id](#input\_cl\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_subnet\_id) | (Optional) The ID of the subnet on which to create an Application Gateway, which in turn will be integrated with the ingress controller of this Kubernetes Cluster. This attribute is only set when subnet\_id is specified when configuring the ingress\_application\_gateway addon | `string` | `null` | no |
| <a name="input_cl_kubernetes_addon_profile_kube_dashboard_enabled"></a> [cl\_kubernetes\_addon\_profile\_kube\_dashboard\_enabled](#input\_cl\_kubernetes\_addon\_profile\_kube\_dashboard\_enabled) | (Optional) Is the Kubernetes Dashboard enabled | `bool` | `false` | no |
| <a name="input_cl_kubernetes_addon_profile_oms_agent_enabled"></a> [cl\_kubernetes\_addon\_profile\_oms\_agent\_enabled](#input\_cl\_kubernetes\_addon\_profile\_oms\_agent\_enabled) | (Optional) Is the OMS Agent Enabled | `bool` | `true` | no |
| <a name="input_cl_kubernetes_api_server_authorized_ip_ranges"></a> [cl\_kubernetes\_api\_server\_authorized\_ip\_ranges](#input\_cl\_kubernetes\_api\_server\_authorized\_ip\_ranges) | (Optional) The IP ranges to allow for incoming traffic to the server nodes. | `list(string)` | `[]` | no |
| <a name="input_cl_kubernetes_auto_scaler_profile"></a> [cl\_kubernetes\_auto\_scaler\_profile](#input\_cl\_kubernetes\_auto\_scaler\_profile) | (Optional) The cluster autoscaler profile affects all node pools that use the cluster autoscaler. You can't set an autoscaler profile per node pool. auto\_scaler\_profile can configure more granular details of the cluster autoscaler by changing the default values in the cluster-wide autoscaler profile. For example, a scale down event happens after nodes are under-utilized after 10 minutes. If you had workloads that ran every 15 minutes, you may want to change the autoscaler profile to scale down under utilized nodes after 15 or 20 minutes. When you enable the cluster autoscaler, a default profile is used unless you specify different settings. for more information https://docs.microsoft.com/en-us/azure/aks/cluster-autoscaler | <pre>map(object({<br>    balance_similar_node_groups      = bool<br>    expander                         = string<br>    max_graceful_termination_sec     = number<br>    max_node_provisioning_time       = string<br>    max_unready_nodes                = number<br>    max_unready_percentage           = number<br>    new_pod_scale_up_delay           = string<br>    scale_down_delay_after_add       = string<br>    scale_down_delay_after_delete    = string<br>    scale_down_delay_after_failure   = string<br>    scan_interval                    = string <br>    scale_down_unready               = string<br>    scale_down_unneeded              = string<br>    scale_down_utilization_threshold = string<br>    empty_bulk_delete_max            = number<br>    skip_nodes_with_local_storage    = bool<br>    skip_nodes_with_system_pods      = bool<br>  }))</pre> | `{}` | no |
| <a name="input_cl_kubernetes_automatic_channel_upgrade"></a> [cl\_kubernetes\_automatic\_channel\_upgrade](#input\_cl\_kubernetes\_automatic\_channel\_upgrade) | (Optional) The upgrade channel for this Kubernetes Cluster. Possible values are patch, rapid, node-image and stable. Cluster Auto-Upgrade will update the Kubernetes Cluster (and it's Node Pools) to the latest GA version of Kubernetes automatically. | `string` | `null` | no |
| <a name="input_cl_kubernetes_default_node_pool_availability_zones"></a> [cl\_kubernetes\_default\_node\_pool\_availability\_zones](#input\_cl\_kubernetes\_default\_node\_pool\_availability\_zones) | (Optional) A list of Availability Zones across which the Node Pool should be spread. Changing this forces a new resource to be created. | `list(string)` | `[]` | no |
| <a name="input_cl_kubernetes_default_node_pool_enable_auto_scaling"></a> [cl\_kubernetes\_default\_node\_pool\_enable\_auto\_scaling](#input\_cl\_kubernetes\_default\_node\_pool\_enable\_auto\_scaling) | (Optional) Should the Kubernetes Auto Scaler be enabled for this Node Pool? Defaults to false. If you're using AutoScaling, you may wish to use Terraform's ignore\_changes functionality to ignore changes to the node\_count field. | `bool` | `true` | no |
| <a name="input_cl_kubernetes_default_node_pool_enable_host_encryption"></a> [cl\_kubernetes\_default\_node\_pool\_enable\_host\_encryption](#input\_cl\_kubernetes\_default\_node\_pool\_enable\_host\_encryption) | (Optional) Should the nodes in the Default Node Pool have host encryption enabled? Defaults to false. Encryption at host feature must be enabled on the subscription: https://docs.microsoft.com/azure/virtual-machines/linux/disks-enable-host-based-encryption-cli | `bool` | `false` | no |
| <a name="input_cl_kubernetes_default_node_pool_enable_node_public_ip"></a> [cl\_kubernetes\_default\_node\_pool\_enable\_node\_public\_ip](#input\_cl\_kubernetes\_default\_node\_pool\_enable\_node\_public\_ip) | (Optional) Should each node have a Public IP Address? Defaults to false. | `bool` | `false` | no |
| <a name="input_cl_kubernetes_default_node_pool_fips_enabled"></a> [cl\_kubernetes\_default\_node\_pool\_fips\_enabled](#input\_cl\_kubernetes\_default\_node\_pool\_fips\_enabled) | (Optional) Should the nodes in this Node Pool have Federal Information Processing Standard enabled? Changing this forces a new resource to be created.FIPS support is in Public Preview | `bool` | `false` | no |
| <a name="input_cl_kubernetes_default_node_pool_kubelet_disk_type"></a> [cl\_kubernetes\_default\_node\_pool\_kubelet\_disk\_type](#input\_cl\_kubernetes\_default\_node\_pool\_kubelet\_disk\_type) | (Optional) The type of disk used by kubelet. At this time the only possible value is OS. | `string` | `null` | no |
| <a name="input_cl_kubernetes_default_node_pool_max_count"></a> [cl\_kubernetes\_default\_node\_pool\_max\_count](#input\_cl\_kubernetes\_default\_node\_pool\_max\_count) | (Required) The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min\_count. | `number` | `5` | no |
| <a name="input_cl_kubernetes_default_node_pool_max_pods"></a> [cl\_kubernetes\_default\_node\_pool\_max\_pods](#input\_cl\_kubernetes\_default\_node\_pool\_max\_pods) | (Optional) The maximum number of pods that can run on each agent. Changing this forces a new resource to be created. | `number` | `110` | no |
| <a name="input_cl_kubernetes_default_node_pool_min_count"></a> [cl\_kubernetes\_default\_node\_pool\_min\_count](#input\_cl\_kubernetes\_default\_node\_pool\_min\_count) | (Required) The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max\_count. | `number` | `1` | no |
| <a name="input_cl_kubernetes_default_node_pool_name"></a> [cl\_kubernetes\_default\_node\_pool\_name](#input\_cl\_kubernetes\_default\_node\_pool\_name) | (Optional)The name which should be used for the default Kubernetes Node Pool. Changing this forces a new resource to be created. | `string` | `"systempool"` | no |
| <a name="input_cl_kubernetes_default_node_pool_node_count"></a> [cl\_kubernetes\_default\_node\_pool\_node\_count](#input\_cl\_kubernetes\_default\_node\_pool\_node\_count) | (Optional) The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min\_count and max\_count | `number` | `3` | no |
| <a name="input_cl_kubernetes_default_node_pool_node_labels"></a> [cl\_kubernetes\_default\_node\_pool\_node\_labels](#input\_cl\_kubernetes\_default\_node\_pool\_node\_labels) | (Optional) A map of Kubernetes labels which should be applied to nodes in the Default Node Pool. Changing this forces a new resource to be created. | `map(string)` | `{}` | no |
| <a name="input_cl_kubernetes_default_node_pool_node_public_ip_prefix_id"></a> [cl\_kubernetes\_default\_node\_pool\_node\_public\_ip\_prefix\_id](#input\_cl\_kubernetes\_default\_node\_pool\_node\_public\_ip\_prefix\_id) | (Optional) Resource ID for the Public IP Addresses Prefix for the nodes in this Node Pool. | `string` | `null` | no |
| <a name="input_cl_kubernetes_default_node_pool_only_critical_addons_enabled"></a> [cl\_kubernetes\_default\_node\_pool\_only\_critical\_addons\_enabled](#input\_cl\_kubernetes\_default\_node\_pool\_only\_critical\_addons\_enabled) | (Optional) Enabling this option will taint default node pool with CriticalAddonsOnly=true:NoSchedule taint. Changing this forces a new resource to be created. | `bool` | `true` | no |
| <a name="input_cl_kubernetes_default_node_pool_orchestrator_version"></a> [cl\_kubernetes\_default\_node\_pool\_orchestrator\_version](#input\_cl\_kubernetes\_default\_node\_pool\_orchestrator\_version) | (Optional) Version of Kubernetes used for the Agents. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade) | `string` | `null` | no |
| <a name="input_cl_kubernetes_default_node_pool_os_disk_size_gb"></a> [cl\_kubernetes\_default\_node\_pool\_os\_disk\_size\_gb](#input\_cl\_kubernetes\_default\_node\_pool\_os\_disk\_size\_gb) | (Optional) The size of the OS Disk which should be used for each agent in the Node Pool. Changing this forces a new resource to be created. | `number` | `256` | no |
| <a name="input_cl_kubernetes_default_node_pool_os_disk_type"></a> [cl\_kubernetes\_default\_node\_pool\_os\_disk\_type](#input\_cl\_kubernetes\_default\_node\_pool\_os\_disk\_type) | (Optional) The type of disk which should be used for the Operating System. Possible values are Ephemeral and Managed. Defaults to Managed. Changing this forces a new resource to be created. | `string` | `"Managed"` | no |
| <a name="input_cl_kubernetes_default_node_pool_os_sku"></a> [cl\_kubernetes\_default\_node\_pool\_os\_sku](#input\_cl\_kubernetes\_default\_node\_pool\_os\_sku) | (Optional) OsSKU to be used to specify Linux OSType. Not applicable to Windows OSType. Possible values include: Ubuntu, CBLMariner. Defaults to Ubuntu. Changing this forces a new resource to be created. | `string` | `"Ubuntu"` | no |
| <a name="input_cl_kubernetes_default_node_pool_pod_subnet_id"></a> [cl\_kubernetes\_default\_node\_pool\_pod\_subnet\_id](#input\_cl\_kubernetes\_default\_node\_pool\_pod\_subnet\_id) | (Optional) The ID of the Subnet where the pods in the default Node Pool should exist. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_kubernetes_default_node_pool_type"></a> [cl\_kubernetes\_default\_node\_pool\_type](#input\_cl\_kubernetes\_default\_node\_pool\_type) | (Optional) The type of Node Pool which should be created. Possible values are AvailabilitySet and VirtualMachineScaleSets. Defaults to VirtualMachineScaleSets. | `string` | `"VirtualMachineScaleSets"` | no |
| <a name="input_cl_kubernetes_default_node_pool_ultra_ssd_enabled"></a> [cl\_kubernetes\_default\_node\_pool\_ultra\_ssd\_enabled](#input\_cl\_kubernetes\_default\_node\_pool\_ultra\_ssd\_enabled) | (Optional) Used to specify whether the UltraSSD is enabled in the Default Node Pool. Defaults to false. | `bool` | `false` | no |
| <a name="input_cl_kubernetes_default_node_pool_upgrade_max_surge"></a> [cl\_kubernetes\_default\_node\_pool\_upgrade\_max\_surge](#input\_cl\_kubernetes\_default\_node\_pool\_upgrade\_max\_surge) | (Optional) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade | `string` | `null` | no |
| <a name="input_cl_kubernetes_default_node_pool_vm_size"></a> [cl\_kubernetes\_default\_node\_pool\_vm\_size](#input\_cl\_kubernetes\_default\_node\_pool\_vm\_size) | (Optional)The size of the Virtual Machine, such as Standard\_DS2\_v2 | `string` | `"standard_ds2_v2"` | no |
| <a name="input_cl_kubernetes_default_node_pool_vnet_subnet_id"></a> [cl\_kubernetes\_default\_node\_pool\_vnet\_subnet\_id](#input\_cl\_kubernetes\_default\_node\_pool\_vnet\_subnet\_id) | (Optional) The ID of a Subnet where the Kubernetes Node Pool should exist. Changing this forces a new resource to be created. | `string` | `""` | no |
| <a name="input_cl_kubernetes_deploy_rg"></a> [cl\_kubernetes\_deploy\_rg](#input\_cl\_kubernetes\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for AKS. | `bool` | `true` | no |
| <a name="input_cl_kubernetes_diagnostics"></a> [cl\_kubernetes\_diagnostics](#input\_cl\_kubernetes\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "kube-apiserver",<br>    "kube-audit",<br>    "kube-audit-admin",<br>    "kube-controller-manager",<br>    "kube-scheduler",<br>    "cluster-autoscaler",<br>    "guard"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_kubernetes_disable_bgp_route_propagation"></a> [cl\_kubernetes\_disable\_bgp\_route\_propagation](#input\_cl\_kubernetes\_disable\_bgp\_route\_propagation) | (Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable | `bool` | `false` | no |
| <a name="input_cl_kubernetes_disk_encryption_set_id"></a> [cl\_kubernetes\_disk\_encryption\_set\_id](#input\_cl\_kubernetes\_disk\_encryption\_set\_id) | (Optional) The ID of the Disk Encryption Set which should be used for the Nodes and Volumes. | `string` | `null` | no |
| <a name="input_cl_kubernetes_dns_prefix"></a> [cl\_kubernetes\_dns\_prefix](#input\_cl\_kubernetes\_dns\_prefix) | (Optional) DNS prefix specified when creating the managed cluster. Changing this forces a new resource to be created. The dns\_prefix must contain between 3 and 45 characters, and can contain only letters, numbers, and hyphens. It must start with a letter and must end with a letter or a number. | `string` | `null` | no |
| <a name="input_cl_kubernetes_dns_prefix_private_cluster"></a> [cl\_kubernetes\_dns\_prefix\_private\_cluster](#input\_cl\_kubernetes\_dns\_prefix\_private\_cluster) | (Optional) Specifies the DNS prefix to use with private clusters. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_kubernetes_identity_type"></a> [cl\_kubernetes\_identity\_type](#input\_cl\_kubernetes\_identity\_type) | (Optional) The type of identity used for the managed cluster. Possible values are SystemAssigned and UserAssigned. If UserAssigned is set, a user\_assigned\_identity\_id must be set as well. | `string` | `null` | no |
| <a name="input_cl_kubernetes_kubelet_config"></a> [cl\_kubernetes\_kubelet\_config](#input\_cl\_kubernetes\_kubelet\_config) | (Optional) Customizing your node configuration allows you to configure or tune your operating system (OS) settings or the kubelet parameters to match the needs of the workloads. When you create an AKS cluster or add a node pool to your cluster, you can customize a subset of commonly used OS and kubelet settings. To configure settings beyond this subset. | <pre>map(object({<br>    allowed_unsafe_sysctls      = list(string)<br>    container_log_max_line      = number<br>    container_log_max_size_mb   = number<br>    cpu_cfs_quota_enabled       = bool<br>    cpu_cfs_quota_period        = string  <br>    cpu_manager_policy          = string<br>    image_gc_high_threshold     = number<br>    image_gc_low_threshold      = number<br>    pod_max_pid                 = number<br>    topology_manager_policy     = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_kubernetes_kubelet_identity"></a> [cl\_kubernetes\_kubelet\_identity](#input\_cl\_kubernetes\_kubelet\_identity) | (Optional) Managed Identity to be assigned to the Kubelets. If not specified a Managed Identity is created automatically. | <pre>object({<br>    client_id                 = string<br>    object_id                 = string<br>    user_assigned_identity_id = string<br>  })</pre> | `null` | no |
| <a name="input_cl_kubernetes_kubernetes_version"></a> [cl\_kubernetes\_kubernetes\_version](#input\_cl\_kubernetes\_kubernetes\_version) | (Optional) Version of Kubernetes specified when creating the AKS managed cluster. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade). | `string` | `"1.16.9"` | no |
| <a name="input_cl_kubernetes_latam_rt"></a> [cl\_kubernetes\_latam\_rt](#input\_cl\_kubernetes\_latam\_rt) | (Optional) add route table for LATAM in true and is the value is false add route table for US | `bool` | `true` | no |
| <a name="input_cl_kubernetes_linux_profile"></a> [cl\_kubernetes\_linux\_profile](#input\_cl\_kubernetes\_linux\_profile) | (Optional) Username and ssh key for accessing Linux machines with ssh. | <pre>object({<br>    username = string<br>    ssh_key  = string<br>  })</pre> | `null` | no |
| <a name="input_cl_kubernetes_load_balancer_profile"></a> [cl\_kubernetes\_load\_balancer\_profile](#input\_cl\_kubernetes\_load\_balancer\_profile) | (Optional) Array for load\_balancer\_profile. | <pre>map(object({<br>    outbound_ip_address_ids   =list(string)<br>    outbound_ports_allocated  = number<br>    idle_timeout_in_minutes   = number<br>    managed_outbound_ip_count = number<br>    outbound_ip_prefix_ids    =list(string) <br>  }))</pre> | `{}` | no |
| <a name="input_cl_kubernetes_local_account_disabled"></a> [cl\_kubernetes\_local\_account\_disabled](#input\_cl\_kubernetes\_local\_account\_disabled) | (Optional) Is local account disabled for AAD integrated kubernetes cluster | `bool` | `true` | no |
| <a name="input_cl_kubernetes_log_analytics_solutions"></a> [cl\_kubernetes\_log\_analytics\_solutions](#input\_cl\_kubernetes\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "ContainerInsights": {<br>    "product": "OMSGallery/ContainerInsights",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_cl_kubernetes_log_analytics_workspace_id"></a> [cl\_kubernetes\_log\_analytics\_workspace\_id](#input\_cl\_kubernetes\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `string` | n/a | yes |
| <a name="input_cl_kubernetes_log_analytics_workspace_name"></a> [cl\_kubernetes\_log\_analytics\_workspace\_name](#input\_cl\_kubernetes\_log\_analytics\_workspace\_name) | (Required) The the log analytics workspace name for diagnostics. | `string` | n/a | yes |
| <a name="input_cl_kubernetes_logging_rg_name"></a> [cl\_kubernetes\_logging\_rg\_name](#input\_cl\_kubernetes\_logging\_rg\_name) | (Required) Specifies monitor components resource group | `string` | n/a | yes |
| <a name="input_cl_kubernetes_main_window_allowed"></a> [cl\_kubernetes\_main\_window\_allowed](#input\_cl\_kubernetes\_main\_window\_allowed) | (Optional) Planned Maintenance allows you to schedule weekly maintenance windows that will update your control plane as well as your kube-system Pods on a VMSS instance and minimize workload impact. | <pre>object({<br>    day       = string<br>    hours     = list(string)<br>  })</pre> | <pre>{<br>  "day": "Sunday",<br>  "hours": [<br>    1,<br>    2<br>  ]<br>}</pre> | no |
| <a name="input_cl_kubernetes_main_window_not_allowed"></a> [cl\_kubernetes\_main\_window\_not\_allowed](#input\_cl\_kubernetes\_main\_window\_not\_allowed) | (Optional) Planned Maintenance allows you to schedule weekly maintenance windows that will update your control plane as well as your kube-system Pods on a VMSS instance and minimize workload impact. | <pre>object({<br>    end       = string<br>    start     = string<br>  })</pre> | <pre>{<br>  "end": "2021-05-30T12:00:00Z",<br>  "start": "2021-05-26T03:00:00Z"<br>}</pre> | no |
| <a name="input_cl_kubernetes_network_profile_dns_service_ip"></a> [cl\_kubernetes\_network\_profile\_dns\_service\_ip](#input\_cl\_kubernetes\_network\_profile\_dns\_service\_ip) | (Optional)The K8S's DNS Service IP, /24 represents 256 IPs. IP address within the Kubernetes service address range that will be used by cluster service discovery (kube-dns). Changing this forces a new resource to be created. | `string` | `"60.0.0.12"` | no |
| <a name="input_cl_kubernetes_network_profile_docker_bridge_cidr"></a> [cl\_kubernetes\_network\_profile\_docker\_bridge\_cidr](#input\_cl\_kubernetes\_network\_profile\_docker\_bridge\_cidr) | (Optional) The K8S's Docker bridge CIDR, /27 represents 32 IPs.  (Optional) IP address (in CIDR notation) used as the Docker bridge IP address on nodes. Changing this forces a new resource to be created. | `string` | `"172.17.0.1/16"` | no |
| <a name="input_cl_kubernetes_network_profile_load_balancer_sku"></a> [cl\_kubernetes\_network\_profile\_load\_balancer\_sku](#input\_cl\_kubernetes\_network\_profile\_load\_balancer\_sku) | (Optional) Specifies the SKU of the Load Balancer used for this Kubernetes Cluster. Possible values are Basic and Standard. Defaults to Standard. | `string` | `null` | no |
| <a name="input_cl_kubernetes_network_profile_network_mode"></a> [cl\_kubernetes\_network\_profile\_network\_mode](#input\_cl\_kubernetes\_network\_profile\_network\_mode) | (Optional) Network mode to be used with Azure CNI. Possible values are bridge and transparent. Changing this forces a new resource to be created. | `string` | `"transparent"` | no |
| <a name="input_cl_kubernetes_network_profile_network_plugin"></a> [cl\_kubernetes\_network\_profile\_network\_plugin](#input\_cl\_kubernetes\_network\_profile\_network\_plugin) | (Optional) If network\_profile is not defined, kubenet profile will be used by default. Network plugin to use for networking. Currently supported values are azure and kubenet. Changing this forces a new resource to be created. | `string` | `"azure"` | no |
| <a name="input_cl_kubernetes_network_profile_network_policy"></a> [cl\_kubernetes\_network\_profile\_network\_policy](#input\_cl\_kubernetes\_network\_profile\_network\_policy) | (Optional) Sets up network policy to be used with Azure CNI. Network policy allows us to control the traffic flow between pods. Currently supported values are calico and azure. Changing this forces a new resource to be created. | `string` | `"azure"` | no |
| <a name="input_cl_kubernetes_network_profile_outbound_type"></a> [cl\_kubernetes\_network\_profile\_outbound\_type](#input\_cl\_kubernetes\_network\_profile\_outbound\_type) | (Optional) The outbound (egress) routing method which should be used for this Kubernetes Cluster. Possible values are loadBalancer and userDefinedRouting. Defaults to loadBalancer. | `string` | `"userDefinedRouting"` | no |
| <a name="input_cl_kubernetes_network_profile_pod_cidr"></a> [cl\_kubernetes\_network\_profile\_pod\_cidr](#input\_cl\_kubernetes\_network\_profile\_pod\_cidr) | (Optional) The CIDR to use for pod IP addresses. This field can only be set when network\_plugin is set to kubenet. Changing this forces a new resource to be created. | `string` | `""` | no |
| <a name="input_cl_kubernetes_network_profile_service_cidr"></a> [cl\_kubernetes\_network\_profile\_service\_cidr](#input\_cl\_kubernetes\_network\_profile\_service\_cidr) | (Optional) The K8S's Service CIDR, /24 represents 256 IPs. (Optional) The Network Range used by the Kubernetes service. Changing this forces a new resource to be created. | `string` | `"60.100.0.0/16"` | no |
| <a name="input_cl_kubernetes_next_hop_in_ip_address"></a> [cl\_kubernetes\_next\_hop\_in\_ip\_address](#input\_cl\_kubernetes\_next\_hop\_in\_ip\_address) | (Optional) Contains the IP address packets should be forwarded to. Next hop values are only allowed in routes where the next hop type is VirtualAppliance. | `string` | `"10.0.0.4"` | no |
| <a name="input_cl_kubernetes_postfix"></a> [cl\_kubernetes\_postfix](#input\_cl\_kubernetes\_postfix) | (Required) A string that is appended to the end of the aks name to identify it. | `string` | n/a | yes |
| <a name="input_cl_kubernetes_private_cluster_enabled"></a> [cl\_kubernetes\_private\_cluster\_enabled](#input\_cl\_kubernetes\_private\_cluster\_enabled) | (Optional)This provides a Private IP Address for the Kubernetes API on the Virtual Network where the Kubernetes Cluster is located. Defaults to false. Changing this forces a new resource to be created. | `bool` | `true` | no |
| <a name="input_cl_kubernetes_private_cluster_public_fqdn_enabled"></a> [cl\_kubernetes\_private\_cluster\_public\_fqdn\_enabled](#input\_cl\_kubernetes\_private\_cluster\_public\_fqdn\_enabled) | (Optional) Specifies whether a Public FQDN for this Private Cluster should be added. Defaults to false. | `bool` | `false` | no |
| <a name="input_cl_kubernetes_private_dns_zone_id"></a> [cl\_kubernetes\_private\_dns\_zone\_id](#input\_cl\_kubernetes\_private\_dns\_zone\_id) | (Optional) Either the ID of Private DNS Zone which should be delegated to this Cluster, System to have AKS manage this or None. In case of None you will need to bring your own DNS server and set up resolving, otherwise cluster will have issues after provisioning. | `string` | `"System"` | no |
| <a name="input_cl_kubernetes_rbac_aad_admin_group_object_ids"></a> [cl\_kubernetes\_rbac\_aad\_admin\_group\_object\_ids](#input\_cl\_kubernetes\_rbac\_aad\_admin\_group\_object\_ids) | (Optional) A list of Object IDs of Azure Active Directory Groups which should have Admin Role on the Cluster. | `list(string)` | `[]` | no |
| <a name="input_cl_kubernetes_rbac_aad_client_app_id"></a> [cl\_kubernetes\_rbac\_aad\_client\_app\_id](#input\_cl\_kubernetes\_rbac\_aad\_client\_app\_id) | (Optional) The Client ID of an Azure Active Directory Application. When managed is set to false | `string` | `""` | no |
| <a name="input_cl_kubernetes_rbac_aad_enable"></a> [cl\_kubernetes\_rbac\_aad\_enable](#input\_cl\_kubernetes\_rbac\_aad\_enable) | (Optional)Is Role Based Access Control Enabled. Changing this forces a new resource to be created. | `bool` | `true` | no |
| <a name="input_cl_kubernetes_rbac_aad_managed"></a> [cl\_kubernetes\_rbac\_aad\_managed](#input\_cl\_kubernetes\_rbac\_aad\_managed) | (Optional) When managed is set to true the following properties can be specified:admin\_group\_object\_ids and azure\_rbac\_enabled, When managed is set to false the following properties can be specified:Client\_app\_id, Server\_app\_id and Server\_app\_secret. | `bool` | `true` | no |
| <a name="input_cl_kubernetes_rbac_aad_server_app_id"></a> [cl\_kubernetes\_rbac\_aad\_server\_app\_id](#input\_cl\_kubernetes\_rbac\_aad\_server\_app\_id) | (Optional) The Server ID of an Azure Active Directory Application. When managed is set to false | `string` | `""` | no |
| <a name="input_cl_kubernetes_rbac_aad_server_app_secret"></a> [cl\_kubernetes\_rbac\_aad\_server\_app\_secret](#input\_cl\_kubernetes\_rbac\_aad\_server\_app\_secret) | (Optional) The Server Secret of an Azure Active Directory Application. When managed is set to false | `string` | `""` | no |
| <a name="input_cl_kubernetes_rg_name"></a> [cl\_kubernetes\_rg\_name](#input\_cl\_kubernetes\_rg\_name) | (Optional) The name of the aks resource group if cl\_aks\_services\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_kubernetes_route_table_subnet"></a> [cl\_kubernetes\_route\_table\_subnet](#input\_cl\_kubernetes\_route\_table\_subnet) | (Optional) The ID of the Subnet. Changing this forces a new resource to be created. | `string` | `""` | no |
| <a name="input_cl_kubernetes_rt_resource_group_name"></a> [cl\_kubernetes\_rt\_resource\_group\_name](#input\_cl\_kubernetes\_rt\_resource\_group\_name) | (Optional) resource group for route table. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_kubernetes_service_principal_client_id"></a> [cl\_kubernetes\_service\_principal\_client\_id](#input\_cl\_kubernetes\_service\_principal\_client\_id) | (Optional) The Client ID for the Service Principal. | `string` | `""` | no |
| <a name="input_cl_kubernetes_service_principal_client_secret"></a> [cl\_kubernetes\_service\_principal\_client\_secret](#input\_cl\_kubernetes\_service\_principal\_client\_secret) | (Optional) The Client Secret for the Service Principal. | `string` | `""` | no |
| <a name="input_cl_kubernetes_sku_tier"></a> [cl\_kubernetes\_sku\_tier](#input\_cl\_kubernetes\_sku\_tier) | (Optional) The SKU Tier that should be used for this Kubernetes Cluster. Possible values are Free and Paid (which includes the Uptime SLA). Defaults to Free. | `string` | `null` | no |
| <a name="input_cl_kubernetes_user_assigned_identity_id"></a> [cl\_kubernetes\_user\_assigned\_identity\_id](#input\_cl\_kubernetes\_user\_assigned\_identity\_id) | (Optional) The ID of a user assigned identity. | `list(string)` | `[]` | no |
| <a name="input_cl_kubernetes_windows_profile"></a> [cl\_kubernetes\_windows\_profile](#input\_cl\_kubernetes\_windows\_profile) | (Optional) Admin username, password and license for Windows hosts. | <pre>object({<br>    username = string<br>    password = string<br>    license  = string<br>  })</pre> | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration              = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_kubernetes"></a> [cl\_kubernetes](#output\_cl\_kubernetes) | n/a |
| <a name="output_cl_kubernetes_diagnostic_settings"></a> [cl\_kubernetes\_diagnostic\_settings](#output\_cl\_kubernetes\_diagnostic\_settings) | n/a |
| <a name="output_cl_kubernetes_id"></a> [cl\_kubernetes\_id](#output\_cl\_kubernetes\_id) | n/a |
| <a name="output_cl_kubernetes_identity"></a> [cl\_kubernetes\_identity](#output\_cl\_kubernetes\_identity) | n/a |
| <a name="output_cl_kubernetes_kube_admin_config"></a> [cl\_kubernetes\_kube\_admin\_config](#output\_cl\_kubernetes\_kube\_admin\_config) | n/a |
| <a name="output_cl_kubernetes_kube_config"></a> [cl\_kubernetes\_kube\_config](#output\_cl\_kubernetes\_kube\_config) | n/a |
| <a name="output_cl_kubernetes_log_analytics_solution"></a> [cl\_kubernetes\_log\_analytics\_solution](#output\_cl\_kubernetes\_log\_analytics\_solution) | n/a |
| <a name="output_cl_kubernetes_rg"></a> [cl\_kubernetes\_rg](#output\_cl\_kubernetes\_rg) | Outputs Azure Kubernetes Services ********************************************************************************************** |

## Usage Azure Kubernetes private cluster integrated with a private Azure Container Registry and add-on AGIC Application Gateway

```terraform

resource "azurerm_subnet" "cl_azure_kubernetes_nodes_subnet" {
  name                                                   = "${var.env}-${var.postfix}-aks-nodes-sn"
  resource_group_name                                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                                   = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                       = ["10.66.0.0/20"]
  enforce_private_link_endpoint_network_policies         = true
  service_endpoints                                      = ["Microsoft.ContainerRegistry","Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.KeyVault"]
}

resource "azurerm_subnet" "private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                   = ["10.66.18.0/24"]
  enforce_private_link_endpoint_network_policies     = true
  service_endpoints                                  = ["Microsoft.ContainerRegistry"]
}

module "cl_azure_container_registry" {
    source                                                      = "../tf-azure-component-library/components/cl_azure_container_registry"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
    cl_azure_container_registry_rg_name                         = module.cl_azure_kubernetes_service.cl_kubernetes_rg[0].name
    cl_azure_container_registry_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_content_trust_enabled           = true
    cl_azure_container_registry_admin_enabled                   = false
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
    cl_azure_container_registry_allowed_vnet_ids                = [data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id]
    cl_azure_container_registry_allowed_subnets                 = [azurerm_subnet.private_endpoint_subnet.id]
    cl_azure_container_registry_public_network_access_enabled   = false
}

module "cl_app_gateway" {
  source                                      = "../tf-azure-component-library/components/cl_application_gateway"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  set_private_ip_listener                     = false
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["10.66.17.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
}

module "cl_azure_kubernetes_service"{
   source                                                               = "../tf-azure-component-library/components/cl_azure_kubernetes_service"
   env                                                                  = var.env
   postfix                                                              = var.postfix
   location                                                             = var.location
   cl_kubernetes_deploy_rg                                              = true
   cl_kubernetes_postfix                                                = "demo"
   cl_kubernetes_kubernetes_version                                     = "1.20.9"
   cl_kubernetes_private_cluster_enabled                                = true
   cl_kubernetes_dns_prefix                                             = "${var.env}-${var.postfix}-aks-dns"
   cl_kubernetes_latam_rt                                               = true/false #true add route to LATAM and false add route to US
   cl_kubernetes_default_node_pool_node_count                           = 3
   cl_kubernetes_default_node_pool_vm_size                              = "Standard_D4ds_v4" 
   cl_kubernetes_default_node_pool_type                                 = "VirtualMachineScaleSets"
   cl_kubernetes_default_node_pool_availability_zones                   = [1]
   cl_kubernetes_default_node_pool_enable_auto_scaling                  = true
   cl_kubernetes_default_node_pool_min_count                            = 1
   cl_kubernetes_default_node_pool_max_count                            = 5
   cl_kubernetes_default_node_pool_upgrade_max_surge                    = "33%"
   cl_kubernetes_default_node_pool_vnet_subnet_id                       = azurerm_subnet.cl_azure_kubernetes_nodes_subnet.id  
   cl_kubernetes_network_profile_service_cidr                           = "10.0.0.0/16"
   cl_kubernetes_network_profile_dns_service_ip                         = "10.0.0.12"
   cl_kubernetes_network_profile_docker_bridge_cidr                     = "172.17.0.1/16"
   cl_kubernetes_logging_rg_name                                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
   cl_kubernetes_log_analytics_workspace_id                             = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_kubernetes_log_analytics_workspace_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
   cl_kubernetes_identity_type                                          = "SystemAssigned"
   cl_kubernetes_addon_profile_ingress_application_gateway_enabled      = true
   cl_kubernetes_addon_profile_ingress_application_gateway_id           = module.cl_app_gateway.cl_app_gateway.id
   cl_kubernetes_addon_profile_azure_policy_enabled                     = true
   cl_kubernetes_rbac_aad_managed                                       = true
   cl_kubernetes_route_table_subnet                                     = azurerm_subnet.cl_azure_kubernetes_nodes_subnet.id  
   cl_kubernetes_rt_resource_group_name                                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

module "cl_azure_kubernetes_service_node_pool"{
   source                                               = "../tf-azure-component-library/components/cl_azure_kubernetes_service_node_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_kubernetes_node_pool_name                         = "internal"
   cl_kubernetes_node_pool_kubernetes_cluster_id        =  module.cl_azure_kubernetes_service.cl_kubernetes_id
   cl_kubernetes_node_pool_vm_size                      = "Standard_B2s"
   cl_kubernetes_node_pool_availability_zones           = [1]
   cl_kubernetes_node_pool_os_disk_size_gb              = 256
   cl_kubernetes_node_pool_enable_auto_scaling          = true
   cl_kubernetes_node_pool_enable_host_encryption       = false
   cl_kubernetes_node_pool_enable_node_public_ip        = false
   cl_kubernetes_node_pool_os_disk_type                 = "Managed"
   cl_kubernetes_node_pool_os_sku                       = "Ubuntu"
   cl_kubernetes_node_pool_os_type                      = "Linux"
   cl_kubernetes_node_pool_mode                         = "User"
   cl_kubernetes_node_pool_node_count                   = 3
   cl_kubernetes_node_pool_max_count                    = 5
   cl_kubernetes_node_pool_min_count                    = 1
   cl_kubernetes_node_pool_max_pods                     = 110
   cl_kubernetes_node_pool_max_surge                    = "33%"
   cl_kubernetes_node_pool_priority                     = "Regular"
}
```
<!-- END_TF_DOCS -->
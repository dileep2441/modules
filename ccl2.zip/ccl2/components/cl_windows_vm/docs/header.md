# Azure Windows VM Component

Windows virtual machine is a computer within a computer that provides the user the same experience they would have on the host operating system itself. 
Each virtual machine provides its own virtual hardware including CPUs, memory, hard drives, network interfaces, and other devices.
This Windows VM component will deploy a new resource group, Vnet, Subnet, Public IP, NIC Interface, Windows VM, Recovery Services Vault, Backup policy and a Backup Protected VM.

For more information, please visit: https://docs.microsoft.com/en-us/azure/virtual-machines/windows/overview 

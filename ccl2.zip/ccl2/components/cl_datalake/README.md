<!-- BEGIN_TF_DOCS -->

# Azure Data Lake Component

Azure Data Lake Storage is an enterprise-wide hyper-scale repository for big data analytic workloads. 
It enables you to capture data of any size, type, and ingestion speed in one single place for operational and exploratory analytics.
This component will deploy a ADLS, private endpoint, azure diagnostics, and configures the storage account with Azure Defender.

For more information, please visit: https://docs.microsoft.com/en-us/azure/data-lake-store/data-lake-store-overview 



## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.cl_advanced_threat_protection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_backup_container_storage_account.cl_datalake_sa_protection_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_container_storage_account) | resource |
| [azurerm_backup_protected_file_share.cl_datalake_sa_protected_fileshare](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_file_share) | resource |
| [azurerm_monitor_diagnostic_setting.cl_datalake_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_datalake_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_datalake_sa_file_share_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.cl_datalake](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.cl_datalake_network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_storage_data_lake_gen2_filesystem.cl_datalake_filesystem](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_filesystem) | resource |
| [azurerm_storage_share.cl_datalake_sa_files](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_share) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_datalake_access_tier"></a> [cl\_datalake\_access\_tier](#input\_cl\_datalake\_access\_tier) | (Optional) Defines the type of access tier to use for the data lake storage account. | `string` | `"Hot"` | no |
| <a name="input_cl_datalake_account_kind"></a> [cl\_datalake\_account\_kind](#input\_cl\_datalake\_account\_kind) | (Optional) Defines the kind of storage account to deploy. | `string` | `"StorageV2"` | no |
| <a name="input_cl_datalake_allowed_ips"></a> [cl\_datalake\_allowed\_ips](#input\_cl\_datalake\_allowed\_ips) | (Optional) A list of Ip addresses that can access the data lake storage account. It is recommended that you add your automation tool's IP range here. | `list` | `[]` | no |
| <a name="input_cl_datalake_allowed_pe_subnet_ids"></a> [cl\_datalake\_allowed\_pe\_subnet\_ids](#input\_cl\_datalake\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a private endpoint that can access the data lake storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_datalake_allowed_vnet_subnet_ids"></a> [cl\_datalake\_allowed\_vnet\_subnet\_ids](#input\_cl\_datalake\_allowed\_vnet\_subnet\_ids) | (Optional) A list of Subnets of the vnet that can access the data lake storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_datalake_blob_retention_days"></a> [cl\_datalake\_blob\_retention\_days](#input\_cl\_datalake\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_datalake_container_retention_days"></a> [cl\_datalake\_container\_retention\_days](#input\_cl\_datalake\_container\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_datalake_diagnostics"></a> [cl\_datalake\_diagnostics](#input\_cl\_datalake\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_datalake_file_share_enabled"></a> [cl\_datalake\_file\_share\_enabled](#input\_cl\_datalake\_file\_share\_enabled) | If set to true, enable file shares | `bool` | `false` | no |
| <a name="input_cl_datalake_log_analytics_workspace_id"></a> [cl\_datalake\_log\_analytics\_workspace\_id](#input\_cl\_datalake\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_datalake_min_tls_version"></a> [cl\_datalake\_min\_tls\_version](#input\_cl\_datalake\_min\_tls\_version) | (Optional) Defines the minimum TLS version to use for the data lake storage account. | `string` | `"TLS1_2"` | no |
| <a name="input_cl_datalake_postfix"></a> [cl\_datalake\_postfix](#input\_cl\_datalake\_postfix) | (Required) A string that is appended to the end of the datalake name to identify it. | `any` | n/a | yes |
| <a name="input_cl_datalake_private_dns_zone_ids"></a> [cl\_datalake\_private\_dns\_zone\_ids](#input\_cl\_datalake\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_datalake_replication_type"></a> [cl\_datalake\_replication\_type](#input\_cl\_datalake\_replication\_type) | (Optional) Defines the type of replication to use for the data lake storage account. | `string` | `"LRS"` | no |
| <a name="input_cl_datalake_resource_group_name"></a> [cl\_datalake\_resource\_group\_name](#input\_cl\_datalake\_resource\_group\_name) | (Required) The name of the resource group where the data lake will be deployed to. | `any` | n/a | yes |
| <a name="input_cl_datalake_sa_backup_policy_fileshare_id"></a> [cl\_datalake\_sa\_backup\_policy\_fileshare\_id](#input\_cl\_datalake\_sa\_backup\_policy\_fileshare\_id) | (Optional) The azure file share backup policy from the recovery service vault. | `any` | `null` | no |
| <a name="input_cl_datalake_sa_file_enable_backup"></a> [cl\_datalake\_sa\_file\_enable\_backup](#input\_cl\_datalake\_sa\_file\_enable\_backup) | If set to true, enable file storage backup. | `bool` | `false` | no |
| <a name="input_cl_datalake_sa_file_shares"></a> [cl\_datalake\_sa\_file\_shares](#input\_cl\_datalake\_sa\_file\_shares) | (Optional) Array for the creation of multiple file shares. | <pre>map(object({<br>    name  = string<br>    quota  = number <br>  }))</pre> | `{}` | no |
| <a name="input_cl_datalake_sa_recovery_vault_name"></a> [cl\_datalake\_sa\_recovery\_vault\_name](#input\_cl\_datalake\_sa\_recovery\_vault\_name) | (Optional) The name of backup recovery service vault. | `any` | `null` | no |
| <a name="input_cl_datalake_sa_rg_backup_name"></a> [cl\_datalake\_sa\_rg\_backup\_name](#input\_cl\_datalake\_sa\_rg\_backup\_name) | (Optional) The RG destination of the azure file share backup. | `any` | `null` | no |
| <a name="input_cl_datalake_tier"></a> [cl\_datalake\_tier](#input\_cl\_datalake\_tier) | (Optional) The pricing tier for the data lake storage account. | `string` | `"Standard"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_datalake"></a> [cl\_datalake](#output\_cl\_datalake) | Outputs ********************************************************************************************** |
| <a name="output_cl_datalake_diagnostic_settings"></a> [cl\_datalake\_diagnostic\_settings](#output\_cl\_datalake\_diagnostic\_settings) | n/a |
| <a name="output_cl_datalake_filesystem"></a> [cl\_datalake\_filesystem](#output\_cl\_datalake\_filesystem) | n/a |
| <a name="output_cl_datalake_network_rules"></a> [cl\_datalake\_network\_rules](#output\_cl\_datalake\_network\_rules) | n/a |
| <a name="output_cl_datalake_private_endpoint"></a> [cl\_datalake\_private\_endpoint](#output\_cl\_datalake\_private\_endpoint) | n/a |
| <a name="output_cl_datalake_sa_file_share_private_endpoint"></a> [cl\_datalake\_sa\_file\_share\_private\_endpoint](#output\_cl\_datalake\_sa\_file\_share\_private\_endpoint) | n/a |
| <a name="output_cl_datalake_sa_files"></a> [cl\_datalake\_sa\_files](#output\_cl\_datalake\_sa\_files) | n/a |
| <a name="output_cl_datalake_sa_protected_fileshare"></a> [cl\_datalake\_sa\_protected\_fileshare](#output\_cl\_datalake\_sa\_protected\_fileshare) | n/a |
| <a name="output_cl_datalake_sa_protection_container"></a> [cl\_datalake\_sa\_protection\_container](#output\_cl\_datalake\_sa\_protection\_container) | n/a |

## Usage with Private Endpoints (file share backup enabled)

```terraform
resource "azurerm_private_dns_zone" "adls_private_dns_zone" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "adls_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-adls-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.adls_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_datalake" {
    source                                 = "../tf-azure-component-library/components/cl_datalake"
    env                                    = var.env
    postfix                                = var.postfix
    location                               = var.location
    cl_datalake_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datalake_allowed_pe_subnet_ids      = [azurerm_subnet.test_subnet.id]
    cl_datalake_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datalake_private_dns_zone_ids       = [azurerm_private_dns_zone.adls_private_dns_zone.id]
    cl_datalake_file_share_enabled              = true
    cl_datalake_sa_file_shares                  = var.cl_datalake_sa_file_shares
    cl_datalake_sa_file_enable_backup           = true
    cl_datalake_sa_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_datalake_sa_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_datalake_sa_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
}

resource "azurerm_private_dns_a_record" "adls_private_dns_record" {
  name                 = "${var.env}-${var.postfix}-adls-pe-record"
  zone_name            = azurerm_private_dns_zone.adls_private_dns_zone.name
  resource_group_name  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                  = var.adls_private_record_ttl
  records              = module.cl_datalake.cl_datalake_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                 = var.tags
}
```

## Usage with Subnet Connection (file share backup enabled)

```terraform
resource "azurerm_private_dns_zone" "adls_private_dns_zone" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "adls_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-adls-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.adls_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_datalake" {
    source                                 = "../tf-azure-component-library/components/cl_datalake"
    env                                    = var.env
    postfix                                = var.postfix
    location                               = var.location
    cl_datalake_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datalake_allowed_vnet_subnet_ids    = [azurerm_subnet.test_subnet.id]
    cl_datalake_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datalake_private_dns_zone_ids       = [azurerm_private_dns_zone.adls_private_dns_zone.id]
    cl_datalake_file_share_enabled              = true
    cl_datalake_sa_file_shares                  = var.cl_datalake_sa_file_shares
    cl_datalake_sa_file_enable_backup           = true
    cl_datalake_sa_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_datalake_sa_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_datalake_sa_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
}

resource "azurerm_private_dns_a_record" "adls_private_dns_record" {
  name                 = "${var.env}-${var.postfix}-adls-pe-record"
  zone_name            = azurerm_private_dns_zone.adls_private_dns_zone.name
  resource_group_name  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                  = var.adls_private_record_ttl
  records              = module.cl_datalake.cl_datalake_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                 = var.tags
}
```
<!-- END_TF_DOCS -->
# Azure Function App Component

A function app lets you group Azure functions as a logical unit for easier management, deployment, scaling, and sharing of resources. 
(Azure Function is a serverless compute service that enables user to run event-triggered code without having to provision or manage infrastructure.)
This component will deploy an Azure Function App resource in either Windows or Linux flavors. It will also deploy a storage account, private endpoints, and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-functions/functions-overview

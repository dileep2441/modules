<!-- BEGIN_TF_DOCS -->

# Azure SQL Server Component

SQL Server on Azure Virtual Machines enables users to use full versions of SQL Server in the cloud without having to manage any on-premises hardware. 
SQL Server virtual machines (VMs) also simplify licensing costs when you pay as you go.
This component will deploy a new Azure SQL Server, storage account for audit & security logging, diagnostic settings for the storage account, storage container, SQL Server audit policy, SQL Server security alert policy, Azure SQL Server security assessment, a private endpoint for Azure SQL Server, firewall rules, vnet rules and logs solutions for Azure SQL Server.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview 


#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified in a Github Action Task:
```Githubaction task
    - name: Setup Terraform
      uses: hashicorp/setup-terraform@v1
      with:
        terraform_version: ${{ env.TF_VERSION }}   
```
Specify TF version in `pattern_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```

## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.cl_azure_sql_server_sa_atp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_data_protection_backup_instance_blob_storage.cl_azure_sql_server_sa_protected_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_instance_blob_storage) | resource |
| [azurerm_log_analytics_solution.cl_azure_sql_server_log_analytics_solution](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_sql_server_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_mssql_server.cl_azure_sql_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server) | resource |
| [azurerm_mssql_server_extended_auditing_policy.cl_azure_sql_server_audit_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server_extended_auditing_policy) | resource |
| [azurerm_mssql_server_security_alert_policy.cl_azure_sql_server_alert_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server_security_alert_policy) | resource |
| [azurerm_mssql_server_vulnerability_assessment.cl_azure_sql_server_security_assessment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_server_vulnerability_assessment) | resource |
| [azurerm_private_endpoint.cl_azure_sql_server_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_azure_sql_server_sa_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_sql_firewall_rule.cl_azure_sql_server_firewall_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/sql_firewall_rule) | resource |
| [azurerm_sql_virtual_network_rule.cl_azure_sql_server_vnet_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/sql_virtual_network_rule) | resource |
| [azurerm_storage_account.cl_azure_sql_server_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.cl_azure_sql_server_sa_network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_storage_container.cl_azure_sql_server_sa_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_azuread_authentication_only"></a> [cl\_azure\_azuread\_authentication\_only](#input\_cl\_azure\_azuread\_authentication\_only) | (Optional) Specifies whether only AD Users and administrators | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_administrator"></a> [cl\_azure\_sql\_server\_administrator](#input\_cl\_azure\_sql\_server\_administrator) | (Required) The administrator login name for the new server. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_alert_email_enabled"></a> [cl\_azure\_sql\_server\_alert\_email\_enabled](#input\_cl\_azure\_sql\_server\_alert\_email\_enabled) | (Optional) Boolean flag which specifies if the alert is sent to the account administrators or not. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_alert_emails"></a> [cl\_azure\_sql\_server\_alert\_emails](#input\_cl\_azure\_sql\_server\_alert\_emails) | (Optional) Specifies an array of e-mail addresses to which the alert is sent. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_alert_retention_days"></a> [cl\_azure\_sql\_server\_alert\_retention\_days](#input\_cl\_azure\_sql\_server\_alert\_retention\_days) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_cl_azure_sql_server_alert_state"></a> [cl\_azure\_sql\_server\_alert\_state](#input\_cl\_azure\_sql\_server\_alert\_state) | (Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific database server. Allowed values are: Disabled, Enabled. | `string` | `"Enabled"` | no |
| <a name="input_cl_azure_sql_server_audit_retention_days"></a> [cl\_azure\_sql\_server\_audit\_retention\_days](#input\_cl\_azure\_sql\_server\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `180` | no |
| <a name="input_cl_azure_sql_server_connection_policy"></a> [cl\_azure\_sql\_server\_connection\_policy](#input\_cl\_azure\_sql\_server\_connection\_policy) | (Optional) The connection policy the server will use. Possible values are Default, Proxy, and Redirect. | `string` | `"Default"` | no |
| <a name="input_cl_azure_sql_server_disabled_alerts"></a> [cl\_azure\_sql\_server\_disabled\_alerts](#input\_cl\_azure\_sql\_server\_disabled\_alerts) | (Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql\_Injection, Sql\_Injection\_Vulnerability, Access\_Anomaly, Data\_Exfiltration, Unsafe\_Action. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_enable_azuread_administrator"></a> [cl\_azure\_sql\_server\_enable\_azuread\_administrator](#input\_cl\_azure\_sql\_server\_enable\_azuread\_administrator) | (Optional) Boolean flag which specifies if azuread\_administrator needs to be deployed. | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_firewall_rules"></a> [cl\_azure\_sql\_server\_firewall\_rules](#input\_cl\_azure\_sql\_server\_firewall\_rules) | (Optional) Define additional firewall rules | <pre>map(object({<br>    start_ip                 = string<br>    end_ip                   = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_sql_server_identity_ids"></a> [cl\_azure\_sql\_server\_identity\_ids](#input\_cl\_azure\_sql\_server\_identity\_ids) | UserAssigned Identities ID to add to azure\_sql\_server. Mandatory if type is UserAssigned | `list(string)` | `null` | no |
| <a name="input_cl_azure_sql_server_identity_type"></a> [cl\_azure\_sql\_server\_identity\_type](#input\_cl\_azure\_sql\_server\_identity\_type) | Add an Identity (MSI) to the azure\_sql\_server. Possible values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_azure_sql_server_log_analytics_solution"></a> [cl\_azure\_sql\_server\_log\_analytics\_solution](#input\_cl\_azure\_sql\_server\_log\_analytics\_solution) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureSQLAnalytics": {<br>    "product": "OMSGallery/AzureSQLAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_cl_azure_sql_server_log_analytics_workspace_id"></a> [cl\_azure\_sql\_server\_log\_analytics\_workspace\_id](#input\_cl\_azure\_sql\_server\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_log_analytics_workspace_name"></a> [cl\_azure\_sql\_server\_log\_analytics\_workspace\_name](#input\_cl\_azure\_sql\_server\_log\_analytics\_workspace\_name) | (Required) The log analytics workspace name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_logging_rg_name"></a> [cl\_azure\_sql\_server\_logging\_rg\_name](#input\_cl\_azure\_sql\_server\_logging\_rg\_name) | (Required) The resource group for log analytics. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_login_username"></a> [cl\_azure\_sql\_server\_login\_username](#input\_cl\_azure\_sql\_server\_login\_username) | Login username Mandatory if azuread\_administrator is true | `string` | `null` | no |
| <a name="input_cl_azure_sql_server_nacl_allowed_subnets"></a> [cl\_azure\_sql\_server\_nacl\_allowed\_subnets](#input\_cl\_azure\_sql\_server\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure SQL Server. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_object_id"></a> [cl\_azure\_sql\_server\_object\_id](#input\_cl\_azure\_sql\_server\_object\_id) | AD Objetct id Mandatory if azuread\_administrator is true | `string` | `null` | no |
| <a name="input_cl_azure_sql_server_password"></a> [cl\_azure\_sql\_server\_password](#input\_cl\_azure\_sql\_server\_password) | (Required) The password associated with the cl\_azure\_sql\_server\_administrator user. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_postfix"></a> [cl\_azure\_sql\_server\_postfix](#input\_cl\_azure\_sql\_server\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_primary_identity_id"></a> [cl\_azure\_sql\_server\_primary\_identity\_id](#input\_cl\_azure\_sql\_server\_primary\_identity\_id) | Primary UserAssigned Identities ID to add to azure\_sql\_server. Mandatory if type is UserAssigned | `string` | `null` | no |
| <a name="input_cl_azure_sql_server_private_dns_zone_ids"></a> [cl\_azure\_sql\_server\_private\_dns\_zone\_ids](#input\_cl\_azure\_sql\_server\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_public_network_access"></a> [cl\_azure\_sql\_server\_public\_network\_access](#input\_cl\_azure\_sql\_server\_public\_network\_access) | (Optional) Whether or not public network access is allowed for this server. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_resource_group_name"></a> [cl\_azure\_sql\_server\_resource\_group\_name](#input\_cl\_azure\_sql\_server\_resource\_group\_name) | (Required) Specifies the Azure SQL Server resource group | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_sa_allowed_ips"></a> [cl\_azure\_sql\_server\_sa\_allowed\_ips](#input\_cl\_azure\_sql\_server\_sa\_allowed\_ips) | (Optional) A list of Ip addresses that can access the sql server storage account. It is recommended that you add your automation tool's IP range here. | `list` | `[]` | no |
| <a name="input_cl_azure_sql_server_sa_allowed_pe_subnet_ids"></a> [cl\_azure\_sql\_server\_sa\_allowed\_pe\_subnet\_ids](#input\_cl\_azure\_sql\_server\_sa\_allowed\_pe\_subnet\_ids) | (Required) A list of Ip addresses that can access the storage account. It is recommended that you add your automation tool's IP range here. | `list` | `[]` | no |
| <a name="input_cl_azure_sql_server_sa_allowed_vnet_subnet_ids"></a> [cl\_azure\_sql\_server\_sa\_allowed\_vnet\_subnet\_ids](#input\_cl\_azure\_sql\_server\_sa\_allowed\_vnet\_subnet\_ids) | (Required) A list of Subnets of the vnet that can access the sql server storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_sa_backup_policy_id"></a> [cl\_azure\_sql\_server\_sa\_backup\_policy\_id](#input\_cl\_azure\_sql\_server\_sa\_backup\_policy\_id) | The azure blob storage backup policy id from the backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_sql_server_sa_backup_vault"></a> [cl\_azure\_sql\_server\_sa\_backup\_vault](#input\_cl\_azure\_sql\_server\_sa\_backup\_vault) | The blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_sql_server_sa_backup_vault_id"></a> [cl\_azure\_sql\_server\_sa\_backup\_vault\_id](#input\_cl\_azure\_sql\_server\_sa\_backup\_vault\_id) | The id of blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_sql_server_sa_enable_backup"></a> [cl\_azure\_sql\_server\_sa\_enable\_backup](#input\_cl\_azure\_sql\_server\_sa\_enable\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_sa_enable_pe"></a> [cl\_azure\_sql\_server\_sa\_enable\_pe](#input\_cl\_azure\_sql\_server\_sa\_enable\_pe) | (Required) Boolean flag which specifies if pe for storage account needs to be deployed. | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_sa_private_dns_zone_ids"></a> [cl\_azure\_sql\_server\_sa\_private\_dns\_zone\_ids](#input\_cl\_azure\_sql\_server\_sa\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list` | `[]` | no |
| <a name="input_cl_azure_sql_server_security_email_subscription"></a> [cl\_azure\_sql\_server\_security\_email\_subscription](#input\_cl\_azure\_sql\_server\_security\_email\_subscription) | (Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_security_emails"></a> [cl\_azure\_sql\_server\_security\_emails](#input\_cl\_azure\_sql\_server\_security\_emails) | (Optional) Specifies an array of e-mail addresses to which the scan notification is sent. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_server_security_scans"></a> [cl\_azure\_sql\_server\_security\_scans](#input\_cl\_azure\_sql\_server\_security\_scans) | (Optional) Boolean flag which specifies if recurring scans is enabled or disabled. | `bool` | `true` | no |
| <a name="input_cl_azure_sql_server_storage_account_allow_nested_items_public_access"></a> [cl\_azure\_sql\_server\_storage\_account\_allow\_nested\_items\_public\_access](#input\_cl\_azure\_sql\_server\_storage\_account\_allow\_nested\_items\_public\_access) | (Optional) Allow or disallow nested items within this Account to opt into being public. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_storage_account_blob_retention_days"></a> [cl\_azure\_sql\_server\_storage\_account\_blob\_retention\_days](#input\_cl\_azure\_sql\_server\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_azure_sql_server_storage_account_diagnostics"></a> [cl\_azure\_sql\_server\_storage\_account\_diagnostics](#input\_cl\_azure\_sql\_server\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_sql_server_storage_account_kind"></a> [cl\_azure\_sql\_server\_storage\_account\_kind](#input\_cl\_azure\_sql\_server\_storage\_account\_kind) | (Optional)  Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. | `string` | `"StorageV2"` | no |
| <a name="input_cl_azure_sql_server_storage_account_replication_to_LRS"></a> [cl\_azure\_sql\_server\_storage\_account\_replication\_to\_LRS](#input\_cl\_azure\_sql\_server\_storage\_account\_replication\_to\_LRS) | If set to true, it overrides the replication to LRS | `bool` | `false` | no |
| <a name="input_cl_azure_sql_server_storage_account_tier"></a> [cl\_azure\_sql\_server\_storage\_account\_tier](#input\_cl\_azure\_sql\_server\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for Azure SQL server audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_cl_azure_sql_server_tenant_id"></a> [cl\_azure\_sql\_server\_tenant\_id](#input\_cl\_azure\_sql\_server\_tenant\_id) | Tenant id Optional | `string` | `null` | no |
| <a name="input_cl_azure_sql_server_tls"></a> [cl\_azure\_sql\_server\_tls](#input\_cl\_azure\_sql\_server\_tls) | (Optional) The Minimum TLS Version for all SQL Database and SQL Data Warehouse databases associated with the server. Valid values are: 1.0, 1.1 and 1.2. | `string` | `"1.2"` | no |
| <a name="input_cl_azure_sql_server_version"></a> [cl\_azure\_sql\_server\_version](#input\_cl\_azure\_sql\_server\_version) | (Optional) The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server). | `string` | `"12.0"` | no |
| <a name="input_cl_azure_sql_server_vnet_rules"></a> [cl\_azure\_sql\_server\_vnet\_rules](#input\_cl\_azure\_sql\_server\_vnet\_rules) | (Optional) Define additional virtual network rules | `list(string)` | `[]` | no |
| <a name="input_cl_private_endpoint_subresource_names"></a> [cl\_private\_endpoint\_subresource\_names](#input\_cl\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "sqlServer"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform

locals {
  timeout_duration = "2h"
  cl_storage_account_blob_properties                           = (var.cl_azure_sql_server_sa_enable_backup ? false : true)
  cl_azure_sql_server_name_no_dash                             = replace("${var.env}${var.postfix}${var.suffix}", "-", "") 
  cl_azure_sql_server_storage_account_name_no_dash             = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
  cl_azure_sql_server_storage_account_infra_encryption_enabled = (var.cl_azure_sql_server_storage_account_kind == "StorageV2" || (var.cl_azure_sql_server_storage_account_kind == "BlockBlobStorage" && var.cl_azure_sql_server_storage_account_tier == "Premium") ? true : false)
  cl_azure_sql_server_primary_user_assigned_identity_id        = (var.cl_azure_sql_server_identity_type == "UserAssigned" ? var.cl_azure_sql_server_primary_identity_id : null)
  cl_azure_sql_server_storage_account_replication_to_LRS    = (var.cl_azure_sql_server_storage_account_replication_to_LRS || var.env == "nprd-pr"  ? true : false ) 
  cl_azure_sql_server_storage_account_replication_type      = (var.cl_azure_sql_server_storage_account_tier != "Premium" ? "GRS" : "LRS")
  cl_azure_sql_server_storage_account = {
    "sbox-pr"  = "sboxpr"
    "nprd-pr"  = "nprdpr"
    "nprd-dr"  = "nprddr"
    "prod-pr"  = "prodpr" 
    "prod-dr"  = "proddr"
    "nprod-pr" ="nprodpr"
  }

  cl_azure_sql_server_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.database.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.database.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.database.usgovcloudapi.net"]
  }

  cl_azure_sql_server_sa_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
  }
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_sql_server"></a> [cl\_azure\_sql\_server](#output\_cl\_azure\_sql\_server) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_sql_server_firewall_rules"></a> [cl\_azure\_sql\_server\_firewall\_rules](#output\_cl\_azure\_sql\_server\_firewall\_rules) | n/a |
| <a name="output_cl_azure_sql_server_log_analytics_solution"></a> [cl\_azure\_sql\_server\_log\_analytics\_solution](#output\_cl\_azure\_sql\_server\_log\_analytics\_solution) | n/a |
| <a name="output_cl_azure_sql_server_private_endpoint"></a> [cl\_azure\_sql\_server\_private\_endpoint](#output\_cl\_azure\_sql\_server\_private\_endpoint) | n/a |
| <a name="output_cl_azure_sql_server_sa_atp"></a> [cl\_azure\_sql\_server\_sa\_atp](#output\_cl\_azure\_sql\_server\_sa\_atp) | n/a |
| <a name="output_cl_azure_sql_server_sa_protected_blob"></a> [cl\_azure\_sql\_server\_sa\_protected\_blob](#output\_cl\_azure\_sql\_server\_sa\_protected\_blob) | n/a |
| <a name="output_cl_azure_sql_server_security_assessment"></a> [cl\_azure\_sql\_server\_security\_assessment](#output\_cl\_azure\_sql\_server\_security\_assessment) | n/a |
| <a name="output_cl_azure_sql_server_storage_account"></a> [cl\_azure\_sql\_server\_storage\_account](#output\_cl\_azure\_sql\_server\_storage\_account) | n/a |
| <a name="output_cl_azure_sql_server_storage_account_diagnostic_setting"></a> [cl\_azure\_sql\_server\_storage\_account\_diagnostic\_setting](#output\_cl\_azure\_sql\_server\_storage\_account\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_sql_server_vnet_rules"></a> [cl\_azure\_sql\_server\_vnet\_rules](#output\_cl\_azure\_sql\_server\_vnet\_rules) | n/a |


## Usage

```terraform

module "cl_azure_sql_server" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_server_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  suffix                                           = var.suffix
  tags                                                    = var.tags
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_sa_private_dns_zone_ids      var.cl_azure_sql_server_sa_private_dns_zone_ids
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
    }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids         = var.cl_azure_sql_server_private_dns_zone_ids
  cl_azure_sql_server_sa_enable_backup                    = true
  cl_azure_sql_server_sa_backup_vault_id                  = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_azure_sql_server_sa_backup_vault                     = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_azure_sql_server_sa_backup_policy_id                 = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_azure_sql_server_login_username                      = "wtamayo@kpmgnp.onmicrosoft.us"
  cl_azure_sql_server_object_id                           = "f3f17b13-24d1-4e1b-ad44-44a748688393"
  cl_azure_sql_server_sa_allowed_vnet_subnet_ids          = var.cl_azure_sql_server_sa_allowed_vnet_subnet_ids 
  cl_azure_sql_server_sa_allowed_pe_subnet_ids            = var.cl_azure_sql_server_sa_allowed_pe_subnet_ids
}
```
<!-- END_TF_DOCS -->
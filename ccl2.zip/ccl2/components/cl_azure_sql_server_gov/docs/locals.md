## Local values

```terraform

locals {
  timeout_duration = "2h"
  cl_storage_account_blob_properties                           = (var.cl_azure_sql_server_sa_enable_backup ? false : true)
  cl_azure_sql_server_name_no_dash                             = replace("${var.env}${var.postfix}${var.suffix}", "-", "") 
  cl_azure_sql_server_storage_account_name_no_dash             = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
  cl_azure_sql_server_storage_account_infra_encryption_enabled = (var.cl_azure_sql_server_storage_account_kind == "StorageV2" || (var.cl_azure_sql_server_storage_account_kind == "BlockBlobStorage" && var.cl_azure_sql_server_storage_account_tier == "Premium") ? true : false)
  cl_azure_sql_server_primary_user_assigned_identity_id        = (var.cl_azure_sql_server_identity_type == "UserAssigned" ? var.cl_azure_sql_server_primary_identity_id : null)
  cl_azure_sql_server_storage_account_replication_to_LRS    = (var.cl_azure_sql_server_storage_account_replication_to_LRS || var.env == "nprd-pr"  ? true : false ) 
  cl_azure_sql_server_storage_account_replication_type      = (var.cl_azure_sql_server_storage_account_tier != "Premium" ? "GRS" : "LRS")
  cl_azure_sql_server_storage_account = {
    "sbox-pr"  = "sboxpr"
    "nprd-pr"  = "nprdpr"
    "nprd-dr"  = "nprddr"
    "prod-pr"  = "prodpr" 
    "prod-dr"  = "proddr"
    "nprod-pr" ="nprodpr"
  }

  cl_azure_sql_server_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.database.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.database.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.database.usgovcloudapi.net"]
  }

  cl_azure_sql_server_sa_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
  }
}
```


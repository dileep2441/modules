## Local values

```terraform
locals {
    timeout_duration = "2h"
    cl_datalake_name_no_dash = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
    cl_datalake_replication_to_LRS    = (var.cl_datalake_replication_to_LRS || var.env == "nprd-pr"  ? true : false ) 
    cl_datalake_replication_type      = (var.cl_datalake_tier != "Premium" ? "GRS" : "LRS")
    cl_datalake_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.usgovcloudapi.net"]
    }
    cl_datalake_private_sa_file_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
    }
    cl_datalake_infra_encryption_enabled = (var.cl_datalake_account_kind == "StorageV2" || (var.cl_datalake_account_kind == "BlockBlobStorage" && var.cl_datalake_tier == "Premium") ? true : false)
    cl_datalake_name = {
        "sbox-pr" = "sboxpr"
        "nprd-pr" = "nprdpr"
        "nprd-dr" = "nprddr"
        "prod-pr" = "prodpr" 
        "prod-dr" = "proddr"
    }
}
```


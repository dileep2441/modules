## Usage

```terraform
// Azure Bastion
//**********************************************************************************************
module "cl_azure_bastion" {
  source                        = "../tf-azure-component-library/components/cl_azure_bastion"
  env                           = var.env
  postfix                       = var.postfix
  location                      = var.location
  cl_azure_bastion_vnet_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_azure_bastion_vnet_rg_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_azure_bastion_enable       = true
  cl_azure_bastion_centralized_enable = false 
  cl_azure_bastion_subnet_prefix = ["55.0.2.0/24"]
  cl_azure_bastion_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_bastion_nsg_rules     = {
  allow_kpmg_inbound = {
    name                          = "allow-kpmg-inbound"
    priority                      = 1003
    direction                     = "Inbound"
    access                        = "Allow"
    protocol                      = "*"
    source_port_range             = null
    source_port_ranges            = ["80","8531","443","8530"]
    destination_port_range        = "*"    
    destination_port_ranges       = null
    source_address_prefix         = "10.1.1.22/24"
    source_address_prefixes       = null
    destination_address_prefix    = "10.69.2.96/27"
    destination_address_prefixes  = null
  }  
}
}

//**********************************************************************************************

// Azure Bastion Centralized
//**********************************************************************************************
module "sharedsvcs_azure_bastion" {
  source                        = "../tf-azure-component-library/components/cl_azure_bastion"
  env                           = var.env
  postfix                       = var.postfix
  location                      = var.location
  cl_azure_bastion_enable       = true
  cl_azure_bastion_centralized_enable = true
  cl_azure_bastion_vnet_name    = azurerm_virtual_network.sharedsvcs_vnet.name
  cl_azure_bastion_vnet_rg_name = azurerm_resource_group.sharedsvcs_rg_network.name
  cl_azure_bastion_subnet_prefix = var.sharedsvcs_bastion_sub_address_prefix
  cl_azure_bastion_log_analytics_workspace_id = azurerm_log_analytics_workspace.sharedsvcs_log_analytics_workspace.id
}
//**********************************************************************************************
```
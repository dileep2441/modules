<!-- BEGIN_TF_DOCS -->

# Azure Azure VM Image Builder

The Azure VM Image Builder (Azure Image Builder) lets you start with a Windows or Linux-based Azure Marketplace image, existing custom images and begin to add your own customizations. Because the Image Builder is built on HashiCorp Packer you will see some similarities, but have the benefit of a managed service. You can also specify where you would like your images hosted, in the Azure Shared Image Gallery, as a managed image or a VHD. This solution build and distributes only KPMG certified OS images for Linux and Windows VMs via Azure Shared Image Gallery (SIG). Any specific requirement or configuration must be assumed by the project itself. We can create and build image definition to LATAM and US for Windows VM.
```

 Azure Image Buildeer is path of the US Country Hosting Platform, and it is will deployed from slingshot tool.

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group_template_deployment.cl_azure_vm_image_builder_template_latam](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_resource_group_template_deployment.cl_azure_vm_image_builder_template_us](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group_template_deployment) | resource |
| [azurerm_role_assignment.cl_azure_vm_image_builder_role_assigned_mi](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.cl_azure_vm_image_builder_sa_role_assigned_mi](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_shared_image.cl_azure_vm_image_builder_image_definition](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/shared_image) | resource |
| [azurerm_storage_blob.cl_azure_vm_image_builder_storage_account_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_blob) | resource |
| [azurerm_storage_container.cl_azure_vm_image_builder_storage_account_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_user_assigned_identity.cl_azure_vm_image_builder_user_assigned_identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_vm_image_build_number"></a> [cl\_azure\_vm\_image\_build\_number](#input\_cl\_azure\_vm\_image\_build\_number) | (Required) Build number from GH actions workflow. | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_distribute_replicationRegions"></a> [cl\_azure\_vm\_image\_builder\_distribute\_replicationRegions](#input\_cl\_azure\_vm\_image\_builder\_distribute\_replicationRegions) | (Optional) destiny location. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_vm_image_builder_identifier_source_offer"></a> [cl\_azure\_vm\_image\_builder\_identifier\_source\_offer](#input\_cl\_azure\_vm\_image\_builder\_identifier\_source\_offer) | (Optional) The Publisher Name for this Gallery Image. Changing this forces a new resource to be created. | `string` | `"AzureVMImageBuilder"` | no |
| <a name="input_cl_azure_vm_image_builder_identifier_source_publisher"></a> [cl\_azure\_vm\_image\_builder\_identifier\_source\_publisher](#input\_cl\_azure\_vm\_image\_builder\_identifier\_source\_publisher) | (Optional) The Offer Name for this Shared Image. Changing this forces a new resource to be created. | `string` | `"KPMG"` | no |
| <a name="input_cl_azure_vm_image_builder_release"></a> [cl\_azure\_vm\_image\_builder\_release](#input\_cl\_azure\_vm\_image\_builder\_release) | (Required) Specifies the relese of the VM Image. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_resource_apiVersion"></a> [cl\_azure\_vm\_image\_builder\_resource\_apiVersion](#input\_cl\_azure\_vm\_image\_builder\_resource\_apiVersion) | (Optional) apiVersion Azure VM Image Builder | `string` | `"2020-02-14"` | no |
| <a name="input_cl_azure_vm_image_builder_shared_image_def_gallery_name"></a> [cl\_azure\_vm\_image\_builder\_shared\_image\_def\_gallery\_name](#input\_cl\_azure\_vm\_image\_builder\_shared\_image\_def\_gallery\_name) | (Required) Specifies the name of the Shared Image Gallery located in sharedservices subscription in which this Shared Image should exist. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_shared_image_def_os_type"></a> [cl\_azure\_vm\_image\_builder\_shared\_image\_def\_os\_type](#input\_cl\_azure\_vm\_image\_builder\_shared\_image\_def\_os\_type) | (Required) The type of Operating System present in this Shared Image. Possible values are Linux and Windows. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_shared_image_def_rg"></a> [cl\_azure\_vm\_image\_builder\_shared\_image\_def\_rg](#input\_cl\_azure\_vm\_image\_builder\_shared\_image\_def\_rg) | (Required) The name of the resource group in which the Shared Image Gallery exists, this rg was created from the core deployment and it has a name rg-var.env-var.postfix-image-gallery. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_source_offer"></a> [cl\_azure\_vm\_image\_builder\_source\_offer](#input\_cl\_azure\_vm\_image\_builder\_source\_offer) | (Required) The name of a group of related images created by a publisher. Examples: RHEL, WindowsServer. By default this values is to create a Windows image | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_source_publisher"></a> [cl\_azure\_vm\_image\_builder\_source\_publisher](#input\_cl\_azure\_vm\_image\_builder\_source\_publisher) | (Required) The organization that created the image. Examples: RedHat, MicrosoftWindowsServer. By default this values is to create a Windows image | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_source_sku"></a> [cl\_azure\_vm\_image\_builder\_source\_sku](#input\_cl\_azure\_vm\_image\_builder\_source\_sku) | (Required) An instance of an offer, such as a major release of a distribution. Examples: 7-LVM, 2019-Datacenter. By default this values is to create a Windows image | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_source_version"></a> [cl\_azure\_vm\_image\_builder\_source\_version](#input\_cl\_azure\_vm\_image\_builder\_source\_version) | (Optional) The version number of an image SKU. | `string` | `"latest"` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_allowed_ips"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_allowed\_ips](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_allowed\_ips) | (Optional) A list of Ip addresses that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_allowed_pe_subnet_ids"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_allowed\_pe\_subnet\_ids](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_allowed_vnet_subnet_ids"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_allowed\_vnet\_subnet\_ids](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_deploy"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_deploy](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_deploy) | (Optional) Deploy sa for image builder scripts, the scripts is going to be uploaded always from shares services core, in case you only require to create a new image definition please, this in false this variable. | `bool` | `true` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_log_analytics_workspace_id"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_log\_analytics\_workspace\_id](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_storage_account_network_rules_default_action"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_network\_rules\_default\_action](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_network\_rules\_default\_action) | (Optional) Default action for network rules access. | `string` | `"Deny"` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_postfix"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_postfix](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_postfix) | (Optional) A unique identifier for the storage account. Part of the naming scheme. | `string` | `""` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_private_dns_zone_ids"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_private\_dns\_zone\_ids](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_vm_image_builder_storage_account_resource_group_name"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_resource\_group\_name](#input\_cl\_azure\_vm\_image\_builder\_storage\_account\_resource\_group\_name) | (Required) The name of the resource group where the storage account will be deployed to. | `any` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_subnet_id"></a> [cl\_azure\_vm\_image\_builder\_subnet\_id](#input\_cl\_azure\_vm\_image\_builder\_subnet\_id) | (Required) The subnetId to Azure VM Image Builder, it was created by core deploymetn with the name var.env-var.postfix-imgbuilder-sn | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_template_deployment_mode"></a> [cl\_azure\_vm\_image\_builder\_template\_deployment\_mode](#input\_cl\_azure\_vm\_image\_builder\_template\_deployment\_mode) | (Optional) The Deployment Mode for this Resource Group Template Deployment. Possible values are Complete (where resources in the Resource Group not specified in the ARM Template will be destroyed) and Incremental (where resources are additive only). | `string` | `"Incremental"` | no |
| <a name="input_cl_azure_vm_image_builder_template_resource_group_name"></a> [cl\_azure\_vm\_image\_builder\_template\_resource\_group\_name](#input\_cl\_azure\_vm\_image\_builder\_template\_resource\_group\_name) | (Required) The name which should be used for this Resource Group Template Deployment, this rg was created from the core deployment and it has a name rg-var.env-var.postfix-imgbuilder. Changing this forces a new Resource Group Template Deployment to be created. | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_template_source_latam"></a> [cl\_azure\_vm\_image\_builder\_template\_source\_latam](#input\_cl\_azure\_vm\_image\_builder\_template\_source\_latam) | (Optional) The name of the ARM template for Windows VM ImageWindowsTemplate.json, for Linux VM. | `string` | `"ImageWindowsTemplatelatamch.json"` | no |
| <a name="input_cl_azure_vm_image_builder_template_source_us"></a> [cl\_azure\_vm\_image\_builder\_template\_source\_us](#input\_cl\_azure\_vm\_image\_builder\_template\_source\_us) | (Optional) The name of the ARM template for Windows VM ImageWindowsTemplate.json, for Linux VM. | `string` | `"ImageWindowsTemplateusch.json"` | no |
| <a name="input_cl_azure_vm_image_builder_user_assigned_identity_deploy"></a> [cl\_azure\_vm\_image\_builder\_user\_assigned\_identity\_deploy](#input\_cl\_azure\_vm\_image\_builder\_user\_assigned\_identity\_deploy) | (Optional) Deploy user manage identity for image builder, the MI is going to be created always from shares services core, in case you only require to create a new image definition please confirm this MI in shared services subscription located in resource group name rg-npord/prod-sharedsvcs-azimgbuilder. | `bool` | `true` | no |
| <a name="input_cl_azure_vm_image_builder_user_assigned_identity_id"></a> [cl\_azure\_vm\_image\_builder\_user\_assigned\_identity\_id](#input\_cl\_azure\_vm\_image\_builder\_user\_assigned\_identity\_id) | (Optional) if Deploy cl\_azure\_vm\_image\_builder\_user\_assigned\_identity\_deploy is in false, please confirm this MI in shared services subscription located in resource group name rg-npord/prod-sharedsvcs-azimgbuilder. | `string` | `null` | no |
| <a name="input_cl_azure_vm_image_builder_user_identity_rg"></a> [cl\_azure\_vm\_image\_builder\_user\_identity\_rg](#input\_cl\_azure\_vm\_image\_builder\_user\_identity\_rg) | (Required) The name which should be used for this Resource Group User Managed Identity, this rg was created from the core deployment and it has a name rg-var.env-var.postfix-imgbuilder. Changing this forces a new Resource Group Template Deployment to be created. | `string` | n/a | yes |
| <a name="input_cl_azure_vm_image_builder_vmSize"></a> [cl\_azure\_vm\_image\_builder\_vmSize](#input\_cl\_azure\_vm\_image\_builder\_vmSize) | (Required) The Size of the windows or Linux vm. By default this values has a Windows vm size | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to the Shared Image. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_vm_image_builder_image_definition"></a> [cl\_azure\_vm\_image\_builder\_image\_definition](#output\_cl\_azure\_vm\_image\_builder\_image\_definition) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_vm_image_builder_role_assigned_mi"></a> [cl\_azure\_vm\_image\_builder\_role\_assigned\_mi](#output\_cl\_azure\_vm\_image\_builder\_role\_assigned\_mi) | n/a |
| <a name="output_cl_azure_vm_image_builder_sa_role_assigned_mi"></a> [cl\_azure\_vm\_image\_builder\_sa\_role\_assigned\_mi](#output\_cl\_azure\_vm\_image\_builder\_sa\_role\_assigned\_mi) | n/a |
| <a name="output_cl_azure_vm_image_builder_storage_account_blob"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_blob](#output\_cl\_azure\_vm\_image\_builder\_storage\_account\_blob) | n/a |
| <a name="output_cl_azure_vm_image_builder_storage_account_container"></a> [cl\_azure\_vm\_image\_builder\_storage\_account\_container](#output\_cl\_azure\_vm\_image\_builder\_storage\_account\_container) | n/a |
| <a name="output_cl_azure_vm_image_builder_template_latam"></a> [cl\_azure\_vm\_image\_builder\_template\_latam](#output\_cl\_azure\_vm\_image\_builder\_template\_latam) | n/a |
| <a name="output_cl_azure_vm_image_builder_template_us"></a> [cl\_azure\_vm\_image\_builder\_template\_us](#output\_cl\_azure\_vm\_image\_builder\_template\_us) | n/a |
| <a name="output_cl_azure_vm_image_builder_user_assigned_identity"></a> [cl\_azure\_vm\_image\_builder\_user\_assigned\_identity](#output\_cl\_azure\_vm\_image\_builder\_user\_assigned\_identity) | n/a |
| <a name="output_cl_storage_account_image_builder"></a> [cl\_storage\_account\_image\_builder](#output\_cl\_storage\_account\_image\_builder) | n/a |

## Usage

```terraform
//Deploy Azure VM Image Builder to Windows DNS Forwarder Image
//***************************************************************************************************
module "cl_azure_vm_image_builder" {
  source                                                                    = "../../components/cl_azure_vm_image_builder"
  env                                                                       = var.env
  postfix                                                                   = var.postfix
  location                                                                  = var.location
  cl_azure_vm_image_builder_release                                         = var.core_azure_vm_image_builder_release
  cl_azure_vm_image_build_number                                            = var.core_azure_vm_image_build_number
  cl_azure_vm_image_builder_user_identity_rg                                = azurerm_resource_group.core_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_gallery_name                   = azurerm_shared_image_gallery.core_shared_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_rg                             = azurerm_resource_group.core_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_os_type                        = var.core_azure_vm_image_builder_shared_image_def_os_type
  cl_azure_vm_image_builder_vmSize                                          = var.core_azure_vm_image_builder_vmSize
  cl_azure_vm_image_builder_source_publisher                                = var.core_azure_vm_image_builder_source_publisher
  cl_azure_vm_image_builder_source_offer                                    = var.core_azure_vm_image_builder_source_offer
  cl_azure_vm_image_builder_source_sku                                      = var.core_azure_vm_image_builder_source_sku
  cl_azure_vm_image_builder_template_resource_group_name                    = azurerm_resource_group.core_rg_azure_image_builder[0].name
  cl_azure_vm_image_builder_subnet_id                                       = azurerm_subnet.core_azure_image_builder_subnet[0].id
  cl_azure_vm_image_builder_identifier_source_publisher                     = var.core_azure_vm_image_builder_identifier_source_publisher
  cl_azure_vm_image_builder_identifier_source_offer                         = var.core_azure_vm_image_builder_identifier_source_offer
  cl_azure_vm_image_builder_template_deployment_mode                        = var.core_azure_vm_image_builder_template_deployment_mode
  cl_azure_vm_image_builder_resource_apiVersion                             = var.core_azure_vm_image_builder_resource_apiVersion
  cl_azure_vm_image_builder_source_version                                  = var.core_azure_vm_image_builder_source_version
  cl_azure_vm_image_builder_distribute_replicationRegions                   = var.core_azure_vm_image_builder_distribute_replicationRegions
  cl_azure_vm_image_builder_template_source_us                              = var.core_azure_vm_image_builder_template_source_us
  cl_azure_vm_image_builder_storage_account_postfix                         = var.core_azure_vm_image_builder_storage_account_postfix
  cl_azure_vm_image_builder_storage_account_resource_group_name             = azurerm_resource_group.core_rg_data.name
  cl_azure_vm_image_builder_storage_account_log_analytics_workspace_id      = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_vm_image_builder_storage_account_allowed_ips                     = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_azure_vm_image_builder_storage_account_allowed_pe_subnet_ids           = [azurerm_subnet.core_private_link_subnet.id]
  cl_azure_vm_image_builder_storage_account_allowed_vnet_subnet_ids         = [azurerm_subnet.core_azure_image_builder_subnet[0].id]
  cl_azure_vm_image_builder_storage_account_private_dns_zone_ids            = var.core_private_dns_zone_enable && var.core_shared_image_gallery_deploy ? [data.azurerm_private_dns_zone.core_data_private_dns_zone_sa[0].id] : var.core_vm_image_builder_storage_account_private_dns_zone_id
  cl_azure_vm_image_builder_storage_account_network_rules_default_action    = var.core_azure_vm_image_builder_storage_account_network_rules_default_action
  tags                                                                      = var.tags
}
//***************************************************************************************************

//Deploy Azure VM Image Builder to Windows DNS Forwarder Image
//***************************************************************************************************
module "cl_azure_vm_image_builder" {
  source                                                                    = "../../components/cl_azure_vm_image_builder"
  env                                                                       = var.env
  postfix                                                                   = var.postfix
  location                                                                  = var.location
  cl_azure_vm_image_builder_release                                         = var.sharedsvs_azure_vm_image_builder_release
  cl_azure_vm_image_build_number                                            = var.sharedsvs_azure_vm_image_build_number
  cl_azure_vm_image_builder_user_identity_rg                                = azurerm_resource_group.sharedsvs_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_gallery_name                   = azurerm_shared_image_gallery.sharedsvs_shared_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_rg                             = azurerm_resource_group.sharedsvs_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_os_type                        = var.sharedsvs_azure_vm_image_builder_shared_image_def_os_type
  cl_azure_vm_image_builder_vmSize                                          = var.sharedsvs_azure_vm_image_builder_vmSize
  cl_azure_vm_image_builder_source_publisher                                = var.sharedsvs_azure_vm_image_builder_source_publisher
  cl_azure_vm_image_builder_source_offer                                    = var.sharedsvs_azure_vm_image_builder_source_offer
  cl_azure_vm_image_builder_source_sku                                      = var.sharedsvs_azure_vm_image_builder_source_sku
  cl_azure_vm_image_builder_template_resource_group_name                    = azurerm_resource_group.sharedsvs_rg_azure_image_builder[0].name
  cl_azure_vm_image_builder_subnet_id                                       = azurerm_subnet.sharedsvs_azure_image_builder_subnet.id
  cl_azure_vm_image_builder_identifier_source_publisher                     = var.sharedsvs_azure_vm_image_builder_identifier_source_publisher
  cl_azure_vm_image_builder_identifier_source_offer                         = var.sharedsvs_azure_vm_image_builder_identifier_source_offer
  cl_azure_vm_image_builder_template_deployment_mode                        = var.sharedsvs_azure_vm_image_builder_template_deployment_mode
  cl_azure_vm_image_builder_resource_apiVersion                             = var.sharedsvs_azure_vm_image_builder_resource_apiVersion
  cl_azure_vm_image_builder_source_version                                  = var.sharedsvs_azure_vm_image_builder_source_version
  cl_azure_vm_image_builder_distribute_replicationRegions                   = var.sharedsvs_azure_vm_image_builder_distribute_replicationRegions
  cl_azure_vm_image_builder_template_source_latam                           = var.sharedsvs_azure_vm_image_builder_template_source_latam
  cl_azure_vm_image_builder_storage_account_postfix                         = var.sharedsvs_azure_vm_image_builder_storage_account_postfix
  cl_azure_vm_image_builder_storage_account_resource_group_name             = azurerm_resource_group.sharedsvs_rg_data.name
  cl_azure_vm_image_builder_storage_account_log_analytics_workspace_id      = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_vm_image_builder_storage_account_allowed_ips                     = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_azure_vm_image_builder_storage_account_allowed_pe_subnet_ids           = [azurerm_subnet.sharedsvs_private_link_subnet.id]
  cl_azure_vm_image_builder_storage_account_allowed_vnet_subnet_ids         = [azurerm_subnet.sharedsvs_azure_image_builder_subnet.id]  
  cl_azure_vm_image_builder_storage_account_private_dns_zone_ids            = var.sharedsvs_private_dns_zone_enable && var.sharedsvs_shared_image_gallery_deploy ? [data.azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_sa[0].id] : null
  cl_azure_vm_image_builder_storage_account_network_rules_default_action    = var.sharedsvs_azure_vm_image_builder_storage_account_network_rules_default_action
  cl_azure_vm_image_builder_storage_account_deploy                          = false // latam image defition VM's byt the default the value in in tru to image defition VM's for US. 

  tags                                                                      = var.tags
}
```
<!-- END_TF_DOCS -->

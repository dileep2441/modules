[CmdletBinding()]
param(
    $QualysActivationId = 'e5f57878-d05c-4167-8930-011aa6b609fe',
    $SccmManagementPoint = 'https://USMDCKPDB6084.us.kworld.kpmg.com',
    $UnsealStorageAccount = 'sanpsharedimagesupport',
    $UnsealUsername = $UnsealStorageAccount,
    $UnsealDnsSuffix = 'us.kworld.kpmg.com',
    $UnsealFileShare = 'unseal',
    $UnsealKey,
    $UnsealScriptName = 'Unseal.ps1',
    [switch]$SkipDiskInitialization,
    [Parameter(ValueFromRemainingArguments=$true)]
    $ExtraArguments
)

$ErrorActionPreference = 'Stop'

if (-Not (Test-Path -Path C:\BuildLog)) {
    $null = New-Item -Path C:\BuildLog -ItemType Directory -Force
}
Start-Transcript -Path "C:\BuildLog\$(Get-Date -Format yyyyMMdd).log" -Append -Force  -Confirm:$false

Write-Host "Attempting to rename gpupdate"
$ErrorActionPreference = 'SilentlyContinue'
takeown /f C:\Windows\System32\gpupdate.exe /a
cacls C:\Windows\System32\gpupdate.exe /T /E /G Administrators:F
Rename-Item -Path C:\Windows\System32\gpupdate.exe -NewName C:\Windows\System32\gpupdate.bak
$ErrorActionPreference = 'Stop'
if (Test-Path -Path C:\Windows\System32\gpudpate.bak) {
    Write-Host "Successfully renamed gpupdate"
} elseif (Test-Path -Path C:\Windows\System32\gpupdate.exe) {
    Write-Host "Unable to rename gpupdate"
}

# pull any variables out of the extra arguments passed to this script
for($i = 0; $i -lt $ExtraArguments.Count; $i += 2) {
    if ($ExtraArguments[$i] -match '^\-') {
        $VariableName = $ExtraArguments[$i] -replace '^\-'
        Write-Host "Processing $VariableName"
        New-Variable -Name $VariableName -Value $ExtraArguments[$i + 1 ]
    }
}

$connectTestResult = Test-NetConnection -ComputerName "$UnsealStorageAccount.$UnsealDnsSuffix" -Port 445
if ($connectTestResult.TcpTestSucceeded) {
    Set-ItemProperty -Path 'HKLM:SYSTEM\CurrentControlSet\Control\Lsa' -Name 'DisableDomainCreds' -Value '0'

    $Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "Azure\$UnsealUsername", ($UnsealKey | ConvertTo-SecureString -AsPlaintext -Force)
    # Mount the drive
    Write-Host "Connecting to \\$UnsealStorageAccount.$UnsealDnsSuffix\$UnsealFileShare as Azure\$UnsealUsername"
    New-PSDrive -Name U -PSProvider FileSystem -Root "\\$UnsealStorageAccount.$UnsealDnsSuffix\$UnsealFileShare" -Credential $Credential -Persist
    if (-Not (Test-Path -Path "C:\Windows\Temp\Unseal")) {
        New-Item -Path "C:\Windows\Temp\Unseal" -ItemType Directory
    }
    Get-ChildItem -Path U:\Unseal* | ForEach-Object {
        Copy-Item -Path $PSItem.FullName -Destination "C:\Windows\Temp\Unseal"
    }
    if (Test-Path -Path "C:\Windows\Temp\Unseal\$UnsealScriptName") {
        Write-Host "Launching C:\Windows\Temp\Unseal\$UnsealScriptName"
        . "C:\Windows\Temp\Unseal\$UnsealScriptName"
    }
    if (Test-Path -Path "C:\Windows\Temp\Unseal\Unseal.final.ps1") {
        Write-Host "Launching C:\Windows\Temp\Unseal\Unseal.final.ps1"
        . "C:\Windows\Temp\Unseal\Unseal.final.ps1"
    }
} else {
    Write-Error -Message "Unable to reach the Azure storage account via port 445. Check to make sure your organization or ISP is not blocking port 445, or use Azure P2S VPN, Azure S2S VPN, or Express Route to tunnel SMB traffic over a different port."
}
Get-PSDrive -Name U -ErrorAction SilentlyContinue | Remove-PSDrive -Force -Confirm:$false
Write-Host "Finished Unseal"
Stop-Transcript
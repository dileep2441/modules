## Usage

```terraform
//Deploy Azure VM Image Builder to Windows DNS Forwarder Image
//***************************************************************************************************
module "cl_azure_vm_image_builder" {
  source                                                                    = "../../components/cl_azure_vm_image_builder"
  env                                                                       = var.env
  postfix                                                                   = var.postfix
  location                                                                  = var.location
  cl_azure_vm_image_builder_release                                         = var.core_azure_vm_image_builder_release
  cl_azure_vm_image_build_number                                            = var.core_azure_vm_image_build_number
  cl_azure_vm_image_builder_user_identity_rg                                = azurerm_resource_group.core_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_gallery_name                   = azurerm_shared_image_gallery.core_shared_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_rg                             = azurerm_resource_group.core_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_os_type                        = var.core_azure_vm_image_builder_shared_image_def_os_type
  cl_azure_vm_image_builder_vmSize                                          = var.core_azure_vm_image_builder_vmSize
  cl_azure_vm_image_builder_source_publisher                                = var.core_azure_vm_image_builder_source_publisher
  cl_azure_vm_image_builder_source_offer                                    = var.core_azure_vm_image_builder_source_offer
  cl_azure_vm_image_builder_source_sku                                      = var.core_azure_vm_image_builder_source_sku
  cl_azure_vm_image_builder_template_resource_group_name                    = azurerm_resource_group.core_rg_azure_image_builder[0].name
  cl_azure_vm_image_builder_subnet_id                                       = azurerm_subnet.core_azure_image_builder_subnet[0].id
  cl_azure_vm_image_builder_identifier_source_publisher                     = var.core_azure_vm_image_builder_identifier_source_publisher
  cl_azure_vm_image_builder_identifier_source_offer                         = var.core_azure_vm_image_builder_identifier_source_offer
  cl_azure_vm_image_builder_template_deployment_mode                        = var.core_azure_vm_image_builder_template_deployment_mode
  cl_azure_vm_image_builder_resource_apiVersion                             = var.core_azure_vm_image_builder_resource_apiVersion
  cl_azure_vm_image_builder_source_version                                  = var.core_azure_vm_image_builder_source_version
  cl_azure_vm_image_builder_distribute_replicationRegions                   = var.core_azure_vm_image_builder_distribute_replicationRegions
  cl_azure_vm_image_builder_template_source_us                              = var.core_azure_vm_image_builder_template_source_us
  cl_azure_vm_image_builder_storage_account_postfix                         = var.core_azure_vm_image_builder_storage_account_postfix
  cl_azure_vm_image_builder_storage_account_resource_group_name             = azurerm_resource_group.core_rg_data.name
  cl_azure_vm_image_builder_storage_account_log_analytics_workspace_id      = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_vm_image_builder_storage_account_allowed_ips                     = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_azure_vm_image_builder_storage_account_allowed_pe_subnet_ids           = [azurerm_subnet.core_private_link_subnet.id]
  cl_azure_vm_image_builder_storage_account_allowed_vnet_subnet_ids         = [azurerm_subnet.core_azure_image_builder_subnet[0].id]
  cl_azure_vm_image_builder_storage_account_private_dns_zone_ids            = var.core_private_dns_zone_enable && var.core_shared_image_gallery_deploy ? [data.azurerm_private_dns_zone.core_data_private_dns_zone_sa[0].id] : var.core_vm_image_builder_storage_account_private_dns_zone_id
  cl_azure_vm_image_builder_storage_account_network_rules_default_action    = var.core_azure_vm_image_builder_storage_account_network_rules_default_action
  tags                                                                      = var.tags
}
//***************************************************************************************************

//Deploy Azure VM Image Builder to Windows DNS Forwarder Image
//***************************************************************************************************
module "cl_azure_vm_image_builder" {
  source                                                                    = "../../components/cl_azure_vm_image_builder"
  env                                                                       = var.env
  postfix                                                                   = var.postfix
  location                                                                  = var.location
  cl_azure_vm_image_builder_release                                         = var.sharedsvs_azure_vm_image_builder_release
  cl_azure_vm_image_build_number                                            = var.sharedsvs_azure_vm_image_build_number
  cl_azure_vm_image_builder_user_identity_rg                                = azurerm_resource_group.sharedsvs_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_gallery_name                   = azurerm_shared_image_gallery.sharedsvs_shared_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_rg                             = azurerm_resource_group.sharedsvs_rg_image_gallery[0].name
  cl_azure_vm_image_builder_shared_image_def_os_type                        = var.sharedsvs_azure_vm_image_builder_shared_image_def_os_type
  cl_azure_vm_image_builder_vmSize                                          = var.sharedsvs_azure_vm_image_builder_vmSize
  cl_azure_vm_image_builder_source_publisher                                = var.sharedsvs_azure_vm_image_builder_source_publisher
  cl_azure_vm_image_builder_source_offer                                    = var.sharedsvs_azure_vm_image_builder_source_offer
  cl_azure_vm_image_builder_source_sku                                      = var.sharedsvs_azure_vm_image_builder_source_sku
  cl_azure_vm_image_builder_template_resource_group_name                    = azurerm_resource_group.sharedsvs_rg_azure_image_builder[0].name
  cl_azure_vm_image_builder_subnet_id                                       = azurerm_subnet.sharedsvs_azure_image_builder_subnet.id
  cl_azure_vm_image_builder_identifier_source_publisher                     = var.sharedsvs_azure_vm_image_builder_identifier_source_publisher
  cl_azure_vm_image_builder_identifier_source_offer                         = var.sharedsvs_azure_vm_image_builder_identifier_source_offer
  cl_azure_vm_image_builder_template_deployment_mode                        = var.sharedsvs_azure_vm_image_builder_template_deployment_mode
  cl_azure_vm_image_builder_resource_apiVersion                             = var.sharedsvs_azure_vm_image_builder_resource_apiVersion
  cl_azure_vm_image_builder_source_version                                  = var.sharedsvs_azure_vm_image_builder_source_version
  cl_azure_vm_image_builder_distribute_replicationRegions                   = var.sharedsvs_azure_vm_image_builder_distribute_replicationRegions
  cl_azure_vm_image_builder_template_source_latam                           = var.sharedsvs_azure_vm_image_builder_template_source_latam
  cl_azure_vm_image_builder_storage_account_postfix                         = var.sharedsvs_azure_vm_image_builder_storage_account_postfix
  cl_azure_vm_image_builder_storage_account_resource_group_name             = azurerm_resource_group.sharedsvs_rg_data.name
  cl_azure_vm_image_builder_storage_account_log_analytics_workspace_id      = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_vm_image_builder_storage_account_allowed_ips                     = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_azure_vm_image_builder_storage_account_allowed_pe_subnet_ids           = [azurerm_subnet.sharedsvs_private_link_subnet.id]
  cl_azure_vm_image_builder_storage_account_allowed_vnet_subnet_ids         = [azurerm_subnet.sharedsvs_azure_image_builder_subnet.id]  
  cl_azure_vm_image_builder_storage_account_private_dns_zone_ids            = var.sharedsvs_private_dns_zone_enable && var.sharedsvs_shared_image_gallery_deploy ? [data.azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_sa[0].id] : null
  cl_azure_vm_image_builder_storage_account_network_rules_default_action    = var.sharedsvs_azure_vm_image_builder_storage_account_network_rules_default_action
  cl_azure_vm_image_builder_storage_account_deploy                          = false // latam image defition VM's byt the default the value in in tru to image defition VM's for US. 

  tags                                                                      = var.tags
}
```

<!-- BEGIN_TF_DOCS -->

# Postgresql Database Component

Azure Database for PostgreSQL is a relational database service based on the open-source Postgres database engine. 
It's a fully managed database-as-a-service that can handle mission-critical workloads with predictable performance, security, high availability, and dynamic scalability.
This component will deploy just the Azure Postgresql Database.

For more information, please visit: https://docs.microsoft.com/en-us/azure/postgresql/#:~:text=Azure%20Database%20for%20PostgreSQL%20is,high%20availability%2C%20and%20dynamic%20scalability



## Resources

| Name | Type |
|------|------|
| [azurerm_postgresql_database.cl_postgres_sql_database](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_database) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_postgres_sql_database_charset"></a> [cl\_postgres\_sql\_database\_charset](#input\_cl\_postgres\_sql\_database\_charset) | Database Character set | `string` | `"UTF8"` | no |
| <a name="input_cl_postgres_sql_database_collation"></a> [cl\_postgres\_sql\_database\_collation](#input\_cl\_postgres\_sql\_database\_collation) | Database Collation | `string` | `"English_United States.1252"` | no |
| <a name="input_cl_postgres_sql_database_postfix"></a> [cl\_postgres\_sql\_database\_postfix](#input\_cl\_postgres\_sql\_database\_postfix) | (Required) A string that is appended to the end of the database name to identify it. | `string` | n/a | yes |
| <a name="input_cl_postgres_sql_server"></a> [cl\_postgres\_sql\_server](#input\_cl\_postgres\_sql\_server) | (Required) PostgreSQL Server Name | `string` | n/a | yes |
| <a name="input_cl_postgres_sql_server_resource_group_name"></a> [cl\_postgres\_sql\_server\_resource\_group\_name](#input\_cl\_postgres\_sql\_server\_resource\_group\_name) | (Required) PostgreSQL Resource Group Name | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_postgres_sql_database"></a> [cl\_postgres\_sql\_database](#output\_cl\_postgres\_sql\_database) | Outputs ********************************************************************************************** |

## Usage

```terraform
// Deploy Postgres Server
//**********************************************************************************************
module "cl_postgresdb" {
  source                                           = "../tf-azure-component-library/components/cl_postgres_sql_server"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_postgres_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_postgres_sql_server_admin_login                          = "adminsql"
  cl_postgres_sql_server_admin_password                       = "Abc1234567890."
  cl_postgres_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_postgres_sql_server_network_rg                           = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
  cl_postgres_sql_server_vnet_id                              = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  cl_postgres_sql_server_vnet_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_postgres_sql_server_pe_subnet_id                         = azurerm_subnet.cl_private_endpoint_subnet.id
  cl_postgres_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.cl_azure_private_dns_zone_db.id]
}
//**********************************************************************************************

// Deploy Postgres database
//**********************************************************************************************
module "cl_postgresdatabase" {
  source                                           = "../tf-azure-component-library/components/cl_postgres_sql_database"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_postgres_sql_server_resource_group_name       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_postgres_sql_server                           = module.cl_postgresdb.cl_postgres_sql_server.name
  cl_postgres_sql_database_postfix                 = "dbname"
}
//**********************************************************************************************

// Deploy Azure DNS Private Zone for db.
// This allows to connect to the DB via dns name.
// **********************************************************************************************
resource "azurerm_private_dns_zone" "cl_azure_private_dns_zone_db" {
  name                = "privatelink.postgres.database.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}
//**********************************************************************************************

// Link DB DNS zone to Virtual Network
// ************************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "cl_linkdnstosubnet_db" {
  name                  = "linkdb"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cl_azure_private_dns_zone_db.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//**********************************************************************************************

// Deploy Subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "cl_private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                   = ["60.0.3.0/24"]
  enforce_private_link_endpoint_network_policies     = true
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
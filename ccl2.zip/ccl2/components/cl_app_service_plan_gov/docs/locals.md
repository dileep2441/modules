## Local values

```terraform
locals {
    timeout_duration = "2h"
    cl_app_service_plan_rg     = var.cl_app_service_plan_deploy_rg ? azurerm_resource_group.cl_app_service_plan_rg[0].name : var.cl_app_service_plan_rg_name
    cl_app_service_plan_integration_subnet = var.cl_app_service_plan_deploy_integration_subnet ? azurerm_subnet.cl_app_service_plan_integration_subnet[0] : null
    cl_app_service_plan_integration_subnet_nsg = var.cl_app_service_plan_deploy_integration_subnet ? azurerm_network_security_group.cl_app_service_plan_integration_subnet_nsg[0] : null
    cl_app_service_plan_integration_subnet_association = var.cl_app_service_plan_deploy_integration_subnet ? azurerm_subnet_network_security_group_association.cl_app_service_plan_integration_subnet_association[0] : null
}
```
## Local values

```terraform
locals {
    timeout_duration = "2h"
    cl_storage_account_blob_properties           = (var.cl_logic_app_storage_account_enable_backup ? false : true)
    cl_logic_app_storage_account_infra_encryption_enabled = (var.cl_logic_app_storage_account_kind == "StorageV2" || var.cl_logic_app_storage_account_kind == "BlockBlobStorage" && var.cl_logic_app_storage_account_tier == "Premium" ? true : false)
    cl_logic_app_storage_account_modify_name = {
        "sbox-pr" = "sboxpr"
        "nprd-pr" = "nprdpr"
        "nprd-dr" = "nprddr"
        "prod-pr" = "prodpr"
        "prod-dr" = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```
# Azure logic App Component

(Azure Logic App is a serverless workflow service that enables the user to run event-triggered code without having to provision or manage infrastructure.)
This component will deploy an Azure Logic App. It will also deploy a storage account, private endpoints, and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/logic-apps/logic-apps-overview

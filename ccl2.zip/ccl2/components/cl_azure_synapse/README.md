<!-- BEGIN_TF_DOCS -->

# Azure Synapse Component

Azure Synapse is a analytics service that brings together data integration, enterprise data warehousing, and big data analytics. 
With these capabilties - synapse allows to ingest, transform and manage data for immediate BI and machine learning needs.
This component will deploy a random password and KV secret for SQL admin for AZ Synapse. It also creates a workspace, dedicated sql pool, private link hub, diagnostics and private endpoint for AZ synapse.

For more information, please visit: https://docs.microsoft.com/en-us/azure/synapse-analytics/overview-what-is 

## Information
## Enabled extended auditing policy to Azure Synpase Workspace and Sql Pool's:
```terraform
1. Deploy the infrastructure to Azure Synpase
3. Before to deploy the extended_auditing_policy, with a Admin CloudOps request the role assignment to the Storage Account created for audit in component Azure Synapse
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/ to manage identity for Azure Synapse name
4. Add the variable to enabled the deploy for the extended_auditing_policy in Azure Synapse Workspace and Sql Pool's
   
   cl_azure_synapse_enabled_audit_security_logs = true

## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.cl_azure_synapse_sa_atp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_data_protection_backup_instance_blob_storage.cl_azure_synapse_sa_protected_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_instance_blob_storage) | resource |
| [azurerm_key_vault_secret.cl_azure_synapse_sql_admin_password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_synapse_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_synapse_sql_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_synapse_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_azure_synapse_private_endpoint_dev](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_azure_synapse_private_endpoint_sql](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_azure_synapse_private_endpoint_sqlondemand](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_azure_synapse_storage_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_security_center_subscription_pricing.cl_azure_synapse_sql_defender](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_storage_account.cl_azure_synapse_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_container.cl_azure_synapse_sa_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_synapse_firewall_rule.cl_azure_synapse_firewall_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_firewall_rule) | resource |
| [azurerm_synapse_managed_private_endpoint.cl_azure_synapse_managed_pe](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_managed_private_endpoint) | resource |
| [azurerm_synapse_managed_private_endpoint.cl_azure_synapse_plinkhub_managed_pe](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_managed_private_endpoint) | resource |
| [azurerm_synapse_private_link_hub.cl_azure_synapse_private_link_hub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_private_link_hub) | resource |
| [azurerm_synapse_sql_pool.cl_azure_synapse_sql_pool](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_sql_pool) | resource |
| [azurerm_synapse_sql_pool_extended_auditing_policy.cl_azure_synapse_sql_audit_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_sql_pool_extended_auditing_policy) | resource |
| [azurerm_synapse_sql_pool_security_alert_policy.cl_azure_synapse_sql_alert_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_sql_pool_security_alert_policy) | resource |
| [azurerm_synapse_sql_pool_vulnerability_assessment.cl_azure_synapse_sql_security_assessment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_sql_pool_vulnerability_assessment) | resource |
| [azurerm_synapse_workspace.cl_azure_synapse_workspace](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_workspace) | resource |
| [azurerm_synapse_workspace_extended_auditing_policy.cl_azure_synapse_workspace_extended_auditing_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_workspace_extended_auditing_policy) | resource |
| [azurerm_synapse_workspace_security_alert_policy.cl_azure_synapse_workspace_alert_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_workspace_security_alert_policy) | resource |
| [azurerm_synapse_workspace_vulnerability_assessment.cl_azure_synapse_workspace_security_assessment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_workspace_vulnerability_assessment) | resource |
| [random_password.cl_azure_synapse_sql_admin](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_synapse_alert_retention_days"></a> [cl\_azure\_synapse\_alert\_retention\_days](#input\_cl\_azure\_synapse\_alert\_retention\_days) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_cl_azure_synapse_audit_retention_days"></a> [cl\_azure\_synapse\_audit\_retention\_days](#input\_cl\_azure\_synapse\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `7` | no |
| <a name="input_cl_azure_synapse_data_exfiltration_protection_enabled"></a> [cl\_azure\_synapse\_data\_exfiltration\_protection\_enabled](#input\_cl\_azure\_synapse\_data\_exfiltration\_protection\_enabled) | (Optional) data exfiltration protection enabled. | `bool` | `true` | no |
| <a name="input_cl_azure_synapse_dev_private_dns_zone_id"></a> [cl\_azure\_synapse\_dev\_private\_dns\_zone\_id](#input\_cl\_azure\_synapse\_dev\_private\_dns\_zone\_id) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_synapse_diagnostic_setting"></a> [cl\_azure\_synapse\_diagnostic\_setting](#input\_cl\_azure\_synapse\_diagnostic\_setting) | (Optional) Monitor Diagnostic Settings | <pre>object({<br>    logs                            = list(string)<br>    metrics                         = list(string)<br>    log_retention_policy_enabled    = bool,<br>    log_retention_policy_days       = number,<br>    metric_retention_policy_enabled = bool,<br>    metric_retention_policy_days    = number<br>  })</pre> | <pre>{<br>  "log_retention_policy_days": 0,<br>  "log_retention_policy_enabled": false,<br>  "logs": [<br>    "SynapseRbacOperations",<br>    "GatewayApiRequests",<br>    "BuiltinSqlReqsEnded",<br>    "IntegrationPipelineRuns",<br>    "IntegrationActivityRuns",<br>    "IntegrationTriggerRuns",<br>    "SQLSecurityAuditEvents"<br>  ],<br>  "metric_retention_policy_days": 0,<br>  "metric_retention_policy_enabled": false,<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_synapse_disabled_alerts"></a> [cl\_azure\_synapse\_disabled\_alerts](#input\_cl\_azure\_synapse\_disabled\_alerts) | (Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql\_Injection, Sql\_Injection\_Vulnerability, Access\_Anomaly, Data\_Exfiltration, Unsafe\_Action. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_synapse_enabled_audit_security_logs"></a> [cl\_azure\_synapse\_enabled\_audit\_security\_logs](#input\_cl\_azure\_synapse\_enabled\_audit\_security\_logs) | (Optional) enabled and save audit and security logs in storage account audit. | `bool` | `false` | no |
| <a name="input_cl_azure_synapse_enabled_sa_diagnostic_settings"></a> [cl\_azure\_synapse\_enabled\_sa\_diagnostic\_settings](#input\_cl\_azure\_synapse\_enabled\_sa\_diagnostic\_settings) | (Optional) Boolean to enable sa monitor diagnostic setting resource creation | `bool` | `true` | no |
| <a name="input_cl_azure_synapse_firewall_allow_azure_services"></a> [cl\_azure\_synapse\_firewall\_allow\_azure\_services](#input\_cl\_azure\_synapse\_firewall\_allow\_azure\_services) | variable to enable Firewall rule to allow azure services | `bool` | `false` | no |
| <a name="input_cl_azure_synapse_firewall_rules"></a> [cl\_azure\_synapse\_firewall\_rules](#input\_cl\_azure\_synapse\_firewall\_rules) | (Optional) Define additional firewall rules | <pre>map(object({<br>    start_ip                 = string<br>    end_ip                   = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_synapse_identity_type"></a> [cl\_azure\_synapse\_identity\_type](#input\_cl\_azure\_synapse\_identity\_type) | (Required) Specifies the type of Managed Service Identity that should be associated with this Synapse Workspace. Possible values are SystemAssigned, UserAssigned and SystemAssigned, UserAssigned (to enable both) | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_azure_synapse_keyvault_enable_secret_expiry"></a> [cl\_azure\_synapse\_keyvault\_enable\_secret\_expiry](#input\_cl\_azure\_synapse\_keyvault\_enable\_secret\_expiry) | (optional) If set to true, enable expiry date on key vault secret. | `bool` | `true` | no |
| <a name="input_cl_azure_synapse_keyvault_id"></a> [cl\_azure\_synapse\_keyvault\_id](#input\_cl\_azure\_synapse\_keyvault\_id) | (Required) The id of the synapse keyvault id. | `string` | n/a | yes |
| <a name="input_cl_azure_synapse_keyvault_secret_expiry_date"></a> [cl\_azure\_synapse\_keyvault\_secret\_expiry\_date](#input\_cl\_azure\_synapse\_keyvault\_secret\_expiry\_date) | (Optional) If cl\_azure\_synapse\_keyvault\_enable\_secret\_expiry is set to true, define a expiry date for KV secret. | `string` | `null` | no |
| <a name="input_cl_azure_synapse_log_analytics_workspace_id"></a> [cl\_azure\_synapse\_log\_analytics\_workspace\_id](#input\_cl\_azure\_synapse\_log\_analytics\_workspace\_id) | (Required) The id of the synapse workspace. | `string` | n/a | yes |
| <a name="input_cl_azure_synapse_manage_private_endpoint"></a> [cl\_azure\_synapse\_manage\_private\_endpoint](#input\_cl\_azure\_synapse\_manage\_private\_endpoint) | (Optional) Manage private endpoint variables | <pre>map(object({<br>    name = string,<br>    target_resource_id = string,<br>    subresource_name = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_synapse_managed_virtual_network_enabled"></a> [cl\_azure\_synapse\_managed\_virtual\_network\_enabled](#input\_cl\_azure\_synapse\_managed\_virtual\_network\_enabled) | (Optional) managed virtual network enabled. | `bool` | `true` | no |
| <a name="input_cl_azure_synapse_policy_state"></a> [cl\_azure\_synapse\_policy\_state](#input\_cl\_azure\_synapse\_policy\_state) | (Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific SQL pool. Allowed values are: Disabled, Enabled. | `string` | `"Enabled"` | no |
| <a name="input_cl_azure_synapse_postfix"></a> [cl\_azure\_synapse\_postfix](#input\_cl\_azure\_synapse\_postfix) | alias azure synapse deployment | `string` | n/a | yes |
| <a name="input_cl_azure_synapse_resource_group_name"></a> [cl\_azure\_synapse\_resource\_group\_name](#input\_cl\_azure\_synapse\_resource\_group\_name) | (Required) The name of the resource group where the synapse resources will be deployed to. | `string` | n/a | yes |
| <a name="input_cl_azure_synapse_sa_backup_policy_id"></a> [cl\_azure\_synapse\_sa\_backup\_policy\_id](#input\_cl\_azure\_synapse\_sa\_backup\_policy\_id) | The azure blob storage backup policy id from the backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_synapse_sa_backup_vault"></a> [cl\_azure\_synapse\_sa\_backup\_vault](#input\_cl\_azure\_synapse\_sa\_backup\_vault) | The blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_synapse_sa_backup_vault_id"></a> [cl\_azure\_synapse\_sa\_backup\_vault\_id](#input\_cl\_azure\_synapse\_sa\_backup\_vault\_id) | The id of blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_azure_synapse_sa_enable_backup"></a> [cl\_azure\_synapse\_sa\_enable\_backup](#input\_cl\_azure\_synapse\_sa\_enable\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_synapse_security_email_subscription"></a> [cl\_azure\_synapse\_security\_email\_subscription](#input\_cl\_azure\_synapse\_security\_email\_subscription) | (Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators. | `bool` | `false` | no |
| <a name="input_cl_azure_synapse_security_emails"></a> [cl\_azure\_synapse\_security\_emails](#input\_cl\_azure\_synapse\_security\_emails) | (Optional) Specifies an array of e-mail addresses to which the scan notification is sent. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_synapse_security_scans"></a> [cl\_azure\_synapse\_security\_scans](#input\_cl\_azure\_synapse\_security\_scans) | (Optional) Boolean flag which specifies if recurring scans is enabled or disabled. | `bool` | `true` | no |
| <a name="input_cl_azure_synapse_sql_admin_password"></a> [cl\_azure\_synapse\_sql\_admin\_password](#input\_cl\_azure\_synapse\_sql\_admin\_password) | (Optional) SQL Admin Password | <pre>object({<br>    length           = number,<br>    special          = bool,<br>    upper            = bool,<br>    lower            = bool,<br>    numeric          = bool,<br>    override_special = string<br>  })</pre> | <pre>{<br>  "length": 16,<br>  "lower": true,<br>  "numeric": true,<br>  "override_special": "!$#%",<br>  "special": true,<br>  "upper": true<br>}</pre> | no |
| <a name="input_cl_azure_synapse_sql_administrator_login"></a> [cl\_azure\_synapse\_sql\_administrator\_login](#input\_cl\_azure\_synapse\_sql\_administrator\_login) | (Optional) The id of the synapse subnet id. | `string` | `"sqladminuser"` | no |
| <a name="input_cl_azure_synapse_sql_administrator_login_password"></a> [cl\_azure\_synapse\_sql\_administrator\_login\_password](#input\_cl\_azure\_synapse\_sql\_administrator\_login\_password) | (Optional) SQL admin login password | `string` | `null` | no |
| <a name="input_cl_azure_synapse_sql_defender_deploy"></a> [cl\_azure\_synapse\_sql\_defender\_deploy](#input\_cl\_azure\_synapse\_sql\_defender\_deploy) | (Optional) to set azurerm\_security\_center\_subscription\_pricing as standard for sql servers, if already enabled in subscription set to false | `bool` | `true` | no |
| <a name="input_cl_azure_synapse_sql_diagnostic_setting"></a> [cl\_azure\_synapse\_sql\_diagnostic\_setting](#input\_cl\_azure\_synapse\_sql\_diagnostic\_setting) | (Optional) Monitor Diagnostic Settings | <pre>object({<br>    logs                            = list(string)<br>    metrics                         = list(string)<br>    log_retention_policy_enabled    = bool,<br>    log_retention_policy_days       = number,<br>    metric_retention_policy_enabled = bool,<br>    metric_retention_policy_days    = number<br>  })</pre> | <pre>{<br>  "log_retention_policy_days": 0,<br>  "log_retention_policy_enabled": false,<br>  "logs": [<br>    "SqlRequests",<br>    "ExecRequests",<br>    "RequestSteps",<br>    "DmsWorkers",<br>    "SQLSecurityAuditEvents",<br>    "Waits"<br>  ],<br>  "metric_retention_policy_days": 0,<br>  "metric_retention_policy_enabled": false,<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_synapse_sql_identity_control_enabled"></a> [cl\_azure\_synapse\_sql\_identity\_control\_enabled](#input\_cl\_azure\_synapse\_sql\_identity\_control\_enabled) | (Optional) Are pipelines (running as workspace's system assigned identity) allowed to access SQL pools? | `bool` | `false` | no |
| <a name="input_cl_azure_synapse_sql_pool"></a> [cl\_azure\_synapse\_sql\_pool](#input\_cl\_azure\_synapse\_sql\_pool) | (Optional) Dedicated SQL pool variables | <pre>map(object({<br>    name          = string,<br>    sku_name       = string,<br>    create_mode    = string,<br>    collation      = string,<br>    data_encrypted = bool<br>  }))</pre> | n/a | yes |
| <a name="input_cl_azure_synapse_sql_private_dns_zone_id"></a> [cl\_azure\_synapse\_sql\_private\_dns\_zone\_id](#input\_cl\_azure\_synapse\_sql\_private\_dns\_zone\_id) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_synapse_storage_account_blob_retention_days"></a> [cl\_azure\_synapse\_storage\_account\_blob\_retention\_days](#input\_cl\_azure\_synapse\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_azure_synapse_storage_account_bypass"></a> [cl\_azure\_synapse\_storage\_account\_bypass](#input\_cl\_azure\_synapse\_storage\_account\_bypass) | (Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. | `list(string)` | <pre>[<br>  "Logging",<br>  "Metrics",<br>  "AzureServices"<br>]</pre> | no |
| <a name="input_cl_azure_synapse_storage_account_container_retention_days"></a> [cl\_azure\_synapse\_storage\_account\_container\_retention\_days](#input\_cl\_azure\_synapse\_storage\_account\_container\_retention\_days) | Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7` | `number` | `7` | no |
| <a name="input_cl_azure_synapse_storage_account_diagnostics"></a> [cl\_azure\_synapse\_storage\_account\_diagnostics](#input\_cl\_azure\_synapse\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "StorageRead",<br>    "StorageWrite",<br>    "StorageDelete"<br>  ],<br>  "metrics": [<br>    "Transaction"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_synapse_storage_account_ip_rules"></a> [cl\_azure\_synapse\_storage\_account\_ip\_rules](#input\_cl\_azure\_synapse\_storage\_account\_ip\_rules) | (Optional) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_synapse_storage_account_min_tls_version"></a> [cl\_azure\_synapse\_storage\_account\_min\_tls\_version](#input\_cl\_azure\_synapse\_storage\_account\_min\_tls\_version) | (Optional) Defines the minimum TLS version to use for the data lake storage account. | `string` | `"TLS1_2"` | no |
| <a name="input_cl_azure_synapse_storage_account_network_default_action"></a> [cl\_azure\_synapse\_storage\_account\_network\_default\_action](#input\_cl\_azure\_synapse\_storage\_account\_network\_default\_action) | (Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow. | `string` | `"Deny"` | no |
| <a name="input_cl_azure_synapse_storage_account_private_dns_zone_ids"></a> [cl\_azure\_synapse\_storage\_account\_private\_dns\_zone\_ids](#input\_cl\_azure\_synapse\_storage\_account\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_synapse_storage_account_replication_type"></a> [cl\_azure\_synapse\_storage\_account\_replication\_type](#input\_cl\_azure\_synapse\_storage\_account\_replication\_type) | (Optional) Defines the type of replication to use for the storage account for Azure SQL server audit and security logging. | `string` | `"LRS"` | no |
| <a name="input_cl_azure_synapse_storage_account_subnet_ids"></a> [cl\_azure\_synapse\_storage\_account\_subnet\_ids](#input\_cl\_azure\_synapse\_storage\_account\_subnet\_ids) | (Optional) A list of resource ids for subnets. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_synapse_storage_account_tier"></a> [cl\_azure\_synapse\_storage\_account\_tier](#input\_cl\_azure\_synapse\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for Azure SQL server audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_cl_azure_synapse_storage_data_lake_gen2_filesystem_id"></a> [cl\_azure\_synapse\_storage\_data\_lake\_gen2\_filesystem\_id](#input\_cl\_azure\_synapse\_storage\_data\_lake\_gen2\_filesystem\_id) | (Required) The id of the data lake filesystem to be used by synapse. | `string` | n/a | yes |
| <a name="input_cl_azure_synapse_subnet_id"></a> [cl\_azure\_synapse\_subnet\_id](#input\_cl\_azure\_synapse\_subnet\_id) | (Required) The id of the synapse subnet id. | `list(string)` | n/a | yes |
| <a name="input_cl_azure_synapse_virtual_network_id"></a> [cl\_azure\_synapse\_virtual\_network\_id](#input\_cl\_azure\_synapse\_virtual\_network\_id) | (Required) The id of the synapse virtual network id. | `string` | n/a | yes |
| <a name="input_cl_azure_synapse_workspace_disabled_alerts"></a> [cl\_azure\_synapse\_workspace\_disabled\_alerts](#input\_cl\_azure\_synapse\_workspace\_disabled\_alerts) | (Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql\_Injection, Sql\_Injection\_Vulnerability, Access\_Anomaly, Data\_Exfiltration, Unsafe\_Action. | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h" 
  cl_azure_synapse_storage_account_blob_properties = (var.cl_azure_synapse_sa_enable_backup ? false : true)
  cl_azure_synapse_storage_account = {
    "sbox-pr"  = "sboxpr"
    "nprd-pr"  = "nprdpr"
    "nprd-dr"  = "nprddr"
    "prod-pr"  = "prodpr" 
    "prod-dr"  = "proddr"
    "nprod-pr" = "nprodpr"
  }
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_synapse_diagnostic_setting"></a> [cl\_azure\_synapse\_diagnostic\_setting](#output\_cl\_azure\_synapse\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_synapse_firewall_rules"></a> [cl\_azure\_synapse\_firewall\_rules](#output\_cl\_azure\_synapse\_firewall\_rules) | n/a |
| <a name="output_cl_azure_synapse_managed_pe"></a> [cl\_azure\_synapse\_managed\_pe](#output\_cl\_azure\_synapse\_managed\_pe) | n/a |
| <a name="output_cl_azure_synapse_plinkhub_managed_pe"></a> [cl\_azure\_synapse\_plinkhub\_managed\_pe](#output\_cl\_azure\_synapse\_plinkhub\_managed\_pe) | n/a |
| <a name="output_cl_azure_synapse_private_endpoint_dev"></a> [cl\_azure\_synapse\_private\_endpoint\_dev](#output\_cl\_azure\_synapse\_private\_endpoint\_dev) | n/a |
| <a name="output_cl_azure_synapse_private_endpoint_sql"></a> [cl\_azure\_synapse\_private\_endpoint\_sql](#output\_cl\_azure\_synapse\_private\_endpoint\_sql) | n/a |
| <a name="output_cl_azure_synapse_private_endpoint_sqlondemand"></a> [cl\_azure\_synapse\_private\_endpoint\_sqlondemand](#output\_cl\_azure\_synapse\_private\_endpoint\_sqlondemand) | n/a |
| <a name="output_cl_azure_synapse_private_link_hub"></a> [cl\_azure\_synapse\_private\_link\_hub](#output\_cl\_azure\_synapse\_private\_link\_hub) | n/a |
| <a name="output_cl_azure_synapse_sql_admin_password"></a> [cl\_azure\_synapse\_sql\_admin\_password](#output\_cl\_azure\_synapse\_sql\_admin\_password) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_synapse_sql_alert_policy"></a> [cl\_azure\_synapse\_sql\_alert\_policy](#output\_cl\_azure\_synapse\_sql\_alert\_policy) | n/a |
| <a name="output_cl_azure_synapse_sql_audit_policy"></a> [cl\_azure\_synapse\_sql\_audit\_policy](#output\_cl\_azure\_synapse\_sql\_audit\_policy) | n/a |
| <a name="output_cl_azure_synapse_sql_diagnostic_setting"></a> [cl\_azure\_synapse\_sql\_diagnostic\_setting](#output\_cl\_azure\_synapse\_sql\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_synapse_sql_pool"></a> [cl\_azure\_synapse\_sql\_pool](#output\_cl\_azure\_synapse\_sql\_pool) | n/a |
| <a name="output_cl_azure_synapse_sql_security_assessment"></a> [cl\_azure\_synapse\_sql\_security\_assessment](#output\_cl\_azure\_synapse\_sql\_security\_assessment) | n/a |
| <a name="output_cl_azure_synapse_storage_account"></a> [cl\_azure\_synapse\_storage\_account](#output\_cl\_azure\_synapse\_storage\_account) | n/a |
| <a name="output_cl_azure_synapse_storage_account_diagnostic_setting"></a> [cl\_azure\_synapse\_storage\_account\_diagnostic\_setting](#output\_cl\_azure\_synapse\_storage\_account\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_synapse_storage_account_private_endpoint"></a> [cl\_azure\_synapse\_storage\_account\_private\_endpoint](#output\_cl\_azure\_synapse\_storage\_account\_private\_endpoint) | n/a |
| <a name="output_cl_azure_synapse_workspace"></a> [cl\_azure\_synapse\_workspace](#output\_cl\_azure\_synapse\_workspace) | n/a |
| <a name="output_cl_azure_synapse_workspace_alert_policy"></a> [cl\_azure\_synapse\_workspace\_alert\_policy](#output\_cl\_azure\_synapse\_workspace\_alert\_policy) | n/a |
| <a name="output_cl_azure_synapse_workspace_extended_auditing_policy"></a> [cl\_azure\_synapse\_workspace\_extended\_auditing\_policy](#output\_cl\_azure\_synapse\_workspace\_extended\_auditing\_policy) | n/a |
| <a name="output_cl_azure_synapse_workspace_security_assessment"></a> [cl\_azure\_synapse\_workspace\_security\_assessment](#output\_cl\_azure\_synapse\_workspace\_security\_assessment) | n/a |

## Usage
```terraform
resource "azurerm_private_dns_zone" "synapse_sql_private_dns_zone" {
  name                = "privatelink.sql.azuresynapse.net"
  resource_group_name =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "synapse_sql_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-synapse-sql-link"
  resource_group_name   =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_sql_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
}

resource "azurerm_private_dns_zone" "synapse_dev_private_dns_zone" {
  name                = "privatelink.dev.azuresynapse.net"
  resource_group_name =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "synapse_dev_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-synapse-dev-link"
  resource_group_name   =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_dev_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
}

module "cl_azure_synapse" {
  source                                                = "../dn-tads_tf-azure-component-library/components/cl_azure_synapse"
  env                                                   = var.env
  postfix                                               = var.postfix
  location                                              = var.location
  cl_azure_synapse_postfix                              = "xxxx"
  cl_azure_synapse_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_synapse_virtual_network_id                   = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  cl_azure_synapse_subnet_id                            = [azurerm_subnet.test_subnet.id]
  cl_azure_synapse_keyvault_id                          = "keyVault.id"
  cl_azure_synapse_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_synapse_storage_data_lake_gen2_filesystem_id = "storage_data_lake_gen2_filesystem.id"
  cl_azure_synapse_sql_private_dns_zone_id              = [azurerm_private_dns_zone.synapse_sql_private_dns_zone.id]
  cl_azure_synapse_dev_private_dns_zone_id              = [azurerm_private_dns_zone.synapse_dev_private_dns_zone.id]
  cl_azure_synapse_storage_account_ip_rules             = ["20.242.108.56/24", "23.102.127.160/24"]
  cl_azure_synapse_storage_account_subnet_ids           = [azurerm_subnet.test_subnet.id]
  cl_azure_synapse_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "x.x.x.x"
          end_ip   = "x.x.x.x"
    }
  }
  cl_azure_synapse_sql_pool                             = {
        pool1 = {
          name                 = "dedicatedpool01"
          sku_name             = "DW300c"
          create_mode          = "Default"
          collation            = "SQL_Latin1_General_CP1_CI_AS"
          data_encrypted       = "true"
          }
         pool2 = {
            name                 = "dedicatedpool02"
            sku_name             = "DW300c"
            create_mode          = "Default"
            collation            = "SQL_Latin1_General_CP1_CI_AS"
            data_encrypted       = "true"
            }
  }
  //this is an example if the project requiere to integrate a resource with a manage private endpoint
  //Resources availables to integrate with Azure Synapse: Azure Blob Storage, Azure Cosmos DB(MongoDB API),Azure Cosmos DB (SQL API), Azure Data Explorer (Kusto),Azure Data Lake Storage Gen2, Azure Database for MariaDB, Azure Database for MySQL, Azure Database for PostgreSQL, Azure Event Hubs, Azure File Storage, Azure Funtion, Azure Key Vault, Azure Machine Learning, Azure Monitor Private Link Scope, Azure Queue Storage, Azure SQL Database, Azure Sql Database Managed Instance, Azure Search, Azure Synapse Analytics, Azure Table Storage, Cognitive Services, Microsoft Purview and Private Link Service
  cl_azure_synapse_manage_private_endpoint = {
    manage_pe_1 = {
        name = "dlsa"
        target_resource_id = "storageAccount.id"
        subresource_name = "blob"
    }
  }
}
```
<!-- END_TF_DOCS -->

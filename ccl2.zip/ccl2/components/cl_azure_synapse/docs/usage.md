## Usage
```terraform
resource "azurerm_private_dns_zone" "synapse_sql_private_dns_zone" {
  name                = "privatelink.sql.azuresynapse.net"
  resource_group_name =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "synapse_sql_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-synapse-sql-link"
  resource_group_name   =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_sql_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
}

resource "azurerm_private_dns_zone" "synapse_dev_private_dns_zone" {
  name                = "privatelink.dev.azuresynapse.net"
  resource_group_name =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "synapse_dev_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-synapse-dev-link"
  resource_group_name   =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_dev_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
}

module "cl_azure_synapse" {
  source                                                = "../dn-tads_tf-azure-component-library/components/cl_azure_synapse"
  env                                                   = var.env
  postfix                                               = var.postfix
  location                                              = var.location
  cl_azure_synapse_postfix                              = "xxxx"
  cl_azure_synapse_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_synapse_virtual_network_id                   = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  cl_azure_synapse_subnet_id                            = [azurerm_subnet.test_subnet.id]
  cl_azure_synapse_keyvault_id                          = "keyVault.id"
  cl_azure_synapse_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_synapse_storage_data_lake_gen2_filesystem_id = "storage_data_lake_gen2_filesystem.id"
  cl_azure_synapse_sql_private_dns_zone_id              = [azurerm_private_dns_zone.synapse_sql_private_dns_zone.id]
  cl_azure_synapse_dev_private_dns_zone_id              = [azurerm_private_dns_zone.synapse_dev_private_dns_zone.id]
  cl_azure_synapse_storage_account_ip_rules             = ["20.242.108.56/24", "23.102.127.160/24"]
  cl_azure_synapse_storage_account_subnet_ids           = [azurerm_subnet.test_subnet.id]
  cl_azure_synapse_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "x.x.x.x"
          end_ip   = "x.x.x.x"
    }
  }
  cl_azure_synapse_sql_pool                             = {
        pool1 = {
          name                 = "dedicatedpool01"
          sku_name             = "DW300c"
          create_mode          = "Default"
          collation            = "SQL_Latin1_General_CP1_CI_AS"
          data_encrypted       = "true"
          }
         pool2 = {
            name                 = "dedicatedpool02"
            sku_name             = "DW300c"
            create_mode          = "Default"
            collation            = "SQL_Latin1_General_CP1_CI_AS"
            data_encrypted       = "true"
            }
  }
  //this is an example if the project requiere to integrate a resource with a manage private endpoint
  //Resources availables to integrate with Azure Synapse: Azure Blob Storage, Azure Cosmos DB(MongoDB API),Azure Cosmos DB (SQL API), Azure Data Explorer (Kusto),Azure Data Lake Storage Gen2, Azure Database for MariaDB, Azure Database for MySQL, Azure Database for PostgreSQL, Azure Event Hubs, Azure File Storage, Azure Funtion, Azure Key Vault, Azure Machine Learning, Azure Monitor Private Link Scope, Azure Queue Storage, Azure SQL Database, Azure Sql Database Managed Instance, Azure Search, Azure Synapse Analytics, Azure Table Storage, Cognitive Services, Microsoft Purview and Private Link Service
  cl_azure_synapse_manage_private_endpoint = {
    manage_pe_1 = {
        name = "dlsa"
        target_resource_id = "storageAccount.id"
        subresource_name = "blob"
    }
  }
}
```
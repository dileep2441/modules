## Local values

```terraform
locals {
  timeout_duration = "2h" 
  cl_azure_synapse_storage_account_blob_properties = (var.cl_azure_synapse_sa_enable_backup ? false : true)
  cl_azure_synapse_storage_account = {
    "sbox-pr"  = "sboxpr"
    "nprd-pr"  = "nprdpr"
    "nprd-dr"  = "nprddr"
    "prod-pr"  = "prodpr" 
    "prod-dr"  = "proddr"
    "nprod-pr" = "nprodpr"
  }
}
```
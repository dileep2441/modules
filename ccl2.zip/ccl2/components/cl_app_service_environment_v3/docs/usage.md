## Usage
//**********************************************************************************************
module "component_ase_v3" {
   source                                   = "../dn-tads_tf-azure-component-library/components/cl_app_service_environment_v3"
    env                                     = var.env
    postfix                                 = var.postfix
    location                                = var.location
    cl_ase_v3_core_vnet_resource_group_name        = var.cl_core_vnet_resource_group_name
    cl_ase_v3_core_vnet_name                       = var.cl_core_vnet_name
    cl_ase_v3_core_vnet_id                         = var.cl_core_vnet_id
    cl_ase_v3_subnet_prefix                 = var.cl_ase_v3_subnet_prefix
    cl_ase_v3_name                          = var.cl_ase_v3_name
    cl_ase_v3_app_service_plans             = var.cl_ase_v3_app_service_plans
    cl_ase_v3_log_analytics_workspace_id    = var.cl_ase_v3_log_analytics_workspace_id
    tags                                    = var.tags

}
//**********************************************************************************************
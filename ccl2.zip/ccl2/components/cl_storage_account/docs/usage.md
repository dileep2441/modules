## Usage
#### Normal Usage (Blob Storage Backup Enabled)
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}


module "cl_storage_account" {
  source                                          = "../tf-azure-component-library/components/cl_storage_account"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.web_subnet.id]
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]  
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone.id]
  cl_storage_account_blob_enable_backup           = true
  cl_storage_account_blob_backup_vault_id         = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_storage_account_blob_backup_vault            = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_storage_account_blob_backup_policy_id        = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```

#### For File Share (File Storage Backup Enabled)
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone" {
  name                = "privatelink.file.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_storage_account" {
    source                                          = "../tf-azure-component-library/components/cl_storage_account"
    env                                             = var.env
    postfix                                         = var.postfix
    location                                        = var.location
    cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
    cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.web_subnet.id]
    cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]
    cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
    cl_storage_account_share_enabled                = true
    cl_storage_account_file_shares                  = var.cl_storage_account_file_shares
    cl_storage_account_file_enable_backup           = true
    cl_storage_account_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_storage_account_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_storage_account_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
    cl_storage_account_large_file_share             = true
    cl_storage_account_tier                         = "Premium"
    cl_storage_account_kind                         = "FileStorage"
    cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone.id]
}
```
#### For Azure Queue Storage
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone" {
  name                = "privatelink.queue.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_storage_account" {
  source                                          = "../tf-azure-component-library/components/cl_storage_account"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]  
  cl_storage_account_queue_enabled                = true
  cl_storage_account_queue_monitor_enabled        = false
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone.id]
}
```
#### For Azure Queue Storage and File Share (File Storage Backup Enabled)
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone_file" {
  name                = "privatelink.file.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link_file" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone_file.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}

resource "azurerm_private_dns_zone" "sa_private_dns_zone_queue" {
  name                = "privatelink.queue.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link_queue" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone_queue.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}

module "cl_storage_account" {
  source                                          = "../tf-azure-component-library/components/cl_storage_account"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
  cl_storage_account_share_enabled                = true
  cl_storage_account_file_shares                  = var.cl_storage_account_file_shares
  cl_storage_account_file_enable_backup           = true
  cl_storage_account_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_storage_account_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_storage_account_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
  cl_storage_account_tier                         = "Standard"
  cl_storage_account_kind                         = "StorageV2"
  cl_storage_account_queue_enabled                = true
  cl_storage_account_queue_monitor_enabled        = true
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone_file.id, azurerm_private_dns_zone.sa_private_dns_zone_queue.id]
}
```
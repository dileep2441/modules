## Local values

```terraform
locals {
  timeout_duration                    = "2h"
  cl_storage_account_blob_properties  = (var.cl_storage_account_kind == "FileStorage" || var.cl_storage_account_blob_enable_backup ? false : true)
  cl_storage_account_queue_enabled  = (var.cl_storage_account_tier == "Standard" && var.cl_storage_account_kind != "BlobStorage" && var.cl_storage_account_queue_enabled ? true : false)
  cl_storage_account_name = {
        "sbox-pr"  = "sboxpr"
        "nprd-pr"  = "nprdpr"
        "nprd-dr"  = "nprddr"
        "prod-pr"  = "prodpr" 
        "prod-dr"  = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```
# Azure App Insights Component

Azure Application Insights is a Application Performance Management (APM) service that is used to monitor live applications. 
This service provides insights on app availability, performance, failures and usage.
This component will deploy Azure Application insights and make itself available for App/Web monitoring.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-monitor/app/app-insights-overview


## Usage

```terraform

// ADI code starts from here *********************************************************************

// Azure Application Insights
//**********************************************************************************************
module "cl_app_insights" {
  source                              = "../dn-tads_tf-azure-component-library/components/cl_app_insights_gov"
  env                                 = var.env
  postfix                             = var.postfix
  location                            = var.location
  tags                                         = var.tags
  cl_app_insights_resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_app_insights_application_type    = "web"
  cl_app_insights_content                      = "requests //simple example query"
  cl_app_insights_scope                        = "shared"
  cl_app_insights_type                         = "query"
  cl_app_insights_web_test_kind                = "ping"
  cl_app_insights_web_test            = {
    web_test = {
     frequency                    = 300
      timeout                     = 60
      enabled                     = true
      geo_locations               = ["us-tx-sn1-azr", "us-il-ch1-azr"]
    }
  }
 }
//************************************************************************************************************************
```

=======
<!-- BEGIN_TF_DOCS -->

# Azure Purview

Microsoft Purview is a unified data governance service that helps you manage and govern your on-premises, multi-cloud, and software-as-a-service (SaaS) data. Microsoft Purview allows you to:

Create a holistic, up-to-date map of your data landscape with automated data discovery, sensitive data classification, and end-to-end data lineage.
Enable data curators to manage and secure your data estate.
Empower data consumers to find valuable, trustworthy data.

For more information, please visit:  https://docs.microsoft.com/en-us/azure/purview/overview



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_purview_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_purview_account_queue_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_purview_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_purview_eventhub_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_purview_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_purview_blob_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_purview_portal_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_purview_queue_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_purview_servicebus_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_purview_account.cl_purview_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/purview_account) | resource |
| [azurerm_resource_group.cl_purview_account_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_purview_account_allowed_pe_subnet_ids"></a> [cl\_purview\_account\_allowed\_pe\_subnet\_ids](#input\_cl\_purview\_account\_allowed\_pe\_subnet\_ids) | (Opional) One or more Subnet ID's which should be able to access through a private endpoint to this purview Account. | `list(string)` | `[]` | no |
| <a name="input_cl_purview_account_deploy_rg"></a> [cl\_purview\_account\_deploy\_rg](#input\_cl\_purview\_account\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the purview Account. | `bool` | `true` | no |
| <a name="input_cl_purview_account_identity_type"></a> [cl\_purview\_account\_identity\_type](#input\_cl\_purview\_account\_identity\_type) | (Optional) Specifies the identity type of the purview account. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_purview_account_postfix"></a> [cl\_purview\_account\_postfix](#input\_cl\_purview\_account\_postfix) | (Required) The postfix value for purview account you are deploying. | `any` | n/a | yes |
| <a name="input_cl_purview_account_private_dns_zone_ids"></a> [cl\_purview\_account\_private\_dns\_zone\_ids](#input\_cl\_purview\_account\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_purview_account_resource_group_name"></a> [cl\_purview\_account\_resource\_group\_name](#input\_cl\_purview\_account\_resource\_group\_name) | (Required) The resource group for purview accoount and private end points. Not required if cl\_purview\_account\_deploy\_rg = true | `any` | `null` | no |
| <a name="input_cl_purview_blob_private_dns_zone_ids"></a> [cl\_purview\_blob\_private\_dns\_zone\_ids](#input\_cl\_purview\_blob\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_purview_diagnostics"></a> [cl\_purview\_diagnostics](#input\_cl\_purview\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ScanStatusLogEvent",<br>    "DataSensitivityLogEvent",<br>    "Security"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_purview_eventhub_diagnostics"></a> [cl\_purview\_eventhub\_diagnostics](#input\_cl\_purview\_eventhub\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ArchiveLogs",<br>    "OperationalLogs",<br>    "AutoScaleLogs",<br>    "KafkaCoordinatorLogs",<br>    "KafkaUserErrorLogs",<br>    "EventHubVNetConnectionEvent",<br>    "CustomerManagedKeyUserLogs",<br>    "RuntimeAuditLogs",<br>    "ApplicationMetricsLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_purview_log_analytics_workspace_id"></a> [cl\_purview\_log\_analytics\_workspace\_id](#input\_cl\_purview\_log\_analytics\_workspace\_id) | (Required) The log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_purview_managed_resource_group_name"></a> [cl\_purview\_managed\_resource\_group\_name](#input\_cl\_purview\_managed\_resource\_group\_name) | (Required) The name which should be used for the new Resource Group where Purview Account creates the managed resources. Changing this forces a new Purview Account to be created. | `any` | n/a | yes |
| <a name="input_cl_purview_portal_private_dns_zone_ids"></a> [cl\_purview\_portal\_private\_dns\_zone\_ids](#input\_cl\_purview\_portal\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_purview_public_network_enabled"></a> [cl\_purview\_public\_network\_enabled](#input\_cl\_purview\_public\_network\_enabled) | (Optional) Should the Purview Account be visible to the public network | `bool` | `false` | no |
| <a name="input_cl_purview_queue_private_dns_zone_ids"></a> [cl\_purview\_queue\_private\_dns\_zone\_ids](#input\_cl\_purview\_queue\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_purview_servicebus_private_dns_zone_ids"></a> [cl\_purview\_servicebus\_private\_dns\_zone\_ids](#input\_cl\_purview\_servicebus\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_purview_storage_account_diagnostics"></a> [cl\_purview\_storage\_account\_diagnostics](#input\_cl\_purview\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "StorageRead",<br>    "StorageWrite",<br>    "StorageDelete"<br>  ],<br>  "metrics": [<br>    "Transaction"<br>  ]<br>}</pre> | no |
| <a name="input_cl_purview_storage_account_diagnostics_queues"></a> [cl\_purview\_storage\_account\_diagnostics\_queues](#input\_cl\_purview\_storage\_account\_diagnostics\_queues) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "StorageRead",<br>    "StorageWrite",<br>    "StorageDelete"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h" 
  cl_purview_account_resource_group_name      = var.cl_purview_account_deploy_rg ? azurerm_resource_group.cl_purview_account_rg[0].name : var.cl_purview_account_resource_group_name 
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_purview_account"></a> [cl\_purview\_account](#output\_cl\_purview\_account) | Outputs ********************************************************************************************** |
| <a name="output_cl_purview_event_hub_namespace_id"></a> [cl\_purview\_event\_hub\_namespace\_id](#output\_cl\_purview\_event\_hub\_namespace\_id) | n/a |
| <a name="output_cl_purview_managed_resources"></a> [cl\_purview\_managed\_resources](#output\_cl\_purview\_managed\_resources) | n/a |
| <a name="output_cl_purview_storage_account_id"></a> [cl\_purview\_storage\_account\_id](#output\_cl\_purview\_storage\_account\_id) | n/a |

## Usage

```terraform
// Azure Purview
//**********************************************************************************************
module "cl_azure_purview" {
  source                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_purview"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  cl_purview_account_postfix                  = var.cl_purview_account_postfix
  cl_purview_account_deploy_rg                = var.cl_purview_account_deploy_rg
  cl_purview_account_resource_group_name      = var.cl_purview_account_resource_group_name
  cl_purview_managed_resource_group_name      = var.cl_purview_managed_resource_group_name
  cl_purview_public_network_enabled           = var.cl_purview_public_network_enabled
  cl_purview_account_allowed_pe_subnet_ids    = var.cl_purview_account_allowed_pe_subnet_ids
  cl_purview_account_private_dns_zone_ids     = var.cl_purview_account_private_dns_zone_ids
  cl_purview_portal_private_dns_zone_ids      = var.cl_purview_portal_private_dns_zone_ids
  cl_purview_blob_private_dns_zone_ids        = var.cl_purview_blob_private_dns_zone_ids
  cl_purview_queue_private_dns_zone_ids       = var.cl_purview_queue_private_dns_zone_ids
  cl_purview_servicebus_private_dns_zone_ids  = var.cl_purview_servicebus_private_dns_zone_ids
  cl_purview_log_analytics_workspace_id       = var.cl_purview_log_analytics_workspace_id  
}
//**********************************************************************************************
<!-- END_TF_DOCS -->

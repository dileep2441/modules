# Azure Purview

Microsoft Purview is a unified data governance service that helps you manage and govern your on-premises, multi-cloud, and software-as-a-service (SaaS) data. Microsoft Purview allows you to:

Create a holistic, up-to-date map of your data landscape with automated data discovery, sensitive data classification, and end-to-end data lineage.
Enable data curators to manage and secure your data estate.
Empower data consumers to find valuable, trustworthy data.

For more information, please visit:  https://docs.microsoft.com/en-us/azure/purview/overview
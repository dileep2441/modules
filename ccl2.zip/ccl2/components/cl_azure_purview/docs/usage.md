## Usage

```terraform
// Azure Purview
//**********************************************************************************************
module "cl_azure_purview" {
  source                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_purview"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  cl_purview_account_postfix                  = var.cl_purview_account_postfix
  cl_purview_account_deploy_rg                = var.cl_purview_account_deploy_rg
  cl_purview_account_resource_group_name      = var.cl_purview_account_resource_group_name
  cl_purview_managed_resource_group_name      = var.cl_purview_managed_resource_group_name
  cl_purview_public_network_enabled           = var.cl_purview_public_network_enabled
  cl_purview_account_allowed_pe_subnet_ids    = var.cl_purview_account_allowed_pe_subnet_ids
  cl_purview_account_private_dns_zone_ids     = var.cl_purview_account_private_dns_zone_ids
  cl_purview_portal_private_dns_zone_ids      = var.cl_purview_portal_private_dns_zone_ids
  cl_purview_blob_private_dns_zone_ids        = var.cl_purview_blob_private_dns_zone_ids
  cl_purview_queue_private_dns_zone_ids       = var.cl_purview_queue_private_dns_zone_ids
  cl_purview_servicebus_private_dns_zone_ids  = var.cl_purview_servicebus_private_dns_zone_ids
  cl_purview_log_analytics_workspace_id       = var.cl_purview_log_analytics_workspace_id  
}
//**********************************************************************************************

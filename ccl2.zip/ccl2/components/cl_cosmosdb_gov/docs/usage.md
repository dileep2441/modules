

## Usage

```terraform
resource "azurerm_private_dns_zone" "cosmosdb_private_dns_zone" {
  name                = "privatelink.mongo.cosmos.azure.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "cosmosdb_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-cosmosdb-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  tags                  = var.tags
}

module "cl_cosmosdb" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_cosmosdb_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  suffix   = var.suffix
  tags                                         = var.tags
  cl_cosmosdb_resource_group_name         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name 
  cl_cosmosdb_log_analytics_workspace_id  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_cosmosdb_allowed_subnet = azurerm_subnet.test_subnet.id
  cl_cosmosdb_private_dns_zone_ids = [azurerm_private_dns_zone.cosmosdb_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "cosmosdb_private_dns_record" {
  name                = "${var.env}-${var.postfix}-cosmosdb-pe-record"
  zone_name           = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ttl                 = var.cosmosdb_private_record_ttl
  records             = module.cl_cosmosdb.cl_cosmosdb_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                = var.tags
}
```
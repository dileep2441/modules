<!-- BEGIN_TF_DOCS -->

# Azure CosmosDB Component

Azure Cosmos DB is Microsoft’s fully managed, globally distributed and horizontally scalable cloud service. 
It’s a multi-model NoSQL database that provides independent scaling across all the Azure regions. It can support many use cases such as document, key value, relational, and graph models. 
This component will deploy Azure CosmosDB, a private endpoint and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/cosmos-db/introduction 



## Resources

| Name | Type |
|------|------|
| [azurerm_cosmosdb_account.cl_cosmosdb](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cosmosdb_account) | resource |
| [azurerm_monitor_diagnostic_setting.cl_cosmosdb_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_cosmosdb_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_cosmosdb_allowed_ips"></a> [cl\_cosmosdb\_allowed\_ips](#input\_cl\_cosmosdb\_allowed\_ips) | (Optional) The list of ips allowed to connect to your CosmosDB database over the internet. | `string` | `""` | no |
| <a name="input_cl_cosmosdb_allowed_subnet"></a> [cl\_cosmosdb\_allowed\_subnet](#input\_cl\_cosmosdb\_allowed\_subnet) | (Optional) The subnet id allowed to connect to this CosmosDB instance. | `string` | `""` | no |
| <a name="input_cl_cosmosdb_capabilities"></a> [cl\_cosmosdb\_capabilities](#input\_cl\_cosmosdb\_capabilities) | (Optional) The capabilities which should be enabled for Cosmos DB account. | `list(string)` | <pre>[<br>  "EnableMongo"<br>]</pre> | no |
| <a name="input_cl_cosmosdb_consistency_max_interval"></a> [cl\_cosmosdb\_consistency\_max\_interval](#input\_cl\_cosmosdb\_consistency\_max\_interval) | (Optional) A mapping of random\_integer value to assign to all resources. | `number` | `350` | no |
| <a name="input_cl_cosmosdb_consistency_max_staleness_prefix"></a> [cl\_cosmosdb\_consistency\_max\_staleness\_prefix](#input\_cl\_cosmosdb\_consistency\_max\_staleness\_prefix) | (Optional) A mapping of random\_integer value to assign to all resources. | `number` | `200000` | no |
| <a name="input_cl_cosmosdb_consistency_policy_level"></a> [cl\_cosmosdb\_consistency\_policy\_level](#input\_cl\_cosmosdb\_consistency\_policy\_level) | (Required) Consistency\_policy\_level will be deployed into. | `string` | `"BoundedStaleness"` | no |
| <a name="input_cl_cosmosdb_diagnostic"></a> [cl\_cosmosdb\_diagnostic](#input\_cl\_cosmosdb\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "CassandraRequests",<br>    "DataPlaneRequests",<br>    "GremlinRequests",<br>    "MongoRequests",<br>    "QueryRuntimeStatistics",<br>    "PartitionKeyStatistics",<br>    "PartitionKeyRUConsumption",<br>    "ControlPlaneRequests"<br>  ],<br>  "metrics": [<br>    "Requests"<br>  ]<br>}</pre> | no |
| <a name="input_cl_cosmosdb_enable_multiple_write_locations"></a> [cl\_cosmosdb\_enable\_multiple\_write\_locations](#input\_cl\_cosmosdb\_enable\_multiple\_write\_locations) | (Optional) Enable multi-master support for this CosmosDB account | `bool` | `false` | no |
| <a name="input_cl_cosmosdb_failover_location"></a> [cl\_cosmosdb\_failover\_location](#input\_cl\_cosmosdb\_failover\_location) | (Required) The cloud region where resources will be deployed into. | `string` | `"usgovtexas"` | no |
| <a name="input_cl_cosmosdb_kind"></a> [cl\_cosmosdb\_kind](#input\_cl\_cosmosdb\_kind) | (Required) The cloud region where resources will be deployed into. | `string` | `"MongoDB"` | no |
| <a name="input_cl_cosmosdb_log_analytics_workspace_id"></a> [cl\_cosmosdb\_log\_analytics\_workspace\_id](#input\_cl\_cosmosdb\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_cosmosdb_offer_type"></a> [cl\_cosmosdb\_offer\_type](#input\_cl\_cosmosdb\_offer\_type) | (Required) The cloud region where resources will be deployed into. | `string` | `"Standard"` | no |
| <a name="input_cl_cosmosdb_private_dns_zone_ids"></a> [cl\_cosmosdb\_private\_dns\_zone\_ids](#input\_cl\_cosmosdb\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_cosmosdb_resource_group_name"></a> [cl\_cosmosdb\_resource\_group\_name](#input\_cl\_cosmosdb\_resource\_group\_name) | (Required) The name of the resource group where the cosmos db will be deployed to. | `any` | n/a | yes |
| <a name="input_cl_cosmosdb_virtual_network_filter_enabled"></a> [cl\_cosmosdb\_virtual\_network\_filter\_enabled](#input\_cl\_cosmosdb\_virtual\_network\_filter\_enabled) | (Optional) Enable/Disable network filtering | `bool` | `true` | no |
| <a name="input_cl_cosmosdb_zone_redundant"></a> [cl\_cosmosdb\_zone\_redundant](#input\_cl\_cosmosdb\_zone\_redundant) | (Optional) Should zone redundancy be enabled for this region? | `bool` | `false` | no |
| <a name="input_cl_private_endpoint_subresource_names"></a> [cl\_private\_endpoint\_subresource\_names](#input\_cl\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint | `list(string)` | <pre>[<br>  "MongoDB"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_cosmosdb"></a> [cl\_cosmosdb](#output\_cl\_cosmosdb) | Outputs ********************************************************************************************** |
| <a name="output_cl_cosmosdb_diagnostic_setting"></a> [cl\_cosmosdb\_diagnostic\_setting](#output\_cl\_cosmosdb\_diagnostic\_setting) | n/a |
| <a name="output_cl_cosmosdb_private_endpoint"></a> [cl\_cosmosdb\_private\_endpoint](#output\_cl\_cosmosdb\_private\_endpoint) | n/a |



## Usage

```terraform
resource "azurerm_private_dns_zone" "cosmosdb_private_dns_zone" {
  name                = "privatelink.mongo.cosmos.azure.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "cosmosdb_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-cosmosdb-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  tags                  = var.tags
}

module "cl_cosmosdb" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_cosmosdb_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  suffix   = var.suffix
  tags                                         = var.tags
  cl_cosmosdb_resource_group_name         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name 
  cl_cosmosdb_log_analytics_workspace_id  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_cosmosdb_allowed_subnet = azurerm_subnet.test_subnet.id
  cl_cosmosdb_private_dns_zone_ids = [azurerm_private_dns_zone.cosmosdb_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "cosmosdb_private_dns_record" {
  name                = "${var.env}-${var.postfix}-cosmosdb-pe-record"
  zone_name           = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ttl                 = var.cosmosdb_private_record_ttl
  records             = module.cl_cosmosdb.cl_cosmosdb_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                = var.tags
}
```
<!-- END_TF_DOCS -->
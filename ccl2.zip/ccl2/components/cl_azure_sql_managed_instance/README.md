<!-- BEGIN_TF_DOCS -->

# Azure SQL Managed Instance Component

Azure SQL Managed Instance is the intelligent, scalable cloud database service that combines the broadest SQL Server database engine compatibility with all the benefits of a fully managed and evergreen platform as a service. SQL Managed Instance has near 100% compatibility with the latest SQL Server (Enterprise Edition) database engine, providing a native virtual network (VNet) implementation that addresses common security concerns, and a business model favorable for existing SQL Server customers. SQL Managed Instance allows existing SQL Server customers to lift and shift their on-premises applications to the cloud with minimal application and database changes. At the same time, SQL Managed Instance preserves all PaaS capabilities (automatic patching and version updates, automated backups, high availability) that drastically reduce management overhead and TCO.

For more information, please visit: 
docs.microsoft.com/en-us/azure/azure-sql/managed-instance/sql-managed-instance-paas-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_azure_sql_mananged_instance_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_mssql_managed_instance.cl_azure_sql_mananged_instance](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_managed_instance) | resource |
| [azurerm_network_security_group.cl_azure_sql_mananged_instance_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_azure_sql_mananged_instance_allow_geodr_inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_sql_mananged_instance_allow_geodr_outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_sql_mananged_instance_allow_privatelink_outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_sql_mananged_instance_allow_redirect_inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_sql_mananged_instance_allow_redirect_outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_sql_mananged_instance_allow_tds_inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_sql_mananged_instance_allow_tds_outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_private_endpoint.cl_azure_sql_mananged_instance_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.cl_azure_sql_managed_instance_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.cl_azure_sql_mananged_instance_core_default_internet_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.cl_azure_sql_mananged_instance_core_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_subnet.cl_azure_sql_mananged_instance_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_azure_sql_mananged_instance_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.cl_azure_sql_mananged_instance_route_table_associate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_sql_deploy_rg"></a> [cl\_azure\_sql\_deploy\_rg](#input\_cl\_azure\_sql\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the SQL. | `bool` | `true` | no |
| <a name="input_cl_azure_sql_managed_instance_administrator"></a> [cl\_azure\_sql\_managed\_instance\_administrator](#input\_cl\_azure\_sql\_managed\_instance\_administrator) | (Required) The administrator login name for the new server. Changing this forces a new resource to be created | `any` | n/a | yes |
| <a name="input_cl_azure_sql_managed_instance_collation"></a> [cl\_azure\_sql\_managed\_instance\_collation](#input\_cl\_azure\_sql\_managed\_instance\_collation) | (Optional) Specifies how the SQL Managed Instance will be collated. Default value is SQL\_Latin1\_General\_CP1\_CI\_AS. Changing this forces a new resource to be created | `string` | `"SQL_Latin1_General_CP1_CI_AS"` | no |
| <a name="input_cl_azure_sql_managed_instance_minimum_tls_version"></a> [cl\_azure\_sql\_managed\_instance\_minimum\_tls\_version](#input\_cl\_azure\_sql\_managed\_instance\_minimum\_tls\_version) | (Optional) The Minimum TLS Version. Default value is 1.2 Valid values include 1.0, 1.1, 1.2 | `string` | `"1.2"` | no |
| <a name="input_cl_azure_sql_managed_instance_password"></a> [cl\_azure\_sql\_managed\_instance\_password](#input\_cl\_azure\_sql\_managed\_instance\_password) | (Required) The password associated with the cl\_azure\_sql\_managed\_instance\_administrator user. Needs to comply with Azure's Password Policy | `any` | n/a | yes |
| <a name="input_cl_azure_sql_managed_instance_proxy_override"></a> [cl\_azure\_sql\_managed\_instance\_proxy\_override](#input\_cl\_azure\_sql\_managed\_instance\_proxy\_override) | (Optional) Specifies how the SQL Managed Instance will be accessed. Default value is Default. Valid values include Default, Proxy, and Redirect. | `string` | `"Default"` | no |
| <a name="input_cl_azure_sql_managed_instance_public_data_endpoint_enabled"></a> [cl\_azure\_sql\_managed\_instance\_public\_data\_endpoint\_enabled](#input\_cl\_azure\_sql\_managed\_instance\_public\_data\_endpoint\_enabled) | (Optional) Is the public data endpoint enabled? Default value is false | `bool` | `false` | no |
| <a name="input_cl_azure_sql_managed_instance_rg"></a> [cl\_azure\_sql\_managed\_instance\_rg](#input\_cl\_azure\_sql\_managed\_instance\_rg) | (Required) The name of the resource group in which to create the SQL Server | `string` | `""` | no |
| <a name="input_cl_azure_sql_managed_instance_sku"></a> [cl\_azure\_sql\_managed\_instance\_sku](#input\_cl\_azure\_sql\_managed\_instance\_sku) | (Required) Specifies the SKU Name for the SQL Managed Instance. Valid values include GP\_Gen4, GP\_Gen5, BC\_Gen4, BC\_Gen5 | `string` | `"GP_Gen5"` | no |
| <a name="input_cl_azure_sql_managed_instance_storage_account_type"></a> [cl\_azure\_sql\_managed\_instance\_storage\_account\_type](#input\_cl\_azure\_sql\_managed\_instance\_storage\_account\_type) | (Optional) Specifies the storage account type used to store backups for this database. Changing this forces a new resource to be created. Possible values are GRS, LRS and ZRS. The default value is GRS. | `string` | `"LRS"` | no |
| <a name="input_cl_azure_sql_managed_instance_storage_license_type"></a> [cl\_azure\_sql\_managed\_instance\_storage\_license\_type](#input\_cl\_azure\_sql\_managed\_instance\_storage\_license\_type) | (Required) What type of license the Managed Instance will use. Valid values include can be LicenseIncluded or BasePrice | `string` | `"BasePrice"` | no |
| <a name="input_cl_azure_sql_managed_instance_storage_size"></a> [cl\_azure\_sql\_managed\_instance\_storage\_size](#input\_cl\_azure\_sql\_managed\_instance\_storage\_size) | (Required) Maximum storage space for your instance. It should be a multiple of 32GB | `number` | `32` | no |
| <a name="input_cl_azure_sql_managed_instance_timezone_id"></a> [cl\_azure\_sql\_managed\_instance\_timezone\_id](#input\_cl\_azure\_sql\_managed\_instance\_timezone\_id) | (Optional) The TimeZone ID that the SQL Managed Instance will be operating in. Default value is UTC. Changing this forces a new resource to be created. | `string` | `"UTC"` | no |
| <a name="input_cl_azure_sql_managed_instance_vcores"></a> [cl\_azure\_sql\_managed\_instance\_vcores](#input\_cl\_azure\_sql\_managed\_instance\_vcores) | (Required) Number of cores that should be assigned to your instance. Values can be 8, 16, or 24 if sku\_name is GP\_Gen4, or 8, 16, 24, 32, or 40 if sku\_name is GP\_Gen5 | `number` | `4` | no |
| <a name="input_cl_azure_sql_mananged_deploy_subnet"></a> [cl\_azure\_sql\_mananged\_deploy\_subnet](#input\_cl\_azure\_sql\_mananged\_deploy\_subnet) | (Optional) A boolean to enable/disable the deployment of a subnet for the SQL managed instance. | `bool` | `true` | no |
| <a name="input_cl_azure_sql_mananged_instance_delegation_name"></a> [cl\_azure\_sql\_mananged\_instance\_delegation\_name](#input\_cl\_azure\_sql\_mananged\_instance\_delegation\_name) | (Optional) name for the subnet delegation | `string` | `"managedinstancedelegation"` | no |
| <a name="input_cl_azure_sql_mananged_instance_deploy_pe"></a> [cl\_azure\_sql\_mananged\_instance\_deploy\_pe](#input\_cl\_azure\_sql\_mananged\_instance\_deploy\_pe) | (Required) Specify whether to deploy Private end point or not not | `bool` | `false` | no |
| <a name="input_cl_azure_sql_mananged_instance_deploy_subnet_nsg"></a> [cl\_azure\_sql\_mananged\_instance\_deploy\_subnet\_nsg](#input\_cl\_azure\_sql\_mananged\_instance\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG | `bool` | `true` | no |
| <a name="input_cl_azure_sql_mananged_instance_deploy_subnet_routetable"></a> [cl\_azure\_sql\_mananged\_instance\_deploy\_subnet\_routetable](#input\_cl\_azure\_sql\_mananged\_instance\_deploy\_subnet\_routetable) | (Optional) A boolean to enable/disable the deployment of a subnet route table | `bool` | `true` | no |
| <a name="input_cl_azure_sql_mananged_instance_diagnostics"></a> [cl\_azure\_sql\_mananged\_instance\_diagnostics](#input\_cl\_azure\_sql\_mananged\_instance\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "SQLSecurityAuditEvents",<br>    "ResourceUsageStats",<br>    "DevOpsOperationsAudit"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_sql_mananged_instance_next_hop_type"></a> [cl\_azure\_sql\_mananged\_instance\_next\_hop\_type](#input\_cl\_azure\_sql\_mananged\_instance\_next\_hop\_type) | (Optional) Next hop type for subnet route table | `string` | `"Internet"` | no |
| <a name="input_cl_azure_sql_mananged_instance_private_dns_zone_ids"></a> [cl\_azure\_sql\_mananged\_instance\_private\_dns\_zone\_ids](#input\_cl\_azure\_sql\_mananged\_instance\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_mananged_instance_service_actions"></a> [cl\_azure\_sql\_mananged\_instance\_service\_actions](#input\_cl\_azure\_sql\_mananged\_instance\_service\_actions) | (Optional) name for the subnet delegation service | `list` | <pre>[<br>  "Microsoft.Network/virtualNetworks/subnets/join/action",<br>  "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",<br>  "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"<br>]</pre> | no |
| <a name="input_cl_azure_sql_mananged_instance_service_delegation_name"></a> [cl\_azure\_sql\_mananged\_instance\_service\_delegation\_name](#input\_cl\_azure\_sql\_mananged\_instance\_service\_delegation\_name) | (Optional) name for the subnet delegation service | `string` | `"Microsoft.Sql/managedInstances"` | no |
| <a name="input_cl_azure_sql_mananged_instance_subnet_address_prefix"></a> [cl\_azure\_sql\_mananged\_instance\_subnet\_address\_prefix](#input\_cl\_azure\_sql\_mananged\_instance\_subnet\_address\_prefix) | (Optional) The prefix of the sql managed instance existing subnet with address prefix for network rules | `any` | `null` | no |
| <a name="input_cl_azure_sql_mananged_instance_subnet_id"></a> [cl\_azure\_sql\_mananged\_instance\_subnet\_id](#input\_cl\_azure\_sql\_mananged\_instance\_subnet\_id) | (Optional) The subnet ID where the Sql MI will be deployed to. Use this only if cl\_azure\_sql\_mananged\_instance\_subnet\_id = false. | `any` | `null` | no |
| <a name="input_cl_azure_sql_mananged_instance_subnet_prefix"></a> [cl\_azure\_sql\_mananged\_instance\_subnet\_prefix](#input\_cl\_azure\_sql\_mananged\_instance\_subnet\_prefix) | (Optional) The prefix of the sql managed instance subnet with address prefix 0.0.0.0/27 & Only one instance per subnet is recommended | `any` | `null` | no |
| <a name="input_cl_azure_sql_mananged_instance_subnet_service_enpoints"></a> [cl\_azure\_sql\_mananged\_instance\_subnet\_service\_enpoints](#input\_cl\_azure\_sql\_mananged\_instance\_subnet\_service\_enpoints) | (Optional) specify the subnet service endpoints to open. | `list(string)` | <pre>[<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault",<br>  "Microsoft.AzureActiveDirectory"<br>]</pre> | no |
| <a name="input_cl_azure_sql_mananged_instance_vnet_name"></a> [cl\_azure\_sql\_mananged\_instance\_vnet\_name](#input\_cl\_azure\_sql\_mananged\_instance\_vnet\_name) | (Required) The name of the core vnet required for the sql managed instance subnet. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_mananged_instance_vnet_rg_name"></a> [cl\_azure\_sql\_mananged\_instance\_vnet\_rg\_name](#input\_cl\_azure\_sql\_mananged\_instance\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in | `any` | n/a | yes |
| <a name="input_cl_azure_sql_mananged_instance_workspace_id"></a> [cl\_azure\_sql\_mananged\_instance\_workspace\_id](#input\_cl\_azure\_sql\_mananged\_instance\_workspace\_id) | (Required) The log analytics workspace ID for diagnostics | `any` | n/a | yes |
| <a name="input_cl_azure_sql_mananged_private_endpoint_subnet"></a> [cl\_azure\_sql\_mananged\_private\_endpoint\_subnet](#input\_cl\_azure\_sql\_mananged\_private\_endpoint\_subnet) | (Optional) Specifies the list of subnets for private endpint | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_postfix"></a> [cl\_azure\_sql\_server\_postfix](#input\_cl\_azure\_sql\_server\_postfix) | (Required) The posftfix for sql servr. Part of the naming scheme. | `string` | `"global"` | no |
| <a name="input_core_route_table_bgp_propagation"></a> [core\_route\_table\_bgp\_propagation](#input\_core\_route\_table\_bgp\_propagation) | (Optional) A boolean variable indicating if the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `true` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_manual_connection"></a> [manual\_connection](#input\_manual\_connection) | (Required) Does the Private Endpoint require Manual Approval from the remote resource owner? Changing this forces a new resource to be created. | `bool` | `false` | no |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_subresource_names"></a> [subresource\_names](#input\_subresource\_names) | (Optional) A list of subresource names which the Private Endpoint is able to connect to. subresource\_names corresponds to group\_id | `list(string)` | <pre>[<br>  "managedInstance"<br>]</pre> | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration                      = "2h"
  cl_azure_sql_managed_instance_rg      = var.cl_azure_sql_deploy_rg ? azurerm_resource_group.cl_azure_sql_managed_instance_rg[0].name : var.cl_azure_sql_managed_instance_rg
  cl_azure_sql_mananged_instance_nsg    = var.cl_azure_sql_mananged_instance_deploy_subnet_nsg ? azurerm_network_security_group.cl_azure_sql_mananged_instance_nsg[0] : null
  cl_azure_sql_mananged_instance_subnet = var.cl_azure_sql_mananged_deploy_subnet ? azurerm_subnet.cl_azure_sql_mananged_instance_subnet[0] : var.cl_azure_sql_mananged_instance_subnet_id
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_sql_managed_instance_rg"></a> [cl\_azure\_sql\_managed\_instance\_rg](#output\_cl\_azure\_sql\_managed\_instance\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_sql_mananged_instance_administrator_login"></a> [cl\_azure\_sql\_mananged\_instance\_administrator\_login](#output\_cl\_azure\_sql\_mananged\_instance\_administrator\_login) | n/a |
| <a name="output_cl_azure_sql_mananged_instance_fqdn"></a> [cl\_azure\_sql\_mananged\_instance\_fqdn](#output\_cl\_azure\_sql\_mananged\_instance\_fqdn) | n/a |
| <a name="output_cl_azure_sql_mananged_instance_id"></a> [cl\_azure\_sql\_mananged\_instance\_id](#output\_cl\_azure\_sql\_mananged\_instance\_id) | n/a |
| <a name="output_cl_azure_sql_mananged_instance_identity"></a> [cl\_azure\_sql\_mananged\_instance\_identity](#output\_cl\_azure\_sql\_mananged\_instance\_identity) | n/a |
| <a name="output_cl_azure_sql_mananged_instance_name"></a> [cl\_azure\_sql\_mananged\_instance\_name](#output\_cl\_azure\_sql\_mananged\_instance\_name) | n/a |
| <a name="output_cl_azure_sql_mananged_instance_nsg"></a> [cl\_azure\_sql\_mananged\_instance\_nsg](#output\_cl\_azure\_sql\_mananged\_instance\_nsg) | n/a |
| <a name="output_cl_azure_sql_mananged_instance_subnet"></a> [cl\_azure\_sql\_mananged\_instance\_subnet](#output\_cl\_azure\_sql\_mananged\_instance\_subnet) | n/a |

## Usage

### Deploy single SQL Managed Instance component
```terraform
module "cl_azure_sql_mananged_instance" {
  source                                  = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_managed_instance"
  env                                                     = var.env
  postfix                                                 = var.postfix
  location                                                = var.location
  cl_azure_sql_managed_instance_sku                       = var.cl_azure_sql_managed_instance_sku
  cl_azure_sql_managed_instance_vcores                    = var.cl_azure_sql_managed_instance_vcores
  cl_azure_sql_managed_instance_storage_size              = var.cl_azure_sql_managed_instance_storage_size
  cl_azure_sql_managed_instance_storage_license_type      = var.cl_azure_sql_managed_instance_storage_license_type
  cl_azure_sql_mananged_instance_vnet_rg_name             = var.cl_azure_sql_managed_instance_vnet_rg_name
  cl_azure_sql_mananged_instance_vnet_name                = var.cl_azure_sql_managed_instance_vnet_name
  cl_azure_sql_mananged_instance_subnet_prefix            = var.cl_azure_sql_managed_instance_subnet_prefix
  cl_azure_sql_managed_instance_administrator             = var.cl_azure_sql_managed_instance_administrator
  cl_azure_sql_managed_instance_password                  = var.cl_azure_sql_managed_instance_password
  cl_azure_sql_deploy_rg                                  = true
  cl_azure_sql_mananged_deploy_subnet                     = true
  cl_azure_sql_mananged_instance_deploy_subnet_nsg        = true
  cl_azure_sql_mananged_instance_deploy_subnet_routetable = true
  cl_azure_sql_mananged_instance_workspace_id             = var.cl_azure_sql_mananged_instance_workspace_id
}
```
//**********************************************************************************************


<!-- END_TF_DOCS -->

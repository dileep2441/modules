## Local values

```terraform
locals {
  timeout_duration                      = "2h"
  cl_azure_sql_managed_instance_rg      = var.cl_azure_sql_deploy_rg ? azurerm_resource_group.cl_azure_sql_managed_instance_rg[0].name : var.cl_azure_sql_managed_instance_rg
  cl_azure_sql_mananged_instance_nsg    = var.cl_azure_sql_mananged_instance_deploy_subnet_nsg ? azurerm_network_security_group.cl_azure_sql_mananged_instance_nsg[0] : null
  cl_azure_sql_mananged_instance_subnet = var.cl_azure_sql_mananged_deploy_subnet ? azurerm_subnet.cl_azure_sql_mananged_instance_subnet[0] : var.cl_azure_sql_mananged_instance_subnet_id
}
```
## Usage Azure Search Service with Private endpoint

```terraform
//********************************************************************************************
//Create a Azure Search Service
//********************************************************************************************

module "cl_search_service" {
   source                                                 = "../tf-azure-component-library/components/cl_search_service"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_search_service_postfix                              = "srchvang"
   cl_search_service_deploy_rg                            = true
   cl_search_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_search_service_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_search_service_nacl_allowed_subnets                 = [data.terraform_remote_state.core.outputs.core_latam_island.core_private_link_subnet.id]
   cl_search_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.srch_private_dns_zone.id]
   tags                                                   = var.tags
}

resource "azurerm_private_dns_zone" "srch_private_dns_zone" {
  name                = "privatelink.search.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "srch_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-srch-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.srch_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************


## Usage Azure Search Service with Private endpoint and Shared Private Links

```terraform
//********************************************************************************************
//Create a Azure Search Service
//********************************************************************************************

module "cl_search_service" {
  source                                                 = "../tf-azure-component-library/components/cl_search_service"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  cl_search_service_postfix                              = "srchvang"
  cl_search_service_deploy_rg                            = false
  cl_search_service_rg_name                              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_search_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_search_service_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_search_service_nacl_allowed_subnets                 = [data.terraform_remote_state.core.outputs.core_latam_island.core_private_link_subnet.id]
  cl_search_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.srch_private_dns_zone.id]
  cl_search_service_deploy_shared_private_link           = true
  cl_search_service_shared_private_link = {
    shared_private_link_sa = {
     name                         = "shared-private-link-sa"
     subresource_name             = "blob"
     target_resource_id           = "##Storage account resource ID##"
    }
    shared_private_link_kv = {
     name                         = "shared-private-link-kv"
     subresource_name             = "vault"
     target_resource_id           = "##Key vault resource ID##"
    }
  }
  tags                                                   = var.tags
}

resource "azurerm_private_dns_zone" "srch_private_dns_zone" {
  name                = "privatelink.search.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "srch_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-srch-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.srch_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************
<!-- BEGIN_TF_DOCS -->

# Azure Shared Services LATAM CH Platform in a Box Module
Shared Services subscription has the consolidation of the Azure services and resources that are used by multiple Spoke subscriptions to perform their business needs. It helps the enterprise to have the central control over common services and security aspects, while maintaining segregation for the workloads in each spoke. Latam Country Hosting Platform is will deployed from slingshot tool.



## Resources

| Name | Type |
|------|------|
| [azurerm_availability_set.sharedsvs_bigfix_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvs_cribl_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvs_jumpbox_vm_avset](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvs_wsus_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_backup_protected_vm.cl_cribl_mstr_vm_protected_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_vm) | resource |
| [azurerm_backup_protected_vm.cl_cribl_wrk_vm_protected_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_vm) | resource |
| [azurerm_key_vault_secret.sharedsvs_bigfix_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_bigfix_vm_admin_pass_secret_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_bigfix_vm_admin_user_secret_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_bigfix_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_cribl_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_cribl_vm_admin_pass_secret_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_cribl_vm_admin_user_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_cribl_vm_admin_user_secret_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_jumpbox_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_jumpbox_vm_admin_user_secret_new_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_jumpbox_wvm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_jumpbox_wvm_admin_pass_secret_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_wsus_vm_admin_password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_wsus_vm_admin_password_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_wsus_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvs_wsus_vm_admin_user_secret_new_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_lb.sharedsvs_cribl_load_balancer_internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb) | resource |
| [azurerm_lb_backend_address_pool.sharedsvs_cribl_backend_addesspool_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_backend_address_pool) | resource |
| [azurerm_lb_probe.sharedsvs_cribl_infoblx_lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_probe.sharedsvs_cribl_poalo2_lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_probe.sharedsvs_cribl_poalo3_lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_rule.sharedsvs_lb_crible_infoblx_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvs_lb_crible_paolo1_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvs_lb_crible_paolo2_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvs_lb_crible_paolo3_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvs_lb_crible_strd1_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvs_lb_crible_strd2_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_monitor_data_collection_endpoint.log_analytics_data_collection_rule_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_data_collection_endpoint) | resource |
| [azurerm_monitor_data_collection_rule.log_analytics_data_collection_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_data_collection_rule) | resource |
| [azurerm_monitor_diagnostic_setting.sharedsvs_vnet_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_private_link_scope.log_analytics_private_link_scope](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scope) | resource |
| [azurerm_monitor_private_link_scoped_service.log_analytics_dcr_endpoint_link_scoped_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scoped_service) | resource |
| [azurerm_monitor_private_link_scoped_service.log_analytics_link_scoped_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scoped_service) | resource |
| [azurerm_monitor_private_link_scoped_service.log_analytics_sentinel_link_scoped_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scoped_service) | resource |
| [azurerm_network_interface.net_int_crible_mst_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface.net_int_crible_wrk_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_cribl_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_interface_security_group_association.core_windows_vm_dns_forwarder_nsg_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_interface_security_group_association.sharedsvs_jumpbox_vm_nsg_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_interface_security_group_association.sharedsvs_wsus_vm_nsg_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.sharedsvs_azure_image_builder_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.sharedsvs_windows_vm_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.sharedsvs_azure_image_builder_nsg_nsgrule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.sharedsvs_vm_azure_DC_Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.sharedsvs_vm_azure_bastion_nsgrule_22](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.sharedsvs_vm_azure_bastion_nsgrule_3389](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_private_dns_zone.sharedsvs_dns_zones](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.sharedsvs_dns_zones](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_endpoint.log_analytics_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.sharedsvs_bigfix_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_azure_image_builder](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_azure_qualys](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_cribl](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_image_gallery](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvs_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.sharedsvs_azure_acr_aksghshr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sharedsvs_azure_aksghshr_role_assigned_contributor](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sharedsvs_azure_aksghshr_role_assigned_mi_operator](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sharedsvs_azure_dns_aksghshr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sharedsvs_azure_dns_aksghshrdr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sharedsvs_azure_keyvault_aksghshr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sharedsvs_azure_keyvault_spn_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_route.sharedsvs_route_table_SS_to_IHub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route.sharedsvs_route_table_SS_to_colombia](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.sharedsvs_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_security_center_auto_provisioning.sharedsvs_security_center_auto_provisioning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_auto_provisioning) | resource |
| [azurerm_security_center_contact.sharedsvs_security_center_contact_info](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_contact) | resource |
| [azurerm_security_center_setting.sharedsvs_security_center_wdatp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_setting) | resource |
| [azurerm_security_center_subscription_pricing.sharedsvs_security_center_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_shared_image_gallery.sharedsvs_shared_image_gallery](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/shared_image_gallery) | resource |
| [azurerm_storage_container.sharedsvs_postprov_sa_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_subnet.sharedsvs_azure_image_builder_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.sharedsvs_mgmt_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.sharedsvs_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.sharedsvs_azure_image_builder_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.sharedsvs_windows_vm_nsg_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.sharedsvs_windows_vm_route_table_associate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_user_assigned_identity.sharedsvs_ptrn_Kubernetes_user_assigned_identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azurerm_virtual_machine.virtual_machine_cribl_mstrs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_virtual_machine.virtual_machine_cribl_workers](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_virtual_machine_extension.sharedsvs_cribl_master_log_analytics_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.sharedsvs_cribl_worker_log_analytics_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_network.sharedsvs_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.peering-dr-ss-to-prod-ss](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-prod-ss-to-dr-ss](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvs-to-additional-ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvs-to-idty](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvs-to-ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [random_password.sharedsvs_bigfix_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvs_cribl_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvs_jumpbox_wvm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvs_wsus_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_acr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_aks](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_automation](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_monitor](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_ods](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_oms](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.sharedsvs_data_private_dns_zone_sa](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_availability_zones"></a> [availability\_zones](#input\_availability\_zones) | (Required) The llist of availability zones to be leveraged by cribl VMs | `list(string)` | <pre>[<br>  "1",<br>  "2",<br>  "3"<br>]</pre> | no |
| <a name="input_cl_azure_dns_resolver_additional_forwarding_rules_enable"></a> [cl\_azure\_dns\_resolver\_additional\_forwarding\_rules\_enable](#input\_cl\_azure\_dns\_resolver\_additional\_forwarding\_rules\_enable) | (Optional) set to true if more DNS forwarding rules are to be added | `bool` | `false` | no |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_additional_names"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_additional\_names](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_additional\_names) | (optional) Name of the  additional Private DNS Resolver Forwarding Rule. | `map(any)` | `{}` | no |
| <a name="input_cribl"></a> [cribl](#input\_cribl) | (Required) Details that will be used to create the Palo Alto Firewall | <pre>object({<br>    vm_size                 = string,<br>    vm_prefix               = string,<br>    vm_image_id             = string,<br>    vm_publisher            = string,<br>    vm_offer                = string,<br>    vm_sku                  = string,<br>    vm_version              = string,<br>    vm_storage_os_disk_size = string,<br>    vm_os                   = string,<br>    vm_from_marketplace     = string,<br>  })</pre> | n/a | yes |
| <a name="input_cribl_backend_addesspool_associations_names"></a> [cribl\_backend\_addesspool\_associations\_names](#input\_cribl\_backend\_addesspool\_associations\_names) | n/a | `list(string)` | `[]` | no |
| <a name="input_cribl_master_names"></a> [cribl\_master\_names](#input\_cribl\_master\_names) | n/a | `list(string)` | `[]` | no |
| <a name="input_cribl_worker_names"></a> [cribl\_worker\_names](#input\_cribl\_worker\_names) | n/a | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_ihub_additional_virtual_network_names"></a> [ihub\_additional\_virtual\_network\_names](#input\_ihub\_additional\_virtual\_network\_names) | n/a | `map(any)` | `{}` | no |
| <a name="input_ihub_internal_lb_private_ip_address"></a> [ihub\_internal\_lb\_private\_ip\_address](#input\_ihub\_internal\_lb\_private\_ip\_address) | n/a | `string` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_sharedsvs_azure_backup_deploy_rsv"></a> [sharedsvs\_azure\_backup\_deploy\_rsv](#input\_sharedsvs\_azure\_backup\_deploy\_rsv) | (Optional) If true, deploy rsv. | `bool` | `true` | no |
| <a name="input_sharedsvs_azure_backup_diagnostics"></a> [sharedsvs\_azure\_backup\_diagnostics](#input\_sharedsvs\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_sharedsvs_azure_backup_enable_blob_storage_backup"></a> [sharedsvs\_azure\_backup\_enable\_blob\_storage\_backup](#input\_sharedsvs\_azure\_backup\_enable\_blob\_storage\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `true` | no |
| <a name="input_sharedsvs_azure_backup_enable_file_storage_backup"></a> [sharedsvs\_azure\_backup\_enable\_file\_storage\_backup](#input\_sharedsvs\_azure\_backup\_enable\_file\_storage\_backup) | (Optional) Toggle the file storage backup feature. | `bool` | `true` | no |
| <a name="input_sharedsvs_azure_backup_enable_vm_backup"></a> [sharedsvs\_azure\_backup\_enable\_vm\_backup](#input\_sharedsvs\_azure\_backup\_enable\_vm\_backup) | (Optional) Toggle the vm backup feature. | `bool` | `true` | no |
| <a name="input_sharedsvs_azure_backup_retention_daily_count"></a> [sharedsvs\_azure\_backup\_retention\_daily\_count](#input\_sharedsvs\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_sharedsvs_azure_backup_time"></a> [sharedsvs\_azure\_backup\_time](#input\_sharedsvs\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_sharedsvs_azure_backup_timezone"></a> [sharedsvs\_azure\_backup\_timezone](#input\_sharedsvs\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_sharedsvs_azure_bastion_availability_zone"></a> [sharedsvs\_azure\_bastion\_availability\_zone](#input\_sharedsvs\_azure\_bastion\_availability\_zone) | (Optional) The availability zone to allocate the Public IP in. Possible values are Zone-Redundant, 1, 2, 3, and No-Zone. Defaults to Zone-Redundant. | `list(string)` | <pre>[<br>  "1"<br>]</pre> | no |
| <a name="input_sharedsvs_azure_bastion_scale_units"></a> [sharedsvs\_azure\_bastion\_scale\_units](#input\_sharedsvs\_azure\_bastion\_scale\_units) | (Optional) The number of scale units with which to provision the Bastion Host. Possible values are between 2 and 50. Defaults to 2. | `string` | `"6"` | no |
| <a name="input_sharedsvs_azure_bastion_subnet_prefix"></a> [sharedsvs\_azure\_bastion\_subnet\_prefix](#input\_sharedsvs\_azure\_bastion\_subnet\_prefix) | (Required) The prefix of the azure bastion subnet. | `list(string)` | n/a | yes |
| <a name="input_sharedsvs_azure_container_registry_georeplication_location"></a> [sharedsvs\_azure\_container\_registry\_georeplication\_location](#input\_sharedsvs\_azure\_container\_registry\_georeplication\_location) | (Optional) A location where the container registry should be geo-replicated. | `string` | `""` | no |
| <a name="input_sharedsvs_azure_container_registry_zone_redundancy_enabled"></a> [sharedsvs\_azure\_container\_registry\_zone\_redundancy\_enabled](#input\_sharedsvs\_azure\_container\_registry\_zone\_redundancy\_enabled) | (Optional) Whether zone redundancy is enabled for this replication location? Defaults to false. | `bool` | `false` | no |
| <a name="input_sharedsvs_azure_defender_resources"></a> [sharedsvs\_azure\_defender\_resources](#input\_sharedsvs\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "AppServices",<br>  "ContainerRegistry",<br>  "KeyVaults",<br>  "KubernetesService",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns"<br>]</pre> | no |
| <a name="input_sharedsvs_azure_dns_resolver_dns_forwarding_rulese_name"></a> [sharedsvs\_azure\_dns\_resolver\_dns\_forwarding\_rulese\_name](#input\_sharedsvs\_azure\_dns\_resolver\_dns\_forwarding\_rulese\_name) | (Required) Specifies the name which should be used for this Private DNS Resolver Dns Forwarding Ruleset. Changing this forces a new Private DNS Resolver Dns Forwarding Ruleset to be created. | `string` | `"kpmglatamch"` | no |
| <a name="input_sharedsvs_azure_dns_resolver_forwarding_rule_onprem_domain_name"></a> [sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_domain\_name](#input\_sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_domain\_name) | (Require) The domain name for the Private DNS Resolver Forwarding Rule in Onprem. | `any` | n/a | yes |
| <a name="input_sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address"></a> [sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address](#input\_sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address) | (Required) DNS server IP address. | `any` | n/a | yes |
| <a name="input_sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address2"></a> [sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address2](#input\_sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address2) | (Required) DNS server IP address. | `any` | n/a | yes |
| <a name="input_sharedsvs_azure_dns_resolver_forwarding_rule_onprem_name"></a> [sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_name](#input\_sharedsvs\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_name) | (Required) Name of the Private DNS Resolver Forwarding Rule. | `string` | `"onprem-latamch"` | no |
| <a name="input_sharedsvs_azure_dns_resolver_inbound_endpoint_name"></a> [sharedsvs\_azure\_dns\_resolver\_inbound\_endpoint\_name](#input\_sharedsvs\_azure\_dns\_resolver\_inbound\_endpoint\_name) | (Required) Specifies the name which should be used for this Private DNS Resolver Inbound Endpoint. Changing this forces a new Private DNS Resolver Inbound Endpoint to be created. | `string` | `"inblatamch"` | no |
| <a name="input_sharedsvs_azure_dns_resolver_outbound_endpoint_name"></a> [sharedsvs\_azure\_dns\_resolver\_outbound\_endpoint\_name](#input\_sharedsvs\_azure\_dns\_resolver\_outbound\_endpoint\_name) | (Required) Specifies the name which should be used for this Private DNS Resolver Outbound Endpoint. Changing this forces a new Private DNS Resolver Outbound Endpoint to be created. | `string` | `"outlatamch"` | no |
| <a name="input_sharedsvs_azure_dns_resolver_subnet_inbound_prefix"></a> [sharedsvs\_azure\_dns\_resolver\_subnet\_inbound\_prefix](#input\_sharedsvs\_azure\_dns\_resolver\_subnet\_inbound\_prefix) | (Required) The address prefixes to use for the indbount endpoint subnet. | `any` | n/a | yes |
| <a name="input_sharedsvs_azure_dns_resolver_subnet_outbound_prefix"></a> [sharedsvs\_azure\_dns\_resolver\_subnet\_outbound\_prefix](#input\_sharedsvs\_azure\_dns\_resolver\_subnet\_outbound\_prefix) | (Required) The address prefixes to use for the outbound endpoint subnet. | `any` | n/a | yes |
| <a name="input_sharedsvs_azure_vm_image_build_number"></a> [sharedsvs\_azure\_vm\_image\_build\_number](#input\_sharedsvs\_azure\_vm\_image\_build\_number) | (Required) Build number from GH actions workflow. | `string` | n/a | yes |
| <a name="input_sharedsvs_azure_vm_image_builder_distribute_replicationRegions"></a> [sharedsvs\_azure\_vm\_image\_builder\_distribute\_replicationRegions](#input\_sharedsvs\_azure\_vm\_image\_builder\_distribute\_replicationRegions) | (Optional) destiny location. | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_identifier_source_offer"></a> [sharedsvs\_azure\_vm\_image\_builder\_identifier\_source\_offer](#input\_sharedsvs\_azure\_vm\_image\_builder\_identifier\_source\_offer) | (Optional) The Publisher Name for this Gallery Image. Changing this forces a new resource to be created. | `string` | `"AzureVMImageBuilder"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_identifier_source_publisher"></a> [sharedsvs\_azure\_vm\_image\_builder\_identifier\_source\_publisher](#input\_sharedsvs\_azure\_vm\_image\_builder\_identifier\_source\_publisher) | (Optional) The Offer Name for this Shared Image. Changing this forces a new resource to be created. | `string` | `"KPMG"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_release"></a> [sharedsvs\_azure\_vm\_image\_builder\_release](#input\_sharedsvs\_azure\_vm\_image\_builder\_release) | (Required) Specifies the relese of the VM Image. Changing this forces a new resource to be created. | `string` | `"r1"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_resource_apiVersion"></a> [sharedsvs\_azure\_vm\_image\_builder\_resource\_apiVersion](#input\_sharedsvs\_azure\_vm\_image\_builder\_resource\_apiVersion) | (Optional) apiVersion Azure VM Image Builder | `string` | `"2022-02-14"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_shared_image_def_os_type"></a> [sharedsvs\_azure\_vm\_image\_builder\_shared\_image\_def\_os\_type](#input\_sharedsvs\_azure\_vm\_image\_builder\_shared\_image\_def\_os\_type) | (Required) The type of Operating System present in this Shared Image. Possible values are Linux and Windows. Changing this forces a new resource to be created. | `string` | `"Windows"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_source_offer"></a> [sharedsvs\_azure\_vm\_image\_builder\_source\_offer](#input\_sharedsvs\_azure\_vm\_image\_builder\_source\_offer) | (Required) The name of a group of related images created by a publisher. Examples: RHEL, WindowsServer. By default this values is to create a Windows image | `string` | `"WindowsServer"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_source_publisher"></a> [sharedsvs\_azure\_vm\_image\_builder\_source\_publisher](#input\_sharedsvs\_azure\_vm\_image\_builder\_source\_publisher) | (Required) The organization that created the image. Examples: RedHat, MicrosoftWindowsServer. By default this values is to create a Windows image | `string` | `"MicrosoftWindowsServer"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_source_sku"></a> [sharedsvs\_azure\_vm\_image\_builder\_source\_sku](#input\_sharedsvs\_azure\_vm\_image\_builder\_source\_sku) | (Required) An instance of an offer, such as a major release of a distribution. Examples: 7-LVM, 2019-Datacenter. By default this values is to create a Windows image | `string` | `"2019-Datacenter"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_source_version"></a> [sharedsvs\_azure\_vm\_image\_builder\_source\_version](#input\_sharedsvs\_azure\_vm\_image\_builder\_source\_version) | (Optional) The version number of an image SKU. | `string` | `"latest"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_storage_account_deploy"></a> [sharedsvs\_azure\_vm\_image\_builder\_storage\_account\_deploy](#input\_sharedsvs\_azure\_vm\_image\_builder\_storage\_account\_deploy) | (Optional) Deploy sa for image builder scripts, the scripts is going to be uploaded always from shares services core, in case you only require to create a new image definition please, this in false this variable. | `bool` | `false` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_storage_account_network_rules_default_action"></a> [sharedsvs\_azure\_vm\_image\_builder\_storage\_account\_network\_rules\_default\_action](#input\_sharedsvs\_azure\_vm\_image\_builder\_storage\_account\_network\_rules\_default\_action) | (Optional) Default action for network rules access. | `string` | `"Allow"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_storage_account_postfix"></a> [sharedsvs\_azure\_vm\_image\_builder\_storage\_account\_postfix](#input\_sharedsvs\_azure\_vm\_image\_builder\_storage\_account\_postfix) | (Optional) A unique identifier for the storage account. Part of the naming scheme. | `string` | `"imgbd"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_template_deployment_mode"></a> [sharedsvs\_azure\_vm\_image\_builder\_template\_deployment\_mode](#input\_sharedsvs\_azure\_vm\_image\_builder\_template\_deployment\_mode) | (Optional) The Deployment Mode for this Resource Group Template Deployment. Possible values are Complete (where resources in the Resource Group not specified in the ARM Template will be destroyed) and Incremental (where resources are additive only). | `string` | `"Complete"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_template_source_latam"></a> [sharedsvs\_azure\_vm\_image\_builder\_template\_source\_latam](#input\_sharedsvs\_azure\_vm\_image\_builder\_template\_source\_latam) | (Optional) The name of the ARM template for Windows VM ImageWindowsTemplate.json, for Linux VM. | `string` | `"ImageWindowsTemplatelatamch.json"` | no |
| <a name="input_sharedsvs_azure_vm_image_builder_vmSize"></a> [sharedsvs\_azure\_vm\_image\_builder\_vmSize](#input\_sharedsvs\_azure\_vm\_image\_builder\_vmSize) | (Required) The Size of the windows or Linux vm. By default this values has a Windows vm size | `string` | `"Standard_D4_v3"` | no |
| <a name="input_sharedsvs_bigfix_vm_computer_name"></a> [sharedsvs\_bigfix\_vm\_computer\_name](#input\_sharedsvs\_bigfix\_vm\_computer\_name) | n/a | `list(string)` | `null` | no |
| <a name="input_sharedsvs_bigfix_vm_data_disk_size"></a> [sharedsvs\_bigfix\_vm\_data\_disk\_size](#input\_sharedsvs\_bigfix\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `string` | `"1024"` | no |
| <a name="input_sharedsvs_bigfix_vm_image_id"></a> [sharedsvs\_bigfix\_vm\_image\_id](#input\_sharedsvs\_bigfix\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvs_bigfix_vm_logging_disk_size"></a> [sharedsvs\_bigfix\_vm\_logging\_disk\_size](#input\_sharedsvs\_bigfix\_vm\_logging\_disk\_size) | (Required) size of managed logging disk. | `string` | `"64"` | no |
| <a name="input_sharedsvs_bigfix_vm_os_disk_disk_size_gb"></a> [sharedsvs\_bigfix\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvs\_bigfix\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `string` | `"300"` | no |
| <a name="input_sharedsvs_bigfix_vm_os_disk_storage_account_type"></a> [sharedsvs\_bigfix\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvs\_bigfix\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvs_bigfix_vm_size"></a> [sharedsvs\_bigfix\_vm\_size](#input\_sharedsvs\_bigfix\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_B4ms"` | no |
| <a name="input_sharedsvs_cribl_computer_names"></a> [sharedsvs\_cribl\_computer\_names](#input\_sharedsvs\_cribl\_computer\_names) | (Optional): Custom os computer names to give to the VMs. | `list(string)` | `null` | no |
| <a name="input_sharedsvs_cribl_local_user"></a> [sharedsvs\_cribl\_local\_user](#input\_sharedsvs\_cribl\_local\_user) | (Required) The local admin username for cribl VM | `string` | n/a | yes |
| <a name="input_sharedsvs_cribl_network_interface_count"></a> [sharedsvs\_cribl\_network\_interface\_count](#input\_sharedsvs\_cribl\_network\_interface\_count) | (Required) The count for cribl VMs | `number` | `1` | no |
| <a name="input_sharedsvs_cribl_vm_enable_log_analytics_settings"></a> [sharedsvs\_cribl\_vm\_enable\_log\_analytics\_settings](#input\_sharedsvs\_cribl\_vm\_enable\_log\_analytics\_settings) | (Required) Enable log analytics extension for cribl VMs | `bool` | `true` | no |
| <a name="input_sharedsvs_cribl_vm_names"></a> [sharedsvs\_cribl\_vm\_names](#input\_sharedsvs\_cribl\_vm\_names) | (Optional): Custom names to give to the VMs. | `list(string)` | `null` | no |
| <a name="input_sharedsvs_cribl_vm_timezone"></a> [sharedsvs\_cribl\_vm\_timezone](#input\_sharedsvs\_cribl\_vm\_timezone) | (Required) The ihub\_pa\_vm\_timezone of the vms. Required if OS = Windows | `string` | `"UTC"` | no |
| <a name="input_sharedsvs_crible_vm_deploy"></a> [sharedsvs\_crible\_vm\_deploy](#input\_sharedsvs\_crible\_vm\_deploy) | Optional Variables - CribleVM ********************************************************************************************** | `bool` | `false` | no |
| <a name="input_sharedsvs_deploy_bigfix"></a> [sharedsvs\_deploy\_bigfix](#input\_sharedsvs\_deploy\_bigfix) | (Optional) deploy bigfix true or false | `bool` | `true` | no |
| <a name="input_sharedsvs_deploy_dr_shsdsvc_to_prod_shsdsvc_peering"></a> [sharedsvs\_deploy\_dr\_shsdsvc\_to\_prod\_shsdsvc\_peering](#input\_sharedsvs\_deploy\_dr\_shsdsvc\_to\_prod\_shsdsvc\_peering) | (Optional) Enabled the peering between prod and dr. | `bool` | `false` | no |
| <a name="input_sharedsvs_deploy_idty_peering"></a> [sharedsvs\_deploy\_idty\_peering](#input\_sharedsvs\_deploy\_idty\_peering) | n/a | `bool` | `false` | no |
| <a name="input_sharedsvs_deploy_ihub_peering"></a> [sharedsvs\_deploy\_ihub\_peering](#input\_sharedsvs\_deploy\_ihub\_peering) | n/a | `bool` | `false` | no |
| <a name="input_sharedsvs_deploy_prod_shsdsvc_to_dr_shsdsvc_peering"></a> [sharedsvs\_deploy\_prod\_shsdsvc\_to\_dr\_shsdsvc\_peering](#input\_sharedsvs\_deploy\_prod\_shsdsvc\_to\_dr\_shsdsvc\_peering) | (Optional) Enabled the peering between prod and dr. | `bool` | `false` | no |
| <a name="input_sharedsvs_dr_to_shsdsvc_prod_peering_network_id"></a> [sharedsvs\_dr\_to\_shsdsvc\_prod\_peering\_network\_id](#input\_sharedsvs\_dr\_to\_shsdsvc\_prod\_peering\_network\_id) | (Optional) Vnet id from prod shared services. | `string` | `null` | no |
| <a name="input_sharedsvs_image_builder_subnet_enforce_service_policies"></a> [sharedsvs\_image\_builder\_subnet\_enforce\_service\_policies](#input\_sharedsvs\_image\_builder\_subnet\_enforce\_service\_policies) | private\_endpoint\_network\_policies\_enabled - (Optional) Enable or Disable network policies for the private endpoint on the subnet. Setting this to true will Enable the policy and setting this to false will Disable the policy. Defaults to true. | `bool` | `true` | no |
| <a name="input_sharedsvs_imgbuilder_sub_address_prefix"></a> [sharedsvs\_imgbuilder\_sub\_address\_prefix](#input\_sharedsvs\_imgbuilder\_sub\_address\_prefix) | (Require) The address prefixes for the subnet of image builder. | `list(string)` | `null` | no |
| <a name="input_sharedsvs_imgbuilder_subnet_service_endpoints"></a> [sharedsvs\_imgbuilder\_subnet\_service\_endpoints](#input\_sharedsvs\_imgbuilder\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.AzureActiveDirectory",<br>  "Microsoft.Storage"<br>]</pre> | no |
| <a name="input_sharedsvs_internal_lb_private_ip_address_allocation"></a> [sharedsvs\_internal\_lb\_private\_ip\_address\_allocation](#input\_sharedsvs\_internal\_lb\_private\_ip\_address\_allocation) | (Required) private IP allocation of internal LB | `string` | `"Dynamic"` | no |
| <a name="input_sharedsvs_internal_lb_probe_interval_in_seconds"></a> [sharedsvs\_internal\_lb\_probe\_interval\_in\_seconds](#input\_sharedsvs\_internal\_lb\_probe\_interval\_in\_seconds) | (Optional) Port on which the Probe queries the backend endpoint | `number` | `5` | no |
| <a name="input_sharedsvs_internal_lb_probe_number_of_probes"></a> [sharedsvs\_internal\_lb\_probe\_number\_of\_probes](#input\_sharedsvs\_internal\_lb\_probe\_number\_of\_probes) | (Optional) The number of failed probe attempts after which the backend endpoint is removed from rotation. The default value is 2 | `number` | `2` | no |
| <a name="input_sharedsvs_internal_lb_rule_disable_outbound_snat"></a> [sharedsvs\_internal\_lb\_rule\_disable\_outbound\_snat](#input\_sharedsvs\_internal\_lb\_rule\_disable\_outbound\_snat) | (Optional) Load Balancer Rule to enable snat | `bool` | `false` | no |
| <a name="input_sharedsvs_internal_lb_rule_enable_floating_ip"></a> [sharedsvs\_internal\_lb\_rule\_enable\_floating\_ip](#input\_sharedsvs\_internal\_lb\_rule\_enable\_floating\_ip) | (Optional) Load Balancer Rule to enable Floating IPs | `bool` | `true` | no |
| <a name="input_sharedsvs_internal_lb_rule_enable_tcp_reset"></a> [sharedsvs\_internal\_lb\_rule\_enable\_tcp\_reset](#input\_sharedsvs\_internal\_lb\_rule\_enable\_tcp\_reset) | (Optional) Load Balancer Rule to enable TCP Reset | `bool` | `false` | no |
| <a name="input_sharedsvs_internal_lb_rule_idle_timeout_in_minutes"></a> [sharedsvs\_internal\_lb\_rule\_idle\_timeout\_in\_minutes](#input\_sharedsvs\_internal\_lb\_rule\_idle\_timeout\_in\_minutes) | (Optional) Specifies the idle timeout in minutes for TCP connections | `number` | `5` | no |
| <a name="input_sharedsvs_internal_lb_rule_load_distribution"></a> [sharedsvs\_internal\_lb\_rule\_load\_distribution](#input\_sharedsvs\_internal\_lb\_rule\_load\_distribution) | (Optional) Specifies the load balancing distribution type to be used by the Load Balancer | `string` | `"Default"` | no |
| <a name="input_sharedsvs_internal_lb_sku"></a> [sharedsvs\_internal\_lb\_sku](#input\_sharedsvs\_internal\_lb\_sku) | (Optional) list of SKU's , every item of list is optional (default value Basic) | `string` | `"Standard"` | no |
| <a name="input_sharedsvs_keyvault_allowed_pe_subnet_ids"></a> [sharedsvs\_keyvault\_allowed\_pe\_subnet\_ids](#input\_sharedsvs\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_keyvault_az_svcs_bypass"></a> [sharedsvs\_keyvault\_az\_svcs\_bypass](#input\_sharedsvs\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_sharedsvs_keyvault_diagnostics"></a> [sharedsvs\_keyvault\_diagnostics](#input\_sharedsvs\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_sharedsvs_keyvault_enable"></a> [sharedsvs\_keyvault\_enable](#input\_sharedsvs\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `true` | no |
| <a name="input_sharedsvs_keyvault_enabled_for_deployment"></a> [sharedsvs\_keyvault\_enabled\_for\_deployment](#input\_sharedsvs\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_sharedsvs_keyvault_enabled_for_disk_encryption"></a> [sharedsvs\_keyvault\_enabled\_for\_disk\_encryption](#input\_sharedsvs\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_sharedsvs_keyvault_enabled_for_template_deployment"></a> [sharedsvs\_keyvault\_enabled\_for\_template\_deployment](#input\_sharedsvs\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_sharedsvs_keyvault_log_analytics_solutions"></a> [sharedsvs\_keyvault\_log\_analytics\_solutions](#input\_sharedsvs\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_sharedsvs_keyvault_nacl_allowed_ips"></a> [sharedsvs\_keyvault\_nacl\_allowed\_ips](#input\_sharedsvs\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | <pre>[<br>  "199.206.0.0/15"<br>]</pre> | no |
| <a name="input_sharedsvs_keyvault_nacl_allowed_subnets"></a> [sharedsvs\_keyvault\_nacl\_allowed\_subnets](#input\_sharedsvs\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_keyvault_nacl_default_action"></a> [sharedsvs\_keyvault\_nacl\_default\_action](#input\_sharedsvs\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_sharedsvs_keyvault_postfix"></a> [sharedsvs\_keyvault\_postfix](#input\_sharedsvs\_keyvault\_postfix) | (Required) The bespoke name of the kv app or project you are deploying. | `string` | `"ch"` | no |
| <a name="input_sharedsvs_keyvault_private_dns_zone_ids"></a> [sharedsvs\_keyvault\_private\_dns\_zone\_ids](#input\_sharedsvs\_keyvault\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_keyvault_prodtodr_id"></a> [sharedsvs\_keyvault\_prodtodr\_id](#input\_sharedsvs\_keyvault\_prodtodr\_id) | DR VM's deployment, send the kv id from prod shared services | `any` | `null` | no |
| <a name="input_sharedsvs_keyvault_purge_protection_enabled"></a> [sharedsvs\_keyvault\_purge\_protection\_enabled](#input\_sharedsvs\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_sharedsvs_keyvault_sku_name"></a> [sharedsvs\_keyvault\_sku\_name](#input\_sharedsvs\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_sharedsvs_keyvault_soft_delete_retention_days"></a> [sharedsvs\_keyvault\_soft\_delete\_retention\_days](#input\_sharedsvs\_keyvault\_soft\_delete\_retention\_days) | (Optional) The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the default) days. | `number` | `90` | no |
| <a name="input_sharedsvs_kubernetes_addon_profile_azure_keyvault_secrets_provider_enabled"></a> [sharedsvs\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_enabled](#input\_sharedsvs\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_enabled) | (Optional) Is the Azure Keyvault Secrets Providerenabled | `bool` | `true` | no |
| <a name="input_sharedsvs_law_private_dns_zone_ids"></a> [sharedsvs\_law\_private\_dns\_zone\_ids](#input\_sharedsvs\_law\_private\_dns\_zone\_ids) | n/a | `any` | `null` | no |
| <a name="input_sharedsvs_load_balancer_diagnostics"></a> [sharedsvs\_load\_balancer\_diagnostics](#input\_sharedsvs\_load\_balancer\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_sharedsvs_mgmt_sub_address_prefix"></a> [sharedsvs\_mgmt\_sub\_address\_prefix](#input\_sharedsvs\_mgmt\_sub\_address\_prefix) | (Require) The address prefixes for the subnet of vm's. | `list(string)` | n/a | yes |
| <a name="input_sharedsvs_mgmt_subnet_service_endpoints"></a> [sharedsvs\_mgmt\_subnet\_service\_endpoints](#input\_sharedsvs\_mgmt\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_sharedsvs_postprov_sa_container_access_type"></a> [sharedsvs\_postprov\_sa\_container\_access\_type](#input\_sharedsvs\_postprov\_sa\_container\_access\_type) | n/a | `string` | `"private"` | no |
| <a name="input_sharedsvs_postprov_sa_container_deploy"></a> [sharedsvs\_postprov\_sa\_container\_deploy](#input\_sharedsvs\_postprov\_sa\_container\_deploy) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvs_postprov_sa_container_name"></a> [sharedsvs\_postprov\_sa\_container\_name](#input\_sharedsvs\_postprov\_sa\_container\_name) | n/a | `set(string)` | `[]` | no |
| <a name="input_sharedsvs_postprov_storage_account_access_tier"></a> [sharedsvs\_postprov\_storage\_account\_access\_tier](#input\_sharedsvs\_postprov\_storage\_account\_access\_tier) | n/a | `string` | `"Hot"` | no |
| <a name="input_sharedsvs_postprov_storage_account_allowed_subnet_ids"></a> [sharedsvs\_postprov\_storage\_account\_allowed\_subnet\_ids](#input\_sharedsvs\_postprov\_storage\_account\_allowed\_subnet\_ids) | variable "sharedsvs\_postprov\_storage\_account\_log\_analytics\_workspace\_id" { type = string default = "" } | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_postprov_storage_account_deploy"></a> [sharedsvs\_postprov\_storage\_account\_deploy](#input\_sharedsvs\_postprov\_storage\_account\_deploy) | Postprovisioning storage account variables ********************************************************************************************** | `bool` | `true` | no |
| <a name="input_sharedsvs_postprov_storage_account_postfix"></a> [sharedsvs\_postprov\_storage\_account\_postfix](#input\_sharedsvs\_postprov\_storage\_account\_postfix) | n/a | `string` | `""` | no |
| <a name="input_sharedsvs_private_dns_zone"></a> [sharedsvs\_private\_dns\_zone](#input\_sharedsvs\_private\_dns\_zone) | n/a | `list(string)` | <pre>[<br>  "privatelink.azure-automation.net",<br>  "privatelink.database.windows.net",<br>  "privatelink.blob.core.windows.net",<br>  "privatelink.table.core.windows.net",<br>  "privatelink.queue.core.windows.net",<br>  "privatelink.file.core.windows.net",<br>  "privatelink.web.core.windows.net",<br>  "privatelink.dfs.core.windows.net",<br>  "privatelink.documents.azure.com",<br>  "privatelink.mongo.cosmos.azure.com",<br>  "privatelink.cassandra.cosmos.azure.com",<br>  "privatelink.gremlin.cosmos.azure.com",<br>  "privatelink.table.cosmos.azure.com",<br>  "privatelink.postgres.database.azure.com",<br>  "privatelink.mysql.database.azure.com",<br>  "privatelink.mariadb.database.azure.com",<br>  "privatelink.vaultcore.azure.net",<br>  "privatelink.search.windows.net",<br>  "privatelink.azurecr.io",<br>  "privatelink.azconfig.io",<br>  "privatelink.servicebus.windows.net",<br>  "privatelink.azure-devices.net",<br>  "privatelink.eventgrid.azure.net",<br>  "privatelink.azurewebsites.net",<br>  "privatelink.api.azureml.ms",<br>  "privatelink.service.signalr.net",<br>  "privatelink.monitor.azure.com",<br>  "privatelink.oms.opinsights.azure.com",<br>  "privatelink.ods.opinsights.azure.com",<br>  "privatelink.agentsvc.azure-automation.net",<br>  "privatelink.cognitiveservices.azure.com",<br>  "privatelink.afs.azure.net",<br>  "privatelink.datafactory.azure.net",<br>  "privatelink.redis.cache.windows.net",<br>  "privatelink.eus.azmk8s.io",<br>  "privatelink.eus.backup.windowsazure.com",<br>  "privatelink.eus2.azmk8s.io",<br>  "privatelink.eus2.backup.windowsazure.com",<br>  "privatelink.wus.azmk8s.io",<br>  "privatelink.wus.backup.windowsazure.com",<br>  "privatelink.siterecovery.windowsazure.com",<br>  "privatelink.eastus2.azmk8s.io",<br>  "privatelink.dev.azuresynapse.net",<br>  "privatelink.azuresynapse.net",<br>  "privatelink.sql.azuresynapse.net",<br>  "privatelink.his.arc.azure.com",<br>  "privatelink.guestconfiguration.azure.com",<br>  "privatelink.dp.kubernetesconfiguration.azure.com",<br>  "privatelink.snowflakecomputing.com",<br>  "privatelink.eastus.azmk8s.io",<br>  "privatelink.westus.azmk8s.io",<br>  "privatelink.northeurope.azmk8s.io",<br>  "privatelink.westeurope.azmk8s.io"<br>]</pre> | no |
| <a name="input_sharedsvs_private_dns_zone_enable"></a> [sharedsvs\_private\_dns\_zone\_enable](#input\_sharedsvs\_private\_dns\_zone\_enable) | (Optional) Enable the creation of private dns zone | `bool` | `true` | no |
| <a name="input_sharedsvs_private_link_subnet_address_prefixes"></a> [sharedsvs\_private\_link\_subnet\_address\_prefixes](#input\_sharedsvs\_private\_link\_subnet\_address\_prefixes) | (Require) The address prefixes for the subnet of private endpoints. | `list(string)` | n/a | yes |
| <a name="input_sharedsvs_private_link_subnet_enforce_endpoint_network_policies"></a> [sharedsvs\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_sharedsvs\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Optional) | `bool` | `true` | no |
| <a name="input_sharedsvs_private_link_subnet_service_endpoints"></a> [sharedsvs\_private\_link\_subnet\_service\_endpoints](#input\_sharedsvs\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_sharedsvs_prod_to_shsdsvc_dr_peering_network_id"></a> [sharedsvs\_prod\_to\_shsdsvc\_dr\_peering\_network\_id](#input\_sharedsvs\_prod\_to\_shsdsvc\_dr\_peering\_network\_id) | (Optional) Vnet id from prod shared services. | `string` | `null` | no |
| <a name="input_sharedsvs_ptrn_azure_container_registry_private_dns_zone_id"></a> [sharedsvs\_ptrn\_azure\_container\_registry\_private\_dns\_zone\_id](#input\_sharedsvs\_ptrn\_azure\_container\_registry\_private\_dns\_zone\_id) | acr private dns zone id | `any` | `null` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_addon_profile_ingress_application_gateway_enabled"></a> [sharedsvs\_ptrn\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_enabled](#input\_sharedsvs\_ptrn\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_enabled) | (Optional) Is the Application Gateway ingress controller integrated with this Kubernetes Cluster | `bool` | `false` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_azure_container_registry_allowed_vnet_ids"></a> [sharedsvs\_ptrn\_kubernetes\_azure\_container\_registry\_allowed\_vnet\_ids](#input\_sharedsvs\_ptrn\_kubernetes\_azure\_container\_registry\_allowed\_vnet\_ids) | (Optional) One or more VNET ID's which should be linked to the Private DNS Zone for ACR name resolution and access trough Private Endpoint. | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_azure_container_registry_network_rule_set_default_action"></a> [sharedsvs\_ptrn\_kubernetes\_azure\_container\_registry\_network\_rule\_set\_default\_action](#input\_sharedsvs\_ptrn\_kubernetes\_azure\_container\_registry\_network\_rule\_set\_default\_action) | (Optional) The behaviour for requests matching no rules. Either Allow or Deny. Defaults to Deny | `string` | `"Deny"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_azure_container_registry_prodtodr_id"></a> [sharedsvs\_ptrn\_kubernetes\_azure\_container\_registry\_prodtodr\_id](#input\_sharedsvs\_ptrn\_kubernetes\_azure\_container\_registry\_prodtodr\_id) | (Optional) DR deployment aks send the ACR ID from Prod | `any` | `null` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_availability_zones"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_availability\_zones](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_availability\_zones) | (Optional) A list of Availability Zones across which the Node Pool should be spread. Changing this forces a new resource to be created. | `list(string)` | <pre>[<br>  1,<br>  2<br>]</pre> | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_max_count"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_max\_count](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_max\_count) | (Required) The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min\_count. | `number` | `3` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_max_pods"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_max\_pods](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_max\_pods) | (Optional) The maximum number of pods that can run on each agent. Changing this forces a new resource to be created. | `number` | `30` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_min_count"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_min\_count](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_min\_count) | (Required) The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max\_count. | `number` | `1` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_node_count"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_node\_count](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_node\_count) | (Optional) The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min\_count and max\_count | `number` | `3` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_orchestrator_version"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_orchestrator\_version](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_orchestrator\_version) | (Optional) Version of Kubernetes used for the Agents. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade) | `string` | `null` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_upgrade_max_surge"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_upgrade\_max\_surge](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_upgrade\_max\_surge) | (Optional) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade | `string` | `"33%"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_default_node_pool_vm_size"></a> [sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_vm\_size](#input\_sharedsvs\_ptrn\_kubernetes\_default\_node\_pool\_vm\_size) | (Optional)The size of the Virtual Machine, such as Standard\_DS2\_v2 | `string` | `"standard_ds2_v2"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_deploy"></a> [sharedsvs\_ptrn\_kubernetes\_deploy](#input\_sharedsvs\_ptrn\_kubernetes\_deploy) | (Optional) deploy or not ptrn\_kubernetes, default false | `bool` | `false` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_deploy_app_gateway"></a> [sharedsvs\_ptrn\_kubernetes\_deploy\_app\_gateway](#input\_sharedsvs\_ptrn\_kubernetes\_deploy\_app\_gateway) | deploy or  not application gateway | `bool` | `false` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_deploy_azure_container_registry"></a> [sharedsvs\_ptrn\_kubernetes\_deploy\_azure\_container\_registry](#input\_sharedsvs\_ptrn\_kubernetes\_deploy\_azure\_container\_registry) | (Optional) Deploy or not ACR component, opcional only in DR. | `bool` | `true` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_deploy_ptrn_privatelink_subnet"></a> [sharedsvs\_ptrn\_kubernetes\_deploy\_ptrn\_privatelink\_subnet](#input\_sharedsvs\_ptrn\_kubernetes\_deploy\_ptrn\_privatelink\_subnet) | (Optional) deploy or not ptrn\_privatelink\_subnet, default true | `bool` | `false` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_deploy_rg"></a> [sharedsvs\_ptrn\_kubernetes\_deploy\_rg](#input\_sharedsvs\_ptrn\_kubernetes\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for AKS. | `bool` | `true` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_identity_type"></a> [sharedsvs\_ptrn\_kubernetes\_identity\_type](#input\_sharedsvs\_ptrn\_kubernetes\_identity\_type) | (Optional) The type of identity used for the managed cluster. Possible values are SystemAssigned and UserAssigned. If UserAssigned is set, a user\_assigned\_identity\_id must be set as well. | `string` | `"UserAssigned"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_kubernetes_version"></a> [sharedsvs\_ptrn\_kubernetes\_kubernetes\_version](#input\_sharedsvs\_ptrn\_kubernetes\_kubernetes\_version) | (Optional) Version of Kubernetes specified when creating the AKS managed cluster. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade). | `string` | `"1.16.9"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_network_profile_dns_service_ip"></a> [sharedsvs\_ptrn\_kubernetes\_network\_profile\_dns\_service\_ip](#input\_sharedsvs\_ptrn\_kubernetes\_network\_profile\_dns\_service\_ip) | (Optional)The K8S's DNS Service IP, /24 represents 256 IPs. IP address within the Kubernetes service address range that will be used by cluster service discovery (kube-dns). Changing this forces a new resource to be created. | `string` | `"10.2.0.10"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_network_profile_docker_bridge_cidr"></a> [sharedsvs\_ptrn\_kubernetes\_network\_profile\_docker\_bridge\_cidr](#input\_sharedsvs\_ptrn\_kubernetes\_network\_profile\_docker\_bridge\_cidr) | (Optional) The K8S's Docker bridge CIDR, /27 represents 32 IPs.  (Optional) IP address (in CIDR notation) used as the Docker bridge IP address on nodes. Changing this forces a new resource to be created. | `string` | `"172.17.0.1/16"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_network_profile_service_cidr"></a> [sharedsvs\_ptrn\_kubernetes\_network\_profile\_service\_cidr](#input\_sharedsvs\_ptrn\_kubernetes\_network\_profile\_service\_cidr) | (Optional) The K8S's Service CIDR, /24 represents 256 IPs. (Optional) The Network Range used by the Kubernetes service. Changing this forces a new resource to be created. | `string` | `"10.2.0.0/16"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_availability_zones"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_availability\_zones](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_availability\_zones) | (Optional) A list of Availability Zones where the Nodes in this Node Pool should be created in. Changing this forces a new resource to be created. | `list(number)` | <pre>[<br>  1,<br>  2<br>]</pre> | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_max_count"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_max\_count](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_max\_count) | (Required) The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min\_count. | `number` | `5` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_max_pods"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_max\_pods](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_max\_pods) | (Optional) The maximum number of pods that can run on each agent. Changing this forces a new resource to be created. | `number` | `30` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_max_surge"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_max\_surge](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_max\_surge) | (Optional) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade.If a percentage is provided, the number of surge nodes is calculated from the current node count on the cluster. Node surge can allow a cluster to have more nodes than max\_count during an upgrade. Ensure that your cluster has enough IP space during an upgrade. | `string` | `"33%"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_min_count"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_min\_count](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_min\_count) | (Required) The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max\_count. | `number` | `1` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_mode"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_mode](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_mode) | (Optional) Should this Node Pool be used for System or User resources? Possible values are System and User. Defaults to User. | `string` | `"User"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_name"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_name](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_name) | (Required) The name of the Node Pool which should be created within the Kubernetes Cluster. Changing this forces a new resource to be created. A Windows Node Pool cannot have a name longer than 6 characters. | `string` | `"internal"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_node_count"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_node\_count](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_node\_count) | (Optional) The initial number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be a value in the range min\_count - max\_count. If you're specifying an initial number of nodes you may wish to use Terraform's ignore\_changes functionality to ignore changes to this field. | `number` | `1` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_orchestrator_version"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_orchestrator\_version](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_orchestrator\_version) | (Optional) Version of Kubernetes used for the Agents. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade). This version must be supported by the Kubernetes Cluster - as such the version of Kubernetes used on the Cluster/Control Plane may need to be upgraded first. | `string` | `null` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_os_disk_size_gb"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_disk\_size\_gb](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_disk\_size\_gb) | (Optional) The Agent Operating System disk size in GB. Changing this forces a new resource to be created. | `number` | `256` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_os_disk_type"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_disk\_type](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_disk\_type) | (Optional) The type of disk which should be used for the Operating System. Possible values are Ephemeral and Managed. Defaults to Managed. Changing this forces a new resource to be created. | `string` | `"Managed"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_os_sku"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_sku](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_sku) | (Optional) OsSKU to be used to specify Linux OSType. Not applicable to Windows OSType. Possible values include: Ubuntu, CBLMariner. Defaults to Ubuntu. Changing this forces a new resource to be created. | `string` | `"Ubuntu"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_os_type"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_type](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_os\_type) | (Optional) The Operating System which should be used for this Node Pool. Changing this forces a new resource to be created. Possible values are Linux and Windows. Defaults to Linux. | `string` | `"Linux"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_node_pool_vm_size"></a> [sharedsvs\_ptrn\_kubernetes\_node\_pool\_vm\_size](#input\_sharedsvs\_ptrn\_kubernetes\_node\_pool\_vm\_size) | (Optional) The SKU which should be used for the Virtual Machines used in this Node Pool. Changing this forces a new resource to be created. | `string` | `"standard_ds2_v2"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_postfix"></a> [sharedsvs\_ptrn\_kubernetes\_postfix](#input\_sharedsvs\_ptrn\_kubernetes\_postfix) | (Required) A string that is appended to the end of the aks name to identify it. | `string` | `"ghshr"` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_private_dns_zone_id"></a> [sharedsvs\_ptrn\_kubernetes\_private\_dns\_zone\_id](#input\_sharedsvs\_ptrn\_kubernetes\_private\_dns\_zone\_id) | aks private dns zone id | `any` | `null` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_rbac_aad_admin_group_object_ids"></a> [sharedsvs\_ptrn\_kubernetes\_rbac\_aad\_admin\_group\_object\_ids](#input\_sharedsvs\_ptrn\_kubernetes\_rbac\_aad\_admin\_group\_object\_ids) | (Optional) A list of Object IDs of Azure Active Directory Groups which should have Admin Role on the Cluster. | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_subnet_nodes_address_prefixes"></a> [sharedsvs\_ptrn\_kubernetes\_subnet\_nodes\_address\_prefixes](#input\_sharedsvs\_ptrn\_kubernetes\_subnet\_nodes\_address\_prefixes) | subnet virtual machine | `list(string)` | `null` | no |
| <a name="input_sharedsvs_ptrn_kubernetes_windows_vm_deploy_subnet_nsg"></a> [sharedsvs\_ptrn\_kubernetes\_windows\_vm\_deploy\_subnet\_nsg](#input\_sharedsvs\_ptrn\_kubernetes\_windows\_vm\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM. | `bool` | `false` | no |
| <a name="input_sharedsvs_rg_security_enable"></a> [sharedsvs\_rg\_security\_enable](#input\_sharedsvs\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to sharedsvs\_rg\_data | `bool` | `true` | no |
| <a name="input_sharedsvs_route_table_disable_bgp_propagation"></a> [sharedsvs\_route\_table\_disable\_bgp\_propagation](#input\_sharedsvs\_route\_table\_disable\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `true` | no |
| <a name="input_sharedsvs_security_center_wdatp_enable"></a> [sharedsvs\_security\_center\_wdatp\_enable](#input\_sharedsvs\_security\_center\_wdatp\_enable) | Optional Variables - KeyVault ********************************************************************************************** | `bool` | `false` | no |
| <a name="input_sharedsvs_shared_image_gallery_deploy"></a> [sharedsvs\_shared\_image\_gallery\_deploy](#input\_sharedsvs\_shared\_image\_gallery\_deploy) | (Optional) Deploy or no image gallery. | `bool` | `true` | no |
| <a name="input_sharedsvs_shared_image_gallery_description"></a> [sharedsvs\_shared\_image\_gallery\_description](#input\_sharedsvs\_shared\_image\_gallery\_description) | (Optional) A description for this Shared Image Gallery. | `string` | `"US CH shared image gallery"` | no |
| <a name="input_sharedsvs_to_idty_peering_network_id"></a> [sharedsvs\_to\_idty\_peering\_network\_id](#input\_sharedsvs\_to\_idty\_peering\_network\_id) | identity resource string for peering connection | `string` | `null` | no |
| <a name="input_sharedsvs_to_ihub_peering_network_id"></a> [sharedsvs\_to\_ihub\_peering\_network\_id](#input\_sharedsvs\_to\_ihub\_peering\_network\_id) | ihub resource string for peering connection | `string` | `null` | no |
| <a name="input_sharedsvs_vm_admin_username"></a> [sharedsvs\_vm\_admin\_username](#input\_sharedsvs\_vm\_admin\_username) | (Required) The name of the windows OS admin. | `string` | n/a | yes |
| <a name="input_sharedsvs_vnet_address_space"></a> [sharedsvs\_vnet\_address\_space](#input\_sharedsvs\_vnet\_address\_space) | (Required) The address space for the virtual network. | `list(string)` | n/a | yes |
| <a name="input_sharedsvs_vnet_dns_servers"></a> [sharedsvs\_vnet\_dns\_servers](#input\_sharedsvs\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_sharedsvs_windows_vm_app_name"></a> [sharedsvs\_windows\_vm\_app\_name](#input\_sharedsvs\_windows\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `string` | `"aksghshr"` | no |
| <a name="input_sharedsvs_windows_vm_data_collection_rule_assoc"></a> [sharedsvs\_windows\_vm\_data\_collection\_rule\_assoc](#input\_sharedsvs\_windows\_vm\_data\_collection\_rule\_assoc) | (Required) conditinal for enabling DCR association on VM. | `bool` | `true` | no |
| <a name="input_sharedsvs_windows_vm_deploy"></a> [sharedsvs\_windows\_vm\_deploy](#input\_sharedsvs\_windows\_vm\_deploy) | (Optional) Enable the creation of The Windows vm dns forwarder | `bool` | `true` | no |
| <a name="input_sharedsvs_windows_vm_deploy_rg"></a> [sharedsvs\_windows\_vm\_deploy\_rg](#input\_sharedsvs\_windows\_vm\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the VM. | `bool` | `true` | no |
| <a name="input_sharedsvs_windows_vm_domain_join_ou_path"></a> [sharedsvs\_windows\_vm\_domain\_join\_ou\_path](#input\_sharedsvs\_windows\_vm\_domain\_join\_ou\_path) | (Optional) OU path to us during domain join | `string` | `"OU=Public Cloud,OU=Servers,OU=KADO_CLOUD,DC=amr,DC=kworld,DC=kpmg,DC=com"` | no |
| <a name="input_sharedsvs_windows_vm_domain_name"></a> [sharedsvs\_windows\_vm\_domain\_name](#input\_sharedsvs\_windows\_vm\_domain\_name) | (Optional) Name of the domain to join | `string` | `"amr.kworld.kpmg.com"` | no |
| <a name="input_sharedsvs_windows_vm_domain_password"></a> [sharedsvs\_windows\_vm\_domain\_password](#input\_sharedsvs\_windows\_vm\_domain\_password) | (Optional) Password of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_sharedsvs_windows_vm_domain_user_upn"></a> [sharedsvs\_windows\_vm\_domain\_user\_upn](#input\_sharedsvs\_windows\_vm\_domain\_user\_upn) | (Optional) UPN of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_sharedsvs_windows_vm_enable_ama_log_analytics_settings"></a> [sharedsvs\_windows\_vm\_enable\_ama\_log\_analytics\_settings](#input\_sharedsvs\_windows\_vm\_enable\_ama\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `true` | no |
| <a name="input_sharedsvs_windows_vm_enable_domain_join"></a> [sharedsvs\_windows\_vm\_enable\_domain\_join](#input\_sharedsvs\_windows\_vm\_enable\_domain\_join) | (Optional) Toggle the domain join feature. | `bool` | `false` | no |
| <a name="input_sharedsvs_windows_vm_enable_mma_log_analytics_settings"></a> [sharedsvs\_windows\_vm\_enable\_mma\_log\_analytics\_settings](#input\_sharedsvs\_windows\_vm\_enable\_mma\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `true` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_admin_user"></a> [sharedsvs\_windows\_vm\_jumpbox\_admin\_user](#input\_sharedsvs\_windows\_vm\_jumpbox\_admin\_user) | (Required) The name of the windows OS admin. | `string` | `"kpmgadmin"` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_computer_name"></a> [sharedsvs\_windows\_vm\_jumpbox\_computer\_name](#input\_sharedsvs\_windows\_vm\_jumpbox\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | `null` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_enable_backup"></a> [sharedsvs\_windows\_vm\_jumpbox\_enable\_backup](#input\_sharedsvs\_windows\_vm\_jumpbox\_enable\_backup) | (Optional) Toggle the backup feature. | `bool` | `false` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_enable_encryption_at_host_enabled"></a> [sharedsvs\_windows\_vm\_jumpbox\_enable\_encryption\_at\_host\_enabled](#input\_sharedsvs\_windows\_vm\_jumpbox\_enable\_encryption\_at\_host\_enabled) | (Optional) Boolean to enable encryption\_at\_host\_enabled. | `bool` | `false` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_enable_log_analytics_settings"></a> [sharedsvs\_windows\_vm\_jumpbox\_enable\_log\_analytics\_settings](#input\_sharedsvs\_windows\_vm\_jumpbox\_enable\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `false` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_identity_type"></a> [sharedsvs\_windows\_vm\_jumpbox\_identity\_type](#input\_sharedsvs\_windows\_vm\_jumpbox\_identity\_type) | (Optional) Managed identity type for VM | `string` | `"SystemAssigned"` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_image_id"></a> [sharedsvs\_windows\_vm\_jumpbox\_image\_id](#input\_sharedsvs\_windows\_vm\_jumpbox\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | `null` | no |
| <a name="input_sharedsvs_windows_vm_jumpbox_size"></a> [sharedsvs\_windows\_vm\_jumpbox\_size](#input\_sharedsvs\_windows\_vm\_jumpbox\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_D2s_v4"` | no |
| <a name="input_sharedsvs_windows_vm_log_analytics_primary_sentinel_shared_key"></a> [sharedsvs\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key](#input\_sharedsvs\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key) | (Required) The log analytics workspace primary shared key. | `any` | `null` | no |
| <a name="input_sharedsvs_windows_vm_log_analytics_workspace_sentinel_id"></a> [sharedsvs\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id](#input\_sharedsvs\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id) | (Required) The log analytics workspace ID for diagnostics. | `string` | `"/subscriptions/0c22d89b-4687-4fa6-9eb4-979dcda22e7d/resourceGroups/us-rg-coreservices/providers/microsoft.operationalinsights/workspaces/us-law-coremonitoring"` | no |
| <a name="input_sharedsvs_wsus_vm_app_name"></a> [sharedsvs\_wsus\_vm\_app\_name](#input\_sharedsvs\_wsus\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `string` | `"wsus"` | no |
| <a name="input_sharedsvs_wsus_vm_computer_name"></a> [sharedsvs\_wsus\_vm\_computer\_name](#input\_sharedsvs\_wsus\_vm\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | n/a | yes |
| <a name="input_sharedsvs_wsus_vm_data_disk2_size"></a> [sharedsvs\_wsus\_vm\_data\_disk2\_size](#input\_sharedsvs\_wsus\_vm\_data\_disk2\_size) | (Required) size of managed data disk. | `string` | `"500"` | no |
| <a name="input_sharedsvs_wsus_vm_data_disk_size"></a> [sharedsvs\_wsus\_vm\_data\_disk\_size](#input\_sharedsvs\_wsus\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `string` | `"128"` | no |
| <a name="input_sharedsvs_wsus_vm_image_id"></a> [sharedsvs\_wsus\_vm\_image\_id](#input\_sharedsvs\_wsus\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvs_wsus_vm_os_disk_disk_size_gb"></a> [sharedsvs\_wsus\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvs\_wsus\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `string` | `"128"` | no |
| <a name="input_sharedsvs_wsus_vm_os_disk_storage_account_type"></a> [sharedsvs\_wsus\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvs\_wsus\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvs_wsus_vm_size"></a> [sharedsvs\_wsus\_vm\_size](#input\_sharedsvs\_wsus\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_B4ms"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"

  core_rg_keyvault_name          = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_first_remote_nva_pip = {
    "nprd-pr" = "52.138.102.104"    
    "prod-pr" = "137.135.105.155"   
    "prod-dr" = "104.42.249.54"
  }

  core_first_bgp_peering_address = {
    "nprd-pr" = "10.4.65.205"
    "prod-pr" = "10.47.129.203" 
    "prod-dr" = "10.47.161.203" 
  }

  core_first_connection_address_space = {
    "nprd-pr" = ["10.4.65.205/32"]
    "prod-pr" = ["10.47.129.203/32"]  
    "prod-dr" = ["10.47.161.203/32"]
  }

  core_second_remote_nva_pip = {
    "nprd-pr" = "52.138.102.58"   
    "prod-pr" = "137.135.105.219"
    "prod-dr" = "13.88.182.186"
  }

  core_second_bgp_peering_address = {
    "nprd-pr" = "10.4.65.206"
    "prod-pr" = "10.47.129.204"
    "prod-dr" = "10.47.161.204"
  }

  core_second_connection_address_space = {
    "nprd-pr" = ["10.4.65.206/32"]
    "prod-pr" = ["10.47.129.204/32"]
    "prod-dr" = ["10.47.161.204/32"]
  }

  core_remote_bgp_asn = {
    "nprd-pr" = "65200"   
    "prod-pr" = "65250"
    "prod-dr" = "65255"
  }

  core_bgp_asn = {
    "nprd-pr" = "65203"
    "prod-pr" = "65253"
    "prod-dr" = "65227"
  }

  core_subscription_diagnostics_settings = {
    logs    = ["Administrative", "Security", "ServiceHealth", "Alert", "Recommendation", "Policy", "Autoscale", "ResourceHealth"]
    metrics = []
  }

  core_vgw_diagnostics_settings = {
    logs    = ["GatewayDiagnosticLog", "IKEDiagnosticLog", "P2SDiagnosticLog", "RouteDiagnosticLog", "TunnelDiagnosticLog"]
    metrics = ["AllMetrics"]
  }

  core_vnet_diagnostics_settings = {
    logs    = ["VMProtectionAlerts"]
    metrics = ["AllMetrics"]
  }

  core_public_ip_diagnostics_settings = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }

   core_private_dns_zones = toset(var.core_private_dns_zone)
   
   core_shared_image_gallery_name = {
        "sbox-pr"  = "sboxpr"
        "nprd-pr"  = "nprdpr"
        "nprd-dr"  = "nprddr"
        "prod-pr"  = "prodpr" 
        "prod-dr"  = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_peering-sharedsvs-to-additional-ihub"></a> [peering-sharedsvs-to-additional-ihub](#output\_peering-sharedsvs-to-additional-ihub) | n/a |
| <a name="output_peering-sharedsvs-to-idty"></a> [peering-sharedsvs-to-idty](#output\_peering-sharedsvs-to-idty) | n/a |
| <a name="output_peering-sharedsvs-to-ihub"></a> [peering-sharedsvs-to-ihub](#output\_peering-sharedsvs-to-ihub) | n/a |
| <a name="output_sharedsvs_azure_acr_aksghshr_role_assigned"></a> [sharedsvs\_azure\_acr\_aksghshr\_role\_assigned](#output\_sharedsvs\_azure\_acr\_aksghshr\_role\_assigned) | n/a |
| <a name="output_sharedsvs_azure_aksghshr_role_assigned_contributor"></a> [sharedsvs\_azure\_aksghshr\_role\_assigned\_contributor](#output\_sharedsvs\_azure\_aksghshr\_role\_assigned\_contributor) | n/a |
| <a name="output_sharedsvs_azure_aksghshr_role_assigned_mi_operator"></a> [sharedsvs\_azure\_aksghshr\_role\_assigned\_mi\_operator](#output\_sharedsvs\_azure\_aksghshr\_role\_assigned\_mi\_operator) | n/a |
| <a name="output_sharedsvs_azure_bastion"></a> [sharedsvs\_azure\_bastion](#output\_sharedsvs\_azure\_bastion) | n/a |
| <a name="output_sharedsvs_azure_dns_aksghshr_role_assigned"></a> [sharedsvs\_azure\_dns\_aksghshr\_role\_assigned](#output\_sharedsvs\_azure\_dns\_aksghshr\_role\_assigned) | n/a |
| <a name="output_sharedsvs_azure_dns_resolver"></a> [sharedsvs\_azure\_dns\_resolver](#output\_sharedsvs\_azure\_dns\_resolver) | n/a |
| <a name="output_sharedsvs_azure_image_builder_association"></a> [sharedsvs\_azure\_image\_builder\_association](#output\_sharedsvs\_azure\_image\_builder\_association) | n/a |
| <a name="output_sharedsvs_azure_image_builder_nsg"></a> [sharedsvs\_azure\_image\_builder\_nsg](#output\_sharedsvs\_azure\_image\_builder\_nsg) | n/a |
| <a name="output_sharedsvs_azure_image_builder_nsg_nsgrule"></a> [sharedsvs\_azure\_image\_builder\_nsg\_nsgrule](#output\_sharedsvs\_azure\_image\_builder\_nsg\_nsgrule) | n/a |
| <a name="output_sharedsvs_azure_image_builder_subnet"></a> [sharedsvs\_azure\_image\_builder\_subnet](#output\_sharedsvs\_azure\_image\_builder\_subnet) | n/a |
| <a name="output_sharedsvs_azure_keyvault_aksghshr_role_assigned"></a> [sharedsvs\_azure\_keyvault\_aksghshr\_role\_assigned](#output\_sharedsvs\_azure\_keyvault\_aksghshr\_role\_assigned) | n/a |
| <a name="output_sharedsvs_azure_keyvault_spn_role_assigned"></a> [sharedsvs\_azure\_keyvault\_spn\_role\_assigned](#output\_sharedsvs\_azure\_keyvault\_spn\_role\_assigned) | n/a |
| <a name="output_sharedsvs_backup"></a> [sharedsvs\_backup](#output\_sharedsvs\_backup) | n/a |
| <a name="output_sharedsvs_bigfix_rg"></a> [sharedsvs\_bigfix\_rg](#output\_sharedsvs\_bigfix\_rg) | n/a |
| <a name="output_sharedsvs_bigfix_vm"></a> [sharedsvs\_bigfix\_vm](#output\_sharedsvs\_bigfix\_vm) | n/a |
| <a name="output_sharedsvs_bigfix_vm_admin_pass_secret_dr"></a> [sharedsvs\_bigfix\_vm\_admin\_pass\_secret\_dr](#output\_sharedsvs\_bigfix\_vm\_admin\_pass\_secret\_dr) | n/a |
| <a name="output_sharedsvs_bigfix_vm_admin_password"></a> [sharedsvs\_bigfix\_vm\_admin\_password](#output\_sharedsvs\_bigfix\_vm\_admin\_password) | n/a |
| <a name="output_sharedsvs_cl_azure_vm_image_builder"></a> [sharedsvs\_cl\_azure\_vm\_image\_builder](#output\_sharedsvs\_cl\_azure\_vm\_image\_builder) | n/a |
| <a name="output_sharedsvs_cl_windows_jumpbox_wvm"></a> [sharedsvs\_cl\_windows\_jumpbox\_wvm](#output\_sharedsvs\_cl\_windows\_jumpbox\_wvm) | n/a |
| <a name="output_sharedsvs_cribl_master_log_analytics_settings"></a> [sharedsvs\_cribl\_master\_log\_analytics\_settings](#output\_sharedsvs\_cribl\_master\_log\_analytics\_settings) | n/a |
| <a name="output_sharedsvs_cribl_vm_admin_pass_secret_dr"></a> [sharedsvs\_cribl\_vm\_admin\_pass\_secret\_dr](#output\_sharedsvs\_cribl\_vm\_admin\_pass\_secret\_dr) | n/a |
| <a name="output_sharedsvs_cribl_vm_admin_password"></a> [sharedsvs\_cribl\_vm\_admin\_password](#output\_sharedsvs\_cribl\_vm\_admin\_password) | n/a |
| <a name="output_sharedsvs_cribl_worker_log_analytics_settings"></a> [sharedsvs\_cribl\_worker\_log\_analytics\_settings](#output\_sharedsvs\_cribl\_worker\_log\_analytics\_settings) | n/a |
| <a name="output_sharedsvs_dns_zones"></a> [sharedsvs\_dns\_zones](#output\_sharedsvs\_dns\_zones) | n/a |
| <a name="output_sharedsvs_jumpbox_vm_nsg_nic_association"></a> [sharedsvs\_jumpbox\_vm\_nsg\_nic\_association](#output\_sharedsvs\_jumpbox\_vm\_nsg\_nic\_association) | n/a |
| <a name="output_sharedsvs_jumpbox_wvm_admin_pass_secret"></a> [sharedsvs\_jumpbox\_wvm\_admin\_pass\_secret](#output\_sharedsvs\_jumpbox\_wvm\_admin\_pass\_secret) | n/a |
| <a name="output_sharedsvs_jumpbox_wvm_admin_pass_secret_dr"></a> [sharedsvs\_jumpbox\_wvm\_admin\_pass\_secret\_dr](#output\_sharedsvs\_jumpbox\_wvm\_admin\_pass\_secret\_dr) | n/a |
| <a name="output_sharedsvs_jumpbox_wvm_admin_password"></a> [sharedsvs\_jumpbox\_wvm\_admin\_password](#output\_sharedsvs\_jumpbox\_wvm\_admin\_password) | n/a |
| <a name="output_sharedsvs_keyvault"></a> [sharedsvs\_keyvault](#output\_sharedsvs\_keyvault) | n/a |
| <a name="output_sharedsvs_log_analytics_workspace"></a> [sharedsvs\_log\_analytics\_workspace](#output\_sharedsvs\_log\_analytics\_workspace) | n/a |
| <a name="output_sharedsvs_machine_cribl_workers"></a> [sharedsvs\_machine\_cribl\_workers](#output\_sharedsvs\_machine\_cribl\_workers) | n/a |
| <a name="output_sharedsvs_mgmt_subnet"></a> [sharedsvs\_mgmt\_subnet](#output\_sharedsvs\_mgmt\_subnet) | n/a |
| <a name="output_sharedsvs_postprov_sa_container"></a> [sharedsvs\_postprov\_sa\_container](#output\_sharedsvs\_postprov\_sa\_container) | n/a |
| <a name="output_sharedsvs_postprov_storage_account"></a> [sharedsvs\_postprov\_storage\_account](#output\_sharedsvs\_postprov\_storage\_account) | ********************************************************************************************** |
| <a name="output_sharedsvs_private_link_subnet"></a> [sharedsvs\_private\_link\_subnet](#output\_sharedsvs\_private\_link\_subnet) | n/a |
| <a name="output_sharedsvs_ptrn_Kubernetes"></a> [sharedsvs\_ptrn\_Kubernetes](#output\_sharedsvs\_ptrn\_Kubernetes) | n/a |
| <a name="output_sharedsvs_ptrn_Kubernetes_user_assigned_identity"></a> [sharedsvs\_ptrn\_Kubernetes\_user\_assigned\_identity](#output\_sharedsvs\_ptrn\_Kubernetes\_user\_assigned\_identity) | n/a |
| <a name="output_sharedsvs_rg_azure_image_builder"></a> [sharedsvs\_rg\_azure\_image\_builder](#output\_sharedsvs\_rg\_azure\_image\_builder) | n/a |
| <a name="output_sharedsvs_rg_cribl"></a> [sharedsvs\_rg\_cribl](#output\_sharedsvs\_rg\_cribl) | n/a |
| <a name="output_sharedsvs_rg_data"></a> [sharedsvs\_rg\_data](#output\_sharedsvs\_rg\_data) | n/a |
| <a name="output_sharedsvs_rg_image_gallery"></a> [sharedsvs\_rg\_image\_gallery](#output\_sharedsvs\_rg\_image\_gallery) | n/a |
| <a name="output_sharedsvs_rg_logging"></a> [sharedsvs\_rg\_logging](#output\_sharedsvs\_rg\_logging) | n/a |
| <a name="output_sharedsvs_rg_network"></a> [sharedsvs\_rg\_network](#output\_sharedsvs\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_sharedsvs_rg_private_dns_zone"></a> [sharedsvs\_rg\_private\_dns\_zone](#output\_sharedsvs\_rg\_private\_dns\_zone) | n/a |
| <a name="output_sharedsvs_rg_security"></a> [sharedsvs\_rg\_security](#output\_sharedsvs\_rg\_security) | n/a |
| <a name="output_sharedsvs_route_table"></a> [sharedsvs\_route\_table](#output\_sharedsvs\_route\_table) | n/a |
| <a name="output_sharedsvs_route_table_SS_to_IHub"></a> [sharedsvs\_route\_table\_SS\_to\_IHub](#output\_sharedsvs\_route\_table\_SS\_to\_IHub) | n/a |
| <a name="output_sharedsvs_security_center_pricing"></a> [sharedsvs\_security\_center\_pricing](#output\_sharedsvs\_security\_center\_pricing) | n/a |
| <a name="output_sharedsvs_shared_image_gallery"></a> [sharedsvs\_shared\_image\_gallery](#output\_sharedsvs\_shared\_image\_gallery) | n/a |
| <a name="output_sharedsvs_virtual_machine_cribl_mstrs"></a> [sharedsvs\_virtual\_machine\_cribl\_mstrs](#output\_sharedsvs\_virtual\_machine\_cribl\_mstrs) | n/a |
| <a name="output_sharedsvs_vnet"></a> [sharedsvs\_vnet](#output\_sharedsvs\_vnet) | n/a |
| <a name="output_sharedsvs_windows_vm_nsg"></a> [sharedsvs\_windows\_vm\_nsg](#output\_sharedsvs\_windows\_vm\_nsg) | n/a |
| <a name="output_sharedsvs_windows_vm_nsg_subnet_association"></a> [sharedsvs\_windows\_vm\_nsg\_subnet\_association](#output\_sharedsvs\_windows\_vm\_nsg\_subnet\_association) | n/a |
| <a name="output_sharedsvs_wsus_vm"></a> [sharedsvs\_wsus\_vm](#output\_sharedsvs\_wsus\_vm) | n/a |
| <a name="output_sharedsvs_wsus_vm_admin_password"></a> [sharedsvs\_wsus\_vm\_admin\_password](#output\_sharedsvs\_wsus\_vm\_admin\_password) | n/a |
| <a name="output_sharedsvs_wsus_vm_admin_password_dr"></a> [sharedsvs\_wsus\_vm\_admin\_password\_dr](#output\_sharedsvs\_wsus\_vm\_admin\_password\_dr) | n/a |


## Usage

```terraform
data "azurerm_virtual_network" "core_data_shdsvc_vnet_ihub" {
  count               = var.sharedsvs_deploy_ihub_peering ? 1 : 0
  provider            = azurerm.ihub
  name                = "nprd-pr-ihubch-vnet"
  resource_group_name = "rg-nprd-pr-ihubch-network"
}
data "azurerm_virtual_network" "core_data_shdsvc_vnet_idty" {
  count               = var.sharedsvs_deploy_idty_peering ? 1 : 0
  provider            = azurerm.idty
  name                = "nprd-pr-idtych-vnet"
  resource_group_name = "rg-nprd-pr-idtych-network"
}


// Deploy the Latam Peninsula Core Platform in a Box
//********************************************************************************************
 module "core_latam_ch_peninsula_sharedsvs" {
  source                                                          = "../dn-tads_tf-azure-component-library/core/core_latam_ch_peninsula_sharedsvs"
  env                                                             = var.env
  postfix                                                         = var.postfix
  location                                                        = var.location
  hub_env                                                         = var.env
  sharedsvs_vnet_address_space                                    = var.sharedsvs_vnet_address_space
  sharedsvs_vnet_dns_servers                                      = var.sharedsvs_vnet_dns_servers
  sharedsvs_keyvault_postfix                                      = var.sharedsvs_keyvault_postfix
  sharedsvs_azure_defender_resources                              = var.sharedsvs_azure_defender_resources
  sharedsvs_private_link_subnet_address_prefixes                  = var.sharedsvs_private_link_subnet_address_prefixes
  sharedsvs_route_table_disable_bgp_propagation                   = var.sharedsvs_route_table_disable_bgp_propagation
  sharedsvs_azure_bastion_subnet_prefix                           = var.sharedsvs_azure_bastion_subnet_prefix
  sharedsvs_mgmt_sub_address_prefix                               = var.sharedsvs_mgmt_sub_address_prefix
  sharedsvs_imgbuilder_sub_address_prefix                         = var.sharedsvs_imgbuilder_sub_address_prefix
  sharedsvs_azure_vm_image_build_number                           = var.BUILD_NUMBER
  sharedsvs_azure_vm_image_builder_distribute_replicationRegions  = var.sharedsvs_azure_vm_image_builder_distribute_replicationRegions
  sharedsvs_windows_vm_deploy                                     = var.sharedsvs_windows_vm_deploy
  sharedsvs_windows_vm_jumpbox_computer_name                      = var.sharedsvs_windows_vm_jumpbox_computer_name
  sharedsvs_windows_vm_jumpbox_image_id                           = var.sharedsvs_vm_image_id
  sharedsvs_windows_vm_enable_domain_join                         = var.sharedsvs_windows_vm_enable_domain_join
  sharedsvs_windows_vm_domain_user_upn                            = var.DOMAIN_USER_LATAM_CH
  sharedsvs_windows_vm_domain_password                            = var.DOMAIN_PASSWORD_LATAM_CH
  sharedsvs_windows_vm_log_analytics_workspace_sentinel_id        = var.GLOBAL_CH_LAW_SENTINEL_ID
  sharedsvs_windows_vm_log_analytics_primary_sentinel_shared_key  = var.GLOBAL_CH_LAW_SENTINEL_SHARED_KEY
  sharedsvs_keyvault_nacl_allowed_ips                             = concat(var.sharedsvs_keyvault_nacl_allowed_ips, [var.GITHUBIP])
  sharedsvs_ptrn_kubernetes_deploy                                = var.sharedsvs_ptrn_kubernetes_deploy
  sharedsvs_ptrn_kubernetes_postfix                               = var.sharedsvs_ptrn_kubernetes_postfix
  sharedsvs_ptrn_kubernetes_subnet_nodes_address_prefixes         = var.sharedsvs_ptrn_kubernetes_subnet_nodes_address_prefixes
  sharedsvs_ptrn_kubernetes_kubernetes_version                    = var.sharedsvs_ptrn_kubernetes_kubernetes_version
  sharedsvs_ptrn_kubernetes_rbac_aad_admin_group_object_ids       = var.sharedsvs_ptrn_kubernetes_rbac_aad_admin_group_object_ids
  sharedsvs_azure_container_registry_georeplication_location      = var.sharedsvs_azure_container_registry_georeplication_location
  tags                                                            = var.tags  
  #Dns Resolver
  sharedsvs_azure_dns_resolver_subnet_inbound_prefix              = var.sharedsvs_azure_dns_resolver_subnet_inbound_prefix
  sharedsvs_azure_dns_resolver_subnet_outbound_prefix             = var.sharedsvs_azure_dns_resolver_subnet_outbound_prefix
  sharedsvs_azure_dns_resolver_forwarding_rule_onprem_domain_name = var.sharedsvs_azure_dns_resolver_forwarding_rule_onprem_domain_name
  sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address  = var.sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address
  sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address2 = var.sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address2
  #peering
  sharedsvs_to_idty_peering_network_id                            = var.sharedsvs_deploy_idty_peering ? data.azurerm_virtual_network.core_data_shdsvc_vnet_idty[0].id : null
  sharedsvs_to_ihub_peering_network_id                            = var.sharedsvs_deploy_ihub_peering ? data.azurerm_virtual_network.core_data_shdsvc_vnet_ihub[0].id : null
  ihub_internal_lb_private_ip_address                             = var.ihub_internal_lb_private_ip_address
  sharedsvs_deploy_ihub_peering                                   = var.sharedsvs_deploy_ihub_peering 
  sharedsvs_deploy_idty_peering                                   = var.sharedsvs_deploy_idty_peering
  #KV Secrets
  sharedsvs_vm_admin_username                                     = var.LOCAL_ADMIN_USER_VM
  #bigFixVms
  sharedsvs_bigfix_vm_computer_name                               = var.sharedsvs_bigfix_vm_computer_name //fix names
  sharedsvs_bigfix_vm_image_id                                    = var.sharedsvs_vm_image_id
  #wsus Vms
  sharedsvs_wsus_vm_computer_name                                 = var.sharedsvs_wsus_vm_computer_name
  sharedsvs_wsus_vm_image_id                                      = var.sharedsvs_vm_image_id
  #criblVms
  sharedsvs_crible_vm_deploy                                      = var.sharedsvs_crible_vm_deploy
  sharedsvs_cribl_local_user                                      = var.PA_USER_LATAM_CH
  cribl_worker_names                                              = var.cribl_worker_names
  cribl_master_names                                              = var.cribl_master_names
  cribl_backend_addesspool_associations_names                     = var.cribl_worker_names
  cribl                                                           = {
      vm_size                                                     = var.cribl.vm_size
      vm_prefix                                                   = var.cribl.vm_prefix
      vm_image_id                                                 = var.cribl.vm_image_id
      vm_publisher                                                = var.cribl.vm_publisher
      vm_offer                                                    = var.cribl.vm_offer
      vm_sku                                                      = var.cribl.vm_sku
      vm_version                                                  = var.cribl.vm_version
      vm_storage_os_disk_size                                     = var.cribl.vm_storage_os_disk_size
      vm_os                                                       = var.cribl.vm_os
      vm_from_marketplace                                         = var.cribl.vm_from_marketplace
    }
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
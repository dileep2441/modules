
## Usage

```terraform
// Deploy the US Gov Peninsula Ihub
//**********************************************************************************************
module "core_us_gov_ihub" {
    source                          = "../dn-tads_tf-azure-component-library/core/core_us_gov_ihub"   #"../dn-tads_tf-azure-gov_component-library/core/core_us_gov_ihub"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    suffix                          = var.suffix
    tags                            = var.tags
    ihub_vgw_lgw_conn_shared_key    = var.SHARED_KEY
    ihub_vnet_dns_servers           = var.ihub_vnet_dns_servers
    ihub_vnet_address_space         = var.ihub_vnet_address_space
    ihub_gateway_sub_address_prefix      = var.ihub_gateway_sub_address_prefix
    ihub_internal_sub_address_prefix     = var.ihub_internal_sub_address_prefix
    ihub_mgmt_sub_address_prefix         = var.ihub_mgmt_sub_address_prefix
    ihub_perimeter_sub_address_prefix    = var.ihub_perimeter_sub_address_prefix
    ihub_deploy_exproute_connection      = var.ihub_deploy_exproute_connection #true
    ihub_log_analytics_supported         = var.ihub_log_analytics_supported #true
    ihub_avail_zones_supported           = var.ihub_avail_zones_supported # true
    ihub_alt_log_analytics_workspace        = var.ihub_alt_log_analytics_workspace
    ihub_alt_log_analytics_workspace_id     = var.ihub_alt_log_analytics_workspace_id
    ihub_alt_log_analytics_workspace_name   = var.ihub_alt_log_analytics_workspace_name

    #Peering
    ihub_shared_services_peering_network_id    = var.ihub_shared_services_peering_network_id
    ihub_avd_peering_network_id                = var.ihub_avd_peering_network_id
    ihub_idty_peering_network_id               = var.ihub_idty_peering_network_id 
    ihub_deploy_avd_peering                    = var.ihub_deploy_avd_peering # true
    ihub_deploy_ss_peering                     = var.ihub_deploy_ss_peering # true
    ihub_deploy_idty_peering                   = var.ihub_deploy_idty_peering # true


    #NSGs
    ihub_nsg_storage_account_postfix            = var.ihub_nsg_storage_account_postfix

    #key vault
    ihub_rg_security_enable                                             = var.ihub_rg_security_enable  #true
    ihub_keyvault_enable                                                = var.ihub_keyvault_enable #true
    ihub_deploy_private_link_subnet                                     = var.ihub_deploy_private_link_subnet  #true
    ihub_private_link_subnet_address_prefixes                           = var.ihub_private_link_subnet_address_prefixes
    ihub_private_link_subnet_enforce_endpoint_network_policies          = var.ihub_private_link_subnet_enforce_endpoint_network_policies #true


    ihub_deploy_kv_secret                                              = var.ihub_deploy_kv_secret #true
    ihub_keyvault_nacl_allowed_subnets                                 = var.ihub_keyvault_nacl_allowed_subnets



    #Route table
    ihub_route_table_loopback_fw1_address_prefix = var.ihub_route_table_loopback_fw1_address_prefix
    ihub_route_table_loopback_fw2_address_prefix = var.ihub_route_table_loopback_fw2_address_prefix

    
    #VGW
    ihub_vgw_active_active                    = var.ihub_vgw_active_active #true
    ihub_vgw_enable_bgp                       = var.ihub_vgw_enable_bgp #true
    ihub_vgw_sku                              = var.ihub_vgw_sku
    ihub_vgw_enable_privateip                 = var.ihub_vgw_enable_privateip  #true
    ihub_local_azure_ip_address_enabled       = var.ihub_local_azure_ip_address_enabled #true
    ihub_first_remote_asr_private_ip          = var.ihub_first_remote_asr_private_ip  
    ihub_first_bgp_peering_address            = var.ihub_first_bgp_peering_address       
    ihub_second_remote_asr_private_ip         = var.ihub_second_remote_asr_private_ip 
    ihub_second_bgp_peering_address           = var.ihub_second_bgp_peering_address    
    ihub_first_remote_bgp_asn                 = var.ihub_first_remote_bgp_asn 
    ihub_second_remote_bgp_asn                = var.ihub_second_remote_bgp_asn
    ihub_bgp_asn                              = var.ihub_bgp_asn
    
    #boot diagnostics
    ihub_boot_storage_account_postfix              = var.ihub_boot_storage_account_postfix
    
    #express route
    ihub_exp_route_service_provider_name         = var.ihub_exp_route_service_provider_name
    ihub_exp_route_bandwidth_in_mbps             = var.ihub_exp_route_bandwidth_in_mbps
    ihub_exp_route_peering_location              = var.ihub_exp_route_peering_location
    ihub_exp_route_tier                          = var.ihub_exp_route_tier 
    ihub_exp_route_family                        = var.ihub_exp_route_family
    ihub_exp_route_primary_peer_address_prefix   = var.ihub_exp_route_primary_peer_address_prefix
    ihub_exp_route_secondary_peer_address_prefix = var.ihub_exp_route_secondary_peer_address_prefix
    ihub_exp_route_vlan_id                       = var.ihub_exp_route_vlan_id
    ihub_exp_route_peer_asn                      = var.ihub_exp_route_peer_asn
    ihub_exp_route_sku                           = var.ihub_exp_route_sku
    ihub_exp_route_active_active                 = var.ihub_exp_route_active_active #false
    ihub_exp_route_enable_bgp                    = var.ihub_exp_route_enable_bgp #false
    ihub_exp_route_circuit_peering_shared_key    = var.ihub_exp_route_circuit_peering_shared_key
    ihub_exp_route_circuit_peering_shared_key_avail = var.ihub_exp_route_circuit_peering_shared_key_avail #false

    
    #palo alto external LB
    ihub_external_lb_probe_protocol                = var.ihub_external_lb_probe_protocol
    ihub_external_lb_probe_port                    = var.ihub_external_lb_probe_port                    
    ihub_external_lb_rule_fe_ip_configuration_name = var.ihub_external_lb_rule_fe_ip_configuration_name
    ihub_external_lb_rule_protocol                 = var.ihub_external_lb_rule_protocol
    ihub_external_lb_rule_fe_port                  = var.ihub_external_lb_rule_fe_port
    ihub_external_lb_rule_be_port                  = var.ihub_external_lb_rule_be_port

    
    #palo alto internal LB
    ihub_internal_lb_probe_protocol                = var.ihub_internal_lb_probe_protocol
    ihub_internal_lb_probe_port                    = var.ihub_internal_lb_probe_port                     
    ihub_internal_lb_rule_fe_ip_configuration_name = var.ihub_internal_lb_rule_fe_ip_configuration_name 
    ihub_internal_lb_rule_protocol                 = var.ihub_internal_lb_rule_protocol
    ihub_internal_lb_rule_fe_port                  = var.ihub_internal_lb_rule_fe_port
    ihub_internal_lb_rule_be_port                  = var.ihub_internal_lb_rule_be_port
    ihub_internal_lb_private_ip_address            = var.ihub_internal_lb_private_ip_address    
    ihub_internal_lb_private_ip_address_allocation = var.ihub_internal_lb_private_ip_address_allocation

    #palo alto VMs
    ihub_PA_LOCAL_USER                         = var.ihub_PA_LOCAL_USER 
    ihub_PA_LOCAL_PASS                         = var.ihub_PA_LOCAL_PASS   
    paloalto = {
        wvd_count               = var.paloalto.wvd_count
        vm_size                 = var.paloalto.vm_size
        vm_prefix               = var.paloalto.vm_prefix
        vm_image_id             = var.paloalto.vm_image_id   
        vm_publisher            = var.paloalto.vm_publisher 
        vm_offer                = var.paloalto.vm_offer 
        vm_sku                  = var.paloalto.vm_sku
        vm_version              = var.paloalto.vm_version
        vm_storage_os_disk_size = var.paloalto.vm_storage_os_disk_size
        vm_os                   = var.paloalto.vm_os    
        vm_from_marketplace     = var.paloalto.vm_from_marketplace  
        management_privateip    = var.paloalto.management_privateip
        perimeter_privateip     = var.paloalto.perimeter_privateip
        internal_privateip      = var.paloalto.internal_privateip  
    }
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  count               = var.deploy_ihub_log_analytics_link_scoped_service ? 1 : 0
  depends_on          = [module.core_us_gov_ihub]
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.ihub_sharedsvcs_logging_rg, var.env)
  scope_name          = lookup(local.ihub_sharedsvcs_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = data.terraform_remote_state.core.outputs.core_us_gov_ihub.ihub_log_analytics_workspace[0].cl_log_analytics_workspace.id
}
//**********************************************************************************************

```
<!-- BEGIN_TF_DOCS -->

# Azure Core US Peninsula
This is the US Peninsula Core component for the US Peninsula spoke. It establishes a baseline cloud environment where other components can be deployed into.

#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified in a Github Action Task:
```Githubaction task
    - name: Setup Terraform
      uses: hashicorp/setup-terraform@v1
      with:
        terraform_version: ${{ env.TF_VERSION }}   
```
Specify TF version in `core_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.core_vnet_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_resource_group.core_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.core_default_internet_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.core_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_security_center_auto_provisioning.core_security_center_auto_provisioning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_auto_provisioning) | resource |
| [azurerm_security_center_contact.core_security_center_contact_info](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_contact) | resource |
| [azurerm_security_center_setting.core_security_center_wdatp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_setting) | resource |
| [azurerm_security_center_subscription_pricing.core_security_center_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_subnet.core_gateway_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.core_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_virtual_network.core_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.core_peering_avd](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.core_peering_identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.core_peering_ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.core_peering_sharedsvcs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_core_azure_backup_deploy_rsv"></a> [core\_azure\_backup\_deploy\_rsv](#input\_core\_azure\_backup\_deploy\_rsv) | (Optional) If true, deploy rsv. | `bool` | `true` | no |
| <a name="input_core_azure_backup_diagnostics"></a> [core\_azure\_backup\_diagnostics](#input\_core\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_core_azure_backup_enable_blob_storage_backup"></a> [core\_azure\_backup\_enable\_blob\_storage\_backup](#input\_core\_azure\_backup\_enable\_blob\_storage\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_enable_file_storage_backup"></a> [core\_azure\_backup\_enable\_file\_storage\_backup](#input\_core\_azure\_backup\_enable\_file\_storage\_backup) | (Optional) Toggle the file storage backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_enable_vm_backup"></a> [core\_azure\_backup\_enable\_vm\_backup](#input\_core\_azure\_backup\_enable\_vm\_backup) | (Optional) Toggle the vm backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_retention_daily_count"></a> [core\_azure\_backup\_retention\_daily\_count](#input\_core\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_core_azure_backup_rsv_allowed_subnets"></a> [core\_azure\_backup\_rsv\_allowed\_subnets](#input\_core\_azure\_backup\_rsv\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this RSV. | `list(string)` | `[]` | no |
| <a name="input_core_azure_backup_time"></a> [core\_azure\_backup\_time](#input\_core\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_core_azure_backup_timezone"></a> [core\_azure\_backup\_timezone](#input\_core\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_core_azure_defender_resources"></a> [core\_azure\_defender\_resources](#input\_core\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "VirtualMachines",<br>  "SqlServers",<br>  "StorageAccounts",<br>  "SqlServerVirtualMachines",<br>  "KubernetesService",<br>  "ContainerRegistry",<br>  "Dns",<br>  "Arm",<br>  "OpenSourceRelationalDatabases",<br>  "Containers"<br>]</pre> | no |
| <a name="input_core_deploy_private_link_subnet"></a> [core\_deploy\_private\_link\_subnet](#input\_core\_deploy\_private\_link\_subnet) | (Optional) A boolean to enable/disable the deployment of a private link subnet for the key vault. | `bool` | `true` | no |
| <a name="input_core_enable_sa_nsg_flow_logs"></a> [core\_enable\_sa\_nsg\_flow\_logs](#input\_core\_enable\_sa\_nsg\_flow\_logs) | (Optional) Toogle to deploy storage account to collect future NSG flow logs. (if any NSGs get deployed with pattern component) | `bool` | `false` | no |
| <a name="input_core_keyvault_allowed_pe_subnet_ids"></a> [core\_keyvault\_allowed\_pe\_subnet\_ids](#input\_core\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_az_svcs_bypass"></a> [core\_keyvault\_az\_svcs\_bypass](#input\_core\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_core_keyvault_diagnostics"></a> [core\_keyvault\_diagnostics](#input\_core\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_core_keyvault_enable"></a> [core\_keyvault\_enable](#input\_core\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `false` | no |
| <a name="input_core_keyvault_enabled_for_deployment"></a> [core\_keyvault\_enabled\_for\_deployment](#input\_core\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_disk_encryption"></a> [core\_keyvault\_enabled\_for\_disk\_encryption](#input\_core\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_template_deployment"></a> [core\_keyvault\_enabled\_for\_template\_deployment](#input\_core\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_core_keyvault_log_analytics_solutions"></a> [core\_keyvault\_log\_analytics\_solutions](#input\_core\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_core_keyvault_nacl_allowed_ips"></a> [core\_keyvault\_nacl\_allowed\_ips](#input\_core\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_nacl_allowed_subnets"></a> [core\_keyvault\_nacl\_allowed\_subnets](#input\_core\_keyvault\_nacl\_allowed\_subnets) | (Required)) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_nacl_default_action"></a> [core\_keyvault\_nacl\_default\_action](#input\_core\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_core_keyvault_privatelink_endpoint_name"></a> [core\_keyvault\_privatelink\_endpoint\_name](#input\_core\_keyvault\_privatelink\_endpoint\_name) | n/a | `string` | `"privatelink.vaultcore.usgovcloudapi.net"` | no |
| <a name="input_core_keyvault_purge_protection_enabled"></a> [core\_keyvault\_purge\_protection\_enabled](#input\_core\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_core_keyvault_sku_name"></a> [core\_keyvault\_sku\_name](#input\_core\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_core_keyvault_soft_delete_enabled"></a> [core\_keyvault\_soft\_delete\_enabled](#input\_core\_keyvault\_soft\_delete\_enabled) | (Optional) When soft-delete is enabled, resources marked as deleted resources are retained for a specified period (90 days by default). | `bool` | `true` | no |
| <a name="input_core_log_analytics_allowed_pe_subnet_ids"></a> [core\_log\_analytics\_allowed\_pe\_subnet\_ids](#input\_core\_log\_analytics\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this log analytics workspace. If private link SN not whitelisted. | `list(string)` | `[]` | no |
| <a name="input_core_private_link_subnet_address_prefixes"></a> [core\_private\_link\_subnet\_address\_prefixes](#input\_core\_private\_link\_subnet\_address\_prefixes) | (Optional) The address prefixes for the subnet of key vault. | `list(string)` | `[]` | no |
| <a name="input_core_private_link_subnet_enforce_endpoint_network_policies"></a> [core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Optional) | `bool` | `true` | no |
| <a name="input_core_private_link_subnet_service_endpoints"></a> [core\_private\_link\_subnet\_service\_endpoints](#input\_core\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault",<br>  "Microsoft.CognitiveServices"<br>]</pre> | no |
| <a name="input_core_rg_security_enable"></a> [core\_rg\_security\_enable](#input\_core\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to core\_rg\_data | `bool` | `false` | no |
| <a name="input_core_route_table_disable_bgp_propagation"></a> [core\_route\_table\_disable\_bgp\_propagation](#input\_core\_route\_table\_disable\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `true` | no |
| <a name="input_core_storage_account_allowed_pe_subnet_ids"></a> [core\_storage\_account\_allowed\_pe\_subnet\_ids](#input\_core\_storage\_account\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this storage account. If private link SN not whitelisted. | `list(string)` | `[]` | no |
| <a name="input_core_storage_account_allowed_vnet_subnet_ids"></a> [core\_storage\_account\_allowed\_vnet\_subnet\_ids](#input\_core\_storage\_account\_allowed\_vnet\_subnet\_ids) | (Optional) One or more vnet ID's which should be able to access through a private endpoint to this storage account. If private link SN not whitelisted. | `list(string)` | `[]` | no |
| <a name="input_core_vnet_address_space"></a> [core\_vnet\_address\_space](#input\_core\_vnet\_address\_space) | (Required) The address space for the virtual network. | `list(string)` | n/a | yes |
| <a name="input_core_vnet_diagnostics"></a> [core\_vnet\_diagnostics](#input\_core\_vnet\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_gateway_sub_address_prefix"></a> [gateway\_sub\_address\_prefix](#input\_gateway\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `list(string)` | n/a | yes |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"

  core_private_link_subnet          = var.core_deploy_private_link_subnet ? [azurerm_subnet.core_private_link_subnet[0].id]              : var.core_keyvault_allowed_pe_subnet_ids
  core_rg_keyvault_name             = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_shared_services_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/06ccb1fb-ef2a-4326-b4ac-b711af550383/resourceGroups/rg-nprd-pr-gov-ss-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-ss-vnet"
    "prod-pr" = "/subscriptions/e2c20008-581c-415b-8bac-9d0977a366d4/resourceGroups/rg-prod-pr-gov-ss-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-ss-vnet"
    "prod-dr" = "/subscriptions/c04bd4f1-2086-4239-b3f5-4416d6887497/resourceGroups/rg-prod-dr-gov-ss-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-ss-vnet"
  }
  core_ihub_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/a145edfd-936e-4975-bb9e-009b2f0009f2/resourceGroups/rg-nprd-pr-gov-ihub-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-ihub-vnet"
    "prod-pr" = "/subscriptions/b57f7ed5-9097-40b8-83db-79951eb7728f/resourceGroups/rg-prod-pr-gov-ihub-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-ihub-vnet"
    "prod-dr" = "/subscriptions/32250771-e46b-40e4-a3b1-25fe42a7d93e/resourceGroups/rg-prod-dr-gov-ihub-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-ihub-vnet"
  }

 core_identity_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-idt-vnet"
    "prod-pr" = "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-idt-vnet"
    "prod-dr" = "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-idt-vnet"
 }
 core_avd_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/192b9169-b57c-4384-a492-80080024e8da/resourceGroups/rg-nprd-pr-gov-avd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-avd-vnet"
    "prod-pr" = "/subscriptions/1d2c54f9-da67-49d7-8615-bf80dc3fdb12/resourceGroups/rg-prod-pr-gov-avd-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-avd-vnet"
    "prod-dr" = "/subscriptions/f2a37c8f-145a-4759-b737-95ca8718becb/resourceGroups/rg-prod-dr-gov-avd-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-avd-vnet"
 }
  core_default_internet_route_peninsula_next_hop_ip = {
      "nprd-pr" = "10.61.128.55"
      "prod-pr" = "10.61.160.55"
      "prod-dr" = "10.61.192.55"
    }
  core_vnet_dns_servers = {
      "nprd-pr" = ["10.61.132.36", "10.61.132.37"]
      "prod-pr" = ["10.61.164.39", "10.61.164.36", "10.61.196.36"]
      "prod-dr" = ["10.61.164.39", "10.61.164.36", "10.61.196.36"]
}
  core_identity_private_dns_zone_id_map = {
     "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
      "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
      "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
  }

}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_core_backup"></a> [core\_backup](#output\_core\_backup) | n/a |
| <a name="output_core_default_internet_route"></a> [core\_default\_internet\_route](#output\_core\_default\_internet\_route) | n/a |
| <a name="output_core_gateway_subnet"></a> [core\_gateway\_subnet](#output\_core\_gateway\_subnet) | n/a |
| <a name="output_core_keyvault"></a> [core\_keyvault](#output\_core\_keyvault) | n/a |
| <a name="output_core_log_analytics_workspace"></a> [core\_log\_analytics\_workspace](#output\_core\_log\_analytics\_workspace) | n/a |
| <a name="output_core_peering_ihub"></a> [core\_peering\_ihub](#output\_core\_peering\_ihub) | n/a |
| <a name="output_core_peering_sharedsvcs"></a> [core\_peering\_sharedsvcs](#output\_core\_peering\_sharedsvcs) | n/a |
| <a name="output_core_private_link_subnet"></a> [core\_private\_link\_subnet](#output\_core\_private\_link\_subnet) | n/a |
| <a name="output_core_rg_data"></a> [core\_rg\_data](#output\_core\_rg\_data) | n/a |
| <a name="output_core_rg_logging"></a> [core\_rg\_logging](#output\_core\_rg\_logging) | n/a |
| <a name="output_core_rg_network"></a> [core\_rg\_network](#output\_core\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_core_rg_security"></a> [core\_rg\_security](#output\_core\_rg\_security) | n/a |
| <a name="output_core_route_table"></a> [core\_route\_table](#output\_core\_route\_table) | n/a |
| <a name="output_core_security_center_pricing"></a> [core\_security\_center\_pricing](#output\_core\_security\_center\_pricing) | n/a |
| <a name="output_core_storage_account"></a> [core\_storage\_account](#output\_core\_storage\_account) | n/a |
| <a name="output_core_vnet"></a> [core\_vnet](#output\_core\_vnet) | n/a |



## Usage

#### Without Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                          = "/dn-tads_tf-azure-component-library/core/core_us_peninsula_gov"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    tags                            = var.tags
    hub_env                         = "nprd-pr"
    core_vnet_address_space         = ["10.0.1.0/24"]
    gateway_sub_address_prefix      = ["10.0.1.0/27"]
    core_enable_sa_nsg_flow_logs    = true/false 

    // (if core_enable_sa_nsg_flow_logs = true)
    core_storage_account_allowed_pe_subnet_ids = var.core_storage_account_allowed_pe_subnet_ids
    core_storage_account_allowed_vnet_subnet_ids  = var.core_storage_account_allowed_vnet_subnet_ids 
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.identity_sharedsvcs_logging_rg, var.env)
  scope_name          = lookup(local.identity_sharedsvcs_log_analytics_private_link_scope_name, var.env)
  depends_on          = [module.core_us_peninsula]
  linked_resource_id  = module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```

#### With Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                                                              = "/dn-tads_tf-azure-component-library/core/core_us_peninsula_gov"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    suffix                                                              = var.suffix
    tags                                                                = var.tags
    hub_env                                                             = "nprd-pr"
    core_vnet_address_space                                             = ["10.0.1.0/24"]
    gateway_sub_address_prefix                                          = ["10.0.1.0/27"]

    core_rg_security_enable                                             = true
    core_keyvault_enable                                                = true
    core_private_link_subnet_address_prefixes                           = var.core_private_link_subnet_address_prefixes  
    core_private_link_subnet_enforce_endpoint_network_policies          = true
    core_enable_sa_nsg_flow_logs                                        = true/false
    core_keyvault_nacl_allowed_subnets                                  = []
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_gov
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_gov_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_gov_log_analytics_private_link_scope_name, var.env)
  depends_on          = [module.core_us_peninsula]
  linked_resource_id  =  module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```

#### With Service Vault VM and Blob Backup Enabled
```terraform
module "core_us_peninsula" {
    source                                                              = "../dn-tads_tf-azure-component-library/core/core_us_peninsula_gov"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    suffix                                                              = var.suffix
    tags                                                                = var.tags
    hub_env                                                             = var.hub_env #"nprd-pr"
    core_vnet_address_space                                             = var.core_vnet_address_space #["10.61.154.0/24"]
    gateway_sub_address_prefix                                          = var.gateway_sub_address_prefix #["10.61.154.0/27"]


    core_rg_security_enable                                             = true
    core_keyvault_enable                                                = true
    core_private_link_subnet_address_prefixes                           = var.core_private_link_subnet_address_prefixes  # ["10.61.154.32/27"]
    core_private_link_subnet_enforce_endpoint_network_policies          = true
    core_enable_sa_nsg_flow_logs                                        = true
    core_keyvault_nacl_allowed_subnets                                  = var.core_keyvault_nacl_allowed_subnets #[]
    
    core_azure_backup_deploy_rsv                                        = true 
    core_azure_backup_enable_vm_backup                                  = true
    core_azure_backup_enable_file_storage_backup                        = false
    core_azure_backup_enable_blob_storage_backup                        = true
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_gov
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_gov_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_gov_log_analytics_private_link_scope_name, var.env)
  depends_on          = [module.core_us_peninsula]
  linked_resource_id  =  module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```

#### Complete the Peering connection, the SPN must have network contributor role over SharedServices, Ihub, Identity and AVD virtual network
```terraform
# Define the providers
provider "azurerm" {
  alias           = "shs"
  version         = "3.6.0"
  subscription_id = lookup(local.core_shared_services_gov_id_map, var.env)
  environment     = "usgovernment"
  features {}
      skip_provider_registration = true
}

provider "azurerm" {
  alias           = "ihub"
  version         = "3.6.0"
  subscription_id = lookup(local.core_ihub_gov_id_map, var.env)
  environment     = "usgovernment"
  features {}
      skip_provider_registration = true
}

provider "azurerm" {
  alias           = "idty"
  version         = "3.6.0"
  subscription_id = lookup(local.core_idty_gov_id_map, var.env)
  environment     = "usgovernment"
  features {}
      skip_provider_registration = true
}

#Complete the peering
// Complete the Peerring SharedServices to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "sharedsvcs_peering_core" {
 provider                     = azurerm.shs
 name                         = "peer-to-${var.postfix}-vnet"
 resource_group_name          = lookup(local.core_shared_services_gov_resource_group_map, var.env)  
 virtual_network_name         = lookup(local.core_shared_services_gov_network_name_map, var.env) 
 remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
 allow_virtual_network_access = true
 allow_forwarded_traffic      = true
 use_remote_gateways          = false

 #allow_gateway_transit' must be set to false for vnet Global Peering
 allow_gateway_transit = false

 timeouts {
   create = local.timeout_duration
   delete = local.timeout_duration
 }
 depends_on          = [module.core_us_peninsula]
}
//**********************************************************************************************

// Complete Peering Identity to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "idty_peering_spoke" {
  provider                     = azurerm.idty
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_idty_gov_resource_group_name_map, var.env)
  virtual_network_name         = lookup(local.core_idty_gov_resource_network_name_map, var.env)
  remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = false

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
  depends_on          = [module.core_us_peninsula]
}
//**********************************************************************************************

// Complete Peering Ihub to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "ihub_peering_spoke" {
  provider                     = azurerm.ihub
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_ihub_gov_resource_group_name_map, var.env)
  virtual_network_name         = lookup(local.core_ihub_gov_resource_network_name_map, var.env)
  remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = true

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
  depends_on          =    [module.core_us_peninsula]
}
//**********************************************************************************************




```
<!-- END_TF_DOCS -->
## Local values

```terraform
locals {
  timeout_duration = "2h"

  core_private_link_subnet          = var.core_deploy_private_link_subnet ? [azurerm_subnet.core_private_link_subnet[0].id]              : var.core_keyvault_allowed_pe_subnet_ids
  core_rg_keyvault_name             = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_shared_services_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/06ccb1fb-ef2a-4326-b4ac-b711af550383/resourceGroups/rg-nprd-pr-gov-ss-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-ss-vnet"
    "prod-pr" = "/subscriptions/e2c20008-581c-415b-8bac-9d0977a366d4/resourceGroups/rg-prod-pr-gov-ss-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-ss-vnet"
    "prod-dr" = "/subscriptions/c04bd4f1-2086-4239-b3f5-4416d6887497/resourceGroups/rg-prod-dr-gov-ss-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-ss-vnet"
  }
  core_ihub_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/a145edfd-936e-4975-bb9e-009b2f0009f2/resourceGroups/rg-nprd-pr-gov-ihub-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-ihub-vnet"
    "prod-pr" = "/subscriptions/b57f7ed5-9097-40b8-83db-79951eb7728f/resourceGroups/rg-prod-pr-gov-ihub-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-ihub-vnet"
    "prod-dr" = "/subscriptions/32250771-e46b-40e4-a3b1-25fe42a7d93e/resourceGroups/rg-prod-dr-gov-ihub-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-ihub-vnet"
  }

 core_identity_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-idt-vnet"
    "prod-pr" = "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-idt-vnet"
    "prod-dr" = "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-idt-vnet"
 }
 core_avd_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/192b9169-b57c-4384-a492-80080024e8da/resourceGroups/rg-nprd-pr-gov-avd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-gov-avd-vnet"
    "prod-pr" = "/subscriptions/1d2c54f9-da67-49d7-8615-bf80dc3fdb12/resourceGroups/rg-prod-pr-gov-avd-network/providers/Microsoft.Network/virtualNetworks/prod-pr-gov-avd-vnet"
    "prod-dr" = "/subscriptions/f2a37c8f-145a-4759-b737-95ca8718becb/resourceGroups/rg-prod-dr-gov-avd-network/providers/Microsoft.Network/virtualNetworks/prod-dr-gov-avd-vnet"
 }
  core_default_internet_route_peninsula_next_hop_ip = {
      "nprd-pr" = "10.61.128.55"
      "prod-pr" = "10.61.160.55"
      "prod-dr" = "10.61.192.55"
    }
  core_vnet_dns_servers = {
      "nprd-pr" = ["10.61.132.36", "10.61.132.37"]
      "prod-pr" = ["10.61.164.39", "10.61.164.36", "10.61.196.36"]
      "prod-dr" = ["10.61.164.39", "10.61.164.36", "10.61.196.36"]
}
  core_identity_private_dns_zone_id_map = {
     "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
      "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
      "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
  }

}
```


<!-- BEGIN_TF_DOCS -->

# Core LATAM Peninsula

This is the LATAM Peninsula Core component for the LATAM Peninsula spoke. It establishes a baseline cloud environment where other components can be deployed into.
Specifically the core module lays the foundational infrastructure required to establish network connectivity of the Azure cloud resources to the KPMG infrastructure.
This module deploys vnets, vnet peering, route tables, network gateways, key vault, log analytics workspace, security center, public IPs, etc.

#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified on Jenkinsfile:
```jenkinsfile
stage("Terraform *** ") {
    agent {
        docker {
            image 'dn-cloud-docker.artifactory.us.kworld.kpmg.com/azure-terraform-0-15-4:latest'
            ...
```
Specify TF version in `core_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```

## Resources

| Name | Type |
|------|------|
| [azurerm_private_dns_zone.core_keyvault_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.keyvault_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_resource_group.core_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.core_default_internet_route_peninsula](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.core_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_security_center_auto_provisioning.core_security_center_auto_provisioning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_auto_provisioning) | resource |
| [azurerm_security_center_contact.core_security_center_contact_info](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_contact) | resource |
| [azurerm_security_center_setting.core_security_center_wdatp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_setting) | resource |
| [azurerm_security_center_subscription_pricing.core_security_center_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_subnet.core_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_virtual_network.core_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.core_internet_hub_peering](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.core_shared_services_peering](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_core_azure_backup_deploy_rsv"></a> [core\_azure\_backup\_deploy\_rsv](#input\_core\_azure\_backup\_deploy\_rsv) | (Optional) If true, deploy rsv. | `bool` | `true` | no |
| <a name="input_core_azure_backup_diagnostics"></a> [core\_azure\_backup\_diagnostics](#input\_core\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_core_azure_backup_enable_blob_storage_backup"></a> [core\_azure\_backup\_enable\_blob\_storage\_backup](#input\_core\_azure\_backup\_enable\_blob\_storage\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_enable_file_storage_backup"></a> [core\_azure\_backup\_enable\_file\_storage\_backup](#input\_core\_azure\_backup\_enable\_file\_storage\_backup) | (Optional) Toggle the file storage backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_enable_vm_backup"></a> [core\_azure\_backup\_enable\_vm\_backup](#input\_core\_azure\_backup\_enable\_vm\_backup) | (Optional) Toggle the vm backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_retention_daily_count"></a> [core\_azure\_backup\_retention\_daily\_count](#input\_core\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_core_azure_backup_time"></a> [core\_azure\_backup\_time](#input\_core\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_core_azure_backup_timezone"></a> [core\_azure\_backup\_timezone](#input\_core\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_core_azure_defender_resources"></a> [core\_azure\_defender\_resources](#input\_core\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "VirtualMachines",<br>  "AppServices",<br>  "ContainerRegistry",<br>  "KeyVaults",<br>  "KubernetesService",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns"<br>]</pre> | no |
| <a name="input_core_keyvault_allowed_pe_subnet_ids"></a> [core\_keyvault\_allowed\_pe\_subnet\_ids](#input\_core\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_az_svcs_bypass"></a> [core\_keyvault\_az\_svcs\_bypass](#input\_core\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_core_keyvault_deploy_private_dns_zone"></a> [core\_keyvault\_deploy\_private\_dns\_zone](#input\_core\_keyvault\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the key vault private endpoint. | `bool` | `false` | no |
| <a name="input_core_keyvault_diagnostics"></a> [core\_keyvault\_diagnostics](#input\_core\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_core_keyvault_enable"></a> [core\_keyvault\_enable](#input\_core\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `false` | no |
| <a name="input_core_keyvault_enabled_for_deployment"></a> [core\_keyvault\_enabled\_for\_deployment](#input\_core\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_disk_encryption"></a> [core\_keyvault\_enabled\_for\_disk\_encryption](#input\_core\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_template_deployment"></a> [core\_keyvault\_enabled\_for\_template\_deployment](#input\_core\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_core_keyvault_log_analytics_solutions"></a> [core\_keyvault\_log\_analytics\_solutions](#input\_core\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_core_keyvault_nacl_allowed_ips"></a> [core\_keyvault\_nacl\_allowed\_ips](#input\_core\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_nacl_allowed_subnets"></a> [core\_keyvault\_nacl\_allowed\_subnets](#input\_core\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_nacl_default_action"></a> [core\_keyvault\_nacl\_default\_action](#input\_core\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_core_keyvault_postfix"></a> [core\_keyvault\_postfix](#input\_core\_keyvault\_postfix) | ((Optional) The bespoke name of the kv app or project you are deploying. | `string` | `null` | no |
| <a name="input_core_keyvault_private_dns_zone_ids"></a> [core\_keyvault\_private\_dns\_zone\_ids](#input\_core\_keyvault\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_purge_protection_enabled"></a> [core\_keyvault\_purge\_protection\_enabled](#input\_core\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_core_keyvault_sku_name"></a> [core\_keyvault\_sku\_name](#input\_core\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_core_private_link_subnet_address_prefixes"></a> [core\_private\_link\_subnet\_address\_prefixes](#input\_core\_private\_link\_subnet\_address\_prefixes) | (Optional) The address prefixes for the subnet of key vault. | `list(string)` | `[]` | no |
| <a name="input_core_private_link_subnet_enforce_endpoint_network_policies"></a> [core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Optional) | `bool` | `true` | no |
| <a name="input_core_private_link_subnet_service_endpoints"></a> [core\_private\_link\_subnet\_service\_endpoints](#input\_core\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | `[]` | no |
| <a name="input_core_rg_security_enable"></a> [core\_rg\_security\_enable](#input\_core\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to core\_rg\_data | `bool` | `false` | no |
| <a name="input_core_route_table_bgp_propagation"></a> [core\_route\_table\_bgp\_propagation](#input\_core\_route\_table\_bgp\_propagation) | (Optional) A boolean variable indicating if the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `false` | no |
| <a name="input_core_vnet_address_space"></a> [core\_vnet\_address\_space](#input\_core\_vnet\_address\_space) | (Required) The address space for the virtual network. | `list` | n/a | yes |
| <a name="input_core_vnet_dns_servers"></a> [core\_vnet\_dns\_servers](#input\_core\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left null, defaults to Azure servers. | `any` | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_core_backup"></a> [core\_backup](#output\_core\_backup) | n/a |
| <a name="output_core_default_internet_route_peninsula"></a> [core\_default\_internet\_route\_peninsula](#output\_core\_default\_internet\_route\_peninsula) | n/a |
| <a name="output_core_internet_hub_peering"></a> [core\_internet\_hub\_peering](#output\_core\_internet\_hub\_peering) | n/a |
| <a name="output_core_keyvault"></a> [core\_keyvault](#output\_core\_keyvault) | n/a |
| <a name="output_core_keyvault_azure_private_dns_zone"></a> [core\_keyvault\_azure\_private\_dns\_zone](#output\_core\_keyvault\_azure\_private\_dns\_zone) | n/a |
| <a name="output_core_log_analytics_workspace"></a> [core\_log\_analytics\_workspace](#output\_core\_log\_analytics\_workspace) | n/a |
| <a name="output_core_private_link_subnet"></a> [core\_private\_link\_subnet](#output\_core\_private\_link\_subnet) | n/a |
| <a name="output_core_rg_data"></a> [core\_rg\_data](#output\_core\_rg\_data) | n/a |
| <a name="output_core_rg_logging"></a> [core\_rg\_logging](#output\_core\_rg\_logging) | n/a |
| <a name="output_core_rg_network"></a> [core\_rg\_network](#output\_core\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_core_rg_security"></a> [core\_rg\_security](#output\_core\_rg\_security) | n/a |
| <a name="output_core_route_table"></a> [core\_route\_table](#output\_core\_route\_table) | n/a |
| <a name="output_core_security_center_auto_provisioning"></a> [core\_security\_center\_auto\_provisioning](#output\_core\_security\_center\_auto\_provisioning) | n/a |
| <a name="output_core_security_center_pricing"></a> [core\_security\_center\_pricing](#output\_core\_security\_center\_pricing) | n/a |
| <a name="output_core_shared_services_peering"></a> [core\_shared\_services\_peering](#output\_core\_shared\_services\_peering) | n/a |
| <a name="output_core_vnet"></a> [core\_vnet](#output\_core\_vnet) | n/a |

## Usage

#### Without Core Key Vault enabled 
```terraform
module "core_latam_peninsula" {
    source                          = "../tf-azure-component-library/core/core_latam_peninsula"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    core_vnet_address_space         = ["10.0.0.0/16"]
}
```

#### With Core Key Vault enabled 
```terraform
module "core_latam_peninsula" {
  source                                                              = "../tf-azure-component-library/core/core_latam_peninsula"
  env                                                                 = var.env
  postfix                                                             = var.postfix
  location                                                            = var.location
  core_vnet_address_space                                             = ["10.0.0.0/16"]

  core_rg_security_enable                                             = true
  core_keyvault_enable                                                = true
  core_private_link_subnet_address_prefixes                           = var.subnet_address_prefixes
  core_private_link_subnet_enforce_endpoint_network_policies          = true
  core_keyvault_nacl_allowed_ips                                      = ["199.207.253.96","199.206.0.0/15","199.207.253.101"]
}
```
<!-- END_TF_DOCS -->
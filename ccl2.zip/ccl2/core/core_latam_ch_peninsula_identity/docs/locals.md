## Local values

```terraform
locals {
  resource_name_no_dash    = replace("${var.env}${var.postfix}${var.suffix}", "-", "")

  timeout_duration = "2h"

  #KeyVault
  identity_rg_keyvault_name            = var.identity_keyvault_enable && var.identity_rg_security_enable ?  azurerm_resource_group.identity_rg_security[0].name  : azurerm_resource_group.identity_rg_data.name
  identity_private_link_subnet          = var.identity_deploy_private_link_subnet ? [azurerm_subnet.identity_private_link_subnet[0].id]              : var.identity_keyvault_allowed_pe_subnet_ids

  identity_private_dns_zone_id_map = {
   "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
   "prod-pr" = [""]
   "prod-dr" = [""]
  }

  private_dns_zones = [
    "privatelink.${var.dns_location}.database.usgovcloudapi.net",
    "privatelink.${var.dns_location}.batch.usgovcloudapi.net",
    "privatelink.${var.dns_location}.backup.windowsazure.us",
    "privatelink.azure-automation.us",
    "privatelink.database.usgovcloudapi.net",
    "privatelink.blob.core.usgovcloudapi.net",
    "privatelink.table.core.usgovcloudapi.net",
    "privatelink.queue.core.usgovcloudapi.net",
    "privatelink.file.core.usgovcloudapi.net",
    "privatelink.web.core.usgovcloudapi.net",
    "privatelink.documents.azure.us",
    "privatelink.postgres.database.usgovcloudapi.net",
    "privatelink.mysql.database.usgovcloudapi.net",
    "privatelink.mariadb.database.usgovcloudapi.net",
    "privatelink.vaultcore.usgovcloudapi.net",
    "privatelink.search.windows.us",
    "privatelink.azconfig.azure.us",
    "privatelink.siterecovery.windowsazure.us",
	  "privatelink.servicebus.windows.us1",
    "privatelink.servicebus.usgovcloudapi.net",
    "privatelink.azure-devices.us",
	  "privatelink.oms.opinsights.azure.us",
	  "privatelink.ods.opinsights.azure.us",
    "privatelink.azurewebsites.us",
	  "privatelink.cognitiveservices.azure.us",
    "privatelink.adx.monitor.azure.us",
    "privatelink.agentsvc.azure-automation.us",
    "privatelink.redis.cache.usgovcloudapi.net",
    "privatelink.azurehdinsight.us",
    "privatelink.azurecr.us",
    "privatelink.mongo.cosmos.azure.us",
    "privatelink.dfs.core.usgovcloudapi.net",
    "privatelink.azuresynapse.usgovcloudapi.net",
    "privatelink.dev.azuresynapse.usgovcloudapi.net",
    "privatelink.sql.azuresynapse.usgovcloudapi.net",
    "privatelink.${var.dns_aks_location}.cx.aks.containerservice.azure.us",
    "privatelink.datafactory.azure.us",
    "privatelink.adf.azure.us",
    "privatelink.monitor.azure.us",
  ]

  custom_data = <<CUSTOM_DATA
  temp_license: TE-SoT
  default_admin_password: '${var.identity_dns_vm_admin_pass}'
  CUSTOM_DATA
}
//**********************************************************************************************

```


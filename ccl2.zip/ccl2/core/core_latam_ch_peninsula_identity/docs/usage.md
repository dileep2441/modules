
## Usage

```terraform
data "azurerm_virtual_network" "core_data_shdsvc_vnet_idty" {
  count               = var.identity_deploy_ss_peering ? 1 : 0
  provider            = azurerm.shs
  name                = "nprd-pr-shdsvsch-vnet"
  resource_group_name = "rg-nprd-pr-shdsvsch-network"
}
data "azurerm_virtual_network" "core_data_idty_vnet_ihub" {
  count               = var.identity_deploy_ihub_peering ? 1 : 0
  provider            = azurerm.ihub
  name                = "nprd-pr-ihubch-vnet"
  resource_group_name = "rg-nprd-pr-ihubch-network"
}

// Deploy the Latam Peninsula Core Platform in a Box
//********************************************************************************************
 module "core_latam_ch_peninsula_identity" {
    source                                                        = "../dn-tads_tf-azure-component-library/core/core_latam_ch_peninsula_identity"
    env                                                           = var.env
    postfix                                                       = var.postfix
    location                                                      = var.location
    hub_env                                                       = var.env
    tags                                                          = var.tags
    identity_vnet_dns_servers                                     = var.identity_vnet_dns_servers
    identity_vnet_address_space                                   = var.identity_vnet_address_space
    identity_dc_sub_address_prefix                                = var.identity_dc_sub_address_prefix
    identity_private_link_subnet_address_prefixes                 = var.identity_private_link_subnet_address_prefixes
    identity_bastion_sub_address_prefix                           = var.identity_bastion_sub_address_prefix
    identity_azure_defender_resources                             = var.identity_azure_defender_resources
    identity_dc_vm_image_id                                       = var.identity_dc_vm_image_id
    identity_dc_vm_computer_name                                  = var.identity_dc_vm_computer_name
    identity_dc_vm_admin_user                                     = var.LOCAL_ADMIN_USER_VM
    identity_ss_mgmt_address_prefix                               = var.identity_ss_mgmt_address_prefix
    #Peering
    identity_to_sharedsvcs_peering_network_id                     = var.identity_deploy_ss_peering ? data.azurerm_virtual_network.core_data_shdsvc_vnet_idty[0].id : null
    identity_to_ihub_peering_network_id                           = var.identity_deploy_ihub_peering ? data.azurerm_virtual_network.core_data_idty_vnet_ihub[0].id : null
    identity_deploy_ss_peering                                    = var.identity_deploy_ss_peering 
    identity_deploy_ihub_peering                                  = var.identity_deploy_ihub_peering 
    #key vault
    identity_keyvault_postfix                                     = var.identity_keyvault_postfix
    identity_keyvault_nacl_allowed_ips                            = concat(var.identity_keyvault_nacl_allowed_ips, [var.GITHUBIP])
    identity_keyvault_private_dns_zone_ids                        = var.identity_keyvault_private_dns_zone_ids 
    # needs sentinel configuration
    identity_windows_vm_log_analytics_workspace_sentinel_id       = var.GLOBAL_CH_LAW_SENTINEL_ID
    identity_windows_vm_log_analytics_primary_sentinel_shared_key = var.GLOBAL_CH_LAW_SENTINEL_SHARED_KEY
    identity_windows_vm_data_collection_rule_endpoint_windows     = var.identity_windows_vm_data_collection_rule_endpoint_windows
    identity_default_internet_route_peninsula_next_hop_ip         = var.identity_default_internet_route_peninsula_next_hop_ip
}
//**********************************************************************************************
```
<!-- BEGIN_TF_DOCS -->

# Azure Identity LATAM CH Platform in a Box Module
Non-Prod and Production tenants will be hosting Domain Controllers and Azure AD Connect Sync VMs. A dedicate subscription will be allocated to support Active Directory Domain Services and Azure AD. Azure Files enforces authorization on user access to both the share and the directory/file levels. Share-level permission assignment can be performed on Azure Active Directory (Azure AD) users or groups managed through the Azure role-based access control (Azure RBAC) model. Latam Country Hosting Platform is will deployed from slingshot tool.



## Resources

| Name | Type |
|------|------|
| [azurerm_availability_set.identity_dc_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_key_vault_secret.secret-domain-controllers-password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-domain-controllers-username_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_monitor_data_collection_rule.log_analytics_data_collection_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_data_collection_rule) | resource |
| [azurerm_network_security_group.identity_dc_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.AD_WebServices](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Allow_BastionHost_Communication](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.CIFS_SMB_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.CIFS_SMB_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DC-Service-Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DFSN_Netlogon](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DFSN_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DFSN_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.IIQ_6060_Service_Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_PWD_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_PWD_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAPS_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAPS_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_GC](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_GC_Secure](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.NetBIOS_NS_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.NetBIOS_NS_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.RPC](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.RPCEPM](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.W32Time](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.dns_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.dns_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.exchange_Service_Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.sharedsvs_vm_azure_DC_Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_resource_group.identity_dc_vm_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.identity_azure_keyvault_spn_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_route.identity_default_colombia_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route.identity_default_internet_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.identity_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_subnet.identity_dc_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.identity_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.identity_dc_subnet_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.identity_dc_vm_route_table_associate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_network.identity_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.identity_additional_peering_ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.identity_peering_ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.identity_peering_sharedsvcs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [random_password.identity_dc_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_enable_Allow_Exchange_IAM_Mgmt_Rule"></a> [enable\_Allow\_Exchange\_IAM\_Mgmt\_Rule](#input\_enable\_Allow\_Exchange\_IAM\_Mgmt\_Rule) | n/a | `bool` | `false` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_identity_alt_log_analytics_vm_workspace_id"></a> [identity\_alt\_log\_analytics\_vm\_workspace\_id](#input\_identity\_alt\_log\_analytics\_vm\_workspace\_id) | (Optional) workspace ID of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_alt_log_analytics_workspace_id"></a> [identity\_alt\_log\_analytics\_workspace\_id](#input\_identity\_alt\_log\_analytics\_workspace\_id) | (Optional) resource ID of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_alt_log_analytics_workspace_name"></a> [identity\_alt\_log\_analytics\_workspace\_name](#input\_identity\_alt\_log\_analytics\_workspace\_name) | (Optional) name of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_alt_log_analytics_workspace_primary_shared_key"></a> [identity\_alt\_log\_analytics\_workspace\_primary\_shared\_key](#input\_identity\_alt\_log\_analytics\_workspace\_primary\_shared\_key) | (Optional) primary shared key of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_azure_defender_resources"></a> [identity\_azure\_defender\_resources](#input\_identity\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "AppServices",<br>  "ContainerRegistry",<br>  "KeyVaults",<br>  "KubernetesService",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns"<br>]</pre> | no |
| <a name="input_identity_bastion_sub_address_prefix"></a> [identity\_bastion\_sub\_address\_prefix](#input\_identity\_bastion\_sub\_address\_prefix) | (Required) The prefix of the azure bastion subnet. | `list(string)` | n/a | yes |
| <a name="input_identity_dc_prod_dr_sub_address_prefix"></a> [identity\_dc\_prod\_dr\_sub\_address\_prefix](#input\_identity\_dc\_prod\_dr\_sub\_address\_prefix) | n/a | `list(string)` | `[]` | no |
| <a name="input_identity_dc_sn_nsg_include_dr"></a> [identity\_dc\_sn\_nsg\_include\_dr](#input\_identity\_dc\_sn\_nsg\_include\_dr) | n/a | `bool` | `false` | no |
| <a name="input_identity_dc_sub_address_prefix"></a> [identity\_dc\_sub\_address\_prefix](#input\_identity\_dc\_sub\_address\_prefix) | (Required) The address prefix for the DCs subnet. | `string` | n/a | yes |
| <a name="input_identity_dc_vm_admin_user"></a> [identity\_dc\_vm\_admin\_user](#input\_identity\_dc\_vm\_admin\_user) | (Optional) local admin user | `string` | n/a | yes |
| <a name="input_identity_dc_vm_computer_name"></a> [identity\_dc\_vm\_computer\_name](#input\_identity\_dc\_vm\_computer\_name) | (Optional) app name. | `list(string)` | n/a | yes |
| <a name="input_identity_dc_vm_data_disk_size"></a> [identity\_dc\_vm\_data\_disk\_size](#input\_identity\_dc\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `string` | `"512"` | no |
| <a name="input_identity_dc_vm_image_id"></a> [identity\_dc\_vm\_image\_id](#input\_identity\_dc\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_identity_dc_vm_logging_disk_size"></a> [identity\_dc\_vm\_logging\_disk\_size](#input\_identity\_dc\_vm\_logging\_disk\_size) | (Required) size of managed logging disk. | `string` | `"64"` | no |
| <a name="input_identity_dc_vm_os_disk_disk_size_gb"></a> [identity\_dc\_vm\_os\_disk\_disk\_size\_gb](#input\_identity\_dc\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `string` | `"256"` | no |
| <a name="input_identity_dc_vm_os_disk_storage_account_type"></a> [identity\_dc\_vm\_os\_disk\_storage\_account\_type](#input\_identity\_dc\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_identity_dc_vm_size"></a> [identity\_dc\_vm\_size](#input\_identity\_dc\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_E4s_v3"` | no |
| <a name="input_identity_default_internet_route_peninsula_next_hop_ip"></a> [identity\_default\_internet\_route\_peninsula\_next\_hop\_ip](#input\_identity\_default\_internet\_route\_peninsula\_next\_hop\_ip) | n/a | `string` | `null` | no |
| <a name="input_identity_deploy_ihub_peering"></a> [identity\_deploy\_ihub\_peering](#input\_identity\_deploy\_ihub\_peering) | n/a | `bool` | `false` | no |
| <a name="input_identity_deploy_private_link_subnet"></a> [identity\_deploy\_private\_link\_subnet](#input\_identity\_deploy\_private\_link\_subnet) | (Optional) A boolean to enable/disable the deployment of a private link subnet for the key vault. | `bool` | `true` | no |
| <a name="input_identity_deploy_ss_peering"></a> [identity\_deploy\_ss\_peering](#input\_identity\_deploy\_ss\_peering) | n/a | `bool` | `false` | no |
| <a name="input_identity_enable_prod_vnet_link"></a> [identity\_enable\_prod\_vnet\_link](#input\_identity\_enable\_prod\_vnet\_link) | (Optional) Enable prod vnet links in DR Idty centralized private DNS zones. | `bool` | `false` | no |
| <a name="input_identity_keyvault_allowed_pe_subnet_ids"></a> [identity\_keyvault\_allowed\_pe\_subnet\_ids](#input\_identity\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_identity_keyvault_az_svcs_bypass"></a> [identity\_keyvault\_az\_svcs\_bypass](#input\_identity\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_identity_keyvault_diagnostics"></a> [identity\_keyvault\_diagnostics](#input\_identity\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_identity_keyvault_enable"></a> [identity\_keyvault\_enable](#input\_identity\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `true` | no |
| <a name="input_identity_keyvault_enabled_for_deployment"></a> [identity\_keyvault\_enabled\_for\_deployment](#input\_identity\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_identity_keyvault_enabled_for_disk_encryption"></a> [identity\_keyvault\_enabled\_for\_disk\_encryption](#input\_identity\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_identity_keyvault_enabled_for_template_deployment"></a> [identity\_keyvault\_enabled\_for\_template\_deployment](#input\_identity\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_identity_keyvault_log_analytics_solutions"></a> [identity\_keyvault\_log\_analytics\_solutions](#input\_identity\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_identity_keyvault_nacl_allowed_ips"></a> [identity\_keyvault\_nacl\_allowed\_ips](#input\_identity\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_identity_keyvault_nacl_allowed_subnets"></a> [identity\_keyvault\_nacl\_allowed\_subnets](#input\_identity\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_identity_keyvault_nacl_default_action"></a> [identity\_keyvault\_nacl\_default\_action](#input\_identity\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_identity_keyvault_postfix"></a> [identity\_keyvault\_postfix](#input\_identity\_keyvault\_postfix) | (Required) | `any` | n/a | yes |
| <a name="input_identity_keyvault_private_dns_zone_ids"></a> [identity\_keyvault\_private\_dns\_zone\_ids](#input\_identity\_keyvault\_private\_dns\_zone\_ids) | (Optional) private\_dns\_zone\_ids to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_identity_keyvault_purge_protection_enabled"></a> [identity\_keyvault\_purge\_protection\_enabled](#input\_identity\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_identity_keyvault_sku_name"></a> [identity\_keyvault\_sku\_name](#input\_identity\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_identity_keyvault_soft_delete_enabled"></a> [identity\_keyvault\_soft\_delete\_enabled](#input\_identity\_keyvault\_soft\_delete\_enabled) | (Optional) When soft-delete is enabled, resources marked as deleted resources are retained for a specified period (90 days by default). | `bool` | `true` | no |
| <a name="input_identity_keyvault_soft_delete_retention_days"></a> [identity\_keyvault\_soft\_delete\_retention\_days](#input\_identity\_keyvault\_soft\_delete\_retention\_days) | (Optional) The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the default) days. | `number` | `90` | no |
| <a name="input_identity_private_link_subnet_address_prefixes"></a> [identity\_private\_link\_subnet\_address\_prefixes](#input\_identity\_private\_link\_subnet\_address\_prefixes) | (Required) The address prefixes for the subnet of key vault. | `string` | n/a | yes |
| <a name="input_identity_private_link_subnet_enforce_endpoint_network_policies"></a> [identity\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_identity\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Required) Enable or Disable network policies for the private link endpoint on the subnet. Setting this to true will Disable the policy and setting this to false will Enable the policy. | `bool` | `true` | no |
| <a name="input_identity_private_link_subnet_service_endpoints"></a> [identity\_private\_link\_subnet\_service\_endpoints](#input\_identity\_private\_link\_subnet\_service\_endpoints) | (Required) The list of Service endpoints to associate with the subnet. | `list(string)` | <pre>[<br>  "Microsoft.Web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_identity_rg_security_enable"></a> [identity\_rg\_security\_enable](#input\_identity\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to identity\_rg\_data | `bool` | `true` | no |
| <a name="input_identity_route_table_disable_bgp_propagation"></a> [identity\_route\_table\_disable\_bgp\_propagation](#input\_identity\_route\_table\_disable\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `false` | no |
| <a name="input_identity_ss_mgmt_address_prefix"></a> [identity\_ss\_mgmt\_address\_prefix](#input\_identity\_ss\_mgmt\_address\_prefix) | (Required) The address prefix for the SS Mgmt subnet. | `string` | n/a | yes |
| <a name="input_identity_subnet_service_endpoints"></a> [identity\_subnet\_service\_endpoints](#input\_identity\_subnet\_service\_endpoints) | (Required) The list of Service endpoints to associate with the subnet. | `list(string)` | <pre>[<br>  "Microsoft.Storage"<br>]</pre> | no |
| <a name="input_identity_to_ihub_peering_network_id"></a> [identity\_to\_ihub\_peering\_network\_id](#input\_identity\_to\_ihub\_peering\_network\_id) | ihub resource string for peering connection | `string` | `null` | no |
| <a name="input_identity_to_sharedsvcs_peering_network_id"></a> [identity\_to\_sharedsvcs\_peering\_network\_id](#input\_identity\_to\_sharedsvcs\_peering\_network\_id) | Shared svcs resource string for peering connection | `string` | `null` | no |
| <a name="input_identity_vnet_address_space"></a> [identity\_vnet\_address\_space](#input\_identity\_vnet\_address\_space) | (Required) The address space for the virtual network. | `string` | n/a | yes |
| <a name="input_identity_vnet_dns_servers"></a> [identity\_vnet\_dns\_servers](#input\_identity\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_identity_windows_vm_app_name"></a> [identity\_windows\_vm\_app\_name](#input\_identity\_windows\_vm\_app\_name) | (Optional) app name. | `string` | `"dc"` | no |
| <a name="input_identity_windows_vm_data_collection_rule_assoc"></a> [identity\_windows\_vm\_data\_collection\_rule\_assoc](#input\_identity\_windows\_vm\_data\_collection\_rule\_assoc) | (Required) conditinal for enabling DCR association on VM. | `bool` | `true` | no |
| <a name="input_identity_windows_vm_data_collection_rule_endpoint_windows"></a> [identity\_windows\_vm\_data\_collection\_rule\_endpoint\_windows](#input\_identity\_windows\_vm\_data\_collection\_rule\_endpoint\_windows) | (Required) conditinal for enabling DCE association on VM From shared services. | `any` | `null` | no |
| <a name="input_identity_windows_vm_enable_ama_log_analytics_settings"></a> [identity\_windows\_vm\_enable\_ama\_log\_analytics\_settings](#input\_identity\_windows\_vm\_enable\_ama\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `false` | no |
| <a name="input_identity_windows_vm_enable_mma_log_analytics_settings"></a> [identity\_windows\_vm\_enable\_mma\_log\_analytics\_settings](#input\_identity\_windows\_vm\_enable\_mma\_log\_analytics\_settings) | (Required) Enable mma for log analytics. Requires Sentinel configuration values | `bool` | `true` | no |
| <a name="input_identity_windows_vm_identity_ids"></a> [identity\_windows\_vm\_identity\_ids](#input\_identity\_windows\_vm\_identity\_ids) | n/a | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_identity_windows_vm_log_analytics_primary_sentinel_shared_key"></a> [identity\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key](#input\_identity\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key) | (Required) The log analytics workspace primary shared key. | `any` | `null` | no |
| <a name="input_identity_windows_vm_log_analytics_workspace_sentinel_id"></a> [identity\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id](#input\_identity\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id) | (Required) The log analytics workspace ID for diagnostics. | `any` | `null` | no |
| <a name="input_ihub_additional_virtual_network_names"></a> [ihub\_additional\_virtual\_network\_names](#input\_ihub\_additional\_virtual\_network\_names) | n/a | `map(any)` | `{}` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_sharedsvs_windows_vm_log_analytics_workspace_sentinel_link_id"></a> [sharedsvs\_windows\_vm\_log\_analytics\_workspace\_sentinel\_link\_id](#input\_sharedsvs\_windows\_vm\_log\_analytics\_workspace\_sentinel\_link\_id) | (Required) conditinal for enabling DCR association on VM. | `string` | `"/subscriptions/0c22d89b-4687-4fa6-9eb4-979dcda22e7d/resourceGroups/us-rg-coreservices/providers/Microsoft.OperationalInsights/workspaces/us-law-coremonitoring"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  resource_name_no_dash    = replace("${var.env}${var.postfix}${var.suffix}", "-", "")

  timeout_duration = "2h"

  #KeyVault
  identity_rg_keyvault_name            = var.identity_keyvault_enable && var.identity_rg_security_enable ?  azurerm_resource_group.identity_rg_security[0].name  : azurerm_resource_group.identity_rg_data.name
  identity_private_link_subnet          = var.identity_deploy_private_link_subnet ? [azurerm_subnet.identity_private_link_subnet[0].id]              : var.identity_keyvault_allowed_pe_subnet_ids

  identity_private_dns_zone_id_map = {
   "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
   "prod-pr" = [""]
   "prod-dr" = [""]
  }

  private_dns_zones = [
    "privatelink.${var.dns_location}.database.usgovcloudapi.net",
    "privatelink.${var.dns_location}.batch.usgovcloudapi.net",
    "privatelink.${var.dns_location}.backup.windowsazure.us",
    "privatelink.azure-automation.us",
    "privatelink.database.usgovcloudapi.net",
    "privatelink.blob.core.usgovcloudapi.net",
    "privatelink.table.core.usgovcloudapi.net",
    "privatelink.queue.core.usgovcloudapi.net",
    "privatelink.file.core.usgovcloudapi.net",
    "privatelink.web.core.usgovcloudapi.net",
    "privatelink.documents.azure.us",
    "privatelink.postgres.database.usgovcloudapi.net",
    "privatelink.mysql.database.usgovcloudapi.net",
    "privatelink.mariadb.database.usgovcloudapi.net",
    "privatelink.vaultcore.usgovcloudapi.net",
    "privatelink.search.windows.us",
    "privatelink.azconfig.azure.us",
    "privatelink.siterecovery.windowsazure.us",
	  "privatelink.servicebus.windows.us1",
    "privatelink.servicebus.usgovcloudapi.net",
    "privatelink.azure-devices.us",
	  "privatelink.oms.opinsights.azure.us",
	  "privatelink.ods.opinsights.azure.us",
    "privatelink.azurewebsites.us",
	  "privatelink.cognitiveservices.azure.us",
    "privatelink.adx.monitor.azure.us",
    "privatelink.agentsvc.azure-automation.us",
    "privatelink.redis.cache.usgovcloudapi.net",
    "privatelink.azurehdinsight.us",
    "privatelink.azurecr.us",
    "privatelink.mongo.cosmos.azure.us",
    "privatelink.dfs.core.usgovcloudapi.net",
    "privatelink.azuresynapse.usgovcloudapi.net",
    "privatelink.dev.azuresynapse.usgovcloudapi.net",
    "privatelink.sql.azuresynapse.usgovcloudapi.net",
    "privatelink.${var.dns_aks_location}.cx.aks.containerservice.azure.us",
    "privatelink.datafactory.azure.us",
    "privatelink.adf.azure.us",
    "privatelink.monitor.azure.us",
  ]

  custom_data = <<CUSTOM_DATA
  temp_license: TE-SoT
  default_admin_password: '${var.identity_dns_vm_admin_pass}'
  CUSTOM_DATA
}
//**********************************************************************************************

```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_identity_additional_peering_ihub"></a> [identity\_additional\_peering\_ihub](#output\_identity\_additional\_peering\_ihub) | n/a |
| <a name="output_identity_dc_subnet"></a> [identity\_dc\_subnet](#output\_identity\_dc\_subnet) | n/a |
| <a name="output_identity_dc_vm_route_table_associate"></a> [identity\_dc\_vm\_route\_table\_associate](#output\_identity\_dc\_vm\_route\_table\_associate) | n/a |
| <a name="output_identity_keyvault"></a> [identity\_keyvault](#output\_identity\_keyvault) | n/a |
| <a name="output_identity_log_analytics_workspace"></a> [identity\_log\_analytics\_workspace](#output\_identity\_log\_analytics\_workspace) | n/a |
| <a name="output_identity_peering_ihub"></a> [identity\_peering\_ihub](#output\_identity\_peering\_ihub) | n/a |
| <a name="output_identity_peering_sharedsvcs"></a> [identity\_peering\_sharedsvcs](#output\_identity\_peering\_sharedsvcs) | n/a |
| <a name="output_identity_private_link_subnet"></a> [identity\_private\_link\_subnet](#output\_identity\_private\_link\_subnet) | n/a |
| <a name="output_identity_rg_data"></a> [identity\_rg\_data](#output\_identity\_rg\_data) | n/a |
| <a name="output_identity_rg_logging"></a> [identity\_rg\_logging](#output\_identity\_rg\_logging) | n/a |
| <a name="output_identity_rg_network"></a> [identity\_rg\_network](#output\_identity\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_identity_rg_security"></a> [identity\_rg\_security](#output\_identity\_rg\_security) | n/a |
| <a name="output_identity_vnet"></a> [identity\_vnet](#output\_identity\_vnet) | n/a |


## Usage

```terraform
data "azurerm_virtual_network" "core_data_shdsvc_vnet_idty" {
  count               = var.identity_deploy_ss_peering ? 1 : 0
  provider            = azurerm.shs
  name                = "nprd-pr-shdsvsch-vnet"
  resource_group_name = "rg-nprd-pr-shdsvsch-network"
}
data "azurerm_virtual_network" "core_data_idty_vnet_ihub" {
  count               = var.identity_deploy_ihub_peering ? 1 : 0
  provider            = azurerm.ihub
  name                = "nprd-pr-ihubch-vnet"
  resource_group_name = "rg-nprd-pr-ihubch-network"
}

// Deploy the Latam Peninsula Core Platform in a Box
//********************************************************************************************
 module "core_latam_ch_peninsula_identity" {
    source                                                        = "../dn-tads_tf-azure-component-library/core/core_latam_ch_peninsula_identity"
    env                                                           = var.env
    postfix                                                       = var.postfix
    location                                                      = var.location
    hub_env                                                       = var.env
    tags                                                          = var.tags
    identity_vnet_dns_servers                                     = var.identity_vnet_dns_servers
    identity_vnet_address_space                                   = var.identity_vnet_address_space
    identity_dc_sub_address_prefix                                = var.identity_dc_sub_address_prefix
    identity_private_link_subnet_address_prefixes                 = var.identity_private_link_subnet_address_prefixes
    identity_bastion_sub_address_prefix                           = var.identity_bastion_sub_address_prefix
    identity_azure_defender_resources                             = var.identity_azure_defender_resources
    identity_dc_vm_image_id                                       = var.identity_dc_vm_image_id
    identity_dc_vm_computer_name                                  = var.identity_dc_vm_computer_name
    identity_dc_vm_admin_user                                     = var.LOCAL_ADMIN_USER_VM
    identity_ss_mgmt_address_prefix                               = var.identity_ss_mgmt_address_prefix
    #Peering
    identity_to_sharedsvcs_peering_network_id                     = var.identity_deploy_ss_peering ? data.azurerm_virtual_network.core_data_shdsvc_vnet_idty[0].id : null
    identity_to_ihub_peering_network_id                           = var.identity_deploy_ihub_peering ? data.azurerm_virtual_network.core_data_idty_vnet_ihub[0].id : null
    identity_deploy_ss_peering                                    = var.identity_deploy_ss_peering 
    identity_deploy_ihub_peering                                  = var.identity_deploy_ihub_peering 
    #key vault
    identity_keyvault_postfix                                     = var.identity_keyvault_postfix
    identity_keyvault_nacl_allowed_ips                            = concat(var.identity_keyvault_nacl_allowed_ips, [var.GITHUBIP])
    identity_keyvault_private_dns_zone_ids                        = var.identity_keyvault_private_dns_zone_ids 
    # needs sentinel configuration
    identity_windows_vm_log_analytics_workspace_sentinel_id       = var.GLOBAL_CH_LAW_SENTINEL_ID
    identity_windows_vm_log_analytics_primary_sentinel_shared_key = var.GLOBAL_CH_LAW_SENTINEL_SHARED_KEY
    identity_windows_vm_data_collection_rule_endpoint_windows     = var.identity_windows_vm_data_collection_rule_endpoint_windows
    identity_default_internet_route_peninsula_next_hop_ip         = var.identity_default_internet_route_peninsula_next_hop_ip
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
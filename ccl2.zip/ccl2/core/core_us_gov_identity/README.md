<!-- BEGIN_TF_DOCS -->

# Azure Identity Platform Module
Non-Prod and Production tenants will be hosting Domain Controllers and Azure AD Connect Sync VMs. A dedicate subscription will be allocated to support Active Directory Domain Services and Azure AD. Azure Files enforces authorization on user access to both the share and the directory/file levels. Share-level permission assignment can be performed on Azure Active Directory (Azure AD) users or groups managed through the Azure role-based access control (Azure RBAC) model.



## Resources

| Name | Type |
|------|------|
| [azurerm_availability_set.identity_ad_sync_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.identity_cyberark_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.identity_dc_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.identity_exchange_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.identity_infoblox_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.identity_sailpoint_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_backup_protected_vm.identity_dns_vm_protected_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_vm) | resource |
| [azurerm_key_vault_secret.identity_cyberark_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.identity_cyberark_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.identity_exchange_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.identity_exchange_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.identity_sailpoint_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.identity_sailpoint_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.identity_vm_domain_password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.identity_vm_domain_username](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-adsync-password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-adsync-username_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-dns-password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-dns-username](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-domain-controllers-password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-domain-controllers-username_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_lb.sailpoint_load_balancer_internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb) | resource |
| [azurerm_lb_backend_address_pool.backend_addesspool_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_backend_address_pool) | resource |
| [azurerm_lb_probe.lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_rule.lb_rule_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_linux_virtual_machine.infoblox_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_virtual_machine) | resource |
| [azurerm_marketplace_agreement.accept-infoblox-eula](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/marketplace_agreement) | resource |
| [azurerm_monitor_diagnostic_setting.sailpoint_load_balancer_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_interface.identity_dns_lan_network_interface](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface.identity_dns_mgmt_network_interface](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_interface_security_group_association.identity_dns_lan_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_interface_security_group_association.identity_dns_mgmt_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.identity_ad_sync_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.identity_dc_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.identity_dns_lan_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.identity_dns_mgmt_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.AD_WebServices](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Allow_BastionHost_Communication](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Allow_Exchange_IAM_Mgmt_Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.CIFS_SMB_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.CIFS_SMB_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DC-Service-Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DFSN_Netlogon](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DFSN_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.DFSN_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Deny-All](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.IIQ_6060_Service_Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_PWD_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_PWD_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Kerberos_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAPS_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAPS_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_GC](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_GC_Secure](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.LDAP_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.NetBIOS_NS_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.NetBIOS_NS_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.RPC](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.RPCEPM](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.W32Time](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.WinRM_Services_Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.dns_Tcp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.dns_Udp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.exchange_Service_Rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.identity_dns_vm_azure_bastion_nsgrule_22_lan](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.identity_dns_vm_azure_bastion_nsgrule_22_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.identity_dns_vm_azure_bastion_nsgrule_3389_lan](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.identity_dns_vm_azure_bastion_nsgrule_3389_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.identity_dns_vm_user_defined_nsg_rules_dns_lan](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.identity_dns_vm_user_defined_nsg_rules_dns_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_watcher_flow_log.identity_vm_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_private_dns_zone.identity_private_dns_zones](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.identity_private_dns_zone_link_dr_to_prod](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_dns_zone_virtual_network_link.identity_private_dns_zone_links](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_resource_group.identity_adsync_vm_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_cyberark_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_dc_vm_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_dns_vm_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_exchnage_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.identity_sailpoint_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.identity_default_internet_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.identity_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_subnet.identity_ad_sync_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.identity_dc_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.identity_dns_lan_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.identity_dns_mgmt_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.identity_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.identity_ad_sync_subnet_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.identity_dc_subnet_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.identity_dns_lan_subnet_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.identity_dns_mgmt_subnet_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.join_default1](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.join_default2](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.join_default3](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.join_default4](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_network.identity_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.identity_dr_peering_identity_prod](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.identity_peering_ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.identity_peering_sharedsvcs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.identity_prod_peering_identity_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-idty-prod-to-ss-dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvc-dr-to-idty-prod](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering_ihub_to_avd](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [random_id.random](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) | resource |
| [random_password.identity_cyberark_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.identity_exchange_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.identity_sailpoint_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_availability_zones"></a> [availability\_zones](#input\_availability\_zones) | (Required) The llist of availability zones to be leveraged by palo alto VMs | `list(string)` | <pre>[<br>  "1",<br>  "2",<br>  "3"<br>]</pre> | no |
| <a name="input_dns_aks_location"></a> [dns\_aks\_location](#input\_dns\_aks\_location) | n/a | `any` | n/a | yes |
| <a name="input_dns_location"></a> [dns\_location](#input\_dns\_location) | (Required) region for private dns zone (in portal its usgovvirginia is shortened as ugv for private dns zone creations). | `string` | `"ugv"` | no |
| <a name="input_enable_Allow_Exchange_IAM_Mgmt_Rule"></a> [enable\_Allow\_Exchange\_IAM\_Mgmt\_Rule](#input\_enable\_Allow\_Exchange\_IAM\_Mgmt\_Rule) | n/a | `bool` | `false` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_identity_ad_sync_sub_address_prefix"></a> [identity\_ad\_sync\_sub\_address\_prefix](#input\_identity\_ad\_sync\_sub\_address\_prefix) | (Required) The address prefix for the AD Sync subnet. | `string` | n/a | yes |
| <a name="input_identity_ad_sync_vm_admin_pass"></a> [identity\_ad\_sync\_vm\_admin\_pass](#input\_identity\_ad\_sync\_vm\_admin\_pass) | (Required) The password of the windows OS admin. | `string` | n/a | yes |
| <a name="input_identity_ad_sync_vm_computer_name"></a> [identity\_ad\_sync\_vm\_computer\_name](#input\_identity\_ad\_sync\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_identity_ad_sync_vm_computer_name_admin_username"></a> [identity\_ad\_sync\_vm\_computer\_name\_admin\_username](#input\_identity\_ad\_sync\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_identity_ad_sync_vm_domain_join_enable"></a> [identity\_ad\_sync\_vm\_domain\_join\_enable](#input\_identity\_ad\_sync\_vm\_domain\_join\_enable) | n/a | `bool` | `true` | no |
| <a name="input_identity_ad_sync_vm_image_id"></a> [identity\_ad\_sync\_vm\_image\_id](#input\_identity\_ad\_sync\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_identity_ad_sync_vm_os_disk_storage_account_type"></a> [identity\_ad\_sync\_vm\_os\_disk\_storage\_account\_type](#input\_identity\_ad\_sync\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_identity_ad_sync_vm_size"></a> [identity\_ad\_sync\_vm\_size](#input\_identity\_ad\_sync\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_identity_alt_log_analytics_vm_workspace_id"></a> [identity\_alt\_log\_analytics\_vm\_workspace\_id](#input\_identity\_alt\_log\_analytics\_vm\_workspace\_id) | (Optional) workspace ID of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_alt_log_analytics_workspace"></a> [identity\_alt\_log\_analytics\_workspace](#input\_identity\_alt\_log\_analytics\_workspace) | (Optional) Set to true if resource diagnostic settings need to be sent to an alternative log analytics workspace. | `bool` | `false` | no |
| <a name="input_identity_alt_log_analytics_workspace_id"></a> [identity\_alt\_log\_analytics\_workspace\_id](#input\_identity\_alt\_log\_analytics\_workspace\_id) | (Optional) resource ID of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_alt_log_analytics_workspace_name"></a> [identity\_alt\_log\_analytics\_workspace\_name](#input\_identity\_alt\_log\_analytics\_workspace\_name) | (Optional) name of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_alt_log_analytics_workspace_primary_shared_key"></a> [identity\_alt\_log\_analytics\_workspace\_primary\_shared\_key](#input\_identity\_alt\_log\_analytics\_workspace\_primary\_shared\_key) | (Optional) primary shared key of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_identity_avail_zones_supported"></a> [identity\_avail\_zones\_supported](#input\_identity\_avail\_zones\_supported) | (Optional) Set to true if availability zones are supported in region. | `bool` | `true` | no |
| <a name="input_identity_azure_defender_resources"></a> [identity\_azure\_defender\_resources](#input\_identity\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "VirtualMachines",<br>  "AppServices",<br>  "ContainerRegistry",<br>  "KeyVaults",<br>  "KubernetesService",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns"<br>]</pre> | no |
| <a name="input_identity_backup_deploy_private_dns_zone"></a> [identity\_backup\_deploy\_private\_dns\_zone](#input\_identity\_backup\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the backup private endpoint. | `bool` | `false` | no |
| <a name="input_identity_bastion_sub_address_prefix"></a> [identity\_bastion\_sub\_address\_prefix](#input\_identity\_bastion\_sub\_address\_prefix) | (Required) The address prefix for the bastion subnet. | `string` | n/a | yes |
| <a name="input_identity_cyberark_vm_computer_name"></a> [identity\_cyberark\_vm\_computer\_name](#input\_identity\_cyberark\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_identity_cyberark_vm_computer_name_admin_username"></a> [identity\_cyberark\_vm\_computer\_name\_admin\_username](#input\_identity\_cyberark\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_identity_cyberark_vm_data_disk_size"></a> [identity\_cyberark\_vm\_data\_disk\_size](#input\_identity\_cyberark\_vm\_data\_disk\_size) | (Optional) The disk size gb for the managed disk of the windows vm. | `any` | `null` | no |
| <a name="input_identity_cyberark_vm_domain_join_enable"></a> [identity\_cyberark\_vm\_domain\_join\_enable](#input\_identity\_cyberark\_vm\_domain\_join\_enable) | n/a | `bool` | `true` | no |
| <a name="input_identity_cyberark_vm_image_id"></a> [identity\_cyberark\_vm\_image\_id](#input\_identity\_cyberark\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_identity_cyberark_vm_os_disk_disk_size_gb"></a> [identity\_cyberark\_vm\_os\_disk\_disk\_size\_gb](#input\_identity\_cyberark\_vm\_os\_disk\_disk\_size\_gb) | (Optional) The disk size gb for the os disk of the windows vm. | `any` | `null` | no |
| <a name="input_identity_cyberark_vm_os_disk_storage_account_type"></a> [identity\_cyberark\_vm\_os\_disk\_storage\_account\_type](#input\_identity\_cyberark\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_identity_cyberark_vm_size"></a> [identity\_cyberark\_vm\_size](#input\_identity\_cyberark\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_identity_dc_prod_dr_sub_address_prefix"></a> [identity\_dc\_prod\_dr\_sub\_address\_prefix](#input\_identity\_dc\_prod\_dr\_sub\_address\_prefix) | n/a | `list(string)` | `[]` | no |
| <a name="input_identity_dc_sn_nsg_include_dr"></a> [identity\_dc\_sn\_nsg\_include\_dr](#input\_identity\_dc\_sn\_nsg\_include\_dr) | n/a | `bool` | `false` | no |
| <a name="input_identity_dc_sub_address_prefix"></a> [identity\_dc\_sub\_address\_prefix](#input\_identity\_dc\_sub\_address\_prefix) | (Required) The address prefix for the DCs subnet. | `string` | n/a | yes |
| <a name="input_identity_dc_vm_admin_pass"></a> [identity\_dc\_vm\_admin\_pass](#input\_identity\_dc\_vm\_admin\_pass) | (Required) The password of the windows OS admin. | `string` | n/a | yes |
| <a name="input_identity_dc_vm_computer_name"></a> [identity\_dc\_vm\_computer\_name](#input\_identity\_dc\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_identity_dc_vm_computer_name_admin_username"></a> [identity\_dc\_vm\_computer\_name\_admin\_username](#input\_identity\_dc\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_identity_dc_vm_data_disk_size"></a> [identity\_dc\_vm\_data\_disk\_size](#input\_identity\_dc\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `any` | n/a | yes |
| <a name="input_identity_dc_vm_image_id"></a> [identity\_dc\_vm\_image\_id](#input\_identity\_dc\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_identity_dc_vm_logging_disk_size"></a> [identity\_dc\_vm\_logging\_disk\_size](#input\_identity\_dc\_vm\_logging\_disk\_size) | (Required) size of managed logging disk. | `any` | n/a | yes |
| <a name="input_identity_dc_vm_os_disk_disk_size_gb"></a> [identity\_dc\_vm\_os\_disk\_disk\_size\_gb](#input\_identity\_dc\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_identity_dc_vm_os_disk_storage_account_type"></a> [identity\_dc\_vm\_os\_disk\_storage\_account\_type](#input\_identity\_dc\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_identity_dc_vm_size"></a> [identity\_dc\_vm\_size](#input\_identity\_dc\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_identity_default_internet_route_peninsula_next_hop_ip"></a> [identity\_default\_internet\_route\_peninsula\_next\_hop\_ip](#input\_identity\_default\_internet\_route\_peninsula\_next\_hop\_ip) | n/a | `string` | n/a | yes |
| <a name="input_identity_deploy_availability_set"></a> [identity\_deploy\_availability\_set](#input\_identity\_deploy\_availability\_set) | (Optional) Set to true if windows VM needs avail set. | `bool` | `false` | no |
| <a name="input_identity_deploy_avd_peering"></a> [identity\_deploy\_avd\_peering](#input\_identity\_deploy\_avd\_peering) | n/a | `bool` | `true` | no |
| <a name="input_identity_deploy_cross_vnet_global_peering_idty_dr_ss_prod"></a> [identity\_deploy\_cross\_vnet\_global\_peering\_idty\_dr\_ss\_prod](#input\_identity\_deploy\_cross\_vnet\_global\_peering\_idty\_dr\_ss\_prod) | Set to true to enable global vnet peering. | `bool` | n/a | yes |
| <a name="input_identity_deploy_cross_vnet_global_peering_idty_prod_ss_dr"></a> [identity\_deploy\_cross\_vnet\_global\_peering\_idty\_prod\_ss\_dr](#input\_identity\_deploy\_cross\_vnet\_global\_peering\_idty\_prod\_ss\_dr) | Set to true to enable global vnet peering. | `bool` | n/a | yes |
| <a name="input_identity_deploy_cyberark"></a> [identity\_deploy\_cyberark](#input\_identity\_deploy\_cyberark) | (Optional) deploy exchange true or false | `bool` | `true` | no |
| <a name="input_identity_deploy_exchange"></a> [identity\_deploy\_exchange](#input\_identity\_deploy\_exchange) | (Optional) deploy exchange true or false | `bool` | `true` | no |
| <a name="input_identity_deploy_ihub_peering"></a> [identity\_deploy\_ihub\_peering](#input\_identity\_deploy\_ihub\_peering) | n/a | `bool` | `true` | no |
| <a name="input_identity_deploy_kv_secrets"></a> [identity\_deploy\_kv\_secrets](#input\_identity\_deploy\_kv\_secrets) | (Optional) Set to true if windows admin creds need to be stored as KV secrets. | `bool` | `true` | no |
| <a name="input_identity_deploy_private_link_subnet"></a> [identity\_deploy\_private\_link\_subnet](#input\_identity\_deploy\_private\_link\_subnet) | (Optional) A boolean to enable/disable the deployment of a private link subnet for the key vault. | `bool` | `false` | no |
| <a name="input_identity_deploy_sailpoint"></a> [identity\_deploy\_sailpoint](#input\_identity\_deploy\_sailpoint) | (Optional) deploy exchange true or false | `bool` | `true` | no |
| <a name="input_identity_deploy_ss_peering"></a> [identity\_deploy\_ss\_peering](#input\_identity\_deploy\_ss\_peering) | n/a | `bool` | `true` | no |
| <a name="input_identity_dns_lan_sub_address_prefix"></a> [identity\_dns\_lan\_sub\_address\_prefix](#input\_identity\_dns\_lan\_sub\_address\_prefix) | (Required) The address prefix for the DNS LAN subnet. | `string` | n/a | yes |
| <a name="input_identity_dns_mgmt_sub_address_prefix"></a> [identity\_dns\_mgmt\_sub\_address\_prefix](#input\_identity\_dns\_mgmt\_sub\_address\_prefix) | (Required) The address prefix for the DNS mgmt subnet. | `string` | n/a | yes |
| <a name="input_identity_dns_nsg_sa_allowed_pe_subnet_ids"></a> [identity\_dns\_nsg\_sa\_allowed\_pe\_subnet\_ids](#input\_identity\_dns\_nsg\_sa\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_identity_dns_nsg_sa_allowed_vnet_subnet_ids"></a> [identity\_dns\_nsg\_sa\_allowed\_vnet\_subnet\_ids](#input\_identity\_dns\_nsg\_sa\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_identity_dns_vm_admin_pass"></a> [identity\_dns\_vm\_admin\_pass](#input\_identity\_dns\_vm\_admin\_pass) | (Required) The password of the windows OS admin. | `string` | n/a | yes |
| <a name="input_identity_dns_vm_admin_user"></a> [identity\_dns\_vm\_admin\_user](#input\_identity\_dns\_vm\_admin\_user) | (Required) The name of the windows OS admin. | `string` | n/a | yes |
| <a name="input_identity_dns_vm_backup_policy_vm_id"></a> [identity\_dns\_vm\_backup\_policy\_vm\_id](#input\_identity\_dns\_vm\_backup\_policy\_vm\_id) | (Optional) The backup policy from the backup vault. | `any` | `null` | no |
| <a name="input_identity_dns_vm_bastion_enable"></a> [identity\_dns\_vm\_bastion\_enable](#input\_identity\_dns\_vm\_bastion\_enable) | (Optional) Enable te creation for azure bastion | `bool` | `false` | no |
| <a name="input_identity_dns_vm_boot_sa_postfix"></a> [identity\_dns\_vm\_boot\_sa\_postfix](#input\_identity\_dns\_vm\_boot\_sa\_postfix) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_computer_name"></a> [identity\_dns\_vm\_computer\_name](#input\_identity\_dns\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string #(Required) The publisher of the solution<br>    name   = string #(Required) The product name of the solution<br>    private_ip_lan_nic =  string<br>    private_ip_mgmt_nic =  string<br>  }))</pre> | `{}` | no |
| <a name="input_identity_dns_vm_computer_name_admin_username"></a> [identity\_dns\_vm\_computer\_name\_admin\_username](#input\_identity\_dns\_vm\_computer\_name\_admin\_username) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |
| <a name="input_identity_dns_vm_custom_data"></a> [identity\_dns\_vm\_custom\_data](#input\_identity\_dns\_vm\_custom\_data) | (Optional) Custom data. | `string` | `null` | no |
| <a name="input_identity_dns_vm_deploy_enable"></a> [identity\_dns\_vm\_deploy\_enable](#input\_identity\_dns\_vm\_deploy\_enable) | (Optional) Deploy Dns VMs | `bool` | `false` | no |
| <a name="input_identity_dns_vm_deploy_kv_secret"></a> [identity\_dns\_vm\_deploy\_kv\_secret](#input\_identity\_dns\_vm\_deploy\_kv\_secret) | (Optional) Deploy KV secrets for infoblox servers | `bool` | `false` | no |
| <a name="input_identity_dns_vm_deploy_nsg_rules"></a> [identity\_dns\_vm\_deploy\_nsg\_rules](#input\_identity\_dns\_vm\_deploy\_nsg\_rules) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_deploy_rg"></a> [identity\_dns\_vm\_deploy\_rg](#input\_identity\_dns\_vm\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the VM. | `bool` | `false` | no |
| <a name="input_identity_dns_vm_deploy_subnet_nsg"></a> [identity\_dns\_vm\_deploy\_subnet\_nsg](#input\_identity\_dns\_vm\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM. | `bool` | `false` | no |
| <a name="input_identity_dns_vm_domain_name"></a> [identity\_dns\_vm\_domain\_name](#input\_identity\_dns\_vm\_domain\_name) | (Optional) Name of the domain to join | `string` | `""` | no |
| <a name="input_identity_dns_vm_domain_password"></a> [identity\_dns\_vm\_domain\_password](#input\_identity\_dns\_vm\_domain\_password) | (Optional) Password of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_identity_dns_vm_domain_user_upn"></a> [identity\_dns\_vm\_domain\_user\_upn](#input\_identity\_dns\_vm\_domain\_user\_upn) | (Optional) UPN of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_identity_dns_vm_enable_antimalware_protection"></a> [identity\_dns\_vm\_enable\_antimalware\_protection](#input\_identity\_dns\_vm\_enable\_antimalware\_protection) | (Optional) Toggle the antimalware protection extension feature. | `bool` | `true` | no |
| <a name="input_identity_dns_vm_enable_automatic_updates"></a> [identity\_dns\_vm\_enable\_automatic\_updates](#input\_identity\_dns\_vm\_enable\_automatic\_updates) | (Optional) Boolean to enable automatic updates. | `bool` | `true` | no |
| <a name="input_identity_dns_vm_enable_backup"></a> [identity\_dns\_vm\_enable\_backup](#input\_identity\_dns\_vm\_enable\_backup) | (Optional) Toggle the backup feature. | `bool` | `false` | no |
| <a name="input_identity_dns_vm_enable_domain_join"></a> [identity\_dns\_vm\_enable\_domain\_join](#input\_identity\_dns\_vm\_enable\_domain\_join) | (Optional) Toggle the domain join feature. | `bool` | `false` | no |
| <a name="input_identity_dns_vm_enable_encryption_at_host"></a> [identity\_dns\_vm\_enable\_encryption\_at\_host](#input\_identity\_dns\_vm\_enable\_encryption\_at\_host) | (Optional) Boolean to enable encryption\_at\_host. | `bool` | `true` | no |
| <a name="input_identity_dns_vm_enable_guest_config"></a> [identity\_dns\_vm\_enable\_guest\_config](#input\_identity\_dns\_vm\_enable\_guest\_config) | (Optional) Toggle the guest config extension feature. | `bool` | `false` | no |
| <a name="input_identity_dns_vm_enable_log_analytics_settings"></a> [identity\_dns\_vm\_enable\_log\_analytics\_settings](#input\_identity\_dns\_vm\_enable\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `true` | no |
| <a name="input_identity_dns_vm_from_marketplace"></a> [identity\_dns\_vm\_from\_marketplace](#input\_identity\_dns\_vm\_from\_marketplace) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_license_type"></a> [identity\_dns\_vm\_license\_type](#input\_identity\_dns\_vm\_license\_type) | (Optional) Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows\_Client and Windows\_Server. | `string` | `"none"` | no |
| <a name="input_identity_dns_vm_nsg_sa_postfix"></a> [identity\_dns\_vm\_nsg\_sa\_postfix](#input\_identity\_dns\_vm\_nsg\_sa\_postfix) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_offer"></a> [identity\_dns\_vm\_offer](#input\_identity\_dns\_vm\_offer) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_os"></a> [identity\_dns\_vm\_os](#input\_identity\_dns\_vm\_os) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_os_disk_caching"></a> [identity\_dns\_vm\_os\_disk\_caching](#input\_identity\_dns\_vm\_os\_disk\_caching) | (Optional) The caching for the os disk of the windows vm. | `string` | `"ReadWrite"` | no |
| <a name="input_identity_dns_vm_os_disk_disk_size_gb"></a> [identity\_dns\_vm\_os\_disk\_disk\_size\_gb](#input\_identity\_dns\_vm\_os\_disk\_disk\_size\_gb) | (Optional) The disk size gb for the os disk of the windows vm. | `any` | `null` | no |
| <a name="input_identity_dns_vm_os_disk_storage_account_type"></a> [identity\_dns\_vm\_os\_disk\_storage\_account\_type](#input\_identity\_dns\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `null` | no |
| <a name="input_identity_dns_vm_os_disk_write_accelerator_enabled"></a> [identity\_dns\_vm\_os\_disk\_write\_accelerator\_enabled](#input\_identity\_dns\_vm\_os\_disk\_write\_accelerator\_enabled) | (Optional) Boolean to enable write accelerator enabled. | `bool` | `false` | no |
| <a name="input_identity_dns_vm_os_ultra_ssd_enabled"></a> [identity\_dns\_vm\_os\_ultra\_ssd\_enabled](#input\_identity\_dns\_vm\_os\_ultra\_ssd\_enabled) | (Optional) Boolean to enable ultra ssd enabled. | `bool` | `false` | no |
| <a name="input_identity_dns_vm_ou_path"></a> [identity\_dns\_vm\_ou\_path](#input\_identity\_dns\_vm\_ou\_path) | (Optional) OU path to us during domain join | `string` | `""` | no |
| <a name="input_identity_dns_vm_provision_vm_agent"></a> [identity\_dns\_vm\_provision\_vm\_agent](#input\_identity\_dns\_vm\_provision\_vm\_agent) | (Optional) Boolean to enable provision vm agent. | `bool` | `true` | no |
| <a name="input_identity_dns_vm_publisher"></a> [identity\_dns\_vm\_publisher](#input\_identity\_dns\_vm\_publisher) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_recovery_vault_name"></a> [identity\_dns\_vm\_recovery\_vault\_name](#input\_identity\_dns\_vm\_recovery\_vault\_name) | (Optional) The name of recovery backup vault. | `any` | `null` | no |
| <a name="input_identity_dns_vm_rg_backup_name"></a> [identity\_dns\_vm\_rg\_backup\_name](#input\_identity\_dns\_vm\_rg\_backup\_name) | (Optional) The RG destination of the windows vm backup. | `any` | `null` | no |
| <a name="input_identity_dns_vm_size"></a> [identity\_dns\_vm\_size](#input\_identity\_dns\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_identity_dns_vm_sku"></a> [identity\_dns\_vm\_sku](#input\_identity\_dns\_vm\_sku) | n/a | `any` | n/a | yes |
| <a name="input_identity_dns_vm_timezone"></a> [identity\_dns\_vm\_timezone](#input\_identity\_dns\_vm\_timezone) | (Optional) The timezone of the windows vm. | `any` | `null` | no |
| <a name="input_identity_dns_vm_user_defined_nsg_rules"></a> [identity\_dns\_vm\_user\_defined\_nsg\_rules](#input\_identity\_dns\_vm\_user\_defined\_nsg\_rules) | (Optional) Define additional NSG rules | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)<br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_identity_dns_vm_version"></a> [identity\_dns\_vm\_version](#input\_identity\_dns\_vm\_version) | n/a | `any` | n/a | yes |
| <a name="input_identity_dr_deploy_identity_prod_peering"></a> [identity\_dr\_deploy\_identity\_prod\_peering](#input\_identity\_dr\_deploy\_identity\_prod\_peering) | n/a | `bool` | `true` | no |
| <a name="input_identity_dr_to_identity_prod_peering_network_id"></a> [identity\_dr\_to\_identity\_prod\_peering\_network\_id](#input\_identity\_dr\_to\_identity\_prod\_peering\_network\_id) | n/a | `any` | n/a | yes |
| <a name="input_identity_enable_prod_vnet_link"></a> [identity\_enable\_prod\_vnet\_link](#input\_identity\_enable\_prod\_vnet\_link) | (Optional) Enable prod vnet links in DR Idty centralized private DNS zones. | `bool` | `false` | no |
| <a name="input_identity_exchange_iam_mgmt_vm_address_prefixes"></a> [identity\_exchange\_iam\_mgmt\_vm\_address\_prefixes](#input\_identity\_exchange\_iam\_mgmt\_vm\_address\_prefixes) | n/a | `any` | n/a | yes |
| <a name="input_identity_exchange_vm_computer_name"></a> [identity\_exchange\_vm\_computer\_name](#input\_identity\_exchange\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_identity_exchange_vm_computer_name_admin_username"></a> [identity\_exchange\_vm\_computer\_name\_admin\_username](#input\_identity\_exchange\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_identity_exchange_vm_database_disk_size"></a> [identity\_exchange\_vm\_database\_disk\_size](#input\_identity\_exchange\_vm\_database\_disk\_size) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_identity_exchange_vm_domain_join_enable"></a> [identity\_exchange\_vm\_domain\_join\_enable](#input\_identity\_exchange\_vm\_domain\_join\_enable) | n/a | `bool` | `true` | no |
| <a name="input_identity_exchange_vm_exchange_disk_size"></a> [identity\_exchange\_vm\_exchange\_disk\_size](#input\_identity\_exchange\_vm\_exchange\_disk\_size) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_identity_exchange_vm_image_id"></a> [identity\_exchange\_vm\_image\_id](#input\_identity\_exchange\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_identity_exchange_vm_os_disk_disk_size_gb"></a> [identity\_exchange\_vm\_os\_disk\_disk\_size\_gb](#input\_identity\_exchange\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of OS system disk. | `any` | n/a | yes |
| <a name="input_identity_exchange_vm_os_disk_storage_account_type"></a> [identity\_exchange\_vm\_os\_disk\_storage\_account\_type](#input\_identity\_exchange\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_identity_exchange_vm_size"></a> [identity\_exchange\_vm\_size](#input\_identity\_exchange\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_identity_exchnage_hybrid_vm_address_prefixes"></a> [identity\_exchnage\_hybrid\_vm\_address\_prefixes](#input\_identity\_exchnage\_hybrid\_vm\_address\_prefixes) | n/a | `any` | n/a | yes |
| <a name="input_identity_keyvault_allowed_pe_subnet_ids"></a> [identity\_keyvault\_allowed\_pe\_subnet\_ids](#input\_identity\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_identity_keyvault_az_svcs_bypass"></a> [identity\_keyvault\_az\_svcs\_bypass](#input\_identity\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_identity_keyvault_deploy_private_dns_zone"></a> [identity\_keyvault\_deploy\_private\_dns\_zone](#input\_identity\_keyvault\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the key vault private endpoint. | `bool` | `false` | no |
| <a name="input_identity_keyvault_diagnostics"></a> [identity\_keyvault\_diagnostics](#input\_identity\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_identity_keyvault_enable"></a> [identity\_keyvault\_enable](#input\_identity\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `false` | no |
| <a name="input_identity_keyvault_enabled_for_deployment"></a> [identity\_keyvault\_enabled\_for\_deployment](#input\_identity\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_identity_keyvault_enabled_for_disk_encryption"></a> [identity\_keyvault\_enabled\_for\_disk\_encryption](#input\_identity\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_identity_keyvault_enabled_for_template_deployment"></a> [identity\_keyvault\_enabled\_for\_template\_deployment](#input\_identity\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_identity_keyvault_log_analytics_solutions"></a> [identity\_keyvault\_log\_analytics\_solutions](#input\_identity\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_identity_keyvault_nacl_allowed_ips"></a> [identity\_keyvault\_nacl\_allowed\_ips](#input\_identity\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_identity_keyvault_nacl_allowed_subnets"></a> [identity\_keyvault\_nacl\_allowed\_subnets](#input\_identity\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_identity_keyvault_nacl_default_action"></a> [identity\_keyvault\_nacl\_default\_action](#input\_identity\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_identity_keyvault_purge_protection_enabled"></a> [identity\_keyvault\_purge\_protection\_enabled](#input\_identity\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_identity_keyvault_sku_name"></a> [identity\_keyvault\_sku\_name](#input\_identity\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_identity_keyvault_soft_delete_enabled"></a> [identity\_keyvault\_soft\_delete\_enabled](#input\_identity\_keyvault\_soft\_delete\_enabled) | (Optional) When soft-delete is enabled, resources marked as deleted resources are retained for a specified period (90 days by default). | `bool` | `true` | no |
| <a name="input_identity_load_balancer_diagnostics"></a> [identity\_load\_balancer\_diagnostics](#input\_identity\_load\_balancer\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_identity_log_analytics_supported"></a> [identity\_log\_analytics\_supported](#input\_identity\_log\_analytics\_supported) | (Optional) Set to true if log analytics workspace is supported in region. | `bool` | `true` | no |
| <a name="input_identity_nsg_count"></a> [identity\_nsg\_count](#input\_identity\_nsg\_count) | n/a | `number` | `4` | no |
| <a name="input_identity_nsg_name"></a> [identity\_nsg\_name](#input\_identity\_nsg\_name) | n/a | `list` | <pre>[<br>  "dns-lan",<br>  "dns-mgmt",<br>  "dc",<br>  "ad-sync"<br>]</pre> | no |
| <a name="input_identity_nsg_sa_deploy_private_dns_zone"></a> [identity\_nsg\_sa\_deploy\_private\_dns\_zone](#input\_identity\_nsg\_sa\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the nsg sa private endpoint. | `bool` | `false` | no |
| <a name="input_identity_private_link_subnet_address_prefixes"></a> [identity\_private\_link\_subnet\_address\_prefixes](#input\_identity\_private\_link\_subnet\_address\_prefixes) | (Required) The address prefixes for the subnet of key vault. | `string` | n/a | yes |
| <a name="input_identity_private_link_subnet_enforce_endpoint_network_policies"></a> [identity\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_identity\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Required) Enable or Disable network policies for the private link endpoint on the subnet. Setting this to true will Disable the policy and setting this to false will Enable the policy. | `bool` | `true` | no |
| <a name="input_identity_private_link_subnet_service_endpoints"></a> [identity\_private\_link\_subnet\_service\_endpoints](#input\_identity\_private\_link\_subnet\_service\_endpoints) | (Required) The list of Service endpoints to associate with the subnet. | `list(string)` | <pre>[<br>  "Microsoft.Web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_identity_prod_deploy_identity_dr_peering"></a> [identity\_prod\_deploy\_identity\_dr\_peering](#input\_identity\_prod\_deploy\_identity\_dr\_peering) | n/a | `bool` | `true` | no |
| <a name="input_identity_prod_to_identity_dr_peering_network_id"></a> [identity\_prod\_to\_identity\_dr\_peering\_network\_id](#input\_identity\_prod\_to\_identity\_dr\_peering\_network\_id) | n/a | `any` | n/a | yes |
| <a name="input_identity_rg_security_enable"></a> [identity\_rg\_security\_enable](#input\_identity\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to identity\_rg\_data | `bool` | `false` | no |
| <a name="input_identity_route_table_disable_bgp_propagation"></a> [identity\_route\_table\_disable\_bgp\_propagation](#input\_identity\_route\_table\_disable\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `false` | no |
| <a name="input_identity_sailpoint_internal_lb_private_ip_address"></a> [identity\_sailpoint\_internal\_lb\_private\_ip\_address](#input\_identity\_sailpoint\_internal\_lb\_private\_ip\_address) | Private IP of sailpoint LB | `string` | n/a | yes |
| <a name="input_identity_sailpoint_internal_lb_private_ip_address_allocation"></a> [identity\_sailpoint\_internal\_lb\_private\_ip\_address\_allocation](#input\_identity\_sailpoint\_internal\_lb\_private\_ip\_address\_allocation) | sailpoint LB ip allocation type | `string` | `"static"` | no |
| <a name="input_identity_sailpoint_internal_lb_probe_interval_in_seconds"></a> [identity\_sailpoint\_internal\_lb\_probe\_interval\_in\_seconds](#input\_identity\_sailpoint\_internal\_lb\_probe\_interval\_in\_seconds) | (Optional) Port on which the Probe queries the backend endpoint | `number` | `5` | no |
| <a name="input_identity_sailpoint_internal_lb_probe_number_of_probes"></a> [identity\_sailpoint\_internal\_lb\_probe\_number\_of\_probes](#input\_identity\_sailpoint\_internal\_lb\_probe\_number\_of\_probes) | (Optional) The number of failed probe attempts after which the backend endpoint is removed from rotation. The default value is 2 | `number` | `2` | no |
| <a name="input_identity_sailpoint_internal_lb_probe_port"></a> [identity\_sailpoint\_internal\_lb\_probe\_port](#input\_identity\_sailpoint\_internal\_lb\_probe\_port) | (Required) Port on which the Probe queries the backend endpoint | `string` | n/a | yes |
| <a name="input_identity_sailpoint_internal_lb_probe_protocol"></a> [identity\_sailpoint\_internal\_lb\_probe\_protocol](#input\_identity\_sailpoint\_internal\_lb\_probe\_protocol) | (Optional) Specifies the protocol of the end point | `string` | n/a | yes |
| <a name="input_identity_sailpoint_internal_lb_probe_request_path"></a> [identity\_sailpoint\_internal\_lb\_probe\_request\_path](#input\_identity\_sailpoint\_internal\_lb\_probe\_request\_path) | (Optional) The URI used for requesting health status from the backend endpoint | `string` | `null` | no |
| <a name="input_identity_sailpoint_internal_lb_rule_be_port"></a> [identity\_sailpoint\_internal\_lb\_rule\_be\_port](#input\_identity\_sailpoint\_internal\_lb\_rule\_be\_port) | (Required) The port used for internal connections on the endpoint | `string` | n/a | yes |
| <a name="input_identity_sailpoint_internal_lb_rule_disable_outbound_snat"></a> [identity\_sailpoint\_internal\_lb\_rule\_disable\_outbound\_snat](#input\_identity\_sailpoint\_internal\_lb\_rule\_disable\_outbound\_snat) | (Optional) Load Balancer Rule to enable snat | `bool` | `false` | no |
| <a name="input_identity_sailpoint_internal_lb_rule_enable_floating_ip"></a> [identity\_sailpoint\_internal\_lb\_rule\_enable\_floating\_ip](#input\_identity\_sailpoint\_internal\_lb\_rule\_enable\_floating\_ip) | (Optional) Load Balancer Rule to enable Floating IPs | `bool` | `false` | no |
| <a name="input_identity_sailpoint_internal_lb_rule_enable_tcp_reset"></a> [identity\_sailpoint\_internal\_lb\_rule\_enable\_tcp\_reset](#input\_identity\_sailpoint\_internal\_lb\_rule\_enable\_tcp\_reset) | (Optional) Load Balancer Rule to enable TCP Reset | `bool` | `false` | no |
| <a name="input_identity_sailpoint_internal_lb_rule_fe_ip_configuration_name"></a> [identity\_sailpoint\_internal\_lb\_rule\_fe\_ip\_configuration\_name](#input\_identity\_sailpoint\_internal\_lb\_rule\_fe\_ip\_configuration\_name) | (Required) The name of the frontend IP configuration to which the rule is associated | `string` | n/a | yes |
| <a name="input_identity_sailpoint_internal_lb_rule_fe_port"></a> [identity\_sailpoint\_internal\_lb\_rule\_fe\_port](#input\_identity\_sailpoint\_internal\_lb\_rule\_fe\_port) | (Required) The port for the internal endpoint | `string` | n/a | yes |
| <a name="input_identity_sailpoint_internal_lb_rule_idle_timeout_in_minutes"></a> [identity\_sailpoint\_internal\_lb\_rule\_idle\_timeout\_in\_minutes](#input\_identity\_sailpoint\_internal\_lb\_rule\_idle\_timeout\_in\_minutes) | (Optional) Specifies the idle timeout in minutes for TCP connections | `number` | `4` | no |
| <a name="input_identity_sailpoint_internal_lb_rule_load_distribution"></a> [identity\_sailpoint\_internal\_lb\_rule\_load\_distribution](#input\_identity\_sailpoint\_internal\_lb\_rule\_load\_distribution) | (Optional) Specifies the load balancing distribution type to be used by the Load Balancer | `string` | `"SourceIPProtocol"` | no |
| <a name="input_identity_sailpoint_internal_lb_rule_protocol"></a> [identity\_sailpoint\_internal\_lb\_rule\_protocol](#input\_identity\_sailpoint\_internal\_lb\_rule\_protocol) | (Required) The transport protocol for the internal endpoint | `string` | n/a | yes |
| <a name="input_identity_sailpoint_internal_lb_sku"></a> [identity\_sailpoint\_internal\_lb\_sku](#input\_identity\_sailpoint\_internal\_lb\_sku) | (Optional) list of SKU's , every item of list is optional (default value Basic) | `string` | `"Standard"` | no |
| <a name="input_identity_sailpoint_lb_zone"></a> [identity\_sailpoint\_lb\_zone](#input\_identity\_sailpoint\_lb\_zone) | (Optional) availability zone of LB | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_identity_sailpoint_vm_computer_name"></a> [identity\_sailpoint\_vm\_computer\_name](#input\_identity\_sailpoint\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_identity_sailpoint_vm_computer_name_admin_username"></a> [identity\_sailpoint\_vm\_computer\_name\_admin\_username](#input\_identity\_sailpoint\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_identity_sailpoint_vm_data_disk1_size"></a> [identity\_sailpoint\_vm\_data\_disk1\_size](#input\_identity\_sailpoint\_vm\_data\_disk1\_size) | (Optional) The disk size gb for the managed disk of the windows vm. | `any` | `null` | no |
| <a name="input_identity_sailpoint_vm_data_disk2_size"></a> [identity\_sailpoint\_vm\_data\_disk2\_size](#input\_identity\_sailpoint\_vm\_data\_disk2\_size) | (Optional) The disk size gb for the managed disk of the windows vm. | `any` | `null` | no |
| <a name="input_identity_sailpoint_vm_data_disk3_size"></a> [identity\_sailpoint\_vm\_data\_disk3\_size](#input\_identity\_sailpoint\_vm\_data\_disk3\_size) | (Optional) The disk size gb for the managed disk of the windows vm. | `any` | `null` | no |
| <a name="input_identity_sailpoint_vm_domain_join_enable"></a> [identity\_sailpoint\_vm\_domain\_join\_enable](#input\_identity\_sailpoint\_vm\_domain\_join\_enable) | n/a | `bool` | `true` | no |
| <a name="input_identity_sailpoint_vm_image_id"></a> [identity\_sailpoint\_vm\_image\_id](#input\_identity\_sailpoint\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_identity_sailpoint_vm_os_disk_disk_size_gb"></a> [identity\_sailpoint\_vm\_os\_disk\_disk\_size\_gb](#input\_identity\_sailpoint\_vm\_os\_disk\_disk\_size\_gb) | (Optional) The disk size gb for the os disk of the windows vm. | `any` | `null` | no |
| <a name="input_identity_sailpoint_vm_os_disk_storage_account_type"></a> [identity\_sailpoint\_vm\_os\_disk\_storage\_account\_type](#input\_identity\_sailpoint\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_identity_sailpoint_vm_size"></a> [identity\_sailpoint\_vm\_size](#input\_identity\_sailpoint\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_identity_ss_mgmt_address_prefix"></a> [identity\_ss\_mgmt\_address\_prefix](#input\_identity\_ss\_mgmt\_address\_prefix) | (Required) The address prefix for the SS Mgmt subnet. | `string` | n/a | yes |
| <a name="input_identity_subnet_service_endpoints"></a> [identity\_subnet\_service\_endpoints](#input\_identity\_subnet\_service\_endpoints) | (Required) The list of Service endpoints to associate with the subnet. | `list(string)` | <pre>[<br>  "Microsoft.Storage"<br>]</pre> | no |
| <a name="input_identity_to_avd_peering_network_id"></a> [identity\_to\_avd\_peering\_network\_id](#input\_identity\_to\_avd\_peering\_network\_id) | AVD resource string for peering connection | `string` | n/a | yes |
| <a name="input_identity_to_ihub_peering_network_id"></a> [identity\_to\_ihub\_peering\_network\_id](#input\_identity\_to\_ihub\_peering\_network\_id) | ihub resource string for peering connection | `string` | n/a | yes |
| <a name="input_identity_to_prod_pr_ss_peering_network_id"></a> [identity\_to\_prod\_pr\_ss\_peering\_network\_id](#input\_identity\_to\_prod\_pr\_ss\_peering\_network\_id) | Prod PR SS resource string for peering connection | `string` | `""` | no |
| <a name="input_identity_to_sharedsvcs_peering_network_id"></a> [identity\_to\_sharedsvcs\_peering\_network\_id](#input\_identity\_to\_sharedsvcs\_peering\_network\_id) | Shared svcs resource string for peering connection | `string` | n/a | yes |
| <a name="input_identity_to_ss_dr_peering_network_id"></a> [identity\_to\_ss\_dr\_peering\_network\_id](#input\_identity\_to\_ss\_dr\_peering\_network\_id) | idty dr resource string for peering connection | `string` | n/a | yes |
| <a name="input_identity_to_ss_prod_peering_network_id"></a> [identity\_to\_ss\_prod\_peering\_network\_id](#input\_identity\_to\_ss\_prod\_peering\_network\_id) | idty prod resource string for peering connection | `string` | n/a | yes |
| <a name="input_identity_vm_domain_name"></a> [identity\_vm\_domain\_name](#input\_identity\_vm\_domain\_name) | (Required) domain name | `any` | n/a | yes |
| <a name="input_identity_vm_domain_password"></a> [identity\_vm\_domain\_password](#input\_identity\_vm\_domain\_password) | (Required) domain join password credentials. | `any` | n/a | yes |
| <a name="input_identity_vm_domain_user_upn"></a> [identity\_vm\_domain\_user\_upn](#input\_identity\_vm\_domain\_user\_upn) | (Required) user UPN for domain join creds | `any` | n/a | yes |
| <a name="input_identity_vm_ou_path"></a> [identity\_vm\_ou\_path](#input\_identity\_vm\_ou\_path) | (Required) OU path of domain | `any` | n/a | yes |
| <a name="input_identity_vnet_address_space"></a> [identity\_vnet\_address\_space](#input\_identity\_vnet\_address\_space) | (Required) The address space for the virtual network. | `string` | n/a | yes |
| <a name="input_identity_vnet_dns_servers"></a> [identity\_vnet\_dns\_servers](#input\_identity\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_identity_vnet_prod_id"></a> [identity\_vnet\_prod\_id](#input\_identity\_vnet\_prod\_id) | (Optional) PROD IDTY VNET ID. | `string` | `""` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  resource_name_no_dash    = replace("${var.env}${var.postfix}${var.suffix}", "-", "")

  timeout_duration = "2h"

  #KeyVault
  identity_rg_keyvault_name            = var.identity_keyvault_enable && var.identity_rg_security_enable ?  azurerm_resource_group.identity_rg_security[0].name  : azurerm_resource_group.identity_rg_data.name
  identity_private_link_subnet          = var.identity_deploy_private_link_subnet ? [azurerm_subnet.identity_private_link_subnet[0].id]              : var.identity_keyvault_allowed_pe_subnet_ids

  identity_private_dns_zone_id_map = {
   "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.adx.monitor.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.us",
                "/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
   "prod-pr" = [""]
   "prod-dr" = [""]
  }

  private_dns_zones = [
    "privatelink.${var.dns_location}.database.usgovcloudapi.net",
    "privatelink.${var.dns_location}.batch.usgovcloudapi.net",
    "privatelink.${var.dns_location}.backup.windowsazure.us",
    "privatelink.azure-automation.us",
    "privatelink.database.usgovcloudapi.net",
    "privatelink.blob.core.usgovcloudapi.net",
    "privatelink.table.core.usgovcloudapi.net",
    "privatelink.queue.core.usgovcloudapi.net",
    "privatelink.file.core.usgovcloudapi.net",
    "privatelink.web.core.usgovcloudapi.net",
    "privatelink.documents.azure.us",
    "privatelink.postgres.database.usgovcloudapi.net",
    "privatelink.mysql.database.usgovcloudapi.net",
    "privatelink.mariadb.database.usgovcloudapi.net",
    "privatelink.vaultcore.usgovcloudapi.net",
    "privatelink.search.windows.us",
    "privatelink.azconfig.azure.us",
    "privatelink.siterecovery.windowsazure.us",
	  "privatelink.servicebus.windows.us1",
    "privatelink.servicebus.usgovcloudapi.net",
    "privatelink.azure-devices.us",
	  "privatelink.oms.opinsights.azure.us",
	  "privatelink.ods.opinsights.azure.us",
    "privatelink.azurewebsites.us",
	  "privatelink.cognitiveservices.azure.us",
    "privatelink.adx.monitor.azure.us",
    "privatelink.agentsvc.azure-automation.us",
    "privatelink.redis.cache.usgovcloudapi.net",
    "privatelink.azurehdinsight.us",
    "privatelink.azurecr.us",
    "privatelink.mongo.cosmos.azure.us",
    "privatelink.dfs.core.usgovcloudapi.net",
    "privatelink.azuresynapse.usgovcloudapi.net",
    "privatelink.dev.azuresynapse.usgovcloudapi.net",
    "privatelink.sql.azuresynapse.usgovcloudapi.net",
    "privatelink.${var.dns_aks_location}.cx.aks.containerservice.azure.us",
    "privatelink.datafactory.azure.us",
    "privatelink.adf.azure.us",
    "privatelink.monitor.azure.us",
  ]

  custom_data = <<CUSTOM_DATA
  temp_license: TE-SoT
  default_admin_password: '${var.identity_dns_vm_admin_pass}'
  CUSTOM_DATA
}
//**********************************************************************************************

```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_identity_ad_sync_subnet"></a> [identity\_ad\_sync\_subnet](#output\_identity\_ad\_sync\_subnet) | n/a |
| <a name="output_identity_backup"></a> [identity\_backup](#output\_identity\_backup) | n/a |
| <a name="output_identity_dc_subnet"></a> [identity\_dc\_subnet](#output\_identity\_dc\_subnet) | n/a |
| <a name="output_identity_dns_lan_subnet"></a> [identity\_dns\_lan\_subnet](#output\_identity\_dns\_lan\_subnet) | n/a |
| <a name="output_identity_dns_mgmt_subnet"></a> [identity\_dns\_mgmt\_subnet](#output\_identity\_dns\_mgmt\_subnet) | n/a |
| <a name="output_identity_keyvault"></a> [identity\_keyvault](#output\_identity\_keyvault) | n/a |
| <a name="output_identity_log_analytics_workspace"></a> [identity\_log\_analytics\_workspace](#output\_identity\_log\_analytics\_workspace) | n/a |
| <a name="output_identity_peering_ihub"></a> [identity\_peering\_ihub](#output\_identity\_peering\_ihub) | n/a |
| <a name="output_identity_peering_sharedsvcs"></a> [identity\_peering\_sharedsvcs](#output\_identity\_peering\_sharedsvcs) | n/a |
| <a name="output_identity_private_link_subnet"></a> [identity\_private\_link\_subnet](#output\_identity\_private\_link\_subnet) | n/a |
| <a name="output_identity_rg_data"></a> [identity\_rg\_data](#output\_identity\_rg\_data) | n/a |
| <a name="output_identity_rg_logging"></a> [identity\_rg\_logging](#output\_identity\_rg\_logging) | n/a |
| <a name="output_identity_rg_network"></a> [identity\_rg\_network](#output\_identity\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_identity_rg_security"></a> [identity\_rg\_security](#output\_identity\_rg\_security) | n/a |
| <a name="output_identity_sailpoint_vm"></a> [identity\_sailpoint\_vm](#output\_identity\_sailpoint\_vm) | n/a |
| <a name="output_identity_vnet"></a> [identity\_vnet](#output\_identity\_vnet) | n/a |


## Usage

```terraform
//**********************************************************************************************
module "identity" {
    source                                                  = "../dn-tads_tf-azure-component-library/government/core/core_us_gov_identity"
    env                                                     = var.env
    postfix                                                 = var.postfix
    location                                                = var.location
    hub_env                                                 = var.env
    suffix                                                  = var.suffix
    tags                                                    = var.tags
    identity_vnet_address_space                             = var.identity_vnet_address_space
    identity_vnet_dns_servers                               = var.identity_vnet_dns_servers
    identity_dns_lan_sub_address_prefix                     = var.identity_dns_lan_sub_address_prefix  
    identity_dns_mgmt_sub_address_prefix                    = var.identity_dns_mgmt_sub_address_prefix
    identity_dc_sub_address_prefix                          = var.identity_dc_sub_address_prefix
    identity_ad_sync_sub_address_prefix                     = var.identity_ad_sync_sub_address_prefix
    identity_deploy_private_link_subnet                     = true
    identity_private_link_subnet_address_prefixes           = var.identity_private_link_subnet_address_prefixes  
    identity_private_link_subnet_service_endpoints          = var.identity_private_link_subnet_service_endpoints
    identity_dc_vm_computer_name                            = var.identity_dc_vm_computer_name
    identity_dc_vm_image_id                                 = var.identity_dc_vm_image_id 
    identity_dc_vm_admin_user                               = var.identity_dc_vm_admin_user 
    identity_dc_vm_admin_pass                               = var.identity_dc_vm_admin_pass 
    identity_dc_vm_size                                     = var.identity_dc_vm_size 
    identity_dc_vm_os_disk_disk_size_gb                     = var.identity_dc_vm_os_disk_disk_size_gb 
    identity_dc_vm_logging_disk_size                        = var.identity_dc_vm_logging_disk_size
    identity_dc_vm_data_disk_size                           = var.identity_dc_vm_data_disk_size
    identity_to_ihub_peering_network_id                     = var.identity_to_ihub_peering_network_id
    identity_to_sharedsvcs_peering_network_id               = var.identity_to_sharedsvcs_peering_network_id
    identity_bastion_sub_address_prefix                     = var.identity_bastion_sub_address_prefix 
    identity_rg_security_enable                             = true
    identity_keyvault_enable                                = false #remove temporally
    identity_private_link_subnet_enforce_endpoint_network_policies = true
    #identity_keyvault_nacl_allowed_subnets                     = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-sharedsvc-vnet/subnets/nprd-pr-sharedghr-kubernetes-nodes-sn"]
    #identity_keyvault_nacl_allowed_ips                     = ["199.207.253.96","199.206.0.0/15","199.207.253.101"]
    identity_keyvault_deploy_private_dns_zone               = true


    

    identity_ad_sync_vm_computer_name                       = var.identity_ad_sync_vm_computer_name
    identity_ad_sync_vm_image_id                            = var.identity_ad_sync_vm_image_id 
    identity_ad_sync_vm_admin_user                          = var.identity_ad_sync_vm_admin_user 
    identity_ad_sync_vm_admin_pass                          = var.identity_ad_sync_vm_admin_pass 
    identity_ad_sync_vm_size                                = var.identity_ad_sync_vm_size 
    identity_default_internet_route_peninsula_next_hop_ip   = var. identity_default_internet_route_peninsula_next_hop_ip
    identity_dns_vm_deploy_rg                               = var.identity_dns_vm_deploy_rg
    identity_dns_vm_deploy_subnet_nsg                       = var.identity_dns_vm_deploy_subnet_nsg
    identity_dns_vm_publisher                               = var.identity_dns_vm_publisher
    identity_dns_vm_offer                                   = var.identity_dns_vm_offer 
    identity_dns_vm_sku                                     = var.identity_dns_vm_sku 
    identity_dns_vm_computer_name                           = var.identity_dns_vm_computer_name 
   # identity_dns_vm_license_type                            = var.identity_dns_vm_license_type
    identity_dns_vm_version                                 = var.identity_dns_vm_version
    identity_dns_vm_os_disk_caching                         = var.identity_dns_vm_os_disk_caching
    identity_dns_vm_os_disk_storage_account_type            = var.identity_dns_vm_os_disk_storage_account_type
    identity_dns_vm_os_disk_disk_size_gb                    = var.identity_dns_vm_os_disk_disk_size_gb
    identity_dns_vm_os_disk_write_accelerator_enabled       = var.identity_dns_vm_os_disk_write_accelerator_enabled
    identity_dns_vm_os_ultra_ssd_enabled                    = var.identity_dns_vm_os_ultra_ssd_enabled 
    identity_dns_vm_os                                      = var.identity_dns_vm_os
    identity_dns_vm_enable_automatic_updates                = var.identity_dns_vm_enable_automatic_updates
    identity_dns_vm_provision_vm_agent                      = var.identity_dns_vm_provision_vm_agent
    identity_dns_vm_timezone                                = var.identity_dns_vm_timezone
    identity_dns_vm_enable_encryption_at_host               = var.identity_dns_vm_enable_encryption_at_host
    identity_dns_vm_enable_backup                           = var.identity_dns_vm_enable_backup 
    identity_dns_vm_enable_log_analytics_settings           = var.identity_dns_vm_enable_log_analytics_settings 
    identity_dns_vm_enable_antimalware_protection           = var.identity_dns_vm_enable_antimalware_protection 
    identity_dns_vm_enable_domain_join                      = var.identity_dns_vm_enable_domain_join
    identity_dns_vm_enable_guest_config                     = var.identity_dns_vm_enable_guest_config
    identity_dns_vm_bastion_enable                          = var.identity_dns_vm_bastion_enable
    identity_dns_vm_deploy_nsg_rules                        = var.identity_dns_vm_deploy_nsg_rules
    identity_dns_vm_size                                    = var.identity_dns_vm_size
    identity_dns_vm_admin_user                              = var.identity_dns_vm_admin_user
    identity_dns_vm_admin_pass                              = var.identity_dns_vm_admin_pass
    identity_dns_vm_from_marketplace                        = var.identity_dns_vm_from_marketplace
    identity_dns_vm_boot_sa_postfix                         = var.identity_dns_vm_boot_sa_postfix
    identity_dns_vm_nsg_sa_postfix                          = var.identity_dns_vm_nsg_sa_postfix
    identity_dns_vm_user_defined_nsg_rules                  = var.identity_dns_vm_user_defined_nsg_rules
    
}
//**********************************************************************************************
    
    
// Complete the Peerring SharedServices to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "sharedsvcs_peering_core" {
  provider                     = azurerm.shs
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_shared_services_resource_group_map, var.env)  
  virtual_network_name         = lookup(local.core_shared_services_network_name_map, var.env) 
  remote_virtual_network_id    = module.identity.identity_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = false
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = false

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
}
//**********************************************************************************************

// Complete Peering IHub to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "ihub_peering_spoke" {
  provider                     = azurerm.ihub 
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_ihub_resource_group_name_map, var.env) 
  virtual_network_name         = lookup(local.core_ihub_resource_network_name_map, var.env)
  remote_virtual_network_id    = module.identity.identity_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = true

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
## Local Values

```terraform
locals {
  timeout_duration = "2h"

  core_keyvault_private_dns_zone = var.core_keyvault_enable && var.core_keyvault_deploy_private_dns_zone ? [azurerm_private_dns_zone.core_keyvault_azure_private_dns_zone[0].id] : var.core_keyvault_private_dns_zone_ids
  core_rg_keyvault_name          = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_shared_services_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-sharedsvc-vnet"
    "prod-pr" = "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-network/providers/Microsoft.Network/virtualNetworks/vnet-prod-shared"
    "prod-dr" = "/subscriptions/153c5e81-83af-4fb0-b548-b16e9ee8f45b/resourceGroups/rg-dr-shared-network/providers/Microsoft.Network/virtualNetworks/vnet-dr-shared"
  }

  core_first_remote_nva_pip = {
    "nprd-pr" = "52.138.102.104"    
    "prod-pr" = "137.135.105.155"   
    "prod-dr" = "104.42.249.54"
  }

  core_first_bgp_peering_address = {
    "nprd-pr" = "10.4.65.205"
    "prod-pr" = "10.47.129.203" 
    "prod-dr" = "10.47.161.203" 
  }

  core_first_connection_address_space = {
    "nprd-pr" = ["10.4.65.205/32"]
    "prod-pr" = ["10.47.129.203/32"]  
    "prod-dr" = ["10.47.161.203/32"]
  }

  core_second_remote_nva_pip = {
    "nprd-pr" = "52.138.102.58"   
    "prod-pr" = "137.135.105.219"
    "prod-dr" = "13.88.182.186"
  }

  core_second_bgp_peering_address = {
    "nprd-pr" = "10.4.65.206"
    "prod-pr" = "10.47.129.204"
    "prod-dr" = "10.47.161.204"
  }

  core_second_connection_address_space = {
    "nprd-pr" = ["10.4.65.206/32"]
    "prod-pr" = ["10.47.129.204/32"]
    "prod-dr" = ["10.47.161.204/32"]
  }

  core_remote_bgp_asn = {
    "nprd-pr" = "65200"   
    "prod-pr" = "65250"
    "prod-dr" = "65255"
  }

  core_bgp_asn = {
    "nprd-pr" = "65203"
    "prod-pr" = "65253"
    "prod-dr" = "65227"
  }

  //private dns map for log Analytics Workspace

   core_shared_services_private_dns_zone_id_map = {
    "nprd-pr" = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net" ]
    "prod-pr" = ["/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"]
    "prod-dr" = [""]
  }


  core_subscription_diagnostics_settings = {
    logs    = ["Administrative", "Security", "ServiceHealth", "Alert", "Recommendation", "Policy", "Autoscale", "ResourceHealth"]
    metrics = []
  }

  core_vgw_diagnostics_settings = {
    logs    = ["GatewayDiagnosticLog", "IKEDiagnosticLog", "P2SDiagnosticLog", "RouteDiagnosticLog", "TunnelDiagnosticLog"]
    metrics = ["AllMetrics"]
  }

  core_vnet_diagnostics_settings = {
    logs    = ["VMProtectionAlerts"]
    metrics = ["AllMetrics"]
  }

  core_public_ip_diagnostics_settings = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
```
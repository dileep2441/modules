
## Usage

```terraform
// Deploy US CH Shared Services Platform
//**********************************************************************************************
 module "core_us_ch_peninsula_sharedsvs" {
     source                                                 = "../dn-tads_tf-azure-component-library/core/core_us_ch_peninsula_sharedsvs"
     env                                                    = var.env
     postfix                                                = var.postfix
     location                                               = var.location
     hub_env                                                = var.env
     core_vnet_address_space                                = var.core_vnet_address_space
     core_vnet_dns_servers                                  = var.core_vnet_dns_servers 
     gateway_sub_address_prefix                             = var.gateway_sub_address_prefix  
     core_keyvault_postfix                                  = var.core_keyvault_postfix
     core_azure_defender_resources                          = var.core_azure_defender_resources 
     core_private_link_subnet_address_prefixes              = var.core_private_link_subnet_address_prefixes
     core_route_table_disable_bgp_propagation               = var.core_route_table_disable_bgp_propagation
     core_azure_bastion_subnet_prefix                       = var.core_azure_bastion_subnet_prefix  
     core_mgmt_sub_address_prefix                           = var.core_mgmt_sub_address_prefix
     core_imgbuilder_sub_address_prefix                     = var.core_imgbuilder_sub_address_prefix 
     core_azure_vm_image_build_number                       = var.BUILD_NUMBER
     core_azure_vm_image_builder_distribute_replicationRegions = var.core_azure_vm_image_builder_distribute_replicationRegions
     core_windows_vm_deploy                                 = var.core_windows_vm_deploy
     core_windows_vm_dns_forwarder_domain_user_upn          = var.DOMAIN_USER_US_CH
     core_windows_vm_dns_forwarder_domain_password          = var.DOMAIN_PASSWORD_US_CH
     core_windows_vm_dns_forwarder_computer_name            = var.core_windows_vm_dns_forwarder_computer_name
     core_windows_vm_dns_forwarder_image_id                 = var.core_vm_image_id
     core_windows_vm_jumpbox_computer_name                  = var.core_windows_vm_jumpbox_computer_name
     core_windows_vm_jumpbox_image_id                       = var.core_vm_image_id
     core_windows_vm_jumpbox_domain_user_upn                = var.DOMAIN_USER_US_CH
     core_windows_vm_jumpbox_domain_password                = var.DOMAIN_PASSWORD_US_CH
     core_keyvault_nacl_allowed_ips                         = concat(var.core_keyvault_nacl_allowed_ips, [var.GITHUBIP])
     core_ptrn_kubernetes_deploy                            = var.core_ptrn_kubernetes_deploy
     core_ptrn_kubernetes_postfix                           = var.core_ptrn_kubernetes_postfix 
     core_ptrn_kubernetes_subnet_nodes_address_prefixes     = var.core_ptrn_kubernetes_subnet_nodes_address_prefixes 
     core_ptrn_kubernetes_kubernetes_version                = var.core_ptrn_kubernetes_kubernetes_version 
     core_ptrn_kubernetes_rbac_aad_admin_group_object_ids   = var.core_ptrn_kubernetes_rbac_aad_admin_group_object_ids
     tags                                                   = var.tags
}
//**********************************************************************************************

// To enable USCH multi-home the CloudOps requiere to enable and apply the policy (https://kiki.us.kworld.kpmg.com/display/6TO/Enable+Azure+Monitor+for+VMs+with+Azure+Monitoring+Agent). And from TF it requiere to deploy DCR 
endpoint deployment with azurerm provider 3.22.0
//**********************************************************************************************

// Data Collection Rules for Windows VM's in each subscription to send metricts to LAW PROD
//**********************************************************************************************
data "azurerm_log_analytics_workspace" "cl_log_analytics_workspace" {
  name                = "oms-prod-pr-shrdsvc-log-analytics"                      
  resource_group_name = "rg-prod-pr-shrdsvc-logging"
}

//Create DCE endpoint 
//**********************************************************************************************
resource "azurerm_monitor_data_collection_endpoint" "log_analytics_data_collection_rule_endpoint" {
  name                          = "${var.env}-${var.postfix}-dc-endpoint"
  resource_group_name           = data.azurerm_log_analytics_workspace.cl_log_analytics_workspace.resource_group_name  
  location                      = var.location
  kind                          = "Windows"
  public_network_access_enabled = false
  description                   = "monitor_data_collection_endpoint"
  tags                          = var.tags
}
//**********************************************************************************************
```

```terraform
// Deploy US CH DR Shared Services Platform 
************************************************************************************************
//AKS data sources
//******************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone_acr" {
  provider            = azurerm.shs
  name                = "privatelink.azurecr.io"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

data "azurerm_private_dns_zone" "core_data_private_dns_zone_aks" {
  provider            = azurerm.shs
  name                = "privatelink.westus.azmk8s.io"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

//Key Vault data sources
//*****************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone" {
  provider            = azurerm.shs
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

//image builder data sources
//*****************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone_sa" {
  provider            = azurerm.shs
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

//log analytics data sources
//*****************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone_monitor" {
  provider            = azurerm.shs
  name                = "privatelink.monitor.azure.com"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_ods" {
  provider              = azurerm.shs
  name                = "privatelink.ods.opinsights.azure.com"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_oms" {
  provider              = azurerm.shs
  name                = "privatelink.oms.opinsights.azure.com"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_automation" {
  provider              = azurerm.shs
  name                = "privatelink.agentsvc.azure-automation.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_blob" {
  provider              = azurerm.shs
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_virtual_network" "core_data_shdsvc_vnet_prod" {
  provider            = azurerm.shs
  name                = "prod-pr-shrdsvc-vnet"
  resource_group_name = "rg-prod-pr-shrdsvc-network"
}
//*****************************************************************************************

// Deploy the US CH SharedServices DR Peninsula Core
//*****************************************************************************************************
module "core_us_ch_peninsula_sharedsvs" {
  source                                                    = "../dn-tads_tf-azure-component-library/core/core_us_ch_peninsula_sharedsvs"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  hub_env                                                   = var.env
  core_vnet_address_space                                   = var.core_vnet_address_space
  core_vnet_dns_servers                                     = var.core_vnet_dns_servers
  gateway_sub_address_prefix                                = var.gateway_sub_address_prefix
  core_azure_defender_resources                             = var.core_azure_defender_resources
  core_private_link_subnet_address_prefixes                 = var.core_private_link_subnet_address_prefixes
  core_route_table_disable_bgp_propagation                  = var.core_route_table_disable_bgp_propagation
  core_azure_bastion_subnet_prefix                          = var.core_azure_bastion_subnet_prefix
  core_azure_bastion_availability_zone                      = var.core_azure_bastion_availability_zone
  core_mgmt_sub_address_prefix                              = var.core_mgmt_sub_address_prefix
  core_windows_vm_deploy                                    = var.core_windows_vm_deploy
  core_windows_vm_dns_forwarder_domain_user_upn             = var.DOMAIN_USER_US_CH
  core_windows_vm_dns_forwarder_domain_password             = var.DOMAIN_PASSWORD_US_CH
  core_windows_vm_dns_forwarder_computer_name               = var.core_windows_vm_dns_forwarder_computer_name
  core_windows_vm_dns_forwarder_image_id                    = var.core_vm_image_id
  core_windows_vm_jumpbox_computer_name                     = var.core_windows_vm_jumpbox_computer_name
  core_windows_vm_jumpbox_image_id                          = var.core_vm_image_id
  core_windows_vm_jumpbox_domain_user_upn                   = var.DOMAIN_USER_US_CH
  core_windows_vm_jumpbox_domain_password                   = var.DOMAIN_PASSWORD_US_CH
  core_windows_vm_log_analytics_workspace_sentinel_id       = var.SENTINEL_CH_LAW_ID
  core_windows_vm_log_analytics_primary_sentinel_shared_key = var.SENTINEL_CH_LAW_SHAREDKEY
  core_windows_vm_log_analytics_workspace_resource_id       = var.SENTINEL_CH_LAW_RESOURCE_ID
  core_ptrn_kubernetes_deploy                               = var.core_ptrn_kubernetes_deploy
  core_ptrn_kubernetes_postfix                              = var.core_ptrn_kubernetes_postfix
  core_ptrn_kubernetes_subnet_nodes_address_prefixes        = var.core_ptrn_kubernetes_subnet_nodes_address_prefixes
  core_ptrn_kubernetes_kubernetes_version                   = var.core_ptrn_kubernetes_kubernetes_version
  core_ptrn_kubernetes_rbac_aad_admin_group_object_ids      = var.core_ptrn_kubernetes_rbac_aad_admin_group_object_ids
  core_ptrn_kubernetes_azure_container_registry_prodtodr_id = "/subscriptions/e17b69e4-59eb-4b56-a090-d08f87c300de/resourceGroups/rg-prod-pr-shrdsvc-kubernetes-ghshr/providers/Microsoft.ContainerRegistry/registries/prodprshrdsvcacr"
  core_keyvault_prodtodr_id                                 = "/subscriptions/e17b69e4-59eb-4b56-a090-d08f87c300de/resourceGroups/rg-prod-pr-shrdsvc-security/providers/Microsoft.KeyVault/vaults/prod-pr-shrdsvc-kv-cp"
  core_ptrn_kubernetes_default_node_pool_availability_zones = var.core_ptrn_kubernetes_default_node_pool_availability_zones
  core_ptrn_kubernetes_node_pool_availability_zones         = var.core_ptrn_kubernetes_node_pool_availability_zones
  core_ptrn_kubernetes_deploy_azure_container_registry      = false 
  core_keyvault_enable                                      = false
  core_rg_security_enable                                   = false
  core_shared_image_gallery_deploy                          = false
  core_law_private_dns_zone_ids                             = [data.azurerm_private_dns_zone.core_data_private_dns_zone_monitor.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_ods.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_oms.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_automation.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_blob.id]
  core_ptrn_kubernetes_private_dns_zone_id                  = data.azurerm_private_dns_zone.core_data_private_dns_zone_aks.id
  core_private_dns_zone_enable                              = false
  core_deploy_dr_shsdsvc_to_prod_shsdsvc_peering            = true
  core_dr_to_shsdsvc_prod_peering_network_id                = data.azurerm_virtual_network.core_data_shdsvc_vnet_prod.id
  tags                                                      = var.tags
}
//*****************************************************************************************


//*****************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "core_dns_zones" {
  provider                                                 = azurerm.shs
  for_each                                                 = local.core_prod_private_dns_zones
  name                                                     = "vnetlink-${var.env}-${var.postfix}-${replace(each.key, "privatelink.", "")}"
  resource_group_name                                      = var.core_rg_private_dnszone_sharedsvcs_prod
  private_dns_zone_name                                    = data.terraform_remote_state.core_shared_prod.outputs.core_us_ch_peninsula_sharedsvs.core_dns_zones[each.key].name
  virtual_network_id                                       = module.core_us_ch_peninsula_sharedsvs.core_vnet.id
  tags                                                     = var.tags
}
//*****************************************************************************************

// To enable USCH multi-home the CloudOps requiere to enable and apply the policy (https://kiki.us.kworld.kpmg.com/display/6TO/Enable+Azure+Monitor+for+VMs+with+Azure+Monitoring+Agent). And from TF it requiere to deploy DCR 
endpoint deployment with azurerm provider 3.22.0
//**********************************************************************************************

// Data Collection Rules for Windows VM's in each subscription to send metricts to LAW PROD
//**********************************************************************************************
data "azurerm_log_analytics_workspace" "cl_log_analytics_workspace" {
  name                = "oms-prod-pr-shrdsvc-log-analytics"                      
  resource_group_name = "rg-prod-pr-shrdsvc-logging"
}

//Create DCE endpoint 
//**********************************************************************************************
resource "azurerm_monitor_data_collection_endpoint" "log_analytics_data_collection_rule_endpoint" {
  name                          = "${var.env}-${var.postfix}-dc-endpoint"
  resource_group_name           = data.azurerm_log_analytics_workspace.cl_log_analytics_workspace.resource_group_name  
  location                      = var.location
  kind                          = "Windows"
  public_network_access_enabled = false
  description                   = "monitor_data_collection_endpoint"
  tags                          = var.tags
}
//**********************************************************************************************
```
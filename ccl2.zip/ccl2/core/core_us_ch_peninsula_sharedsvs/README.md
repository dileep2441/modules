<!-- BEGIN_TF_DOCS -->

# Azure Shared Services Platform Module
Shared Services subscription has the consolidation of the Azure services and resources that are used by multiple Spoke subscriptions to perform their business needs. It helps the enterprise to have the central control over common services and security aspects, while maintaining segregation for the workloads in each spoke. US Country Hosting Platform is will deployed from slingshot tool.



## Resources

| Name | Type |
|------|------|
| [azurerm_availability_set.core_dns_forwarder_vm_avset](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.core_jumpbox_vm_avset](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_key_vault_secret.core_dns_forwarder_dr_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.core_dns_forwarder_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.core_jumpbox_dr_wvm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.core_jumpbox_wvm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_local_network_gateway.core_primary_local_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/local_network_gateway) | resource |
| [azurerm_local_network_gateway.core_secondary_local_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/local_network_gateway) | resource |
| [azurerm_monitor_diagnostic_setting.core_primary_vgw_pip_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.core_secondary_vgw_pip_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.core_virtual_network_gateway_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.core_vnet_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_private_link_scope.log_analytics_private_link_scope](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scope) | resource |
| [azurerm_monitor_private_link_scoped_service.log_analytics_link_scoped_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scoped_service) | resource |
| [azurerm_monitor_private_link_scoped_service.log_analytics_sentinel_link_scoped_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scoped_service) | resource |
| [azurerm_network_interface_security_group_association.core_jumpbox_vm_nsg_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_interface_security_group_association.core_windows_vm_dns_forwarder_nsg_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.core_azure_image_builder_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.core_windows_vm_dns_forwarder_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.core_azure_image_builder_nsg_nsgrule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.core_vm_azure_bastion_nsgrule_22](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.core_vm_azure_bastion_nsgrule_3389](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_private_dns_zone.core_dns_zones](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.core_dns_zones](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_endpoint.log_analytics_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_public_ip.core_primary_vgw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.core_secondary_vgw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_resource_group.core_rg_azure_image_builder](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_azure_qualys](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_image_gallery](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_private_dns_forwarder](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.core_azure_acr_aksghshr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.core_azure_aksghshr_role_assigned_contributor](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.core_azure_aksghshr_role_assigned_mi_operator](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.core_azure_dns_aksghshr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.core_azure_dns_aksghshrdr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.core_azure_keyvault_aksghshr_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.core_azure_keyvault_spn_role_assigned](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_route.core_default_internet_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.core_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_security_center_auto_provisioning.core_security_center_auto_provisioning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_auto_provisioning) | resource |
| [azurerm_security_center_contact.core_security_center_contact_info](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_contact) | resource |
| [azurerm_security_center_setting.core_security_center_wdatp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_setting) | resource |
| [azurerm_security_center_subscription_pricing.core_security_center_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_shared_image_gallery.core_shared_image_gallery](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/shared_image_gallery) | resource |
| [azurerm_subnet.core_azure_image_builder_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.core_gateway_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.core_mgmt_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.core_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.core_azure_image_builder_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.core_windows_vm_dns_forwarder_nsg_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.core_windows_vm_dns_forwarder_route_table_associate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_user_assigned_identity.core_ptrn_Kubernetes_user_assigned_identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azurerm_virtual_network.core_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_gateway.core_virtual_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway) | resource |
| [azurerm_virtual_network_gateway_connection.core_primary_vgw_to_lgw_connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway_connection) | resource |
| [azurerm_virtual_network_gateway_connection.core_secondary_vgw_to_lgw_connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway_connection) | resource |
| [azurerm_virtual_network_peering.peering-dr-ss-to-prod-ss](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-prod-ss-to-dr-ss](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [random_password.core_dns_forwarder_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.core_jumpbox_wvm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_acr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_aks](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_automation](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_monitor](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_ods](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_oms](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |
| [azurerm_private_dns_zone.core_data_private_dns_zone_sa](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/private_dns_zone) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_core_azure_backup_deploy_rsv"></a> [core\_azure\_backup\_deploy\_rsv](#input\_core\_azure\_backup\_deploy\_rsv) | (Optional) If true, deploy rsv. | `bool` | `true` | no |
| <a name="input_core_azure_backup_diagnostics"></a> [core\_azure\_backup\_diagnostics](#input\_core\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_core_azure_backup_enable_blob_storage_backup"></a> [core\_azure\_backup\_enable\_blob\_storage\_backup](#input\_core\_azure\_backup\_enable\_blob\_storage\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `true` | no |
| <a name="input_core_azure_backup_enable_file_storage_backup"></a> [core\_azure\_backup\_enable\_file\_storage\_backup](#input\_core\_azure\_backup\_enable\_file\_storage\_backup) | (Optional) Toggle the file storage backup feature. | `bool` | `true` | no |
| <a name="input_core_azure_backup_enable_vm_backup"></a> [core\_azure\_backup\_enable\_vm\_backup](#input\_core\_azure\_backup\_enable\_vm\_backup) | (Optional) Toggle the vm backup feature. | `bool` | `true` | no |
| <a name="input_core_azure_backup_retention_daily_count"></a> [core\_azure\_backup\_retention\_daily\_count](#input\_core\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_core_azure_backup_time"></a> [core\_azure\_backup\_time](#input\_core\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_core_azure_backup_timezone"></a> [core\_azure\_backup\_timezone](#input\_core\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_core_azure_bastion_availability_zone"></a> [core\_azure\_bastion\_availability\_zone](#input\_core\_azure\_bastion\_availability\_zone) | (Optional) The availability zone to allocate the Public IP in. Possible values are Zone-Redundant, 1, 2, 3, and No-Zone. Defaults to Zone-Redundant. | `string` | `"Zone-Redundant"` | no |
| <a name="input_core_azure_bastion_scale_units"></a> [core\_azure\_bastion\_scale\_units](#input\_core\_azure\_bastion\_scale\_units) | (Optional) The number of scale units with which to provision the Bastion Host. Possible values are between 2 and 50. Defaults to 2. | `string` | `"6"` | no |
| <a name="input_core_azure_bastion_subnet_prefix"></a> [core\_azure\_bastion\_subnet\_prefix](#input\_core\_azure\_bastion\_subnet\_prefix) | (Required) The prefix of the azure bastion subnet. | `list(string)` | n/a | yes |
| <a name="input_core_azure_container_registry_georeplication_location"></a> [core\_azure\_container\_registry\_georeplication\_location](#input\_core\_azure\_container\_registry\_georeplication\_location) | (Optional) A location where the container registry should be geo-replicated. | `string` | `""` | no |
| <a name="input_core_azure_container_registry_zone_redundancy_enabled"></a> [core\_azure\_container\_registry\_zone\_redundancy\_enabled](#input\_core\_azure\_container\_registry\_zone\_redundancy\_enabled) | (Optional) Whether zone redundancy is enabled for this replication location? Defaults to false. | `bool` | `false` | no |
| <a name="input_core_azure_defender_resources"></a> [core\_azure\_defender\_resources](#input\_core\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "AppServices",<br>  "ContainerRegistry",<br>  "KeyVaults",<br>  "KubernetesService",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns"<br>]</pre> | no |
| <a name="input_core_azure_vm_image_build_number"></a> [core\_azure\_vm\_image\_build\_number](#input\_core\_azure\_vm\_image\_build\_number) | (Optional) Build number from GH actions workflow. | `string` | `null` | no |
| <a name="input_core_azure_vm_image_builder_distribute_replicationRegions"></a> [core\_azure\_vm\_image\_builder\_distribute\_replicationRegions](#input\_core\_azure\_vm\_image\_builder\_distribute\_replicationRegions) | (Optional) destiny location. | `list(string)` | `[]` | no |
| <a name="input_core_azure_vm_image_builder_identifier_source_offer"></a> [core\_azure\_vm\_image\_builder\_identifier\_source\_offer](#input\_core\_azure\_vm\_image\_builder\_identifier\_source\_offer) | (Optional) The Publisher Name for this Gallery Image. Changing this forces a new resource to be created. | `string` | `"AzureVMImageBuilder"` | no |
| <a name="input_core_azure_vm_image_builder_identifier_source_publisher"></a> [core\_azure\_vm\_image\_builder\_identifier\_source\_publisher](#input\_core\_azure\_vm\_image\_builder\_identifier\_source\_publisher) | (Optional) The Offer Name for this Shared Image. Changing this forces a new resource to be created. | `string` | `"KPMG"` | no |
| <a name="input_core_azure_vm_image_builder_release"></a> [core\_azure\_vm\_image\_builder\_release](#input\_core\_azure\_vm\_image\_builder\_release) | (Required) Specifies the relese of the VM Image. Changing this forces a new resource to be created. | `string` | `"r1"` | no |
| <a name="input_core_azure_vm_image_builder_resource_apiVersion"></a> [core\_azure\_vm\_image\_builder\_resource\_apiVersion](#input\_core\_azure\_vm\_image\_builder\_resource\_apiVersion) | (Optional) apiVersion Azure VM Image Builder | `string` | `"2022-02-14"` | no |
| <a name="input_core_azure_vm_image_builder_shared_image_def_os_type"></a> [core\_azure\_vm\_image\_builder\_shared\_image\_def\_os\_type](#input\_core\_azure\_vm\_image\_builder\_shared\_image\_def\_os\_type) | (Required) The type of Operating System present in this Shared Image. Possible values are Linux and Windows. Changing this forces a new resource to be created. | `string` | `"Windows"` | no |
| <a name="input_core_azure_vm_image_builder_source_offer"></a> [core\_azure\_vm\_image\_builder\_source\_offer](#input\_core\_azure\_vm\_image\_builder\_source\_offer) | (Required) The name of a group of related images created by a publisher. Examples: RHEL, WindowsServer. By default this values is to create a Windows image | `string` | `"WindowsServer"` | no |
| <a name="input_core_azure_vm_image_builder_source_publisher"></a> [core\_azure\_vm\_image\_builder\_source\_publisher](#input\_core\_azure\_vm\_image\_builder\_source\_publisher) | (Required) The organization that created the image. Examples: RedHat, MicrosoftWindowsServer. By default this values is to create a Windows image | `string` | `"MicrosoftWindowsServer"` | no |
| <a name="input_core_azure_vm_image_builder_source_sku"></a> [core\_azure\_vm\_image\_builder\_source\_sku](#input\_core\_azure\_vm\_image\_builder\_source\_sku) | (Required) An instance of an offer, such as a major release of a distribution. Examples: 7-LVM, 2019-Datacenter. By default this values is to create a Windows image | `string` | `"2019-Datacenter"` | no |
| <a name="input_core_azure_vm_image_builder_source_version"></a> [core\_azure\_vm\_image\_builder\_source\_version](#input\_core\_azure\_vm\_image\_builder\_source\_version) | (Optional) The version number of an image SKU. | `string` | `"latest"` | no |
| <a name="input_core_azure_vm_image_builder_storage_account_network_rules_default_action"></a> [core\_azure\_vm\_image\_builder\_storage\_account\_network\_rules\_default\_action](#input\_core\_azure\_vm\_image\_builder\_storage\_account\_network\_rules\_default\_action) | (Optional) Default action for network rules access. | `string` | `"Allow"` | no |
| <a name="input_core_azure_vm_image_builder_storage_account_postfix"></a> [core\_azure\_vm\_image\_builder\_storage\_account\_postfix](#input\_core\_azure\_vm\_image\_builder\_storage\_account\_postfix) | (Optional) A unique identifier for the storage account. Part of the naming scheme. | `string` | `"imgbd"` | no |
| <a name="input_core_azure_vm_image_builder_template_deployment_mode"></a> [core\_azure\_vm\_image\_builder\_template\_deployment\_mode](#input\_core\_azure\_vm\_image\_builder\_template\_deployment\_mode) | (Optional) The Deployment Mode for this Resource Group Template Deployment. Possible values are Complete (where resources in the Resource Group not specified in the ARM Template will be destroyed) and Incremental (where resources are additive only). | `string` | `"Complete"` | no |
| <a name="input_core_azure_vm_image_builder_template_source"></a> [core\_azure\_vm\_image\_builder\_template\_source](#input\_core\_azure\_vm\_image\_builder\_template\_source) | (Optional) The name of the ARM template for Windows VM ImageWindowsTemplate.json, for Linux VM. | `string` | `"ImageWindowsTemplateusch.json"` | no |
| <a name="input_core_azure_vm_image_builder_vmSize"></a> [core\_azure\_vm\_image\_builder\_vmSize](#input\_core\_azure\_vm\_image\_builder\_vmSize) | (Required) The Size of the windows or Linux vm. By default this values has a Windows vm size | `string` | `"Standard_D4_v3"` | no |
| <a name="input_core_deploy_dr_shsdsvc_to_prod_shsdsvc_peering"></a> [core\_deploy\_dr\_shsdsvc\_to\_prod\_shsdsvc\_peering](#input\_core\_deploy\_dr\_shsdsvc\_to\_prod\_shsdsvc\_peering) | (Optional) Enabled the peering between prod and dr. | `bool` | `false` | no |
| <a name="input_core_deploy_prod_shsdsvc_to_dr_shsdsvc_peering"></a> [core\_deploy\_prod\_shsdsvc\_to\_dr\_shsdsvc\_peering](#input\_core\_deploy\_prod\_shsdsvc\_to\_dr\_shsdsvc\_peering) | (Optional) Enabled the peering between prod and dr. | `bool` | `false` | no |
| <a name="input_core_dr_to_shsdsvc_prod_peering_network_id"></a> [core\_dr\_to\_shsdsvc\_prod\_peering\_network\_id](#input\_core\_dr\_to\_shsdsvc\_prod\_peering\_network\_id) | (Optional) Vnet id from prod shared services. | `string` | `null` | no |
| <a name="input_core_image_builder_subnet_enforce_service_policies"></a> [core\_image\_builder\_subnet\_enforce\_service\_policies](#input\_core\_image\_builder\_subnet\_enforce\_service\_policies) | private\_endpoint\_network\_policies\_enabled - (Optional) Enable or Disable network policies for the private endpoint on the subnet. Setting this to true will Enable the policy and setting this to false will Disable the policy. Defaults to true. | `bool` | `true` | no |
| <a name="input_core_imgbuilder_sub_address_prefix"></a> [core\_imgbuilder\_sub\_address\_prefix](#input\_core\_imgbuilder\_sub\_address\_prefix) | (Optional) The address prefixes for the subnet of image builder. | `list(string)` | `null` | no |
| <a name="input_core_imgbuilder_subnet_service_endpoints"></a> [core\_imgbuilder\_subnet\_service\_endpoints](#input\_core\_imgbuilder\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.AzureActiveDirectory",<br>  "Microsoft.Storage"<br>]</pre> | no |
| <a name="input_core_keyvault_allowed_pe_subnet_ids"></a> [core\_keyvault\_allowed\_pe\_subnet\_ids](#input\_core\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_az_svcs_bypass"></a> [core\_keyvault\_az\_svcs\_bypass](#input\_core\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_core_keyvault_diagnostics"></a> [core\_keyvault\_diagnostics](#input\_core\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_core_keyvault_enable"></a> [core\_keyvault\_enable](#input\_core\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_deployment"></a> [core\_keyvault\_enabled\_for\_deployment](#input\_core\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_disk_encryption"></a> [core\_keyvault\_enabled\_for\_disk\_encryption](#input\_core\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_template_deployment"></a> [core\_keyvault\_enabled\_for\_template\_deployment](#input\_core\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_core_keyvault_log_analytics_solutions"></a> [core\_keyvault\_log\_analytics\_solutions](#input\_core\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_core_keyvault_nacl_allowed_ips"></a> [core\_keyvault\_nacl\_allowed\_ips](#input\_core\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | <pre>[<br>  "199.206.0.0/15"<br>]</pre> | no |
| <a name="input_core_keyvault_nacl_allowed_subnets"></a> [core\_keyvault\_nacl\_allowed\_subnets](#input\_core\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_nacl_default_action"></a> [core\_keyvault\_nacl\_default\_action](#input\_core\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_core_keyvault_postfix"></a> [core\_keyvault\_postfix](#input\_core\_keyvault\_postfix) | (Required) The bespoke name of the kv app or project you are deploying. | `string` | `"ch"` | no |
| <a name="input_core_keyvault_private_dns_zone_ids"></a> [core\_keyvault\_private\_dns\_zone\_ids](#input\_core\_keyvault\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_prodtodr_id"></a> [core\_keyvault\_prodtodr\_id](#input\_core\_keyvault\_prodtodr\_id) | DR VM's deployment, send the kv id from prod shared services | `any` | `null` | no |
| <a name="input_core_keyvault_purge_protection_enabled"></a> [core\_keyvault\_purge\_protection\_enabled](#input\_core\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_core_keyvault_sku_name"></a> [core\_keyvault\_sku\_name](#input\_core\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_core_keyvault_soft_delete_retention_days"></a> [core\_keyvault\_soft\_delete\_retention\_days](#input\_core\_keyvault\_soft\_delete\_retention\_days) | (Optional) The number of days that items should be retained for once soft-deleted. This value can be between 7 and 90 (the default) days. | `number` | `90` | no |
| <a name="input_core_kubernetes_addon_profile_azure_keyvault_secrets_provider_enabled"></a> [core\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_enabled](#input\_core\_kubernetes\_addon\_profile\_azure\_keyvault\_secrets\_provider\_enabled) | (Optional) Is the Azure Keyvault Secrets Providerenabled | `bool` | `true` | no |
| <a name="input_core_law_private_dns_zone_ids"></a> [core\_law\_private\_dns\_zone\_ids](#input\_core\_law\_private\_dns\_zone\_ids) | n/a | `any` | `null` | no |
| <a name="input_core_mgmt_sub_address_prefix"></a> [core\_mgmt\_sub\_address\_prefix](#input\_core\_mgmt\_sub\_address\_prefix) | (Require) The address prefixes for the subnet of vm's. | `list(string)` | n/a | yes |
| <a name="input_core_mgmt_subnet_service_endpoints"></a> [core\_mgmt\_subnet\_service\_endpoints](#input\_core\_mgmt\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_core_private_dns_zone"></a> [core\_private\_dns\_zone](#input\_core\_private\_dns\_zone) | n/a | `list(string)` | <pre>[<br>  "privatelink.azure-automation.net",<br>  "privatelink.database.windows.net",<br>  "privatelink.blob.core.windows.net",<br>  "privatelink.table.core.windows.net",<br>  "privatelink.queue.core.windows.net",<br>  "privatelink.file.core.windows.net",<br>  "privatelink.web.core.windows.net",<br>  "privatelink.dfs.core.windows.net",<br>  "privatelink.documents.azure.com",<br>  "privatelink.mongo.cosmos.azure.com",<br>  "privatelink.cassandra.cosmos.azure.com",<br>  "privatelink.gremlin.cosmos.azure.com",<br>  "privatelink.table.cosmos.azure.com",<br>  "privatelink.postgres.database.azure.com",<br>  "privatelink.mysql.database.azure.com",<br>  "privatelink.mariadb.database.azure.com",<br>  "privatelink.vaultcore.azure.net",<br>  "privatelink.search.windows.net",<br>  "privatelink.azurecr.io",<br>  "privatelink.azconfig.io",<br>  "privatelink.servicebus.windows.net",<br>  "privatelink.azure-devices.net",<br>  "privatelink.eventgrid.azure.net",<br>  "privatelink.azurewebsites.net",<br>  "privatelink.api.azureml.ms",<br>  "privatelink.service.signalr.net",<br>  "privatelink.monitor.azure.com",<br>  "privatelink.oms.opinsights.azure.com",<br>  "privatelink.ods.opinsights.azure.com",<br>  "privatelink.agentsvc.azure-automation.net",<br>  "privatelink.cognitiveservices.azure.com",<br>  "privatelink.afs.azure.net",<br>  "privatelink.datafactory.azure.net",<br>  "privatelink.redis.cache.windows.net",<br>  "privatelink.eus.azmk8s.io",<br>  "privatelink.eus.backup.windowsazure.com",<br>  "privatelink.eus2.azmk8s.io",<br>  "privatelink.eus2.backup.windowsazure.com",<br>  "privatelink.wus.azmk8s.io",<br>  "privatelink.wus.backup.windowsazure.com",<br>  "privatelink.siterecovery.windowsazure.com",<br>  "privatelink.eastus2.azmk8s.io",<br>  "privatelink.dev.azuresynapse.net",<br>  "privatelink.azuresynapse.net",<br>  "privatelink.sql.azuresynapse.net",<br>  "privatelink.his.arc.azure.com",<br>  "privatelink.guestconfiguration.azure.com",<br>  "privatelink.dp.kubernetesconfiguration.azure.com",<br>  "privatelink.snowflakecomputing.com",<br>  "privatelink.eastus.azmk8s.io",<br>  "privatelink.westus.azmk8s.io",<br>  "privatelink.northeurope.azmk8s.io",<br>  "privatelink.westeurope.azmk8s.io"<br>]</pre> | no |
| <a name="input_core_private_dns_zone_enable"></a> [core\_private\_dns\_zone\_enable](#input\_core\_private\_dns\_zone\_enable) | (Optional) Enable the creation of private dns zone | `bool` | `true` | no |
| <a name="input_core_private_link_subnet_address_prefixes"></a> [core\_private\_link\_subnet\_address\_prefixes](#input\_core\_private\_link\_subnet\_address\_prefixes) | (Require) The address prefixes for the subnet of private endpoints. | `list(string)` | n/a | yes |
| <a name="input_core_private_link_subnet_enforce_endpoint_network_policies"></a> [core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Optional) | `bool` | `true` | no |
| <a name="input_core_private_link_subnet_service_endpoints"></a> [core\_private\_link\_subnet\_service\_endpoints](#input\_core\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_core_prod_to_shsdsvc_dr_peering_network_id"></a> [core\_prod\_to\_shsdsvc\_dr\_peering\_network\_id](#input\_core\_prod\_to\_shsdsvc\_dr\_peering\_network\_id) | (Optional) Vnet id from prod shared services. | `string` | `null` | no |
| <a name="input_core_ptrn_azure_container_registry_private_dns_zone_id"></a> [core\_ptrn\_azure\_container\_registry\_private\_dns\_zone\_id](#input\_core\_ptrn\_azure\_container\_registry\_private\_dns\_zone\_id) | acr private dns zone id | `any` | `null` | no |
| <a name="input_core_ptrn_kubernetes_addon_profile_ingress_application_gateway_enabled"></a> [core\_ptrn\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_enabled](#input\_core\_ptrn\_kubernetes\_addon\_profile\_ingress\_application\_gateway\_enabled) | (Optional) Is the Application Gateway ingress controller integrated with this Kubernetes Cluster | `bool` | `false` | no |
| <a name="input_core_ptrn_kubernetes_azure_container_registry_allowed_vnet_ids"></a> [core\_ptrn\_kubernetes\_azure\_container\_registry\_allowed\_vnet\_ids](#input\_core\_ptrn\_kubernetes\_azure\_container\_registry\_allowed\_vnet\_ids) | (Optional) One or more VNET ID's which should be linked to the Private DNS Zone for ACR name resolution and access trough Private Endpoint. | `list(string)` | `[]` | no |
| <a name="input_core_ptrn_kubernetes_azure_container_registry_network_rule_set_default_action"></a> [core\_ptrn\_kubernetes\_azure\_container\_registry\_network\_rule\_set\_default\_action](#input\_core\_ptrn\_kubernetes\_azure\_container\_registry\_network\_rule\_set\_default\_action) | (Optional) The behaviour for requests matching no rules. Either Allow or Deny. Defaults to Deny | `string` | `"Deny"` | no |
| <a name="input_core_ptrn_kubernetes_azure_container_registry_prodtodr_id"></a> [core\_ptrn\_kubernetes\_azure\_container\_registry\_prodtodr\_id](#input\_core\_ptrn\_kubernetes\_azure\_container\_registry\_prodtodr\_id) | (Optional) DR deployment aks send the ACR ID from Prod | `any` | `null` | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_availability_zones"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_availability\_zones](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_availability\_zones) | (Optional) A list of Availability Zones across which the Node Pool should be spread. Changing this forces a new resource to be created. | `list(string)` | <pre>[<br>  1,<br>  2<br>]</pre> | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_max_count"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_max\_count](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_max\_count) | (Required) The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min\_count. | `number` | `3` | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_max_pods"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_max\_pods](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_max\_pods) | (Optional) The maximum number of pods that can run on each agent. Changing this forces a new resource to be created. | `number` | `30` | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_min_count"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_min\_count](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_min\_count) | (Required) The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max\_count. | `number` | `1` | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_node_count"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_node\_count](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_node\_count) | (Optional) The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min\_count and max\_count | `number` | `3` | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_orchestrator_version"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_orchestrator\_version](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_orchestrator\_version) | (Optional) Version of Kubernetes used for the Agents. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade) | `string` | `null` | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_upgrade_max_surge"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_upgrade\_max\_surge](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_upgrade\_max\_surge) | (Optional) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade | `string` | `"33%"` | no |
| <a name="input_core_ptrn_kubernetes_default_node_pool_vm_size"></a> [core\_ptrn\_kubernetes\_default\_node\_pool\_vm\_size](#input\_core\_ptrn\_kubernetes\_default\_node\_pool\_vm\_size) | (Optional)The size of the Virtual Machine, such as Standard\_DS2\_v2 | `string` | `"standard_ds2_v2"` | no |
| <a name="input_core_ptrn_kubernetes_deploy"></a> [core\_ptrn\_kubernetes\_deploy](#input\_core\_ptrn\_kubernetes\_deploy) | (Optional) deploy or not ptrn\_kubernetes, default false | `bool` | `false` | no |
| <a name="input_core_ptrn_kubernetes_deploy_app_gateway"></a> [core\_ptrn\_kubernetes\_deploy\_app\_gateway](#input\_core\_ptrn\_kubernetes\_deploy\_app\_gateway) | deploy or  not application gateway | `bool` | `false` | no |
| <a name="input_core_ptrn_kubernetes_deploy_azure_container_registry"></a> [core\_ptrn\_kubernetes\_deploy\_azure\_container\_registry](#input\_core\_ptrn\_kubernetes\_deploy\_azure\_container\_registry) | (Optional) Deploy or not ACR component, opcional only in DR. | `bool` | `true` | no |
| <a name="input_core_ptrn_kubernetes_deploy_ptrn_privatelink_subnet"></a> [core\_ptrn\_kubernetes\_deploy\_ptrn\_privatelink\_subnet](#input\_core\_ptrn\_kubernetes\_deploy\_ptrn\_privatelink\_subnet) | (Optional) deploy or not ptrn\_privatelink\_subnet, default true | `bool` | `false` | no |
| <a name="input_core_ptrn_kubernetes_deploy_rg"></a> [core\_ptrn\_kubernetes\_deploy\_rg](#input\_core\_ptrn\_kubernetes\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for AKS. | `bool` | `true` | no |
| <a name="input_core_ptrn_kubernetes_identity_type"></a> [core\_ptrn\_kubernetes\_identity\_type](#input\_core\_ptrn\_kubernetes\_identity\_type) | (Optional) The type of identity used for the managed cluster. Possible values are SystemAssigned and UserAssigned. If UserAssigned is set, a user\_assigned\_identity\_id must be set as well. | `string` | `"UserAssigned"` | no |
| <a name="input_core_ptrn_kubernetes_kubernetes_version"></a> [core\_ptrn\_kubernetes\_kubernetes\_version](#input\_core\_ptrn\_kubernetes\_kubernetes\_version) | (Optional) Version of Kubernetes specified when creating the AKS managed cluster. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade). | `string` | `"1.16.9"` | no |
| <a name="input_core_ptrn_kubernetes_network_profile_dns_service_ip"></a> [core\_ptrn\_kubernetes\_network\_profile\_dns\_service\_ip](#input\_core\_ptrn\_kubernetes\_network\_profile\_dns\_service\_ip) | (Optional)The K8S's DNS Service IP, /24 represents 256 IPs. IP address within the Kubernetes service address range that will be used by cluster service discovery (kube-dns). Changing this forces a new resource to be created. | `string` | `"10.2.0.10"` | no |
| <a name="input_core_ptrn_kubernetes_network_profile_docker_bridge_cidr"></a> [core\_ptrn\_kubernetes\_network\_profile\_docker\_bridge\_cidr](#input\_core\_ptrn\_kubernetes\_network\_profile\_docker\_bridge\_cidr) | (Optional) The K8S's Docker bridge CIDR, /27 represents 32 IPs.  (Optional) IP address (in CIDR notation) used as the Docker bridge IP address on nodes. Changing this forces a new resource to be created. | `string` | `"172.17.0.1/16"` | no |
| <a name="input_core_ptrn_kubernetes_network_profile_service_cidr"></a> [core\_ptrn\_kubernetes\_network\_profile\_service\_cidr](#input\_core\_ptrn\_kubernetes\_network\_profile\_service\_cidr) | (Optional) The K8S's Service CIDR, /24 represents 256 IPs. (Optional) The Network Range used by the Kubernetes service. Changing this forces a new resource to be created. | `string` | `"10.2.0.0/16"` | no |
| <a name="input_core_ptrn_kubernetes_next_hop_in_ip_address"></a> [core\_ptrn\_kubernetes\_next\_hop\_in\_ip\_address](#input\_core\_ptrn\_kubernetes\_next\_hop\_in\_ip\_address) | (Optional) Contains the IP address packets should be forwarded to. Next hop values are only allowed in routes where the next hop type is VirtualAppliance. | `string` | `"10.0.0.4"` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_availability_zones"></a> [core\_ptrn\_kubernetes\_node\_pool\_availability\_zones](#input\_core\_ptrn\_kubernetes\_node\_pool\_availability\_zones) | (Optional) A list of Availability Zones where the Nodes in this Node Pool should be created in. Changing this forces a new resource to be created. | `list(number)` | <pre>[<br>  1,<br>  2<br>]</pre> | no |
| <a name="input_core_ptrn_kubernetes_node_pool_max_count"></a> [core\_ptrn\_kubernetes\_node\_pool\_max\_count](#input\_core\_ptrn\_kubernetes\_node\_pool\_max\_count) | (Required) The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min\_count. | `number` | `5` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_max_pods"></a> [core\_ptrn\_kubernetes\_node\_pool\_max\_pods](#input\_core\_ptrn\_kubernetes\_node\_pool\_max\_pods) | (Optional) The maximum number of pods that can run on each agent. Changing this forces a new resource to be created. | `number` | `30` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_max_surge"></a> [core\_ptrn\_kubernetes\_node\_pool\_max\_surge](#input\_core\_ptrn\_kubernetes\_node\_pool\_max\_surge) | (Optional) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade.If a percentage is provided, the number of surge nodes is calculated from the current node count on the cluster. Node surge can allow a cluster to have more nodes than max\_count during an upgrade. Ensure that your cluster has enough IP space during an upgrade. | `string` | `"33%"` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_min_count"></a> [core\_ptrn\_kubernetes\_node\_pool\_min\_count](#input\_core\_ptrn\_kubernetes\_node\_pool\_min\_count) | (Required) The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max\_count. | `number` | `1` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_mode"></a> [core\_ptrn\_kubernetes\_node\_pool\_mode](#input\_core\_ptrn\_kubernetes\_node\_pool\_mode) | (Optional) Should this Node Pool be used for System or User resources? Possible values are System and User. Defaults to User. | `string` | `"User"` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_name"></a> [core\_ptrn\_kubernetes\_node\_pool\_name](#input\_core\_ptrn\_kubernetes\_node\_pool\_name) | (Required) The name of the Node Pool which should be created within the Kubernetes Cluster. Changing this forces a new resource to be created. A Windows Node Pool cannot have a name longer than 6 characters. | `string` | `"internal"` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_node_count"></a> [core\_ptrn\_kubernetes\_node\_pool\_node\_count](#input\_core\_ptrn\_kubernetes\_node\_pool\_node\_count) | (Optional) The initial number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be a value in the range min\_count - max\_count. If you're specifying an initial number of nodes you may wish to use Terraform's ignore\_changes functionality to ignore changes to this field. | `number` | `1` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_orchestrator_version"></a> [core\_ptrn\_kubernetes\_node\_pool\_orchestrator\_version](#input\_core\_ptrn\_kubernetes\_node\_pool\_orchestrator\_version) | (Optional) Version of Kubernetes used for the Agents. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade). This version must be supported by the Kubernetes Cluster - as such the version of Kubernetes used on the Cluster/Control Plane may need to be upgraded first. | `string` | `null` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_os_disk_size_gb"></a> [core\_ptrn\_kubernetes\_node\_pool\_os\_disk\_size\_gb](#input\_core\_ptrn\_kubernetes\_node\_pool\_os\_disk\_size\_gb) | (Optional) The Agent Operating System disk size in GB. Changing this forces a new resource to be created. | `number` | `256` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_os_disk_type"></a> [core\_ptrn\_kubernetes\_node\_pool\_os\_disk\_type](#input\_core\_ptrn\_kubernetes\_node\_pool\_os\_disk\_type) | (Optional) The type of disk which should be used for the Operating System. Possible values are Ephemeral and Managed. Defaults to Managed. Changing this forces a new resource to be created. | `string` | `"Managed"` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_os_sku"></a> [core\_ptrn\_kubernetes\_node\_pool\_os\_sku](#input\_core\_ptrn\_kubernetes\_node\_pool\_os\_sku) | (Optional) OsSKU to be used to specify Linux OSType. Not applicable to Windows OSType. Possible values include: Ubuntu, CBLMariner. Defaults to Ubuntu. Changing this forces a new resource to be created. | `string` | `"Ubuntu"` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_os_type"></a> [core\_ptrn\_kubernetes\_node\_pool\_os\_type](#input\_core\_ptrn\_kubernetes\_node\_pool\_os\_type) | (Optional) The Operating System which should be used for this Node Pool. Changing this forces a new resource to be created. Possible values are Linux and Windows. Defaults to Linux. | `string` | `"Linux"` | no |
| <a name="input_core_ptrn_kubernetes_node_pool_vm_size"></a> [core\_ptrn\_kubernetes\_node\_pool\_vm\_size](#input\_core\_ptrn\_kubernetes\_node\_pool\_vm\_size) | (Optional) The SKU which should be used for the Virtual Machines used in this Node Pool. Changing this forces a new resource to be created. | `string` | `"standard_ds2_v2"` | no |
| <a name="input_core_ptrn_kubernetes_postfix"></a> [core\_ptrn\_kubernetes\_postfix](#input\_core\_ptrn\_kubernetes\_postfix) | (Required) A string that is appended to the end of the aks name to identify it. | `string` | `"ghshr"` | no |
| <a name="input_core_ptrn_kubernetes_private_dns_zone_id"></a> [core\_ptrn\_kubernetes\_private\_dns\_zone\_id](#input\_core\_ptrn\_kubernetes\_private\_dns\_zone\_id) | aks private dns zone id | `any` | `null` | no |
| <a name="input_core_ptrn_kubernetes_rbac_aad_admin_group_object_ids"></a> [core\_ptrn\_kubernetes\_rbac\_aad\_admin\_group\_object\_ids](#input\_core\_ptrn\_kubernetes\_rbac\_aad\_admin\_group\_object\_ids) | (Optional) A list of Object IDs of Azure Active Directory Groups which should have Admin Role on the Cluster. | `list(string)` | `[]` | no |
| <a name="input_core_ptrn_kubernetes_subnet_nodes_address_prefixes"></a> [core\_ptrn\_kubernetes\_subnet\_nodes\_address\_prefixes](#input\_core\_ptrn\_kubernetes\_subnet\_nodes\_address\_prefixes) | subnet virtual machine | `list(string)` | `null` | no |
| <a name="input_core_ptrn_kubernetes_windows_vm_deploy_subnet_nsg"></a> [core\_ptrn\_kubernetes\_windows\_vm\_deploy\_subnet\_nsg](#input\_core\_ptrn\_kubernetes\_windows\_vm\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM. | `bool` | `false` | no |
| <a name="input_core_rg_security_enable"></a> [core\_rg\_security\_enable](#input\_core\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to core\_rg\_data | `bool` | `true` | no |
| <a name="input_core_route_table_disable_bgp_propagation"></a> [core\_route\_table\_disable\_bgp\_propagation](#input\_core\_route\_table\_disable\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `true` | no |
| <a name="input_core_shared_image_gallery_deploy"></a> [core\_shared\_image\_gallery\_deploy](#input\_core\_shared\_image\_gallery\_deploy) | (Optional) Deploy or no image gallery. | `bool` | `true` | no |
| <a name="input_core_shared_image_gallery_description"></a> [core\_shared\_image\_gallery\_description](#input\_core\_shared\_image\_gallery\_description) | (Optional) A description for this Shared Image Gallery. | `string` | `"US CH shared image gallery"` | no |
| <a name="input_core_vm_image_builder_storage_account_private_dns_zone_id"></a> [core\_vm\_image\_builder\_storage\_account\_private\_dns\_zone\_id](#input\_core\_vm\_image\_builder\_storage\_account\_private\_dns\_zone\_id) | image builder privare dns zone to be determined | `any` | `null` | no |
| <a name="input_core_vnet_address_space"></a> [core\_vnet\_address\_space](#input\_core\_vnet\_address\_space) | (Required) The address space for the virtual network. | `list(string)` | n/a | yes |
| <a name="input_core_vnet_dns_servers"></a> [core\_vnet\_dns\_servers](#input\_core\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_core_windows_vm_app_name"></a> [core\_windows\_vm\_app\_name](#input\_core\_windows\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `string` | `"aksghshr"` | no |
| <a name="input_core_windows_vm_deploy"></a> [core\_windows\_vm\_deploy](#input\_core\_windows\_vm\_deploy) | (Optional) Enable the creation of The Windows vm dns forwarder | `bool` | `true` | no |
| <a name="input_core_windows_vm_deploy_rg"></a> [core\_windows\_vm\_deploy\_rg](#input\_core\_windows\_vm\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the VM. | `bool` | `true` | no |
| <a name="input_core_windows_vm_dns_forwarder_admin_user"></a> [core\_windows\_vm\_dns\_forwarder\_admin\_user](#input\_core\_windows\_vm\_dns\_forwarder\_admin\_user) | (Required) The name of the windows OS admin. | `string` | `"kpmgadmin"` | no |
| <a name="input_core_windows_vm_dns_forwarder_computer_name"></a> [core\_windows\_vm\_dns\_forwarder\_computer\_name](#input\_core\_windows\_vm\_dns\_forwarder\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `list(string)` | `null` | no |
| <a name="input_core_windows_vm_dns_forwarder_deploy_subnet_nsg"></a> [core\_windows\_vm\_dns\_forwarder\_deploy\_subnet\_nsg](#input\_core\_windows\_vm\_dns\_forwarder\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM. | `bool` | `false` | no |
| <a name="input_core_windows_vm_dns_forwarder_domain_join_ou_path"></a> [core\_windows\_vm\_dns\_forwarder\_domain\_join\_ou\_path](#input\_core\_windows\_vm\_dns\_forwarder\_domain\_join\_ou\_path) | (Optional) OU path to us during domain join | `string` | `"OU=Application,OU=Member Servers v8.0,OU=Windows 2019 Server GSv8.x,OU=AZR,OU=Public Cloud,OU=Server Policies,DC=us,DC=kworld,DC=kpmg,DC=com"` | no |
| <a name="input_core_windows_vm_dns_forwarder_domain_name"></a> [core\_windows\_vm\_dns\_forwarder\_domain\_name](#input\_core\_windows\_vm\_dns\_forwarder\_domain\_name) | (Optional) Name of the domain to join | `string` | `"us.kworld.kpmg.com"` | no |
| <a name="input_core_windows_vm_dns_forwarder_domain_password"></a> [core\_windows\_vm\_dns\_forwarder\_domain\_password](#input\_core\_windows\_vm\_dns\_forwarder\_domain\_password) | (Optional) Password of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_core_windows_vm_dns_forwarder_domain_user_upn"></a> [core\_windows\_vm\_dns\_forwarder\_domain\_user\_upn](#input\_core\_windows\_vm\_dns\_forwarder\_domain\_user\_upn) | (Optional) UPN of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_core_windows_vm_dns_forwarder_enable_backup"></a> [core\_windows\_vm\_dns\_forwarder\_enable\_backup](#input\_core\_windows\_vm\_dns\_forwarder\_enable\_backup) | (Optional) Toggle the backup feature. | `bool` | `true` | no |
| <a name="input_core_windows_vm_dns_forwarder_enable_domain_join"></a> [core\_windows\_vm\_dns\_forwarder\_enable\_domain\_join](#input\_core\_windows\_vm\_dns\_forwarder\_enable\_domain\_join) | (Optional) Toggle the domain join feature. | `bool` | `true` | no |
| <a name="input_core_windows_vm_dns_forwarder_enable_encryption_at_host_enabled"></a> [core\_windows\_vm\_dns\_forwarder\_enable\_encryption\_at\_host\_enabled](#input\_core\_windows\_vm\_dns\_forwarder\_enable\_encryption\_at\_host\_enabled) | (Optional) Boolean to enable encryption\_at\_host\_enabled. | `bool` | `false` | no |
| <a name="input_core_windows_vm_dns_forwarder_identity_type"></a> [core\_windows\_vm\_dns\_forwarder\_identity\_type](#input\_core\_windows\_vm\_dns\_forwarder\_identity\_type) | (Optional) Managed identity type for VM | `string` | `"SystemAssigned"` | no |
| <a name="input_core_windows_vm_dns_forwarder_image_id"></a> [core\_windows\_vm\_dns\_forwarder\_image\_id](#input\_core\_windows\_vm\_dns\_forwarder\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | `null` | no |
| <a name="input_core_windows_vm_dns_forwarder_size"></a> [core\_windows\_vm\_dns\_forwarder\_size](#input\_core\_windows\_vm\_dns\_forwarder\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_D2s_v4"` | no |
| <a name="input_core_windows_vm_enable_ama_log_analytics_settings"></a> [core\_windows\_vm\_enable\_ama\_log\_analytics\_settings](#input\_core\_windows\_vm\_enable\_ama\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `true` | no |
| <a name="input_core_windows_vm_enable_mma_log_analytics_settings"></a> [core\_windows\_vm\_enable\_mma\_log\_analytics\_settings](#input\_core\_windows\_vm\_enable\_mma\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `true` | no |
| <a name="input_core_windows_vm_jumpbox_admin_user"></a> [core\_windows\_vm\_jumpbox\_admin\_user](#input\_core\_windows\_vm\_jumpbox\_admin\_user) | (Required) The name of the windows OS admin. | `string` | `"kpmgadmin"` | no |
| <a name="input_core_windows_vm_jumpbox_computer_name"></a> [core\_windows\_vm\_jumpbox\_computer\_name](#input\_core\_windows\_vm\_jumpbox\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | `null` | no |
| <a name="input_core_windows_vm_jumpbox_domain_join_ou_path"></a> [core\_windows\_vm\_jumpbox\_domain\_join\_ou\_path](#input\_core\_windows\_vm\_jumpbox\_domain\_join\_ou\_path) | (Optional) OU path to us during domain join | `string` | `"OU=Application,OU=Member Servers v8.0,OU=Windows 2019 Server GSv8.x,OU=AZR,OU=Public Cloud,OU=Server Policies,DC=us,DC=kworld,DC=kpmg,DC=com"` | no |
| <a name="input_core_windows_vm_jumpbox_domain_name"></a> [core\_windows\_vm\_jumpbox\_domain\_name](#input\_core\_windows\_vm\_jumpbox\_domain\_name) | (Optional) Name of the domain to join | `string` | `"us.kworld.kpmg.com"` | no |
| <a name="input_core_windows_vm_jumpbox_domain_password"></a> [core\_windows\_vm\_jumpbox\_domain\_password](#input\_core\_windows\_vm\_jumpbox\_domain\_password) | (Optional) Password of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_core_windows_vm_jumpbox_domain_user_upn"></a> [core\_windows\_vm\_jumpbox\_domain\_user\_upn](#input\_core\_windows\_vm\_jumpbox\_domain\_user\_upn) | (Optional) UPN of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_core_windows_vm_jumpbox_enable_backup"></a> [core\_windows\_vm\_jumpbox\_enable\_backup](#input\_core\_windows\_vm\_jumpbox\_enable\_backup) | (Optional) Toggle the backup feature. | `bool` | `true` | no |
| <a name="input_core_windows_vm_jumpbox_enable_domain_join"></a> [core\_windows\_vm\_jumpbox\_enable\_domain\_join](#input\_core\_windows\_vm\_jumpbox\_enable\_domain\_join) | (Optional) Toggle the domain join feature. | `bool` | `true` | no |
| <a name="input_core_windows_vm_jumpbox_enable_encryption_at_host_enabled"></a> [core\_windows\_vm\_jumpbox\_enable\_encryption\_at\_host\_enabled](#input\_core\_windows\_vm\_jumpbox\_enable\_encryption\_at\_host\_enabled) | (Optional) Boolean to enable encryption\_at\_host\_enabled. | `bool` | `false` | no |
| <a name="input_core_windows_vm_jumpbox_enable_log_analytics_settings"></a> [core\_windows\_vm\_jumpbox\_enable\_log\_analytics\_settings](#input\_core\_windows\_vm\_jumpbox\_enable\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `false` | no |
| <a name="input_core_windows_vm_jumpbox_identity_type"></a> [core\_windows\_vm\_jumpbox\_identity\_type](#input\_core\_windows\_vm\_jumpbox\_identity\_type) | (Optional) Managed identity type for VM | `string` | `"SystemAssigned"` | no |
| <a name="input_core_windows_vm_jumpbox_image_id"></a> [core\_windows\_vm\_jumpbox\_image\_id](#input\_core\_windows\_vm\_jumpbox\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | `null` | no |
| <a name="input_core_windows_vm_jumpbox_size"></a> [core\_windows\_vm\_jumpbox\_size](#input\_core\_windows\_vm\_jumpbox\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_D2s_v4"` | no |
| <a name="input_core_windows_vm_log_analytics_primary_sentinel_shared_key"></a> [core\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key](#input\_core\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key) | (Required) The log analytics workspace primary shared key. | `any` | `null` | no |
| <a name="input_core_windows_vm_log_analytics_workspace_resource_id"></a> [core\_windows\_vm\_log\_analytics\_workspace\_resource\_id](#input\_core\_windows\_vm\_log\_analytics\_workspace\_resource\_id) | (Required) conditinal for enabling DCR association on VM. | `string` | `"/subscriptions/0c22d89b-4687-4fa6-9eb4-979dcda22e7d/resourceGroups/us-rg-coreservices/providers/Microsoft.OperationalInsights/workspaces/us-law-coremonitoring"` | no |
| <a name="input_core_windows_vm_log_analytics_workspace_sentinel_id"></a> [core\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id](#input\_core\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id) | (Required) The log analytics workspace ID for diagnostics. | `any` | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_gateway_sub_address_prefix"></a> [gateway\_sub\_address\_prefix](#input\_gateway\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `list(string)` | n/a | yes |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"

  core_rg_keyvault_name          = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_first_remote_nva_pip = {
    "nprd-pr" = "52.138.102.104"    
    "prod-pr" = "137.135.105.155"   
    "prod-dr" = "104.42.249.54"
  }

  core_first_bgp_peering_address = {
    "nprd-pr" = "10.4.65.205"
    "prod-pr" = "10.47.129.203" 
    "prod-dr" = "10.47.161.203" 
  }

  core_first_connection_address_space = {
    "nprd-pr" = ["10.4.65.205/32"]
    "prod-pr" = ["10.47.129.203/32"]  
    "prod-dr" = ["10.47.161.203/32"]
  }

  core_second_remote_nva_pip = {
    "nprd-pr" = "52.138.102.58"   
    "prod-pr" = "137.135.105.219"
    "prod-dr" = "13.88.182.186"
  }

  core_second_bgp_peering_address = {
    "nprd-pr" = "10.4.65.206"
    "prod-pr" = "10.47.129.204"
    "prod-dr" = "10.47.161.204"
  }

  core_second_connection_address_space = {
    "nprd-pr" = ["10.4.65.206/32"]
    "prod-pr" = ["10.47.129.204/32"]
    "prod-dr" = ["10.47.161.204/32"]
  }

  core_remote_bgp_asn = {
    "nprd-pr" = "65200"   
    "prod-pr" = "65250"
    "prod-dr" = "65255"
  }

  core_bgp_asn = {
    "nprd-pr" = "65203"
    "prod-pr" = "65253"
    "prod-dr" = "65227"
  }

  core_subscription_diagnostics_settings = {
    logs    = ["Administrative", "Security", "ServiceHealth", "Alert", "Recommendation", "Policy", "Autoscale", "ResourceHealth"]
    metrics = []
  }

  core_vgw_diagnostics_settings = {
    logs    = ["GatewayDiagnosticLog", "IKEDiagnosticLog", "P2SDiagnosticLog", "RouteDiagnosticLog", "TunnelDiagnosticLog"]
    metrics = ["AllMetrics"]
  }

  core_vnet_diagnostics_settings = {
    logs    = ["VMProtectionAlerts"]
    metrics = ["AllMetrics"]
  }

  core_public_ip_diagnostics_settings = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }

   core_private_dns_zones = toset(var.core_private_dns_zone)
   
   core_shared_image_gallery_name = {
        "sbox-pr"  = "sboxpr"
        "nprd-pr"  = "nprdpr"
        "nprd-dr"  = "nprddr"
        "prod-pr"  = "prodpr" 
        "prod-dr"  = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```

```terraform
// US CH SharedServices DR Local variables
***************************************************************************************************

locals {
  core_prod_private_dns_zones = toset(var.core_prod_private_dns_zone) #the variable var.core_prod_private_dns_zone needs to be have the same value from core_us_ch_peninsula_sharedsvs variable core_private_dns_zone in the CCL.
}
***************************************************************************************************
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_core_azure_acr_aksghshr_role_assigned"></a> [core\_azure\_acr\_aksghshr\_role\_assigned](#output\_core\_azure\_acr\_aksghshr\_role\_assigned) | n/a |
| <a name="output_core_azure_aksghshr_role_assigned_contributor"></a> [core\_azure\_aksghshr\_role\_assigned\_contributor](#output\_core\_azure\_aksghshr\_role\_assigned\_contributor) | n/a |
| <a name="output_core_azure_aksghshr_role_assigned_mi_operator"></a> [core\_azure\_aksghshr\_role\_assigned\_mi\_operator](#output\_core\_azure\_aksghshr\_role\_assigned\_mi\_operator) | n/a |
| <a name="output_core_azure_bastion"></a> [core\_azure\_bastion](#output\_core\_azure\_bastion) | n/a |
| <a name="output_core_azure_dns_aksghshr_role_assigned"></a> [core\_azure\_dns\_aksghshr\_role\_assigned](#output\_core\_azure\_dns\_aksghshr\_role\_assigned) | n/a |
| <a name="output_core_azure_image_builder_association"></a> [core\_azure\_image\_builder\_association](#output\_core\_azure\_image\_builder\_association) | n/a |
| <a name="output_core_azure_image_builder_nsg"></a> [core\_azure\_image\_builder\_nsg](#output\_core\_azure\_image\_builder\_nsg) | n/a |
| <a name="output_core_azure_image_builder_nsg_nsgrule"></a> [core\_azure\_image\_builder\_nsg\_nsgrule](#output\_core\_azure\_image\_builder\_nsg\_nsgrule) | n/a |
| <a name="output_core_azure_image_builder_subnet"></a> [core\_azure\_image\_builder\_subnet](#output\_core\_azure\_image\_builder\_subnet) | n/a |
| <a name="output_core_azure_keyvault_aksghshr_role_assigned"></a> [core\_azure\_keyvault\_aksghshr\_role\_assigned](#output\_core\_azure\_keyvault\_aksghshr\_role\_assigned) | n/a |
| <a name="output_core_azure_keyvault_spn_role_assigned"></a> [core\_azure\_keyvault\_spn\_role\_assigned](#output\_core\_azure\_keyvault\_spn\_role\_assigned) | n/a |
| <a name="output_core_backup"></a> [core\_backup](#output\_core\_backup) | n/a |
| <a name="output_core_cl_azure_vm_image_builder"></a> [core\_cl\_azure\_vm\_image\_builder](#output\_core\_cl\_azure\_vm\_image\_builder) | n/a |
| <a name="output_core_cl_windows_jumpbox_wvm"></a> [core\_cl\_windows\_jumpbox\_wvm](#output\_core\_cl\_windows\_jumpbox\_wvm) | n/a |
| <a name="output_core_default_internet_route"></a> [core\_default\_internet\_route](#output\_core\_default\_internet\_route) | n/a |
| <a name="output_core_dns_zones"></a> [core\_dns\_zones](#output\_core\_dns\_zones) | n/a |
| <a name="output_core_gateway_subnet"></a> [core\_gateway\_subnet](#output\_core\_gateway\_subnet) | n/a |
| <a name="output_core_jumpbox_vm_nsg_nic_association"></a> [core\_jumpbox\_vm\_nsg\_nic\_association](#output\_core\_jumpbox\_vm\_nsg\_nic\_association) | n/a |
| <a name="output_core_jumpbox_wvm_admin_pass_secret"></a> [core\_jumpbox\_wvm\_admin\_pass\_secret](#output\_core\_jumpbox\_wvm\_admin\_pass\_secret) | n/a |
| <a name="output_core_jumpbox_wvm_admin_password"></a> [core\_jumpbox\_wvm\_admin\_password](#output\_core\_jumpbox\_wvm\_admin\_password) | n/a |
| <a name="output_core_keyvault"></a> [core\_keyvault](#output\_core\_keyvault) | n/a |
| <a name="output_core_log_analytics_workspace"></a> [core\_log\_analytics\_workspace](#output\_core\_log\_analytics\_workspace) | n/a |
| <a name="output_core_mgmt_subnet"></a> [core\_mgmt\_subnet](#output\_core\_mgmt\_subnet) | n/a |
| <a name="output_core_primary_local_network_gateway"></a> [core\_primary\_local\_network\_gateway](#output\_core\_primary\_local\_network\_gateway) | n/a |
| <a name="output_core_primary_vgw_pip"></a> [core\_primary\_vgw\_pip](#output\_core\_primary\_vgw\_pip) | n/a |
| <a name="output_core_primary_vgw_to_lgw_connection"></a> [core\_primary\_vgw\_to\_lgw\_connection](#output\_core\_primary\_vgw\_to\_lgw\_connection) | n/a |
| <a name="output_core_private_link_subnet"></a> [core\_private\_link\_subnet](#output\_core\_private\_link\_subnet) | n/a |
| <a name="output_core_ptrn_Kubernetes"></a> [core\_ptrn\_Kubernetes](#output\_core\_ptrn\_Kubernetes) | n/a |
| <a name="output_core_ptrn_Kubernetes_user_assigned_identity"></a> [core\_ptrn\_Kubernetes\_user\_assigned\_identity](#output\_core\_ptrn\_Kubernetes\_user\_assigned\_identity) | n/a |
| <a name="output_core_rg_azure_image_builder"></a> [core\_rg\_azure\_image\_builder](#output\_core\_rg\_azure\_image\_builder) | n/a |
| <a name="output_core_rg_azure_qualys"></a> [core\_rg\_azure\_qualys](#output\_core\_rg\_azure\_qualys) | n/a |
| <a name="output_core_rg_data"></a> [core\_rg\_data](#output\_core\_rg\_data) | n/a |
| <a name="output_core_rg_image_gallery"></a> [core\_rg\_image\_gallery](#output\_core\_rg\_image\_gallery) | n/a |
| <a name="output_core_rg_logging"></a> [core\_rg\_logging](#output\_core\_rg\_logging) | n/a |
| <a name="output_core_rg_network"></a> [core\_rg\_network](#output\_core\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_core_rg_private_dns_forwarder"></a> [core\_rg\_private\_dns\_forwarder](#output\_core\_rg\_private\_dns\_forwarder) | n/a |
| <a name="output_core_rg_private_dns_zone"></a> [core\_rg\_private\_dns\_zone](#output\_core\_rg\_private\_dns\_zone) | n/a |
| <a name="output_core_rg_security"></a> [core\_rg\_security](#output\_core\_rg\_security) | n/a |
| <a name="output_core_route_table"></a> [core\_route\_table](#output\_core\_route\_table) | n/a |
| <a name="output_core_secondary_local_network_gateway"></a> [core\_secondary\_local\_network\_gateway](#output\_core\_secondary\_local\_network\_gateway) | n/a |
| <a name="output_core_secondary_vgw_pip"></a> [core\_secondary\_vgw\_pip](#output\_core\_secondary\_vgw\_pip) | n/a |
| <a name="output_core_secondary_vgw_to_lgw_connection"></a> [core\_secondary\_vgw\_to\_lgw\_connection](#output\_core\_secondary\_vgw\_to\_lgw\_connection) | n/a |
| <a name="output_core_security_center_pricing"></a> [core\_security\_center\_pricing](#output\_core\_security\_center\_pricing) | n/a |
| <a name="output_core_shared_image_gallery"></a> [core\_shared\_image\_gallery](#output\_core\_shared\_image\_gallery) | n/a |
| <a name="output_core_virtual_network_gateway"></a> [core\_virtual\_network\_gateway](#output\_core\_virtual\_network\_gateway) | n/a |
| <a name="output_core_vnet"></a> [core\_vnet](#output\_core\_vnet) | n/a |
| <a name="output_core_windows_vm_dns_forward"></a> [core\_windows\_vm\_dns\_forward](#output\_core\_windows\_vm\_dns\_forward) | n/a |
| <a name="output_core_windows_vm_dns_forwarder_nsg"></a> [core\_windows\_vm\_dns\_forwarder\_nsg](#output\_core\_windows\_vm\_dns\_forwarder\_nsg) | n/a |
| <a name="output_core_windows_vm_dns_forwarder_nsg_nic_association"></a> [core\_windows\_vm\_dns\_forwarder\_nsg\_nic\_association](#output\_core\_windows\_vm\_dns\_forwarder\_nsg\_nic\_association) | n/a |
| <a name="output_core_windows_vm_dns_forwarder_nsg_subnet_association"></a> [core\_windows\_vm\_dns\_forwarder\_nsg\_subnet\_association](#output\_core\_windows\_vm\_dns\_forwarder\_nsg\_subnet\_association) | n/a |
| <a name="output_core_windows_vm_dns_forwarder_route_table_associate"></a> [core\_windows\_vm\_dns\_forwarder\_route\_table\_associate](#output\_core\_windows\_vm\_dns\_forwarder\_route\_table\_associate) | n/a |


## Usage

```terraform
// Deploy US CH Shared Services Platform
//**********************************************************************************************
 module "core_us_ch_peninsula_sharedsvs" {
     source                                                 = "../dn-tads_tf-azure-component-library/core/core_us_ch_peninsula_sharedsvs"
     env                                                    = var.env
     postfix                                                = var.postfix
     location                                               = var.location
     hub_env                                                = var.env
     core_vnet_address_space                                = var.core_vnet_address_space
     core_vnet_dns_servers                                  = var.core_vnet_dns_servers 
     gateway_sub_address_prefix                             = var.gateway_sub_address_prefix  
     core_keyvault_postfix                                  = var.core_keyvault_postfix
     core_azure_defender_resources                          = var.core_azure_defender_resources 
     core_private_link_subnet_address_prefixes              = var.core_private_link_subnet_address_prefixes
     core_route_table_disable_bgp_propagation               = var.core_route_table_disable_bgp_propagation
     core_azure_bastion_subnet_prefix                       = var.core_azure_bastion_subnet_prefix  
     core_mgmt_sub_address_prefix                           = var.core_mgmt_sub_address_prefix
     core_imgbuilder_sub_address_prefix                     = var.core_imgbuilder_sub_address_prefix 
     core_azure_vm_image_build_number                       = var.BUILD_NUMBER
     core_azure_vm_image_builder_distribute_replicationRegions = var.core_azure_vm_image_builder_distribute_replicationRegions
     core_windows_vm_deploy                                 = var.core_windows_vm_deploy
     core_windows_vm_dns_forwarder_domain_user_upn          = var.DOMAIN_USER_US_CH
     core_windows_vm_dns_forwarder_domain_password          = var.DOMAIN_PASSWORD_US_CH
     core_windows_vm_dns_forwarder_computer_name            = var.core_windows_vm_dns_forwarder_computer_name
     core_windows_vm_dns_forwarder_image_id                 = var.core_vm_image_id
     core_windows_vm_jumpbox_computer_name                  = var.core_windows_vm_jumpbox_computer_name
     core_windows_vm_jumpbox_image_id                       = var.core_vm_image_id
     core_windows_vm_jumpbox_domain_user_upn                = var.DOMAIN_USER_US_CH
     core_windows_vm_jumpbox_domain_password                = var.DOMAIN_PASSWORD_US_CH
     core_keyvault_nacl_allowed_ips                         = concat(var.core_keyvault_nacl_allowed_ips, [var.GITHUBIP])
     core_ptrn_kubernetes_deploy                            = var.core_ptrn_kubernetes_deploy
     core_ptrn_kubernetes_postfix                           = var.core_ptrn_kubernetes_postfix 
     core_ptrn_kubernetes_subnet_nodes_address_prefixes     = var.core_ptrn_kubernetes_subnet_nodes_address_prefixes 
     core_ptrn_kubernetes_kubernetes_version                = var.core_ptrn_kubernetes_kubernetes_version 
     core_ptrn_kubernetes_rbac_aad_admin_group_object_ids   = var.core_ptrn_kubernetes_rbac_aad_admin_group_object_ids
     tags                                                   = var.tags
}
//**********************************************************************************************

// To enable USCH multi-home the CloudOps requiere to enable and apply the policy (https://kiki.us.kworld.kpmg.com/display/6TO/Enable+Azure+Monitor+for+VMs+with+Azure+Monitoring+Agent). And from TF it requiere to deploy DCR 
endpoint deployment with azurerm provider 3.22.0
//**********************************************************************************************

// Data Collection Rules for Windows VM's in each subscription to send metricts to LAW PROD
//**********************************************************************************************
data "azurerm_log_analytics_workspace" "cl_log_analytics_workspace" {
  name                = "oms-prod-pr-shrdsvc-log-analytics"                      
  resource_group_name = "rg-prod-pr-shrdsvc-logging"
}

//Create DCE endpoint 
//**********************************************************************************************
resource "azurerm_monitor_data_collection_endpoint" "log_analytics_data_collection_rule_endpoint" {
  name                          = "${var.env}-${var.postfix}-dc-endpoint"
  resource_group_name           = data.azurerm_log_analytics_workspace.cl_log_analytics_workspace.resource_group_name  
  location                      = var.location
  kind                          = "Windows"
  public_network_access_enabled = false
  description                   = "monitor_data_collection_endpoint"
  tags                          = var.tags
}
//**********************************************************************************************
```

```terraform
// Deploy US CH DR Shared Services Platform 
************************************************************************************************
//AKS data sources
//******************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone_acr" {
  provider            = azurerm.shs
  name                = "privatelink.azurecr.io"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

data "azurerm_private_dns_zone" "core_data_private_dns_zone_aks" {
  provider            = azurerm.shs
  name                = "privatelink.westus.azmk8s.io"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

//Key Vault data sources
//*****************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone" {
  provider            = azurerm.shs
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

//image builder data sources
//*****************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone_sa" {
  provider            = azurerm.shs
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}

//log analytics data sources
//*****************************************
data "azurerm_private_dns_zone" "core_data_private_dns_zone_monitor" {
  provider            = azurerm.shs
  name                = "privatelink.monitor.azure.com"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_ods" {
  provider              = azurerm.shs
  name                = "privatelink.ods.opinsights.azure.com"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_oms" {
  provider              = azurerm.shs
  name                = "privatelink.oms.opinsights.azure.com"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_automation" {
  provider              = azurerm.shs
  name                = "privatelink.agentsvc.azure-automation.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_private_dns_zone" "core_data_private_dns_zone_blob" {
  provider              = azurerm.shs
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = var.core_rg_private_dnszone_sharedsvcs_prod
}
data "azurerm_virtual_network" "core_data_shdsvc_vnet_prod" {
  provider            = azurerm.shs
  name                = "prod-pr-shrdsvc-vnet"
  resource_group_name = "rg-prod-pr-shrdsvc-network"
}
//*****************************************************************************************

// Deploy the US CH SharedServices DR Peninsula Core
//*****************************************************************************************************
module "core_us_ch_peninsula_sharedsvs" {
  source                                                    = "../dn-tads_tf-azure-component-library/core/core_us_ch_peninsula_sharedsvs"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  hub_env                                                   = var.env
  core_vnet_address_space                                   = var.core_vnet_address_space
  core_vnet_dns_servers                                     = var.core_vnet_dns_servers
  gateway_sub_address_prefix                                = var.gateway_sub_address_prefix
  core_azure_defender_resources                             = var.core_azure_defender_resources
  core_private_link_subnet_address_prefixes                 = var.core_private_link_subnet_address_prefixes
  core_route_table_disable_bgp_propagation                  = var.core_route_table_disable_bgp_propagation
  core_azure_bastion_subnet_prefix                          = var.core_azure_bastion_subnet_prefix
  core_azure_bastion_availability_zone                      = var.core_azure_bastion_availability_zone
  core_mgmt_sub_address_prefix                              = var.core_mgmt_sub_address_prefix
  core_windows_vm_deploy                                    = var.core_windows_vm_deploy
  core_windows_vm_dns_forwarder_domain_user_upn             = var.DOMAIN_USER_US_CH
  core_windows_vm_dns_forwarder_domain_password             = var.DOMAIN_PASSWORD_US_CH
  core_windows_vm_dns_forwarder_computer_name               = var.core_windows_vm_dns_forwarder_computer_name
  core_windows_vm_dns_forwarder_image_id                    = var.core_vm_image_id
  core_windows_vm_jumpbox_computer_name                     = var.core_windows_vm_jumpbox_computer_name
  core_windows_vm_jumpbox_image_id                          = var.core_vm_image_id
  core_windows_vm_jumpbox_domain_user_upn                   = var.DOMAIN_USER_US_CH
  core_windows_vm_jumpbox_domain_password                   = var.DOMAIN_PASSWORD_US_CH
  core_windows_vm_log_analytics_workspace_sentinel_id       = var.SENTINEL_CH_LAW_ID
  core_windows_vm_log_analytics_primary_sentinel_shared_key = var.SENTINEL_CH_LAW_SHAREDKEY
  core_windows_vm_log_analytics_workspace_resource_id       = var.SENTINEL_CH_LAW_RESOURCE_ID
  core_ptrn_kubernetes_deploy                               = var.core_ptrn_kubernetes_deploy
  core_ptrn_kubernetes_postfix                              = var.core_ptrn_kubernetes_postfix
  core_ptrn_kubernetes_subnet_nodes_address_prefixes        = var.core_ptrn_kubernetes_subnet_nodes_address_prefixes
  core_ptrn_kubernetes_kubernetes_version                   = var.core_ptrn_kubernetes_kubernetes_version
  core_ptrn_kubernetes_rbac_aad_admin_group_object_ids      = var.core_ptrn_kubernetes_rbac_aad_admin_group_object_ids
  core_ptrn_kubernetes_azure_container_registry_prodtodr_id = "/subscriptions/e17b69e4-59eb-4b56-a090-d08f87c300de/resourceGroups/rg-prod-pr-shrdsvc-kubernetes-ghshr/providers/Microsoft.ContainerRegistry/registries/prodprshrdsvcacr"
  core_keyvault_prodtodr_id                                 = "/subscriptions/e17b69e4-59eb-4b56-a090-d08f87c300de/resourceGroups/rg-prod-pr-shrdsvc-security/providers/Microsoft.KeyVault/vaults/prod-pr-shrdsvc-kv-cp"
  core_ptrn_kubernetes_default_node_pool_availability_zones = var.core_ptrn_kubernetes_default_node_pool_availability_zones
  core_ptrn_kubernetes_node_pool_availability_zones         = var.core_ptrn_kubernetes_node_pool_availability_zones
  core_ptrn_kubernetes_deploy_azure_container_registry      = false 
  core_keyvault_enable                                      = false
  core_rg_security_enable                                   = false
  core_shared_image_gallery_deploy                          = false
  core_law_private_dns_zone_ids                             = [data.azurerm_private_dns_zone.core_data_private_dns_zone_monitor.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_ods.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_oms.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_automation.id,
                                                              data.azurerm_private_dns_zone.core_data_private_dns_zone_blob.id]
  core_ptrn_kubernetes_private_dns_zone_id                  = data.azurerm_private_dns_zone.core_data_private_dns_zone_aks.id
  core_private_dns_zone_enable                              = false
  core_deploy_dr_shsdsvc_to_prod_shsdsvc_peering            = true
  core_dr_to_shsdsvc_prod_peering_network_id                = data.azurerm_virtual_network.core_data_shdsvc_vnet_prod.id
  tags                                                      = var.tags
}
//*****************************************************************************************


//*****************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "core_dns_zones" {
  provider                                                 = azurerm.shs
  for_each                                                 = local.core_prod_private_dns_zones
  name                                                     = "vnetlink-${var.env}-${var.postfix}-${replace(each.key, "privatelink.", "")}"
  resource_group_name                                      = var.core_rg_private_dnszone_sharedsvcs_prod
  private_dns_zone_name                                    = data.terraform_remote_state.core_shared_prod.outputs.core_us_ch_peninsula_sharedsvs.core_dns_zones[each.key].name
  virtual_network_id                                       = module.core_us_ch_peninsula_sharedsvs.core_vnet.id
  tags                                                     = var.tags
}
//*****************************************************************************************

// To enable USCH multi-home the CloudOps requiere to enable and apply the policy (https://kiki.us.kworld.kpmg.com/display/6TO/Enable+Azure+Monitor+for+VMs+with+Azure+Monitoring+Agent). And from TF it requiere to deploy DCR 
endpoint deployment with azurerm provider 3.22.0
//**********************************************************************************************

// Data Collection Rules for Windows VM's in each subscription to send metricts to LAW PROD
//**********************************************************************************************
data "azurerm_log_analytics_workspace" "cl_log_analytics_workspace" {
  name                = "oms-prod-pr-shrdsvc-log-analytics"                      
  resource_group_name = "rg-prod-pr-shrdsvc-logging"
}

//Create DCE endpoint 
//**********************************************************************************************
resource "azurerm_monitor_data_collection_endpoint" "log_analytics_data_collection_rule_endpoint" {
  name                          = "${var.env}-${var.postfix}-dc-endpoint"
  resource_group_name           = data.azurerm_log_analytics_workspace.cl_log_analytics_workspace.resource_group_name  
  location                      = var.location
  kind                          = "Windows"
  public_network_access_enabled = false
  description                   = "monitor_data_collection_endpoint"
  tags                          = var.tags
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
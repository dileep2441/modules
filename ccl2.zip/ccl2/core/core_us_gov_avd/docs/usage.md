
## Usage

```terraform
//**********************************************************************************************
module "avd_us_gov" {
    source                          = "../dn-tads_tf-azure-component-library/core/core_us_gov_avd"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    suffix                          = var.suffix
    dns_location                    = "ugv"
    hub_env                         = var.env
    tags                           = var.tags
    avd_vnet_address_space         = var.avd_vnet_address_space
    avd_vnet_dns_servers           = var.avd_vnet_dns_servers
    avd_private_link_subnet_address_prefixes = var.avd_private_link_subnet_address_prefixes
    avd_nsg_flow_log_postfix         = var.avd_nsg_flow_log_postfix
    avd_storage_account_fix_suffix               = var.avd_storage_account_fix_suffix              
    avd_storage_account_tier                                  = var.avd_storage_account_tier
    avd_storage_account_kind                                  = var.avd_storage_account_kind
    avd_storage_account_allowed_ips                           = var.avd_storage_account_allowed_ips
    avd_storage_account_private_link_access_enabled           = var.avd_storage_account_private_link_access_enabled 
    avd_storage_account_private_link_access_endpoint_resource_id = var.avd_storage_account_private_link_access_endpoint_resource_id
    avd_storage_account_private_link_access_endpoint_tenant_id   = var.avd_storage_account_private_link_access_endpoint_tenant_id
    avd_log_analytics_supported                                     = var.avd_log_analytics_supported
    avd_alt_log_analytics_workspace                                 = var.avd_alt_log_analytics_workspace
    avd_alt_log_analytics_workspace_name                            = var.avd_alt_log_analytics_workspace_name
    avd_alt_log_analytics_workspace_id                              = var.avd_alt_log_analytics_workspace_id
    avd_storage_account_fslogix_file_share_office_allowed_vnet_subnet_ids   = var.avd_storage_account_fslogix_file_share_office_allowed_vnet_subnet_ids
    avd_storage_account_fslogix_file_share_allowed_vnet_subnet_ids          = var.avd_storage_account_fslogix_file_share_allowed_vnet_subnet_ids
    avd_storage_account_allowed_vnet_subnet_ids                             = var.avd_storage_account_allowed_vnet_subnet_ids
    avd_fslogix_storage_account_file_shares                                 = var.avd_fslogix_storage_account_file_shares
    avd_office_storage_account_file_shares                                  = var.avd_office_storage_account_file_shares

    #fileshare AD Auth
      avd_storage_account_fslogix_file_share_personal_ad_auth_enable = var.avd_storage_account_fslogix_file_share_personal_ad_auth_enable
      avd_storage_account_fslogix_file_share_office_ad_auth_enable   = var.avd_storage_account_fslogix_file_share_office_ad_auth_enable
      avd_storage_account_file_share_directory_type   = var.avd_storage_account_file_share_directory_type
      avd_storage_account_file_share_domain_guid  = var.avd_storage_account_file_share_domain_guid 
      avd_storage_account_file_share_domain_name  = var.avd_storage_account_file_share_domain_name 
      avd_storage_account_file_share_domain_sid   = var.avd_storage_account_file_share_domain_sid
      avd_storage_account_file_share_forest_name  = var.avd_storage_account_file_share_forest_name
      avd_storage_account_file_share_netbios_domain_name  = var.avd_storage_account_file_share_netbios_domain_name 
      avd_storage_account_personal_file_share_storage_sid = var.avd_storage_account_personal_file_share_storage_sid 
      avd_storage_account_office_file_share_storage_sid   = var.avd_storage_account_office_file_share_storage_sid
      avd_log_analytics_workspace_count_performance_counters = var.avd_log_analytics_workspace_count_performance_counters
#       avd_storage_account_fslogix_file_share_wdac_allowed_vnet_subnet_ids = var.avd_storage_account_fslogix_file_share_wdac_allowed_vnet_subnet_ids
#       avd_wdac_storage_account_file_shares                                = var.avd_wdac_storage_account_file_shares
#       avd_storage_account_wdac_file_share_storage_sid                     = var.avd_storage_account_wdac_file_share_storage_sid
#       avd_storage_account_wdac_file_share_ad_auth_enable        = var.avd_storage_account_wdac_file_share_ad_auth_enable


    #KV
    avd_rg_security_enable                                             = var.avd_rg_security_enable    
    avd_keyvault_enable                                                = var.avd_keyvault_enable 
    avd_keyvault_nacl_allowed_subnets                                  = var.avd_keyvault_nacl_allowed_subnets
    avd_keyvault_nacl_allowed_ips                                      = var.avd_keyvault_nacl_allowed_ips
 
    #peering
    avd_shared_services_peering_network_id    = var.avd_shared_services_peering_network_id
    avd_ihub_peering_network_id               = var.avd_ihub_peering_network_id
    avd_idt_peering_network_id                = var.avd_idt_peering_network_id
    avd_prod_to_avd_dr_peering_network_id       = var.avd_prod_to_avd_dr_peering_network_id 
    avd_dr_to_avd_prod_peering_network_id       = var.avd_dr_to_avd_prod_peering_network_id
    avd_dr_deploy_avd_prod_peering              = var.avd_dr_deploy_avd_prod_peering
    avd_prod_deploy_avd_dr_peering              = var.avd_prod_deploy_avd_dr_peering
    
    #route
    ihub_internal_lb_private_ip_address       = var.ihub_internal_lb_private_ip_address
    avd_route_table_disable_bgp_propagation   = false
    avd_hpool1_sub_address_prefix             = var.avd_hpool1_sub_address_prefix
    avd_hpool2_sub_address_prefix             = var.avd_hpool2_sub_address_prefix
    avd_hpool3_sub_address_prefix             = var.avd_hpool3_sub_address_prefix

}
//**********************************************************************************************
resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  count               = var.deploy_avd_log_analytics_link_scoped_service ? 1 : 0
  depends_on          = [module.avd_us_gov]
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.avd_sharedsvcs_logging_rg, var.env)
  scope_name          = lookup(local.avd_sharedsvcs_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = module.avd_us_gov.cl_log_analytics_workspace[0].cl_log_analytics_workspace.id
}
```
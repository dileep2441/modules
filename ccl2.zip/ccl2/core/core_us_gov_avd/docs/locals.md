## Local values

```terraform
locals {
  resource_name_no_dash    = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
  timeout_duration = "2h"
  
  # KeyVault
  avd_rg_keyvault_name            = var.avd_keyvault_enable && var.avd_rg_security_enable ?  azurerm_resource_group.avd_rg_security[0].name  : azurerm_resource_group.avd_rg_data.name
  avd_private_link_subnet          = var.avd_deploy_private_link_subnet ? [azurerm_subnet.avd_private_link_subnet[0].id]              : var.avd_keyvault_allowed_pe_subnet_ids
}
```


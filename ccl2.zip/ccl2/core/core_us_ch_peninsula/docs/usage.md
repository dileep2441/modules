## Usage

#### With Core Key Vault enabled
```terraform
// Deploy the US CH Peninsula Core
// Without Core Key Vault enabled, please send the value in false to variable: core_keyvault_enable = false
//**********************************************************************************************
module "core_us_peninsula" {
    source                                            = "../dn-tads_tf-azure-component-library/core/core_us_ch_peninsula"
    env                                               = var.env
    postfix                                           = var.postfix
    location                                          = var.location
    hub_env                                           = var.env
    core_vnet_address_space                           = var.core_vnet_address_space
    core_vnet_dns_servers                             = var.core_vnet_dns_servers
    gateway_sub_address_prefix                        = var.gateway_sub_address_prefix
    core_private_link_subnet_address_prefixes         = var.core_private_link_subnet_address_prefixes
    core_private_link_subnet_service_endpoints        = var.core_private_link_subnet_service_endpoints
    vgw_lgw_conn_shared_key                           = var.SHARED_KEY
    core_rg_security_enable                           = var.core_rg_security_enable
    core_keyvault_enable                              = var.core_keyvault_enable
    core_keyvault_postfix                             = var.core_keyvault_postfix
    core_keyvault_nacl_allowed_subnets                = var.core_keyvault_nacl_allowed_subnets
    core_keyvault_private_dns_zone_ids                = var.core_keyvault_private_dns_zone_ids
    core_azure_backup_enable_vm_backup                = var.core_azure_backup_enable_vm_backup 
    core_azure_backup_enable_file_storage_backup      = var.core_azure_backup_enable_file_storage_backup
    core_azure_backup_enable_blob_storage_backup      = var.core_azure_backup_enable_blob_storage_backup
    core_keyvault_nacl_allowed_ips                    = var.core_keyvault_nacl_allowed_ips
    tags                                              = var.tags
}
//**********************************************************************************************


//Add private link scoped service from spoke LAW to AMPLS in shared services
//NOTE: Spoke SPN must have contributor role over the private link scope resource in shared services subscription.
//The alias provider azurerm.shs require the resources names from shared services subscription(LAW RG name,AMPLS name,LAW Id)
//**********************************************************************************************
resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = var.ampls_sharedsvcs_logging_rg
  scope_name          = var.ampls_sharedsvcs_log_analytics_private_link_scope_name
  linked_resource_id  = module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
//**********************************************************************************************


// Complete the Peerring SharedServices to Spoke
//NOTE: Spoke SPN must have network contributor role over the vnet resource in shared services subscription.
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "sharedsvcs_peering_core" {
 depends_on                   = [module.core_us_peninsula]
 provider                     = azurerm.shs
 name                         = "peer-to-${var.postfix}-vnet"
 resource_group_name          = var.core_shared_services_resource_group_map  
 virtual_network_name         = var.core_shared_services_network_name_map 
 remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
 allow_virtual_network_access = true
 allow_forwarded_traffic      = true
 use_remote_gateways          = false

 #allow_gateway_transit' must be set to false for vnet Global Peering
 allow_gateway_transit        = false

 timeouts {
   create                     = local.timeout_duration
   delete                     = local.timeout_duration
 }
}
//**********************************************************************************************
```
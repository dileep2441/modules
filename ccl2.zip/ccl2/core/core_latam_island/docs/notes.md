#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified on Jenkinsfile:
```jenkinsfile
stage("Terraform *** ") {
    agent {
        docker {
            image 'dn-cloud-docker.artifactory.us.kworld.kpmg.com/azure-terraform-0-15-4:latest'
            ...
```
Specify TF version in `core_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```
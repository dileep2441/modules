## Local values

```terraform
locals {
  resource_name_no_dash    = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
  timeout_duration = "2h"
  sharedsvcs_cribl_vm_log_analytics_workspace_id   = var.sharedsvcs_alt_log_analytics_workspace ? var.sharedsvcs_alt_log_analytics_vm_workspace_id : module.cl_log_analytics_workspace[0].cl_log_analytics_workspace.workspace_id
  sharedsvcs_cribl_vm_log_analytics_workspace_key  = var.sharedsvcs_alt_log_analytics_workspace ? var.sharedsvcs_alt_log_analytics_workspace_primary_shared_key : module.cl_log_analytics_workspace[0].cl_log_analytics_workspace.primary_shared_key
  # KeyVault
  sharedsvcs_rg_keyvault_name             = var.sharedsvcs_keyvault_enable && var.sharedsvcs_rg_security_enable ?  azurerm_resource_group.sharedsvcs_rg_security[0].name  : azurerm_resource_group.sharedsvcs_rg_data.name
  sharedsvcs_private_link_subnet          = var.sharedsvcs_deploy_private_link_subnet ? [azurerm_subnet.sharedsvcs_private_link_subnet[0].id]              : var.sharedsvcs_keyvault_allowed_pe_subnet_ids
}
```


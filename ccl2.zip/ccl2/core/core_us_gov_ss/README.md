<!-- BEGIN_TF_DOCS -->

# Azure Shared Services Platform Module
Shared Services subscription has the consolidation of the Azure services and resources that are used by multiple Spoke subscriptions to perform their business needs. It helps the enterprise to have the central control over common services and security aspects, while maintaining segregation for the workloads in each spoke.



## Resources

| Name | Type |
|------|------|
| [azurerm_availability_set.sharedsvcs_bigfix_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_cribl_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_fileshare_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_forensic_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_jumpserver_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_management_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_mgmt_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_pentest_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_personalization_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_sql_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_availability_set.sharedsvcs_wsus_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_backup_protected_vm.cl_cribl_mstr_vm_protected_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_vm) | resource |
| [azurerm_backup_protected_vm.cl_cribl_wrk_vm_protected_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_vm) | resource |
| [azurerm_key_vault_secret.sharedsvcs_bigfix_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_bigfix_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_cribl_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_cribl_vm_admin_user_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_fileshare_vm_admin_password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_fileshare_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_forensic_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_forensic_vm_admin_user_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_jumpserver_vm_admin_password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_jumpserver_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_avd_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_avd_vm_admin_user_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_exchange_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_exchange_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_idty_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_idty_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_intune_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_intune_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_powerbi_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_powerbi_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_purview_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_purview_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_sharepoint_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_sharepoint_vm_admin_user_secret_updated](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_teams_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_management_teams_vm_admin_user_secret_updated](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_mgmt_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_mgmt_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_pentest_vm_admin_pass_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_pentest_vm_admin_user_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_personalization_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_personalization_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_sql_vm_admin_pass_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_sql_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_vm_domain_password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_vm_domain_username](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_wsus_vm_admin_password](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.sharedsvcs_wsus_vm_admin_user_secret_new](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_lb.sharedsvcs_cribl_load_balancer_internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb) | resource |
| [azurerm_lb.sharedsvcs_load_balancer_internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb) | resource |
| [azurerm_lb_backend_address_pool.sharedsvcs_backend_addesspool_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_backend_address_pool) | resource |
| [azurerm_lb_backend_address_pool.sharedsvcs_cribl_backend_addesspool_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_backend_address_pool) | resource |
| [azurerm_lb_probe.sharedsvcs_cribl_infoblx_lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_probe.sharedsvcs_cribl_poalo2_lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_probe.sharedsvcs_cribl_poalo3_lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_probe.sharedsvcs_lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_crible_infoblx_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_crible_paolo1_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_crible_paolo2_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_crible_paolo3_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_crible_strd1_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_crible_strd2_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_rule_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_rule_int_personalization](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.sharedsvcs_lb_rule_int_sql](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_monitor_diagnostic_setting.int_cribl_load_balancer_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.int_load_balancer_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_private_link_scope.sharedsvcs_log_analytics_private_link_scope](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scope) | resource |
| [azurerm_monitor_private_link_scoped_service.cl_log_analytics_link_scoped_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_private_link_scoped_service) | resource |
| [azurerm_network_interface.net_int_crible_mst_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface.net_int_crible_wrk_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_cribl_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_int_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_int_personalization](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_int_sql](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_security_group.default-nsg-sn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_watcher_flow_log.sharedsvcs_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_private_dns_zone.sharedsvcs_backup_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.sharedsvcs_keyvault_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.sharedsvcs_nsg_sa_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.keyvault_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_dns_zone_virtual_network_link.sharedsvcs_backup_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_dns_zone_virtual_network_link.sharedsvcs_nsg_sa_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_endpoint.sharedsvcs_log_analytics_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.sharedsvc_rg_cribl](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_avd_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_bigfix_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_exchange_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_forensic_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_idty_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_intune_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_pentest_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_powerbi_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_purview_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_fileshare](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_image_gallery](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_personalization](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_rg_sql](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_sharepoint_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.sharedsvcs_teams_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.SS-to-IHub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.sharedsvcs_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_shared_image_gallery.sharedsvcs_image_gallery](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/shared_image_gallery) | resource |
| [azurerm_subnet.sharedsvcs_ivanti_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.sharedsvcs_mgmt_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.sharedsvcs_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.sharedsvcs_private_link_subnet2](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.ivanti-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.mgmt-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.joinivanti](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.joinmgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_machine.virtual_machine_cribl_mstrs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_virtual_machine.virtual_machine_cribl_workers](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_virtual_machine_extension.sharedsvcs_cribl_master_log_analytics_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.sharedsvcs_cribl_worker_log_analytics_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_network.sharedsvcs_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.peering-dr-ss-to-prod-ss](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-prod-ss-to-dr-ss](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvc-dr-to-idty-prod](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvc-prod-to-idty-dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvc-to-avd](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvc-to-idty](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering-sharedsvc-to-ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [random_password.sharedsvcs_bigfix_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_cribl_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_fileshare_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_forensic_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_jumpserver_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_management_avd_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_management_exchange_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_management_idty_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_management_intune_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_management_powerbi_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_management_purview_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_management_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_mgmt_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_pentest_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_personalization_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_sql_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [random_password.sharedsvcs_wsus_vm_admin_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_availability_zones"></a> [availability\_zones](#input\_availability\_zones) | (Required) The llist of availability zones to be leveraged by cribl VMs | `list(string)` | <pre>[<br>  "1",<br>  "2",<br>  "3"<br>]</pre> | no |
| <a name="input_cribl"></a> [cribl](#input\_cribl) | (Required) Details that will be used to create the Palo Alto Firewall | <pre>object({<br>    vm_size                 = string,<br>    vm_prefix               = string,<br>    vm_image_id             = string,<br>    vm_publisher            = string,<br>    vm_offer                = string,<br>    vm_sku                  = string,<br>    vm_version              = string,<br>    vm_storage_os_disk_size = string,<br>    vm_os                   = string,<br>    vm_from_marketplace     = string,<br>    management_privateip    = list(string),<br><br>  })</pre> | n/a | yes |
| <a name="input_cribl_backend_addesspool_associations_names"></a> [cribl\_backend\_addesspool\_associations\_names](#input\_cribl\_backend\_addesspool\_associations\_names) | n/a | `list(string)` | `[]` | no |
| <a name="input_cribl_master_names"></a> [cribl\_master\_names](#input\_cribl\_master\_names) | n/a | `list(string)` | `[]` | no |
| <a name="input_cribl_master_private_ip_address_allocation"></a> [cribl\_master\_private\_ip\_address\_allocation](#input\_cribl\_master\_private\_ip\_address\_allocation) | n/a | `any` | n/a | yes |
| <a name="input_cribl_worker_names"></a> [cribl\_worker\_names](#input\_cribl\_worker\_names) | n/a | `list(string)` | `[]` | no |
| <a name="input_cribl_worker_private_ip_address_allocation"></a> [cribl\_worker\_private\_ip\_address\_allocation](#input\_cribl\_worker\_private\_ip\_address\_allocation) | n/a | `any` | n/a | yes |
| <a name="input_dns_location"></a> [dns\_location](#input\_dns\_location) | (Required) The abbreviated cloud region used for private dns zone creation. | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_private_ip_address"></a> [ihub\_internal\_lb\_private\_ip\_address](#input\_ihub\_internal\_lb\_private\_ip\_address) | n/a | `string` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_sharedsvccs_vm_domain_password"></a> [sharedsvccs\_vm\_domain\_password](#input\_sharedsvccs\_vm\_domain\_password) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_alt_log_analytics_vm_workspace_id"></a> [sharedsvcs\_alt\_log\_analytics\_vm\_workspace\_id](#input\_sharedsvcs\_alt\_log\_analytics\_vm\_workspace\_id) | (Optional) workspace ID of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_sharedsvcs_alt_log_analytics_workspace"></a> [sharedsvcs\_alt\_log\_analytics\_workspace](#input\_sharedsvcs\_alt\_log\_analytics\_workspace) | (Optional) Set to true if resource diagnostic settings need to be sent to an alternative log analytics workspace. | `bool` | `false` | no |
| <a name="input_sharedsvcs_alt_log_analytics_workspace_id"></a> [sharedsvcs\_alt\_log\_analytics\_workspace\_id](#input\_sharedsvcs\_alt\_log\_analytics\_workspace\_id) | (Optional) resource ID of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_sharedsvcs_alt_log_analytics_workspace_name"></a> [sharedsvcs\_alt\_log\_analytics\_workspace\_name](#input\_sharedsvcs\_alt\_log\_analytics\_workspace\_name) | (Optional) name of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_sharedsvcs_alt_log_analytics_workspace_primary_shared_key"></a> [sharedsvcs\_alt\_log\_analytics\_workspace\_primary\_shared\_key](#input\_sharedsvcs\_alt\_log\_analytics\_workspace\_primary\_shared\_key) | (Optional) primary shared key of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_sharedsvcs_avail_zones_supported"></a> [sharedsvcs\_avail\_zones\_supported](#input\_sharedsvcs\_avail\_zones\_supported) | (Optional) Set to true if availability zones are supported in region. | `bool` | `true` | no |
| <a name="input_sharedsvcs_azure_defender_resources"></a> [sharedsvcs\_azure\_defender\_resources](#input\_sharedsvcs\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "VirtualMachines",<br>  "AppServices",<br>  "ContainerRegistry",<br>  "KeyVaults",<br>  "KubernetesService",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns"<br>]</pre> | no |
| <a name="input_sharedsvcs_backup_deploy_private_dns_zone"></a> [sharedsvcs\_backup\_deploy\_private\_dns\_zone](#input\_sharedsvcs\_backup\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the backup private endpoint. | `bool` | `false` | no |
| <a name="input_sharedsvcs_bastion_nsg_flow_log_postfix"></a> [sharedsvcs\_bastion\_nsg\_flow\_log\_postfix](#input\_sharedsvcs\_bastion\_nsg\_flow\_log\_postfix) | (Required) postfix name for the bastion NSG flow log | `any` | n/a | yes |
| <a name="input_sharedsvcs_bastion_sub_address_prefix"></a> [sharedsvcs\_bastion\_sub\_address\_prefix](#input\_sharedsvcs\_bastion\_sub\_address\_prefix) | (Required) The address prefix for the bastion subnet. | `list(string)` | n/a | yes |
| <a name="input_sharedsvcs_bigfix_vm_computer_name"></a> [sharedsvcs\_bigfix\_vm\_computer\_name](#input\_sharedsvcs\_bigfix\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    admin_username   = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_bigfix_vm_computer_name_admin_username"></a> [sharedsvcs\_bigfix\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_bigfix\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_bigfix_vm_data_disk_size"></a> [sharedsvcs\_bigfix\_vm\_data\_disk\_size](#input\_sharedsvcs\_bigfix\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_bigfix_vm_image_id"></a> [sharedsvcs\_bigfix\_vm\_image\_id](#input\_sharedsvcs\_bigfix\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_bigfix_vm_logging_disk_size"></a> [sharedsvcs\_bigfix\_vm\_logging\_disk\_size](#input\_sharedsvcs\_bigfix\_vm\_logging\_disk\_size) | (Required) size of managed logging disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_bigfix_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_bigfix\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_bigfix\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_bigfix_vm_os_disk_storage_account_type"></a> [sharedsvcs\_bigfix\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_bigfix\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_bigfix_vm_size"></a> [sharedsvcs\_bigfix\_vm\_size](#input\_sharedsvcs\_bigfix\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_core_sa_enabled"></a> [sharedsvcs\_core\_sa\_enabled](#input\_sharedsvcs\_core\_sa\_enabled) | (Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs. | `bool` | `true` | no |
| <a name="input_sharedsvcs_cribl_computer_names"></a> [sharedsvcs\_cribl\_computer\_names](#input\_sharedsvcs\_cribl\_computer\_names) | (Optional): Custom os computer names to give to the VMs. | `list(string)` | `null` | no |
| <a name="input_sharedsvcs_cribl_local_user"></a> [sharedsvcs\_cribl\_local\_user](#input\_sharedsvcs\_cribl\_local\_user) | (Required) The local admin username for cribl VM | `string` | n/a | yes |
| <a name="input_sharedsvcs_cribl_network_interface_count"></a> [sharedsvcs\_cribl\_network\_interface\_count](#input\_sharedsvcs\_cribl\_network\_interface\_count) | (Required) The count for cribl VMs | `number` | `1` | no |
| <a name="input_sharedsvcs_cribl_vm_enable_log_analytics_settings"></a> [sharedsvcs\_cribl\_vm\_enable\_log\_analytics\_settings](#input\_sharedsvcs\_cribl\_vm\_enable\_log\_analytics\_settings) | (Required) Enable log analytics extension for cribl VMs | `bool` | `false` | no |
| <a name="input_sharedsvcs_cribl_vm_names"></a> [sharedsvcs\_cribl\_vm\_names](#input\_sharedsvcs\_cribl\_vm\_names) | (Optional): Custom names to give to the VMs. | `list(string)` | `null` | no |
| <a name="input_sharedsvcs_cribl_vm_timezone"></a> [sharedsvcs\_cribl\_vm\_timezone](#input\_sharedsvcs\_cribl\_vm\_timezone) | (Required) The ihub\_pa\_vm\_timezone of the vms. Required if OS = Windows | `string` | `"UTC"` | no |
| <a name="input_sharedsvcs_deploy_availability_set"></a> [sharedsvcs\_deploy\_availability\_set](#input\_sharedsvcs\_deploy\_availability\_set) | (Optional) Set to true if windows VM needs avail set. | `bool` | `false` | no |
| <a name="input_sharedsvcs_deploy_avd_peering"></a> [sharedsvcs\_deploy\_avd\_peering](#input\_sharedsvcs\_deploy\_avd\_peering) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_bigfix"></a> [sharedsvcs\_deploy\_bigfix](#input\_sharedsvcs\_deploy\_bigfix) | (Optional) deploy bigfix true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_cross_vnet_global_peering_ss_dr_idty_prod"></a> [sharedsvcs\_deploy\_cross\_vnet\_global\_peering\_ss\_dr\_idty\_prod](#input\_sharedsvcs\_deploy\_cross\_vnet\_global\_peering\_ss\_dr\_idty\_prod) | Set to true to enable global vnet peering. | `bool` | n/a | yes |
| <a name="input_sharedsvcs_deploy_cross_vnet_global_peering_ss_prod_idty_dr"></a> [sharedsvcs\_deploy\_cross\_vnet\_global\_peering\_ss\_prod\_idty\_dr](#input\_sharedsvcs\_deploy\_cross\_vnet\_global\_peering\_ss\_prod\_idty\_dr) | Set to true to enable global vnet peering. | `bool` | n/a | yes |
| <a name="input_sharedsvcs_deploy_dr_ss_to_prod_ss_peering"></a> [sharedsvcs\_deploy\_dr\_ss\_to\_prod\_ss\_peering](#input\_sharedsvcs\_deploy\_dr\_ss\_to\_prod\_ss\_peering) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_fileshare"></a> [sharedsvcs\_deploy\_fileshare](#input\_sharedsvcs\_deploy\_fileshare) | (Optional) deploy fileshare true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_forensic"></a> [sharedsvcs\_deploy\_forensic](#input\_sharedsvcs\_deploy\_forensic) | Forensic VM | `bool` | `false` | no |
| <a name="input_sharedsvcs_deploy_idty_peering"></a> [sharedsvcs\_deploy\_idty\_peering](#input\_sharedsvcs\_deploy\_idty\_peering) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_ihub_peering"></a> [sharedsvcs\_deploy\_ihub\_peering](#input\_sharedsvcs\_deploy\_ihub\_peering) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_ivantimgmt"></a> [sharedsvcs\_deploy\_ivantimgmt](#input\_sharedsvcs\_deploy\_ivantimgmt) | (Optional) deploy ivanti mgmt true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_jumpserver"></a> [sharedsvcs\_deploy\_jumpserver](#input\_sharedsvcs\_deploy\_jumpserver) | (Optional) deploy jumpserver true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_kv_secrets"></a> [sharedsvcs\_deploy\_kv\_secrets](#input\_sharedsvcs\_deploy\_kv\_secrets) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management"></a> [sharedsvcs\_deploy\_management](#input\_sharedsvcs\_deploy\_management) | (Optional) deploy management true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_avd"></a> [sharedsvcs\_deploy\_management\_avd](#input\_sharedsvcs\_deploy\_management\_avd) | (Optional) deploy management\_avd true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_exchange"></a> [sharedsvcs\_deploy\_management\_exchange](#input\_sharedsvcs\_deploy\_management\_exchange) | (Optional) deploy management\_exchange true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_idty"></a> [sharedsvcs\_deploy\_management\_idty](#input\_sharedsvcs\_deploy\_management\_idty) | (Optional) deploy management\_idty true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_intune"></a> [sharedsvcs\_deploy\_management\_intune](#input\_sharedsvcs\_deploy\_management\_intune) | (Optional) deploy management\_intune true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_powerbi"></a> [sharedsvcs\_deploy\_management\_powerbi](#input\_sharedsvcs\_deploy\_management\_powerbi) | (Optional) deploy management\_powerbi true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_purview"></a> [sharedsvcs\_deploy\_management\_purview](#input\_sharedsvcs\_deploy\_management\_purview) | (Optional) deploy management\_purview true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_sharepoint"></a> [sharedsvcs\_deploy\_management\_sharepoint](#input\_sharedsvcs\_deploy\_management\_sharepoint) | (Optional) deploy management\_SP true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_management_teams"></a> [sharedsvcs\_deploy\_management\_teams](#input\_sharedsvcs\_deploy\_management\_teams) | (Optional) deploy management\_teams true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_pentest"></a> [sharedsvcs\_deploy\_pentest](#input\_sharedsvcs\_deploy\_pentest) | (Optional) deploy pentest true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_persvm"></a> [sharedsvcs\_deploy\_persvm](#input\_sharedsvcs\_deploy\_persvm) | (Optional) deploy persvm true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_private_link_subnet"></a> [sharedsvcs\_deploy\_private\_link\_subnet](#input\_sharedsvcs\_deploy\_private\_link\_subnet) | (Optional) A boolean to enable/disable the deployment of a private link subnet for the key vault. | `bool` | `false` | no |
| <a name="input_sharedsvcs_deploy_prod_ss_to_dr_ss_peering"></a> [sharedsvcs\_deploy\_prod\_ss\_to\_dr\_ss\_peering](#input\_sharedsvcs\_deploy\_prod\_ss\_to\_dr\_ss\_peering) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_secondary_private_link_subnet"></a> [sharedsvcs\_deploy\_secondary\_private\_link\_subnet](#input\_sharedsvcs\_deploy\_secondary\_private\_link\_subnet) | (Optional) Deploy secondary private link subnet. | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_sqlvm"></a> [sharedsvcs\_deploy\_sqlvm](#input\_sharedsvcs\_deploy\_sqlvm) | (Optional) deploy sqlvm true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_vm_password"></a> [sharedsvcs\_deploy\_vm\_password](#input\_sharedsvcs\_deploy\_vm\_password) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_deploy_wsus"></a> [sharedsvcs\_deploy\_wsus](#input\_sharedsvcs\_deploy\_wsus) | (Optional) deploy wsus true or false | `bool` | `true` | no |
| <a name="input_sharedsvcs_dr_to_ss_prod_peering_network_id"></a> [sharedsvcs\_dr\_to\_ss\_prod\_peering\_network\_id](#input\_sharedsvcs\_dr\_to\_ss\_prod\_peering\_network\_id) | identity dr resource string for peering connection | `string` | n/a | yes |
| <a name="input_sharedsvcs_enable_domain_join"></a> [sharedsvcs\_enable\_domain\_join](#input\_sharedsvcs\_enable\_domain\_join) | n/a | `bool` | `true` | no |
| <a name="input_sharedsvcs_fileshare_vm_admin_user"></a> [sharedsvcs\_fileshare\_vm\_admin\_user](#input\_sharedsvcs\_fileshare\_vm\_admin\_user) | (Required) The name of the windows OS admin. | `string` | n/a | yes |
| <a name="input_sharedsvcs_fileshare_vm_app_name"></a> [sharedsvcs\_fileshare\_vm\_app\_name](#input\_sharedsvcs\_fileshare\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `any` | n/a | yes |
| <a name="input_sharedsvcs_fileshare_vm_avail_zone"></a> [sharedsvcs\_fileshare\_vm\_avail\_zone](#input\_sharedsvcs\_fileshare\_vm\_avail\_zone) | (Optional) The availability zone of the windows vm. Options 1, 2 or 3. | `string` | `"1"` | no |
| <a name="input_sharedsvcs_fileshare_vm_computer_name"></a> [sharedsvcs\_fileshare\_vm\_computer\_name](#input\_sharedsvcs\_fileshare\_vm\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | n/a | yes |
| <a name="input_sharedsvcs_fileshare_vm_data_disk_size"></a> [sharedsvcs\_fileshare\_vm\_data\_disk\_size](#input\_sharedsvcs\_fileshare\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_fileshare_vm_image_id"></a> [sharedsvcs\_fileshare\_vm\_image\_id](#input\_sharedsvcs\_fileshare\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_fileshare_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_fileshare\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_fileshare\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_fileshare_vm_os_disk_storage_account_type"></a> [sharedsvcs\_fileshare\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_fileshare\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_fileshare_vm_private_ip"></a> [sharedsvcs\_fileshare\_vm\_private\_ip](#input\_sharedsvcs\_fileshare\_vm\_private\_ip) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_fileshare_vm_size"></a> [sharedsvcs\_fileshare\_vm\_size](#input\_sharedsvcs\_fileshare\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_forensic_vm_computer_name"></a> [sharedsvcs\_forensic\_vm\_computer\_name](#input\_sharedsvcs\_forensic\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    admin_username   = string<br>    private_ip       = string <br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_forensic_vm_computer_name_admin_username"></a> [sharedsvcs\_forensic\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_forensic\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_forensic_vm_image_id"></a> [sharedsvcs\_forensic\_vm\_image\_id](#input\_sharedsvcs\_forensic\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_forensic_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_forensic\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_forensic\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_forensic_vm_os_disk_storage_account_type"></a> [sharedsvcs\_forensic\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_forensic\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_forensic_vm_second_disk_size"></a> [sharedsvcs\_forensic\_vm\_second\_disk\_size](#input\_sharedsvcs\_forensic\_vm\_second\_disk\_size) | n/a | `string` | `""` | no |
| <a name="input_sharedsvcs_forensic_vm_size"></a> [sharedsvcs\_forensic\_vm\_size](#input\_sharedsvcs\_forensic\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_internal_cribl_lb_private_ip_address"></a> [sharedsvcs\_internal\_cribl\_lb\_private\_ip\_address](#input\_sharedsvcs\_internal\_cribl\_lb\_private\_ip\_address) | (Required) private IP of internal LB | `string` | n/a | yes |
| <a name="input_sharedsvcs_internal_lb_mgmt_probe_port"></a> [sharedsvcs\_internal\_lb\_mgmt\_probe\_port](#input\_sharedsvcs\_internal\_lb\_mgmt\_probe\_port) | (Required) Health probe port number for mgmt load balancer | `string` | `null` | no |
| <a name="input_sharedsvcs_internal_lb_personalization_probe_port"></a> [sharedsvcs\_internal\_lb\_personalization\_probe\_port](#input\_sharedsvcs\_internal\_lb\_personalization\_probe\_port) | (Required) Health probe port number for personalization load balancer | `string` | `null` | no |
| <a name="input_sharedsvcs_internal_lb_private_ip_address"></a> [sharedsvcs\_internal\_lb\_private\_ip\_address](#input\_sharedsvcs\_internal\_lb\_private\_ip\_address) | (Required) private IP of internal LB | `list(string)` | n/a | yes |
| <a name="input_sharedsvcs_internal_lb_private_ip_address_allocation"></a> [sharedsvcs\_internal\_lb\_private\_ip\_address\_allocation](#input\_sharedsvcs\_internal\_lb\_private\_ip\_address\_allocation) | (Required) private IP allocation of internal LB | `string` | `"Static"` | no |
| <a name="input_sharedsvcs_internal_lb_probe_interval_in_seconds"></a> [sharedsvcs\_internal\_lb\_probe\_interval\_in\_seconds](#input\_sharedsvcs\_internal\_lb\_probe\_interval\_in\_seconds) | (Optional) Port on which the Probe queries the backend endpoint | `number` | `5` | no |
| <a name="input_sharedsvcs_internal_lb_probe_number_of_probes"></a> [sharedsvcs\_internal\_lb\_probe\_number\_of\_probes](#input\_sharedsvcs\_internal\_lb\_probe\_number\_of\_probes) | (Optional) The number of failed probe attempts after which the backend endpoint is removed from rotation. The default value is 2 | `number` | `2` | no |
| <a name="input_sharedsvcs_internal_lb_probe_protocol"></a> [sharedsvcs\_internal\_lb\_probe\_protocol](#input\_sharedsvcs\_internal\_lb\_probe\_protocol) | (Optional) Specifies the protocol of the end point | `string` | n/a | yes |
| <a name="input_sharedsvcs_internal_lb_probe_request_path"></a> [sharedsvcs\_internal\_lb\_probe\_request\_path](#input\_sharedsvcs\_internal\_lb\_probe\_request\_path) | (Optional) The URI used for requesting health status from the backend endpoint | `string` | `null` | no |
| <a name="input_sharedsvcs_internal_lb_rule_be_port"></a> [sharedsvcs\_internal\_lb\_rule\_be\_port](#input\_sharedsvcs\_internal\_lb\_rule\_be\_port) | (Required) The port used for internal connections on the endpoint | `string` | n/a | yes |
| <a name="input_sharedsvcs_internal_lb_rule_disable_outbound_snat"></a> [sharedsvcs\_internal\_lb\_rule\_disable\_outbound\_snat](#input\_sharedsvcs\_internal\_lb\_rule\_disable\_outbound\_snat) | (Optional) Load Balancer Rule to enable snat | `bool` | `false` | no |
| <a name="input_sharedsvcs_internal_lb_rule_enable_floating_ip"></a> [sharedsvcs\_internal\_lb\_rule\_enable\_floating\_ip](#input\_sharedsvcs\_internal\_lb\_rule\_enable\_floating\_ip) | (Optional) Load Balancer Rule to enable Floating IPs | `bool` | `true` | no |
| <a name="input_sharedsvcs_internal_lb_rule_enable_tcp_reset"></a> [sharedsvcs\_internal\_lb\_rule\_enable\_tcp\_reset](#input\_sharedsvcs\_internal\_lb\_rule\_enable\_tcp\_reset) | (Optional) Load Balancer Rule to enable TCP Reset | `bool` | `false` | no |
| <a name="input_sharedsvcs_internal_lb_rule_fe_port"></a> [sharedsvcs\_internal\_lb\_rule\_fe\_port](#input\_sharedsvcs\_internal\_lb\_rule\_fe\_port) | (Required) The port for the internal endpoint | `string` | n/a | yes |
| <a name="input_sharedsvcs_internal_lb_rule_idle_timeout_in_minutes"></a> [sharedsvcs\_internal\_lb\_rule\_idle\_timeout\_in\_minutes](#input\_sharedsvcs\_internal\_lb\_rule\_idle\_timeout\_in\_minutes) | (Optional) Specifies the idle timeout in minutes for TCP connections | `number` | `5` | no |
| <a name="input_sharedsvcs_internal_lb_rule_load_distribution"></a> [sharedsvcs\_internal\_lb\_rule\_load\_distribution](#input\_sharedsvcs\_internal\_lb\_rule\_load\_distribution) | (Optional) Specifies the load balancing distribution type to be used by the Load Balancer | `string` | `"SourceIPProtocol"` | no |
| <a name="input_sharedsvcs_internal_lb_rule_protocol"></a> [sharedsvcs\_internal\_lb\_rule\_protocol](#input\_sharedsvcs\_internal\_lb\_rule\_protocol) | (Required) The transport protocol for the internal endpoint | `string` | n/a | yes |
| <a name="input_sharedsvcs_internal_lb_sku"></a> [sharedsvcs\_internal\_lb\_sku](#input\_sharedsvcs\_internal\_lb\_sku) | (Optional) list of SKU's , every item of list is optional (default value Basic) | `string` | `"Standard"` | no |
| <a name="input_sharedsvcs_internal_lb_sql_probe_port"></a> [sharedsvcs\_internal\_lb\_sql\_probe\_port](#input\_sharedsvcs\_internal\_lb\_sql\_probe\_port) | (Required) Health probe port number for sql load balancer | `string` | `null` | no |
| <a name="input_sharedsvcs_internal_sql_lb_rule_be_port"></a> [sharedsvcs\_internal\_sql\_lb\_rule\_be\_port](#input\_sharedsvcs\_internal\_sql\_lb\_rule\_be\_port) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_internal_sql_lb_rule_fe_port"></a> [sharedsvcs\_internal\_sql\_lb\_rule\_fe\_port](#input\_sharedsvcs\_internal\_sql\_lb\_rule\_fe\_port) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_ivanti_int_lb_names"></a> [sharedsvcs\_ivanti\_int\_lb\_names](#input\_sharedsvcs\_ivanti\_int\_lb\_names) | n/a | `list` | <pre>[<br>  "mgmt",<br>  "personalization",<br>  "sql"<br>]</pre> | no |
| <a name="input_sharedsvcs_ivanti_internal_load_balancer_count"></a> [sharedsvcs\_ivanti\_internal\_load\_balancer\_count](#input\_sharedsvcs\_ivanti\_internal\_load\_balancer\_count) | n/a | `number` | `3` | no |
| <a name="input_sharedsvcs_ivanti_sub_address_prefix"></a> [sharedsvcs\_ivanti\_sub\_address\_prefix](#input\_sharedsvcs\_ivanti\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `list(string)` | n/a | yes |
| <a name="input_sharedsvcs_ivanti_subnet_service_endpoints"></a> [sharedsvcs\_ivanti\_subnet\_service\_endpoints](#input\_sharedsvcs\_ivanti\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_sharedsvcs_jumpserver_vm_admin_user"></a> [sharedsvcs\_jumpserver\_vm\_admin\_user](#input\_sharedsvcs\_jumpserver\_vm\_admin\_user) | (Required) The name of the windows OS admin. | `string` | n/a | yes |
| <a name="input_sharedsvcs_jumpserver_vm_app_name"></a> [sharedsvcs\_jumpserver\_vm\_app\_name](#input\_sharedsvcs\_jumpserver\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `any` | n/a | yes |
| <a name="input_sharedsvcs_jumpserver_vm_avail_zone"></a> [sharedsvcs\_jumpserver\_vm\_avail\_zone](#input\_sharedsvcs\_jumpserver\_vm\_avail\_zone) | (Optional) The availability zone of the windows vm. Options 1, 2 or 3. | `string` | `"1"` | no |
| <a name="input_sharedsvcs_jumpserver_vm_computer_name"></a> [sharedsvcs\_jumpserver\_vm\_computer\_name](#input\_sharedsvcs\_jumpserver\_vm\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | n/a | yes |
| <a name="input_sharedsvcs_jumpserver_vm_data_disk_size"></a> [sharedsvcs\_jumpserver\_vm\_data\_disk\_size](#input\_sharedsvcs\_jumpserver\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_jumpserver_vm_image_id"></a> [sharedsvcs\_jumpserver\_vm\_image\_id](#input\_sharedsvcs\_jumpserver\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_jumpserver_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_jumpserver\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_jumpserver\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_jumpserver_vm_os_disk_storage_account_type"></a> [sharedsvcs\_jumpserver\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_jumpserver\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_jumpserver_vm_private_ip"></a> [sharedsvcs\_jumpserver\_vm\_private\_ip](#input\_sharedsvcs\_jumpserver\_vm\_private\_ip) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_jumpserver_vm_size"></a> [sharedsvcs\_jumpserver\_vm\_size](#input\_sharedsvcs\_jumpserver\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_keyvault_allowed_pe_subnet_ids"></a> [sharedsvcs\_keyvault\_allowed\_pe\_subnet\_ids](#input\_sharedsvcs\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_sharedsvcs_keyvault_az_svcs_bypass"></a> [sharedsvcs\_keyvault\_az\_svcs\_bypass](#input\_sharedsvcs\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_sharedsvcs_keyvault_deploy_private_dns_zone"></a> [sharedsvcs\_keyvault\_deploy\_private\_dns\_zone](#input\_sharedsvcs\_keyvault\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the key vault private endpoint. | `bool` | `false` | no |
| <a name="input_sharedsvcs_keyvault_diagnostics"></a> [sharedsvcs\_keyvault\_diagnostics](#input\_sharedsvcs\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_sharedsvcs_keyvault_enable"></a> [sharedsvcs\_keyvault\_enable](#input\_sharedsvcs\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `false` | no |
| <a name="input_sharedsvcs_keyvault_enabled_for_deployment"></a> [sharedsvcs\_keyvault\_enabled\_for\_deployment](#input\_sharedsvcs\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_sharedsvcs_keyvault_enabled_for_disk_encryption"></a> [sharedsvcs\_keyvault\_enabled\_for\_disk\_encryption](#input\_sharedsvcs\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_sharedsvcs_keyvault_enabled_for_template_deployment"></a> [sharedsvcs\_keyvault\_enabled\_for\_template\_deployment](#input\_sharedsvcs\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_sharedsvcs_keyvault_log_analytics_solutions"></a> [sharedsvcs\_keyvault\_log\_analytics\_solutions](#input\_sharedsvcs\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_sharedsvcs_keyvault_nacl_allowed_ips"></a> [sharedsvcs\_keyvault\_nacl\_allowed\_ips](#input\_sharedsvcs\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_sharedsvcs_keyvault_nacl_allowed_subnets"></a> [sharedsvcs\_keyvault\_nacl\_allowed\_subnets](#input\_sharedsvcs\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_sharedsvcs_keyvault_nacl_default_action"></a> [sharedsvcs\_keyvault\_nacl\_default\_action](#input\_sharedsvcs\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_sharedsvcs_keyvault_purge_protection_enabled"></a> [sharedsvcs\_keyvault\_purge\_protection\_enabled](#input\_sharedsvcs\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_sharedsvcs_keyvault_sku_name"></a> [sharedsvcs\_keyvault\_sku\_name](#input\_sharedsvcs\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_sharedsvcs_load_balancer_diagnostics"></a> [sharedsvcs\_load\_balancer\_diagnostics](#input\_sharedsvcs\_load\_balancer\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_sharedsvcs_log_analytics_supported"></a> [sharedsvcs\_log\_analytics\_supported](#input\_sharedsvcs\_log\_analytics\_supported) | (Optional) Set to true if log analytics workspace is supported in region. | `bool` | `true` | no |
| <a name="input_sharedsvcs_management_avd_vm_computer_name"></a> [sharedsvcs\_management\_avd\_vm\_computer\_name](#input\_sharedsvcs\_management\_avd\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    admin_username   = string<br>    private_ip       = string <br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_management_avd_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_avd\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_avd\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_avd_vm_image_id"></a> [sharedsvcs\_management\_avd\_vm\_image\_id](#input\_sharedsvcs\_management\_avd\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_avd_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_management\_avd\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_management\_avd\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_avd_vm_os_disk_storage_account_type"></a> [sharedsvcs\_management\_avd\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_management\_avd\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_management_avd_vm_size"></a> [sharedsvcs\_management\_avd\_vm\_size](#input\_sharedsvcs\_management\_avd\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_management_exchange_vm_computer_name"></a> [sharedsvcs\_management\_exchange\_vm\_computer\_name](#input\_sharedsvcs\_management\_exchange\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    admin_username   = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_management_exchange_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_exchange\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_exchange\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_exchange_vm_image_id"></a> [sharedsvcs\_management\_exchange\_vm\_image\_id](#input\_sharedsvcs\_management\_exchange\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_exchange_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_management\_exchange\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_management\_exchange\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_exchange_vm_os_disk_storage_account_type"></a> [sharedsvcs\_management\_exchange\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_management\_exchange\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_management_exchange_vm_size"></a> [sharedsvcs\_management\_exchange\_vm\_size](#input\_sharedsvcs\_management\_exchange\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_management_idty_vm_computer_name"></a> [sharedsvcs\_management\_idty\_vm\_computer\_name](#input\_sharedsvcs\_management\_idty\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string #(Required) The publisher of the solution<br>    resource_group_name   = string #(Required) The product name of the solution<br>    admin_username        = string<br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_management_idty_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_idty\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_idty\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_idty_vm_data_disk_size"></a> [sharedsvcs\_management\_idty\_vm\_data\_disk\_size](#input\_sharedsvcs\_management\_idty\_vm\_data\_disk\_size) | (Required) size of managed system disk. | `string` | `"60"` | no |
| <a name="input_sharedsvcs_management_idty_vm_image_id"></a> [sharedsvcs\_management\_idty\_vm\_image\_id](#input\_sharedsvcs\_management\_idty\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_idty_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_management\_idty\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_management\_idty\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_idty_vm_os_disk_storage_account_type"></a> [sharedsvcs\_management\_idty\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_management\_idty\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_management_idty_vm_size"></a> [sharedsvcs\_management\_idty\_vm\_size](#input\_sharedsvcs\_management\_idty\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_management_intune_vm_computer_name"></a> [sharedsvcs\_management\_intune\_vm\_computer\_name](#input\_sharedsvcs\_management\_intune\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string #(Required) The publisher of the solution<br>    admin_username   = string #(Required) The product name of the solution<br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_management_intune_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_intune\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_intune\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_intune_vm_image_id"></a> [sharedsvcs\_management\_intune\_vm\_image\_id](#input\_sharedsvcs\_management\_intune\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_intune_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_management\_intune\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_management\_intune\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_intune_vm_os_disk_storage_account_type"></a> [sharedsvcs\_management\_intune\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_management\_intune\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_management_intune_vm_size"></a> [sharedsvcs\_management\_intune\_vm\_size](#input\_sharedsvcs\_management\_intune\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_management_m365_vm_computer_name"></a> [sharedsvcs\_management\_m365\_vm\_computer\_name](#input\_sharedsvcs\_management\_m365\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string #(Required) The publisher of the solution<br>    resource_group_name   = string #(Required) The product name of the solution<br>    admin_username        = string<br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_management_m365_vm_image_id"></a> [sharedsvcs\_management\_m365\_vm\_image\_id](#input\_sharedsvcs\_management\_m365\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_m365_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_management\_m365\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_management\_m365\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_m365_vm_os_disk_storage_account_type"></a> [sharedsvcs\_management\_m365\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_management\_m365\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_management_m365_vm_size"></a> [sharedsvcs\_management\_m365\_vm\_size](#input\_sharedsvcs\_management\_m365\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_management_powerbi_vm_computer_name"></a> [sharedsvcs\_management\_powerbi\_vm\_computer\_name](#input\_sharedsvcs\_management\_powerbi\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    admin_username   = string<br>    private_ip       = string <br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_management_powerbi_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_powerbi\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_powerbi\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_powerbi_vm_image_id"></a> [sharedsvcs\_management\_powerbi\_vm\_image\_id](#input\_sharedsvcs\_management\_powerbi\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_powerbi_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_management\_powerbi\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_management\_powerbi\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_powerbi_vm_os_disk_storage_account_type"></a> [sharedsvcs\_management\_powerbi\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_management\_powerbi\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_management_powerbi_vm_size"></a> [sharedsvcs\_management\_powerbi\_vm\_size](#input\_sharedsvcs\_management\_powerbi\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_management_purview_vm_computer_name"></a> [sharedsvcs\_management\_purview\_vm\_computer\_name](#input\_sharedsvcs\_management\_purview\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    admin_username   = string <br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_management_purview_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_purview\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_purview\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_purview_vm_image_id"></a> [sharedsvcs\_management\_purview\_vm\_image\_id](#input\_sharedsvcs\_management\_purview\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_purview_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_management\_purview\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_management\_purview\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_management_purview_vm_os_disk_storage_account_type"></a> [sharedsvcs\_management\_purview\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_management\_purview\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_management_purview_vm_size"></a> [sharedsvcs\_management\_purview\_vm\_size](#input\_sharedsvcs\_management\_purview\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_management_sharepoint_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_sharepoint\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_sharepoint\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_teams_vm_computer_name_admin_username"></a> [sharedsvcs\_management\_teams\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_management\_teams\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_management_vm_name"></a> [sharedsvcs\_management\_vm\_name](#input\_sharedsvcs\_management\_vm\_name) | n/a | `string` | `""` | no |
| <a name="input_sharedsvcs_mgmt_sub_address_prefix"></a> [sharedsvcs\_mgmt\_sub\_address\_prefix](#input\_sharedsvcs\_mgmt\_sub\_address\_prefix) | (Required) The address prefix for the mgmt subnet. | `list(string)` | n/a | yes |
| <a name="input_sharedsvcs_mgmt_subnet_service_endpoints"></a> [sharedsvcs\_mgmt\_subnet\_service\_endpoints](#input\_sharedsvcs\_mgmt\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_sharedsvcs_mgmt_vm_availability_set_count"></a> [sharedsvcs\_mgmt\_vm\_availability\_set\_count](#input\_sharedsvcs\_mgmt\_vm\_availability\_set\_count) | n/a | `number` | `0` | no |
| <a name="input_sharedsvcs_mgmt_vm_computer_name"></a> [sharedsvcs\_mgmt\_vm\_computer\_name](#input\_sharedsvcs\_mgmt\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    admin_username   = string <br>    zone             = string<br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_mgmt_vm_computer_name_admin_username"></a> [sharedsvcs\_mgmt\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_mgmt\_vm\_computer\_name\_admin\_username) | IVANTI MGMT VM | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_mgmt_vm_image_id"></a> [sharedsvcs\_mgmt\_vm\_image\_id](#input\_sharedsvcs\_mgmt\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_mgmt_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_mgmt\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_mgmt\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_mgmt_vm_os_disk_storage_account_type"></a> [sharedsvcs\_mgmt\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_mgmt\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"Premium_LRS"` | no |
| <a name="input_sharedsvcs_mgmt_vm_size"></a> [sharedsvcs\_mgmt\_vm\_size](#input\_sharedsvcs\_mgmt\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_nsg_flow_log_postfix"></a> [sharedsvcs\_nsg\_flow\_log\_postfix](#input\_sharedsvcs\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | n/a | yes |
| <a name="input_sharedsvcs_nsg_sa_deploy_private_dns_zone"></a> [sharedsvcs\_nsg\_sa\_deploy\_private\_dns\_zone](#input\_sharedsvcs\_nsg\_sa\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the nsg sa private endpoint. | `bool` | `false` | no |
| <a name="input_sharedsvcs_pentest_vm_computer_name"></a> [sharedsvcs\_pentest\_vm\_computer\_name](#input\_sharedsvcs\_pentest\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    zone = string <br>    admin_username   = string<br>        private_ip       = string <br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_pentest_vm_computer_name_admin_username"></a> [sharedsvcs\_pentest\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_pentest\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_pentest_vm_image_id"></a> [sharedsvcs\_pentest\_vm\_image\_id](#input\_sharedsvcs\_pentest\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_pentest_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_pentest\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_pentest\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_pentest_vm_os_disk_storage_account_type"></a> [sharedsvcs\_pentest\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_pentest\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_pentest_vm_size"></a> [sharedsvcs\_pentest\_vm\_size](#input\_sharedsvcs\_pentest\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_personalization_vm_computer_name"></a> [sharedsvcs\_personalization\_vm\_computer\_name](#input\_sharedsvcs\_personalization\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>    admin_username   = string <br>    zone             = string<br>    private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_personalization_vm_computer_name_admin_username"></a> [sharedsvcs\_personalization\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_personalization\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_personalization_vm_image_id"></a> [sharedsvcs\_personalization\_vm\_image\_id](#input\_sharedsvcs\_personalization\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_personalization_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_personalization\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_personalization\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_personalization_vm_os_disk_storage_account_type"></a> [sharedsvcs\_personalization\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_personalization\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"Premium_LRS"` | no |
| <a name="input_sharedsvcs_personalization_vm_size"></a> [sharedsvcs\_personalization\_vm\_size](#input\_sharedsvcs\_personalization\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_sharedsvcs_private_dns_zone_id_map"></a> [sharedsvcs\_private\_dns\_zone\_id\_map](#input\_sharedsvcs\_private\_dns\_zone\_id\_map) | (Required) centralized private dns zone id map for log analytics workspace | `list(string)` | `[]` | no |
| <a name="input_sharedsvcs_private_link_seondary_subnet_address_prefixes"></a> [sharedsvcs\_private\_link\_seondary\_subnet\_address\_prefixes](#input\_sharedsvcs\_private\_link\_seondary\_subnet\_address\_prefixes) | (Optional) The address prefixes for the subnet of key vault. | `list(string)` | `[]` | no |
| <a name="input_sharedsvcs_private_link_subnet_address_prefixes"></a> [sharedsvcs\_private\_link\_subnet\_address\_prefixes](#input\_sharedsvcs\_private\_link\_subnet\_address\_prefixes) | (Optional) The address prefixes for the subnet of key vault. | `list(string)` | `[]` | no |
| <a name="input_sharedsvcs_private_link_subnet_enforce_endpoint_network_policies"></a> [sharedsvcs\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_sharedsvcs\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Optional) | `bool` | `true` | no |
| <a name="input_sharedsvcs_private_link_subnet_service_endpoints"></a> [sharedsvcs\_private\_link\_subnet\_service\_endpoints](#input\_sharedsvcs\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_sharedsvcs_prod_to_ss_dr_peering_network_id"></a> [sharedsvcs\_prod\_to\_ss\_dr\_peering\_network\_id](#input\_sharedsvcs\_prod\_to\_ss\_dr\_peering\_network\_id) | identity dr resource string for peering connection | `string` | n/a | yes |
| <a name="input_sharedsvcs_rg_security_enable"></a> [sharedsvcs\_rg\_security\_enable](#input\_sharedsvcs\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to sharedsvcs\_rg\_data | `bool` | `false` | no |
| <a name="input_sharedsvcs_route_table_disable_bgp_propagation"></a> [sharedsvcs\_route\_table\_disable\_bgp\_propagation](#input\_sharedsvcs\_route\_table\_disable\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `false` | no |
| <a name="input_sharedsvcs_sql_vm_computer_name"></a> [sharedsvcs\_sql\_vm\_computer\_name](#input\_sharedsvcs\_sql\_vm\_computer\_name) | (Optional) A plan block | <pre>map(object({<br>      enable_managed_disk_availability_zone  = bool<br>      availability_zone  = string<br>      vm_size            = string<br>      admin_username     = string<br>      private_ip       = string<br>  }))</pre> | `{}` | no |
| <a name="input_sharedsvcs_sql_vm_computer_name_admin_username"></a> [sharedsvcs\_sql\_vm\_computer\_name\_admin\_username](#input\_sharedsvcs\_sql\_vm\_computer\_name\_admin\_username) | n/a | `map(any)` | `{}` | no |
| <a name="input_sharedsvcs_sql_vm_data_disk1_size"></a> [sharedsvcs\_sql\_vm\_data\_disk1\_size](#input\_sharedsvcs\_sql\_vm\_data\_disk1\_size) | (Required) size of managed system disk. | `string` | `null` | no |
| <a name="input_sharedsvcs_sql_vm_data_disk2_size"></a> [sharedsvcs\_sql\_vm\_data\_disk2\_size](#input\_sharedsvcs\_sql\_vm\_data\_disk2\_size) | (Required) size of managed system disk. | `string` | `null` | no |
| <a name="input_sharedsvcs_sql_vm_data_disk3_size"></a> [sharedsvcs\_sql\_vm\_data\_disk3\_size](#input\_sharedsvcs\_sql\_vm\_data\_disk3\_size) | (Required) size of managed system disk. | `string` | `null` | no |
| <a name="input_sharedsvcs_sql_vm_data_disk4_size"></a> [sharedsvcs\_sql\_vm\_data\_disk4\_size](#input\_sharedsvcs\_sql\_vm\_data\_disk4\_size) | (Required) size of managed system disk. | `string` | `null` | no |
| <a name="input_sharedsvcs_sql_vm_image_id"></a> [sharedsvcs\_sql\_vm\_image\_id](#input\_sharedsvcs\_sql\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_sql_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_sql\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_sql\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of ops system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_sql_vm_os_disk_storage_account_type"></a> [sharedsvcs\_sql\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_sql\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"Premium_LRS"` | no |
| <a name="input_sharedsvcs_storage_account_file_share_access_tier"></a> [sharedsvcs\_storage\_account\_file\_share\_access\_tier](#input\_sharedsvcs\_storage\_account\_file\_share\_access\_tier) | n/a | `any` | `null` | no |
| <a name="input_sharedsvcs_storage_account_file_share_allowed_ips"></a> [sharedsvcs\_storage\_account\_file\_share\_allowed\_ips](#input\_sharedsvcs\_storage\_account\_file\_share\_allowed\_ips) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_storage_account_file_share_allowed_pe_subnet_ids"></a> [sharedsvcs\_storage\_account\_file\_share\_allowed\_pe\_subnet\_ids](#input\_sharedsvcs\_storage\_account\_file\_share\_allowed\_pe\_subnet\_ids) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_storage_account_file_share_allowed_vnet_subnet_ids"></a> [sharedsvcs\_storage\_account\_file\_share\_allowed\_vnet\_subnet\_ids](#input\_sharedsvcs\_storage\_account\_file\_share\_allowed\_vnet\_subnet\_ids) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_storage_account_file_shares"></a> [sharedsvcs\_storage\_account\_file\_shares](#input\_sharedsvcs\_storage\_account\_file\_shares) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_storage_account_kind"></a> [sharedsvcs\_storage\_account\_kind](#input\_sharedsvcs\_storage\_account\_kind) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_storage_account_private_dns_zone_file_ids"></a> [sharedsvcs\_storage\_account\_private\_dns\_zone\_file\_ids](#input\_sharedsvcs\_storage\_account\_private\_dns\_zone\_file\_ids) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_storage_account_tier"></a> [sharedsvcs\_storage\_account\_tier](#input\_sharedsvcs\_storage\_account\_tier) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_to_avd_peering_network_id"></a> [sharedsvcs\_to\_avd\_peering\_network\_id](#input\_sharedsvcs\_to\_avd\_peering\_network\_id) | avd resource string for peering connection | `string` | n/a | yes |
| <a name="input_sharedsvcs_to_idty_dr_peering_network_id"></a> [sharedsvcs\_to\_idty\_dr\_peering\_network\_id](#input\_sharedsvcs\_to\_idty\_dr\_peering\_network\_id) | idty dr resource string for peering connection | `string` | n/a | yes |
| <a name="input_sharedsvcs_to_idty_peering_network_id"></a> [sharedsvcs\_to\_idty\_peering\_network\_id](#input\_sharedsvcs\_to\_idty\_peering\_network\_id) | identity resource string for peering connection | `string` | n/a | yes |
| <a name="input_sharedsvcs_to_idty_prod_peering_network_id"></a> [sharedsvcs\_to\_idty\_prod\_peering\_network\_id](#input\_sharedsvcs\_to\_idty\_prod\_peering\_network\_id) | idty prod resource string for peering connection | `string` | n/a | yes |
| <a name="input_sharedsvcs_to_ihub_peering_network_id"></a> [sharedsvcs\_to\_ihub\_peering\_network\_id](#input\_sharedsvcs\_to\_ihub\_peering\_network\_id) | ihub resource string for peering connection | `string` | n/a | yes |
| <a name="input_sharedsvcs_vm_domain_name"></a> [sharedsvcs\_vm\_domain\_name](#input\_sharedsvcs\_vm\_domain\_name) | Shared VM Vars | `any` | n/a | yes |
| <a name="input_sharedsvcs_vm_domain_user_upn"></a> [sharedsvcs\_vm\_domain\_user\_upn](#input\_sharedsvcs\_vm\_domain\_user\_upn) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_vm_ou_path"></a> [sharedsvcs\_vm\_ou\_path](#input\_sharedsvcs\_vm\_ou\_path) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_vnet_address_space"></a> [sharedsvcs\_vnet\_address\_space](#input\_sharedsvcs\_vnet\_address\_space) | (Required) The address space for the virtual network. | `list(string)` | n/a | yes |
| <a name="input_sharedsvcs_vnet_dns_servers"></a> [sharedsvcs\_vnet\_dns\_servers](#input\_sharedsvcs\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_sharedsvcs_wsus_vm_admin_user"></a> [sharedsvcs\_wsus\_vm\_admin\_user](#input\_sharedsvcs\_wsus\_vm\_admin\_user) | (Required) The name of the windows OS admin. | `string` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_app_name"></a> [sharedsvcs\_wsus\_vm\_app\_name](#input\_sharedsvcs\_wsus\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `any` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_avail_zone"></a> [sharedsvcs\_wsus\_vm\_avail\_zone](#input\_sharedsvcs\_wsus\_vm\_avail\_zone) | (Optional) The availability zone of the windows vm. Options 1, 2 or 3. | `string` | `"1"` | no |
| <a name="input_sharedsvcs_wsus_vm_computer_name"></a> [sharedsvcs\_wsus\_vm\_computer\_name](#input\_sharedsvcs\_wsus\_vm\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_data_disk2_size"></a> [sharedsvcs\_wsus\_vm\_data\_disk2\_size](#input\_sharedsvcs\_wsus\_vm\_data\_disk2\_size) | (Required) size of managed data disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_data_disk_size"></a> [sharedsvcs\_wsus\_vm\_data\_disk\_size](#input\_sharedsvcs\_wsus\_vm\_data\_disk\_size) | (Required) size of managed data disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_image_id"></a> [sharedsvcs\_wsus\_vm\_image\_id](#input\_sharedsvcs\_wsus\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_os_disk_disk_size_gb"></a> [sharedsvcs\_wsus\_vm\_os\_disk\_disk\_size\_gb](#input\_sharedsvcs\_wsus\_vm\_os\_disk\_disk\_size\_gb) | (Required) size of managed system disk. | `any` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_os_disk_storage_account_type"></a> [sharedsvcs\_wsus\_vm\_os\_disk\_storage\_account\_type](#input\_sharedsvcs\_wsus\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"StandardSSD_LRS"` | no |
| <a name="input_sharedsvcs_wsus_vm_private_ip"></a> [sharedsvcs\_wsus\_vm\_private\_ip](#input\_sharedsvcs\_wsus\_vm\_private\_ip) | n/a | `any` | n/a | yes |
| <a name="input_sharedsvcs_wsus_vm_size"></a> [sharedsvcs\_wsus\_vm\_size](#input\_sharedsvcs\_wsus\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `null` | no |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  resource_name_no_dash    = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
  timeout_duration = "2h"
  sharedsvcs_cribl_vm_log_analytics_workspace_id   = var.sharedsvcs_alt_log_analytics_workspace ? var.sharedsvcs_alt_log_analytics_vm_workspace_id : module.cl_log_analytics_workspace[0].cl_log_analytics_workspace.workspace_id
  sharedsvcs_cribl_vm_log_analytics_workspace_key  = var.sharedsvcs_alt_log_analytics_workspace ? var.sharedsvcs_alt_log_analytics_workspace_primary_shared_key : module.cl_log_analytics_workspace[0].cl_log_analytics_workspace.primary_shared_key
  # KeyVault
  sharedsvcs_rg_keyvault_name             = var.sharedsvcs_keyvault_enable && var.sharedsvcs_rg_security_enable ?  azurerm_resource_group.sharedsvcs_rg_security[0].name  : azurerm_resource_group.sharedsvcs_rg_data.name
  sharedsvcs_private_link_subnet          = var.sharedsvcs_deploy_private_link_subnet ? [azurerm_subnet.sharedsvcs_private_link_subnet[0].id]              : var.sharedsvcs_keyvault_allowed_pe_subnet_ids
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_peering-sharedsvc-to-ihub"></a> [peering-sharedsvc-to-ihub](#output\_peering-sharedsvc-to-ihub) | n/a |
| <a name="output_sharedsvc_rg_cribl"></a> [sharedsvc\_rg\_cribl](#output\_sharedsvc\_rg\_cribl) | n/a |
| <a name="output_sharedsvcs_azure_bastion"></a> [sharedsvcs\_azure\_bastion](#output\_sharedsvcs\_azure\_bastion) | n/a |
| <a name="output_sharedsvcs_backup"></a> [sharedsvcs\_backup](#output\_sharedsvcs\_backup) | n/a |
| <a name="output_sharedsvcs_bigfix_rg"></a> [sharedsvcs\_bigfix\_rg](#output\_sharedsvcs\_bigfix\_rg) | n/a |
| <a name="output_sharedsvcs_bigfix_vm"></a> [sharedsvcs\_bigfix\_vm](#output\_sharedsvcs\_bigfix\_vm) | n/a |
| <a name="output_sharedsvcs_keyvault"></a> [sharedsvcs\_keyvault](#output\_sharedsvcs\_keyvault) | n/a |
| <a name="output_sharedsvcs_log_analytics_workspace"></a> [sharedsvcs\_log\_analytics\_workspace](#output\_sharedsvcs\_log\_analytics\_workspace) | n/a |
| <a name="output_sharedsvcs_mgmt_subnet"></a> [sharedsvcs\_mgmt\_subnet](#output\_sharedsvcs\_mgmt\_subnet) | n/a |
| <a name="output_sharedsvcs_mgmt_vm"></a> [sharedsvcs\_mgmt\_vm](#output\_sharedsvcs\_mgmt\_vm) | n/a |
| <a name="output_sharedsvcs_personalization_vm"></a> [sharedsvcs\_personalization\_vm](#output\_sharedsvcs\_personalization\_vm) | n/a |
| <a name="output_sharedsvcs_private_link_subnet"></a> [sharedsvcs\_private\_link\_subnet](#output\_sharedsvcs\_private\_link\_subnet) | n/a |
| <a name="output_sharedsvcs_rg_data"></a> [sharedsvcs\_rg\_data](#output\_sharedsvcs\_rg\_data) | n/a |
| <a name="output_sharedsvcs_rg_image_gallery"></a> [sharedsvcs\_rg\_image\_gallery](#output\_sharedsvcs\_rg\_image\_gallery) | n/a |
| <a name="output_sharedsvcs_rg_logging"></a> [sharedsvcs\_rg\_logging](#output\_sharedsvcs\_rg\_logging) | n/a |
| <a name="output_sharedsvcs_rg_network"></a> [sharedsvcs\_rg\_network](#output\_sharedsvcs\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_sharedsvcs_rg_security"></a> [sharedsvcs\_rg\_security](#output\_sharedsvcs\_rg\_security) | n/a |
| <a name="output_sharedsvcs_sql_vm"></a> [sharedsvcs\_sql\_vm](#output\_sharedsvcs\_sql\_vm) | n/a |
| <a name="output_sharedsvcs_storage_account"></a> [sharedsvcs\_storage\_account](#output\_sharedsvcs\_storage\_account) | n/a |
| <a name="output_sharedsvcs_vnet"></a> [sharedsvcs\_vnet](#output\_sharedsvcs\_vnet) | n/a |
| <a name="output_sharedsvcs_wsus_vm"></a> [sharedsvcs\_wsus\_vm](#output\_sharedsvcs\_wsus\_vm) | n/a |


## Usage

```terraform
// Deploy Gov Cloud Shared Services
//**********************************************************************************************
module "sharedsvcs_us_gov_ss" {
    source                          = "../dn-tads_tf-azure-component-library/core/core_us_gov_ss" #"../dn-tads_tf-azure-gov_component-library/core/core_us_gov_ss"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    hub_env                         = var.env
    suffix                          = var.suffix
    dns_location                    = var.dns_location
    tags                            = var.tags
    #Network
    sharedsvcs_vnet_address_space                                    = var.sharedsvcs_vnet_address_space
    sharedsvcs_vnet_dns_servers                                      = var.sharedsvcs_vnet_dns_servers
    sharedsvcs_mgmt_sub_address_prefix                               = var.sharedsvcs_mgmt_sub_address_prefix
    sharedsvcs_bastion_sub_address_prefix                            = var.sharedsvcs_bastion_sub_address_prefix
    sharedsvcs_ivanti_sub_address_prefix                             = var.sharedsvcs_ivanti_sub_address_prefix
    sharedsvcs_private_link_seondary_subnet_address_prefixes         = var.sharedsvcs_private_link_seondary_subnet_address_prefixes
    sharedsvcs_deploy_secondary_private_link_subnet                  = var.sharedsvcs_deploy_secondary_private_link_subnet
    sharedsvcs_azure_defender_resources                              = var.sharedsvcs_azure_defender_resources
    sharedsvcs_private_link_subnet_service_endpoints                 = var.sharedsvcs_private_link_subnet_service_endpoints
    sharedsvcs_to_idty_peering_network_id                            = var.sharedsvcs_to_idty_peering_network_id
    sharedsvcs_private_link_subnet_enforce_endpoint_network_policies = var.sharedsvcs_private_link_subnet_enforce_endpoint_network_policies
    sharedsvcs_deploy_private_link_subnet                            = var.sharedsvcs_deploy_private_link_subnet 
    sharedsvcs_private_link_subnet_address_prefixes                  = var.sharedsvcs_private_link_subnet_address_prefixes
    sharedsvcs_to_ihub_peering_network_id                            = var.sharedsvcs_to_ihub_peering_network_id
    sharedsvcs_to_avd_peering_network_id                             = var.sharedsvcs_to_avd_peering_network_id
    ihub_internal_lb_private_ip_address                              = var.ihub_internal_lb_private_ip_address
    sharedsvcs_nsg_flow_log_postfix                                  = var.sharedsvcs_nsg_flow_log_postfix
    sharedsvcs_bastion_nsg_flow_log_postfix                          = var.sharedsvcs_bastion_nsg_flow_log_postfix
    sharedsvcs_private_dns_zone_id_map                               = var.sharedsvcs_private_dns_zone_id_map
    sharedsvcs_deploy_cross_vnet_global_peering_ss_prod_idty_dr      = var.sharedsvcs_deploy_cross_vnet_global_peering_ss_prod_idty_dr
    sharedsvcs_deploy_cross_vnet_global_peering_ss_dr_idty_prod      = var.sharedsvcs_deploy_cross_vnet_global_peering_ss_dr_idty_prod
    sharedsvcs_to_idty_prod_peering_network_id                        = var.sharedsvcs_to_idty_prod_peering_network_id 
    sharedsvcs_to_idty_dr_peering_network_id                         = var.sharedsvcs_to_idty_dr_peering_network_id  
    sharedsvcs_deploy_avd_peering                                       = var.sharedsvcs_deploy_avd_peering 
    sharedsvcs_deploy_ihub_peering                                      = var.sharedsvcs_deploy_ihub_peering 
    sharedsvcs_deploy_idty_peering                                      = var.sharedsvcs_deploy_idty_peering
    sharedsvcs_deploy_prod_ss_to_dr_ss_peering                          = var.sharedsvcs_deploy_prod_ss_to_dr_ss_peering
    sharedsvcs_deploy_dr_ss_to_prod_ss_peering                          = var.sharedsvcs_deploy_dr_ss_to_prod_ss_peering
    sharedsvcs_prod_to_ss_dr_peering_network_id                         = var.sharedsvcs_prod_to_ss_dr_peering_network_id
    sharedsvcs_dr_to_ss_prod_peering_network_id                         = var.sharedsvcs_dr_to_ss_prod_peering_network_id
    sharedsvcs_backup_deploy_private_dns_zone                           = var.sharedsvcs_backup_deploy_private_dns_zone  
    sharedsvcs_keyvault_deploy_private_dns_zone                         = var.sharedsvcs_keyvault_deploy_private_dns_zone
    sharedsvcs_nsg_sa_deploy_private_dns_zone                           = var.sharedsvcs_nsg_sa_deploy_private_dns_zone 
    sharedsvcs_storage_account_file_share_allowed_pe_subnet_ids         = var.sharedsvcs_storage_account_file_share_allowed_pe_subnet_ids   
    sharedsvcs_storage_account_file_share_allowed_vnet_subnet_ids       = var.sharedsvcs_storage_account_file_share_allowed_vnet_subnet_ids
    sharedsvcs_storage_account_file_share_allowed_ips                   = var.sharedsvcs_storage_account_file_share_allowed_ips 
    sharedsvcs_deploy_management_teams                                  = var.sharedsvcs_deploy_management_teams
    sharedsvcs_deploy_management_sharepoint                             = var. sharedsvcs_deploy_management_sharepoint
    sharedsvcs_deploy_vm_password                                        = var.sharedsvcs_deploy_vm_password
    
    sharedsvcs_deploy_forensic                                  = var.sharedsvcs_deploy_forensic
    sharedsvcs_forensic_vm_computer_name_admin_username         = var.sharedsvcs_forensic_vm_computer_name_admin_username
    sharedsvcs_forensic_vm_computer_name                        = var.sharedsvcs_forensic_vm_computer_name
    sharedsvcs_forensic_vm_image_id                             = var.sharedsvcs_forensic_vm_image_id 
    sharedsvcs_forensic_vm_size                                 = var.sharedsvcs_forensic_vm_size
    sharedsvcs_forensic_vm_os_disk_disk_size_gb                 = var.sharedsvcs_forensic_vm_os_disk_disk_size_gb
    sharedsvcs_forensic_vm_second_disk_size                     = var.sharedsvcs_forensic_vm_second_disk_size     
    
    #KeyVault
    sharedsvcs_deploy_kv_secrets                                              = var.sharedsvcs_deploy_kv_secrets
    sharedsvcs_enable_domain_join                                             = var.sharedsvcs_enable_domain_join
    sharedsvcs_rg_security_enable                                             = var.sharedsvcs_rg_security_enable    
    sharedsvcs_keyvault_enable                                                = var. sharedsvcs_keyvault_enable 
    sharedsvcs_keyvault_nacl_allowed_subnets                                  = var.sharedsvcs_keyvault_nacl_allowed_subnets
    sharedsvcs_keyvault_nacl_allowed_ips                                      = var.sharedsvcs_keyvault_nacl_allowed_ips

    
    #KV Secrets
    sharedsvcs_bigfix_vm_computer_name_admin_username               = var.sharedsvcs_bigfix_vm_computer_name_admin_username
    sharedsvcs_management_intune_vm_computer_name_admin_username    = var.sharedsvcs_management_intune_vm_computer_name_admin_username
    sharedsvcs_management_exchange_vm_computer_name_admin_username  = var.sharedsvcs_management_exchange_vm_computer_name_admin_username
    sharedsvcs_management_powerbi_vm_computer_name_admin_username   = var.sharedsvcs_management_powerbi_vm_computer_name_admin_username
    sharedsvcs_management_avd_vm_computer_name_admin_username       = var.sharedsvcs_management_avd_vm_computer_name_admin_username
    sharedsvcs_management_purview_vm_computer_name_admin_username   = var.sharedsvcs_management_purview_vm_computer_name_admin_username
    sharedsvcs_management_idty_vm_computer_name_admin_username      = var.sharedsvcs_management_idty_vm_computer_name_admin_username
    sharedsvcs_mgmt_vm_computer_name_admin_username                 = var.sharedsvcs_mgmt_vm_computer_name_admin_username
    sharedsvcs_personalization_vm_computer_name_admin_username      = var.sharedsvcs_personalization_vm_computer_name_admin_username
    sharedsvcs_sql_vm_computer_name_admin_username                  = var.sharedsvcs_sql_vm_computer_name_admin_username
    sharedsvcs_management_sharepoint_vm_computer_name_admin_username  = var.sharedsvcs_management_sharepoint_vm_computer_name_admin_username
    sharedsvcs_management_teams_vm_computer_name_admin_username       = var.sharedsvcs_management_teams_vm_computer_name_admin_username

    sharedsvcs_log_analytics_supported              = var.sharedsvcs_log_analytics_supported 
    sharedsvcs_deploy_availability_set              = var.sharedsvcs_deploy_availability_set
    sharedsvcs_avail_zones_supported                = var.sharedsvcs_avail_zones_supported
    sharedsvcs_alt_log_analytics_workspace          = var.sharedsvcs_alt_log_analytics_workspace
    sharedsvcs_alt_log_analytics_workspace_name     = var.sharedsvcs_alt_log_analytics_workspace_name
    sharedsvcs_alt_log_analytics_workspace_id       = var.sharedsvcs_alt_log_analytics_workspace_id
    sharedsvcs_alt_log_analytics_vm_workspace_id    = var.sharedsvcs_alt_log_analytics_vm_workspace_id
    sharedsvcs_alt_log_analytics_workspace_primary_shared_key = var.sharedsvcs_alt_log_analytics_workspace_primary_shared_key

    #Ivanti
    sharedsvcs_ivanti_internal_load_balancer_count       = var.sharedsvcs_ivanti_internal_load_balancer_count
    sharedsvcs_internal_lb_private_ip_address            = var.sharedsvcs_internal_lb_private_ip_address
    sharedsvcs_internal_lb_probe_protocol                = var.sharedsvcs_internal_lb_probe_protocol
    sharedsvcs_internal_lb_mgmt_probe_port               = var.sharedsvcs_internal_lb_mgmt_probe_port
    sharedsvcs_internal_lb_personalization_probe_port    = var.sharedsvcs_internal_lb_personalization_probe_port
    sharedsvcs_internal_lb_sql_probe_port                = var.sharedsvcs_internal_lb_sql_probe_port
    sharedsvcs_internal_lb_rule_protocol                 = var.sharedsvcs_internal_lb_rule_protocol
    sharedsvcs_internal_lb_rule_fe_port                  = var.sharedsvcs_internal_lb_rule_fe_port
    sharedsvcs_internal_lb_rule_be_port                  = var.sharedsvcs_internal_lb_rule_be_port
    sharedsvcs_internal_sql_lb_rule_fe_port             = var.sharedsvcs_internal_sql_lb_rule_fe_port
    sharedsvcs_internal_sql_lb_rule_be_port             = var.sharedsvcs_internal_sql_lb_rule_be_port


    #bigFixVms
    sharedsvcs_deploy_bigfix                                             = var.sharedsvcs_deploy_bigfix
    sharedsvcs_bigfix_vm_computer_name                                  = var.sharedsvcs_bigfix_vm_computer_name //fix names
    sharedsvcs_bigfix_vm_image_id                                       = var.sharedsvcs_bigfix_vm_image_id
    sharedsvcs_bigfix_vm_size                                           = var.sharedsvcs_bigfix_vm_size
    sharedsvcs_bigfix_vm_os_disk_disk_size_gb                           = var.sharedsvcs_bigfix_vm_os_disk_disk_size_gb
    sharedsvcs_bigfix_vm_logging_disk_size                              = var.sharedsvcs_bigfix_vm_logging_disk_size
    sharedsvcs_bigfix_vm_data_disk_size                                 = var.sharedsvcs_bigfix_vm_data_disk_size

    #pentestVms
    sharedsvcs_deploy_pentest                                             = var.sharedsvcs_deploy_pentest
    sharedsvcs_pentest_vm_computer_name                                  = var.sharedsvcs_pentest_vm_computer_name //fix names
    sharedsvcs_pentest_vm_image_id                                       = var.sharedsvcs_pentest_vm_image_id
    sharedsvcs_pentest_vm_size                                           = var.sharedsvcs_pentest_vm_size
    sharedsvcs_pentest_vm_os_disk_disk_size_gb                           = var.sharedsvcs_pentest_vm_os_disk_disk_size_gb
    
    #MgmtVms
    sharedsvcs_deploy_management                                                 = var.sharedsvcs_deploy_management
    sharedsvcs_management_m365_vm_computer_name                                  = var.sharedsvcs_management_m365_vm_computer_name 
    sharedsvcs_management_m365_vm_image_id                                       = var.sharedsvcs_management_m365_vm_image_id
    sharedsvcs_management_m365_vm_size                                           = var.sharedsvcs_management_m365_vm_size
    sharedsvcs_management_m365_vm_os_disk_disk_size_gb                           = var.sharedsvcs_management_m365_vm_os_disk_disk_size_gb      
    
    sharedsvcs_deploy_management_idty                                            = var.sharedsvcs_deploy_management_idty
    sharedsvcs_management_idty_vm_computer_name                                  = var.sharedsvcs_management_idty_vm_computer_name 
    sharedsvcs_management_idty_vm_image_id                                       = var.sharedsvcs_management_idty_vm_image_id
    sharedsvcs_management_idty_vm_size                                           = var.sharedsvcs_management_idty_vm_size
    sharedsvcs_management_idty_vm_os_disk_disk_size_gb                           = var.sharedsvcs_management_idty_vm_os_disk_disk_size_gb
   
    
    sharedsvcs_deploy_management_purview                                        = var.sharedsvcs_deploy_management_purview
    sharedsvcs_management_purview_vm_computer_name                              = var.sharedsvcs_management_purview_vm_computer_name
    sharedsvcs_management_purview_vm_image_id                                   = var.sharedsvcs_management_purview_vm_image_id
    sharedsvcs_management_purview_vm_size                                       = var.sharedsvcs_management_purview_vm_size
    sharedsvcs_management_purview_vm_os_disk_disk_size_gb                       = var.sharedsvcs_management_purview_vm_os_disk_disk_size_gb 

    # # // powerbi Mgmt VMs
    sharedsvcs_deploy_management_powerbi                                        = var.sharedsvcs_deploy_management_powerbi
    sharedsvcs_management_powerbi_vm_computer_name                              = var.sharedsvcs_management_powerbi_vm_computer_name
    sharedsvcs_management_powerbi_vm_image_id                                   = var.sharedsvcs_management_powerbi_vm_image_id
    sharedsvcs_management_powerbi_vm_size                                       = var.sharedsvcs_management_powerbi_vm_size
    sharedsvcs_management_powerbi_vm_os_disk_disk_size_gb                       = var.sharedsvcs_management_powerbi_vm_os_disk_disk_size_gb 

    # # // avd Mgmt VMs
    sharedsvcs_deploy_management_avd                                        = var.sharedsvcs_deploy_management_avd
    sharedsvcs_management_avd_vm_computer_name                              = var.sharedsvcs_management_avd_vm_computer_name
    sharedsvcs_management_avd_vm_image_id                                   = var.sharedsvcs_management_avd_vm_image_id
    sharedsvcs_management_avd_vm_size                                       = var.sharedsvcs_management_avd_vm_size
    sharedsvcs_management_avd_vm_os_disk_disk_size_gb                       = var.sharedsvcs_management_avd_vm_os_disk_disk_size_gb 
    
    # # // exchange Mgmt VMs
    sharedsvcs_deploy_management_exchange                                   = var.sharedsvcs_deploy_management_exchange
    sharedsvcs_management_exchange_vm_computer_name                         = var.sharedsvcs_management_exchange_vm_computer_name
    sharedsvcs_management_exchange_vm_image_id                              = var.sharedsvcs_management_exchange_vm_image_id
    sharedsvcs_management_exchange_vm_size                                  = var.sharedsvcs_management_exchange_vm_size
    sharedsvcs_management_exchange_vm_os_disk_disk_size_gb                  = var.sharedsvcs_management_exchange_vm_os_disk_disk_size_gb

    # # // intune Mgmt VMs
    sharedsvcs_deploy_management_intune                                     = var.sharedsvcs_deploy_management_intune
    sharedsvcs_management_intune_vm_computer_name                           = var.sharedsvcs_management_intune_vm_computer_name
    sharedsvcs_management_intune_vm_image_id                                = var.sharedsvcs_management_intune_vm_image_id
    sharedsvcs_management_intune_vm_size                                    = var.sharedsvcs_management_intune_vm_size
    sharedsvcs_management_intune_vm_os_disk_disk_size_gb                    = var.sharedsvcs_management_intune_vm_os_disk_disk_size_gb


    #Ivanti Mgmt Vms
    sharedsvcs_deploy_ivantimgmt                                      = var.sharedsvcs_deploy_ivantimgmt
    sharedsvcs_mgmt_vm_computer_name                                  = var.sharedsvcs_mgmt_vm_computer_name
    sharedsvcs_mgmt_vm_image_id                                       = var.sharedsvcs_mgmt_vm_image_id
    sharedsvcs_mgmt_vm_size                                           = var.sharedsvcs_mgmt_vm_size
    sharedsvcs_mgmt_vm_os_disk_disk_size_gb                           = var.sharedsvcs_mgmt_vm_os_disk_disk_size_gb

    #personalization Vms
    sharedsvcs_deploy_persvm                                                     = var.sharedsvcs_deploy_persvm
    sharedsvcs_personalization_vm_computer_name                                  = var.sharedsvcs_personalization_vm_computer_name
    sharedsvcs_personalization_vm_image_id                                       = var.sharedsvcs_personalization_vm_image_id
    sharedsvcs_personalization_vm_size                                           = var.sharedsvcs_personalization_vm_size
    sharedsvcs_personalization_vm_os_disk_disk_size_gb                           = var.sharedsvcs_personalization_vm_os_disk_disk_size_gb

    #SQL Vms
    sharedsvcs_deploy_sqlvm                                          = var.sharedsvcs_deploy_sqlvm
    sharedsvcs_sql_vm_computer_name                                  = var.sharedsvcs_sql_vm_computer_name
    sharedsvcs_sql_vm_image_id                                       = var.sharedsvcs_sql_vm_image_id
    sharedsvcs_sql_vm_os_disk_disk_size_gb                           = var.sharedsvcs_sql_vm_os_disk_disk_size_gb
    sharedsvcs_sql_vm_data_disk1_size                                 = var.sharedsvcs_sql_vm_data_disk1_size
    sharedsvcs_sql_vm_data_disk2_size                                 = var.sharedsvcs_sql_vm_data_disk2_size
    sharedsvcs_sql_vm_data_disk3_size                                 = var.sharedsvcs_sql_vm_data_disk3_size
    sharedsvcs_sql_vm_data_disk4_size                                 = var.sharedsvcs_sql_vm_data_disk4_size
    
    #wsus Vms
    sharedsvcs_deploy_wsus                                            = var.sharedsvcs_deploy_wsus
    sharedsvcs_wsus_vm_computer_name                                  = var.sharedsvcs_wsus_vm_computer_name
    sharedsvcs_wsus_vm_app_name                                       = var.sharedsvcs_wsus_vm_app_name
    sharedsvcs_wsus_vm_image_id                                       = var.sharedsvcs_wsus_vm_image_id
    sharedsvcs_wsus_vm_size                                           = var.sharedsvcs_wsus_vm_size
    sharedsvcs_wsus_vm_admin_user                                     = var.sharedsvcs_wsus_vm_admin_user
    sharedsvcs_wsus_vm_os_disk_disk_size_gb                           = var.sharedsvcs_wsus_vm_os_disk_disk_size_gb
    sharedsvcs_wsus_vm_data_disk_size                                 = var.sharedsvcs_wsus_vm_data_disk_size
    sharedsvcs_wsus_vm_data_disk2_size                                = var.sharedsvcs_wsus_vm_data_disk2_size
    sharedsvcs_wsus_vm_private_ip                                     = var.sharedsvcs_wsus_vm_private_ip

    #jumpserver Vms
    sharedsvcs_deploy_jumpserver                                            = var.sharedsvcs_deploy_jumpserver
    sharedsvcs_jumpserver_vm_computer_name                                  = var.sharedsvcs_jumpserver_vm_computer_name
    sharedsvcs_jumpserver_vm_app_name                                       = var.sharedsvcs_jumpserver_vm_app_name
    sharedsvcs_jumpserver_vm_image_id                                       = var.sharedsvcs_jumpserver_vm_image_id
    sharedsvcs_jumpserver_vm_size                                           = var.sharedsvcs_jumpserver_vm_size
    sharedsvcs_jumpserver_vm_admin_user                                     = var.sharedsvcs_jumpserver_vm_admin_user
    sharedsvcs_jumpserver_vm_os_disk_disk_size_gb                           = var.sharedsvcs_jumpserver_vm_os_disk_disk_size_gb
    sharedsvcs_jumpserver_vm_data_disk_size                                 = var.sharedsvcs_jumpserver_vm_data_disk_size
    sharedsvcs_jumpserver_vm_private_ip                                     = var.sharedsvcs_jumpserver_vm_private_ip
    
    #shared vm vars
    sharedsvcs_vm_domain_name                                        = var.sharedsvcs_vm_domain_name
    sharedsvcs_vm_ou_path                                            = var.sharedsvcs_vm_ou_path
    sharedsvcs_vm_domain_user_upn                                    = var.sharedsvcs_vm_domain_user_upn
    sharedsvccs_vm_domain_password                                   = var.env == "nprd-pr" ? var.SHAREDSVCCS_VM_DOMAIN_PASSWORD_NONPROD : var.SHAREDSVCCS_VM_DOMAIN_PASSWORD_PROD

    #FileShare Vars
    sharedsvcs_deploy_fileshare                                      = var.sharedsvcs_deploy_fileshare
    sharedsvcs_storage_account_file_shares                           = var.sharedsvcs_storage_account_file_shares
    sharedsvcs_storage_account_tier                                  = var.sharedsvcs_storage_account_tier
    sharedsvcs_storage_account_kind                                  = var.sharedsvcs_storage_account_kind
    sharedsvcs_storage_account_private_dns_zone_file_ids             = var.sharedsvcs_storage_account_private_dns_zone_file_ids
    sharedsvcs_fileshare_vm_computer_name                            = var.sharedsvcs_fileshare_vm_computer_name
    sharedsvcs_fileshare_vm_app_name                                 = var.sharedsvcs_fileshare_vm_app_name
    sharedsvcs_fileshare_vm_image_id                                 = var.sharedsvcs_fileshare_vm_image_id
    sharedsvcs_fileshare_vm_size                                     = var.sharedsvcs_fileshare_vm_size
    sharedsvcs_fileshare_vm_admin_user                               = var.sharedsvcs_fileshare_vm_admin_user
    sharedsvcs_fileshare_vm_os_disk_disk_size_gb                     = var.sharedsvcs_fileshare_vm_os_disk_disk_size_gb
    sharedsvcs_fileshare_vm_data_disk_size                           = var.sharedsvcs_fileshare_vm_data_disk_size
    sharedsvcs_fileshare_vm_private_ip                               = var.sharedsvcs_fileshare_vm_private_ip

 #criblVms
        sharedsvcs_cribl_local_user                         = var.sharedsvcs_cribl_local_user
        sharedsvcs_cribl_network_interface_count            = var.sharedsvcs_cribl_network_interface_count
        cribl_worker_names                                  = var.cribl_worker_names
        cribl_master_names                                  = var.cribl_master_names
        cribl_master_private_ip_address_allocation          = var.cribl_master_private_ip_address_allocation
        cribl_worker_private_ip_address_allocation          = var.cribl_worker_private_ip_address_allocation
        cribl_backend_addesspool_associations_names         = var.cribl_backend_addesspool_associations_names
        sharedsvcs_internal_cribl_lb_private_ip_address    = var.sharedsvcs_internal_cribl_lb_private_ip_address
        cribl = {
            vm_size                 = var.cribl.vm_size
            vm_prefix               = var.cribl.vm_prefix
            vm_image_id             = var.cribl.vm_image_id
            vm_publisher            = var.cribl.vm_publisher
            vm_offer                = var.cribl.vm_offer
            vm_sku                  = var.cribl.vm_sku
            vm_version              = var.cribl.vm_version
            vm_storage_os_disk_size = var.cribl.vm_storage_os_disk_size
            vm_os                   = var.cribl.vm_os
            vm_from_marketplace     = var.cribl.vm_from_marketplace
            management_privateip    = var.cribl.management_privateip
        }
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
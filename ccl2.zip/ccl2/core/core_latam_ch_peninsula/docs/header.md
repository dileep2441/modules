# Core LATAM CH Peninsula

This is the LATAM Country Hosting Peninsula Core component for the LATAM CH Peninsula spoke. It establishes a baseline cloud environment where other components can be deployed into.
Specifically the core module lays the foundational infrastructure required to establish network connectivity  of the Azure cloud resources to the KPMG infrastructure.
This module deploys vnets, vnet peering, route tables, network gateways, key vault, log analytics workspace, security center, public IPs, etc.
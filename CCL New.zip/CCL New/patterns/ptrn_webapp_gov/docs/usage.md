

## Usage

```terraform
//1. Deploy Pattern
//**********************************************************************************************
module "ptrn_webapp" {
  source                                                       = "../dn-tads_tf-azure-component-library/patterns/ptrn_webapp_gov"
  env                                                          = var.env
  postfix                                                      = var.postfix
  location                                                     = var.location
  suffix                                                       = var.suffix
  tags                                                         = var.tags
  ptrn_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA       
  ptrn_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  ptrn_webapp_app_gateway_subnet_address_prefix                = ["60.0.1.0/24"]
  ptrn_webapp_set_private_ip_listener                          = true
  ptrn_webapp_app_gateway_rg                                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_network_rg                                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_vnet_id                                          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  ptrn_webapp_vnet_name                                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  ptrn_webapp_analytics_rg                                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  ptrn_webapp_service_log_analytics_workspace_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_webapp_log_analytics_workspace_name                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  ptrn_webapp_app_service_plan_integration_vnet_rg_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ptrn_webapp_app_service_plan_deploy_integration_subnet       = true
  ptrn_webapp_app_service_plan_integration_subnet_service_endpoints = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  ptrn_webapp_app_service_plan_integration_subnet_prefix       = ["60.0.2.0/24"]
  ptrn_webapp_app_service_app_postfix                          = "app1"
  ptrn_webapp_app_service_plan_app_postfix                     = "apppsfx"
  ptrn_webapp_app_service_plan_route_table_id                  = azurerm_route_table.routetable60.id
  ptrn_webapp_app_service_auth_settings_enabled                = false
  ptrn_webapp_azure_sql_server_resource_group_name             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_webapp_azure_sql_server_postfix                         = "global"
  ptrn_webapp_azure_sql_server_administrator                   = "xxxxxxx"
  ptrn_webapp_azure_sql_server_password                        = "xxxxxxx"
  ptrn_webapp_azure_sql_server_login_username                  = "xxxx@kpmg.com"
  ptrn_webapp_azure_sql_server_object_id                       = "xxxxxxxxxxxxxxx"
  ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = var.ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids
  ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = var.ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids
  ptrn_webapp_azure_sql_elastic_pool_enable                    = true # true deploy elastic pool module / false no deploy 
  ptrn_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_webapp_azure_sql_elastic_pool_enable in false dont send values for variable ptrn_webapp_azure_sql_database_sku
  ptrn_webapp_azure_sql_database_postfix                       = "globaldb"
  ptrn_webapp_endpoint_address_prefixes                        = ["60.0.3.0/24"]
  ptrn_webapp_app_storage_account_nsg_flow_log_id               = var.ptrn_webapp_app_storage_account_nsg_flow_log_id
  ptrn_webapp_app_gateway_nsg_flow_log_postfix                  = var.ptrn_webapp_app_gateway_nsg_flow_log_postfix
}
```
//2. Deploy Pattern with App Service single-container and ACR 
//**********************************************************************************************
```terraform

//Deploy Module ACR for single container App Servie
module "cl_azure_container_registry" {
    source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
     tags                                                         = var.tags
    cl_azure_container_registry_rg_name                         = module.ptrn_webapp.ptrn_webapp_service_rg
    cl_azure_container_registry_log_analytics_workspace_id      = var.cl_b2c_manager_core_log_analytics_workspace_id
    cl_azure_container_registry_allowed_vnet_ids                = [var.cl_b2c_manager_core_vnet_id]
    cl_azure_container_registry_content_trust_enabled           = false
    cl_azure_container_registry_admin_enabled                   = true
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
}

// Deploy Module ptrn webapp: Application Gateway, App Service Plan, App Service and Azure SQL

module "ptrn_webapp" {
  source                                                            = "../dn-tads_tf-azure-component-library/patterns/ptrn_webapp_gov"
  env                                                               = var.env
  postfix                                                           = var.postfix
  location                                                          = var.location
  suffix                                                            = var.suffix
  tags                                                              = var.tags
  ptrn_webapp_app_gateway_frontend_tls_cert                         = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA       
  ptrn_webapp_app_gateway_frontend_tls_cert_pass                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  ptrn_webapp_app_gateway_subnet_address_prefix                     = ["10.1.3.0/24"]
  ptrn_webapp_set_private_ip_listener                               = true
  ptrn_webapp_app_gateway_rg                                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_network_rg                                            = var.cl_b2c_manager_core_rg_network_name
  ptrn_webapp_vnet_id                                               = var.cl_b2c_manager_core_vnet_id
  ptrn_webapp_vnet_name                                             = var.cl_b2c_manager_core_vnet_name
  ptrn_webapp_analytics_rg                                          = var.cl_b2c_manager_core_rg_logging_name
  ptrn_webapp_service_log_analytics_workspace_id                    = var.cl_b2c_manager_core_log_analytics_workspace_id
  ptrn_webapp_log_analytics_workspace_name                          = var.cl_b2c_manager_core_log_analytics_workspace_name
  ptrn_webapp_app_service_plan_integration_vnet_rg_name             = var.cl_b2c_manager_core_rg_network_name
  ptrn_webapp_app_service_plan_deploy_integration_subnet            = true
  ptrn_webapp_app_service_plan_integration_subnet_service_endpoints = ["Microsoft.AzureActiveDirectory", "Microsoft.Sql", "Microsoft.Storage", "Microsoft.Web", "Microsoft.ContainerRegistry"]
  ptrn_webapp_app_service_plan_integration_subnet_prefix            = ["10.1.4.0/27"]
  ptrn_webapp_app_service_app_postfix                               = "b2cmanagement"
  ptrn_webapp_app_service_plan_app_postfix                          = "b2cmanager"
  ptrn_webapp_app_service_plan_route_table_id                       = var.cl_b2c_route_table_defatul_id
  ptrn_webapp_app_service_auth_settings_enabled                     = false
  ptrn_webapp_azure_sql_server_resource_group_name                  = module.ptrn_webapp.ptrn_webapp_service_rg
  ptrn_webapp_azure_sql_server_postfix                              = "b2cmanager"
  ptrn_webapp_azure_sql_server_administrator                        = "xxxxx"
  ptrn_webapp_azure_sql_server_password                             = "xxxxx"
  ptrn_webapp_azure_sql_server_login_username                  = "xxxx@kpmg.com"
  ptrn_webapp_azure_sql_server_object_id                       = "xxxxxxxxxxxxxxx"
  ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = var.ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids
  ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = var.ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids
  ptrn_webapp_azure_sql_elastic_pool_enable                    = true # true deploy elastic pool module / false no deploy 
  ptrn_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / variable ptrn_webapp_azure_sql_elastic_pool_enable in false dont send values for variable ptrn_webapp_azure_sql_database_sku
  ptrn_webapp_azure_sql_database_postfix                            = "b2cmanager"
  ptrn_webapp_endpoint_address_prefixes                             = ["10.1.5.0/24"]
  ptrn_webapp_app_storage_account_nsg_flow_log_id               = var.ptrn_webapp_app_storage_account_nsg_flow_log_id
  ptrn_webapp_app_gateway_nsg_flow_log_postfix                  = var.ptrn_webapp_app_gateway_nsg_flow_log_postfix
  ptrn_webapp_app_service_plan_os_type                              = "Windows"
  ptrn_webapp_app_service_plan_reserved                             = true
  ptrn_webapp_app_service_http2_enabled                             = true
  ptrn_webapp_app_service_use_32_bit_worker_process                 = true
  #ptrn_webapp_app_service_is_docker                                 = true
  #ptrn_webapp_app_service_acr_image                                 = "imagename:version" 
  #ptrn_webapp_app_service_acr_scm_type                              = "None"    
  ptrn_webapp_app_service_acr_login_server  = module.cl_azure_container_registry.cl_azure_container_registry.login_server
  ptrn_webapp_app_service_acr_username      = module.cl_azure_container_registry.cl_azure_container_registry_admin_username
  ptrn_webapp_app_service_acr_password      = module.cl_azure_container_registry.cl_azure_container_registry_admin_password
  ptrn_webapp_app_service_connection_strings = {
      connection_string = {
        name      = "sa_peninsula_connection"
        type      = "Custom"
        value     = var.cl_b2c_manager_app_service_connection_string_value
      }
    }
    }
```
```terraform
//3. Deploy Pattern with key vault to save Application Gateway certificates and Managed Identity asigned
//**********************************************************************************************
//Get the current client config
//***************************************************************************************************
data "azurerm_client_config" "current" {}

//Get the Principle(Object) Id of Application Gateway's Managed Identoty
//***************************************************************************************************
resource "azurerm_user_assigned_identity" "appgateway_keyvault_integration" {
  name                = "ptrn-iaas-webap-pappgwy-msi"
  location            = var.location
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
}

//Deploy Key vault
//Note: KeyVault Adminstrator role needs to be granted to SPN on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//Note:  KeyVault Secrets user/crypto user/certificates officer role needs to be granted to Application Gateway's Managed Identitity on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//***************************************************************************************************
module "cl_keyvault" {
  source                                   = "../dn-tads_tf-azure-component-library/components/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  suffix                                   = var.suffix
  tags                                     = var.tags
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_keyvault_nacl_allowed_ips             = ["199.206.0.0/15"]
  // ToDo: Remove app gateway subnet if dependency fails
  cl_keyvault_nacl_allowed_subnets         = [module.ptrn_webapp.ptrn_webapp_private_endpoint_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [module.ptrn_webapp.ptrn_webapp_private_endpoint_subnet.id]
}


//Add secrets/certificates to keyvault
//***************************************************************************************************
resource "azurerm_key_vault_certificate" "appgateway_cert" {
  name         = "ptrn-iaas-webapp-appgateway-cert"
  key_vault_id = module.cl_keyvault.cl_keyvault.id

  certificate {
    contents = filebase64(var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA)
    password = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  }

  certificate_policy {
    issuer_parameters {
      name = "Unknown"
    }

    key_properties {
      exportable = true
      key_size   = 2048
      key_type   = "RSA"
      reuse_key  = false
    }

    secret_properties {
      content_type = "application/x-pkcs12"
    }
  }
}

//Deploy webapp pattern 
//***************************************************************************************************
module "ptrn_webapp" {
  source                                                       = "../dn-tads_tf-azure-component-library/patterns/ptrn_webapp_gov"
  env                                                          = var.env
  postfix                                                      = var.postfix
  location                                                     = var.location
  suffix                                                       = var.suffix
  tags                                                         = var.tags
  ptrn_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA       
  ptrn_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  ptrn_webapp_app_gateway_subnet_address_prefix                = ["60.0.1.0/24"]
  ptrn_webapp_set_private_ip_listener                          = true
  ptrn_webapp_app_gateway_rg                                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_network_rg                                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_vnet_id                                          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  ptrn_webapp_vnet_name                                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  ptrn_webapp_analytics_rg                                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  ptrn_webapp_service_log_analytics_workspace_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_webapp_log_analytics_workspace_name                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  ptrn_webapp_app_service_plan_integration_vnet_rg_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ptrn_webapp_app_service_plan_deploy_integration_subnet       = true
  ptrn_webapp_app_service_plan_integration_subnet_service_endpoints = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web", "Microsoft.KeyVault"]
  ptrn_webapp_app_service_plan_integration_subnet_prefix       = ["60.0.2.0/24"]
  ptrn_webapp_app_service_app_postfix                          = "app1"
  ptrn_webapp_app_service_plan_app_postfix                     = "apppsfx"
  ptrn_webapp_app_service_plan_route_table_id                  = azurerm_route_table.routetable60.id
  ptrn_webapp_app_service_auth_settings_enabled                = false
  ptrn_webapp_azure_sql_server_resource_group_name             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_webapp_azure_sql_server_postfix                         = "global"
  ptrn_webapp_azure_sql_server_administrator                   = "xxxxxxx"
  ptrn_webapp_azure_sql_server_password                        = "xxxxxxx"
  ptrn_webapp_azure_sql_server_login_username                  = "xxxx@kpmg.com"
  ptrn_webapp_azure_sql_server_object_id                       = "xxxxxxxxxxxxxxx"
  ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = var.ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids
  ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = var.ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids
  ptrn_webapp_azure_sql_elastic_pool_enable                    = true # true deploy elastic pool module / false no deploy 
  ptrn_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_webapp_azure_sql_elastic_pool_enable in false dont send values for variable ptrn_webapp_azure_sql_database_sku
  ptrn_webapp_azure_sql_database_postfix                       = "globaldb"
  ptrn_webapp_endpoint_address_prefixes                        = ["60.0.3.0/24"]
  ptrn_webapp_app_storage_account_nsg_flow_log_id               = var.ptrn_webapp_app_storage_account_nsg_flow_log_id
  ptrn_webapp_app_gateway_nsg_flow_log_postfix                  = var.ptrn_webapp_app_gateway_nsg_flow_log_postfix
  ptrn_webapp_app_gateway_identity_ids                         = [azurerm_user_assigned_identity.appgateway_keyvault_integration.id]
  ptrn_webapp_app_gateway_frontend_tls_cert_keyvault_id        = azurerm_key_vault_certificate.appgateway_cert.secret_id
}
```
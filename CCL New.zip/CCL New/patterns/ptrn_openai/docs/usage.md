## Usage
```terraform
//**********************************************************************************************
module "core_openai_ptrn" {
    source                                                                              = "../dn-tads_tf-azure-component-library/patterns/ptrn_openai"
    env                                                                                 = var.env
    postfix                                                                             = var.postfix
    location                                                                            = var.location
    tags                                                                                = var.tags

# Container Registry
    ptrn_openai_deploy_container_registry                                               = true
    ptrn_openai_azure_container_registry_ip_rule_ranges                                 = var.ptrn_openai_azure_container_registry_ip_rule_ranges
    ptrn_openai_azure_container_registry_private_dns_zone_id                            = var.ptrn_openai_azure_container_registry_private_dns_zone_id
    ptrn_openai_azure_container_registry_allowed_vnet_ids                               = var.ptrn_openai_azure_container_registry_allowed_vnet_ids
    ptrn_openai_ptrn_privatelink_subnet                                                 = var.ptrn_openai_ptrn_privatelink_subnet
    ptrn_openai_core_log_analytics_workspace_resource_id                                = var.ptrn_openai_core_log_analytics_workspace_resource_id
    ptrn_openai_core_log_analytics_workspace_name                                       = var.ptrn_openai_core_log_analytics_workspace_name

# cognitive services
    ptrn_openai_cl_cognitive_services_openai                                            = var.ptrn_openai_cl_cognitive_services_openai
    ptrn_openai_cl_cognitive_services_deploy_rg                                         = true
    ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids                  = var.ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids
    ptrn_openai_cl_cognitive_services_nacl_allowed_subnets                              = var.ptrn_openai_cl_cognitive_services_nacl_allowed_subnets
    ptrn_openai_cl_cognitive_services_private_dns_zone_ids                              = var.ptrn_openai_cl_cognitive_services_private_dns_zone_ids
    ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges                           = var.ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges

# App service Plan
    ptrn_openai_app_service_plan_deploy_rg                                              = var.ptrn_openai_app_service_plan_deploy_rg
    ptrn_openai_app_service_plan_reserved                                               = var.ptrn_openai_app_service_plan_reserved
    ptrn_openai_app_service_plan_kind                                                   = var.ptrn_openai_app_service_plan_kind
    ptrn_openai_app_service_plan_deploy_integration_subnet                              = var.ptrn_openai_app_service_plan_deploy_integration_subnet
    ptrn_openai_core_rg_network_name                                                    = var.ptrn_openai_core_rg_network_name
    ptrn_openai_core_vnet_name                                                          = var.ptrn_openai_core_vnet_name
    ptrn_openai_app_service_plan_integration_subnet_prefix                              = var.ptrn_openai_app_service_plan_integration_subnet_prefix
    ptrn_openai_app_service_plan_route_table_id                                         = var.ptrn_openai_app_service_plan_route_table_id
    ptrn_openai_app_service_plan_sku_tier                                               = var.ptrn_openai_app_service_plan_sku_tier
    ptrn_openai_app_service_plan_sku_size                                               = var.ptrn_openai_app_service_plan_sku_size
    ptrn_openai_app_service_plan_sku_capacity                                           = var.ptrn_openai_app_service_plan_sku_capacity
    ptrn_openai_app_service_plan_app_postfix                                            = var.ptrn_openai_app_service_plan_app_postfix

# App Service 
    ptrn_openai_app_service                                                                 = var.ptrn_openai_app_service
    ptrn_openai_app_service_pe_subnet_ids                                                   = var.ptrn_openai_app_service_pe_subnet_ids
    ptrn_openai_app_service_settings                                                        = var.ptrn_openai_app_service_settings
    ptrn_openai_app_service_identity_identity_ids                                           = var.ptrn_openai_app_service_identity_identity_ids
    ptrn_openai_app_service_private_dns_zone_id                                             = var.ptrn_openai_app_service_private_dns_zone_id
    ptrn_openai_app_service_acr_login_server                                                = var.ptrn_openai_app_service_acr_login_server
    ptrn_openai_app_service_acr_username                                                    = var.ptrn_openai_app_service_acr_username
    ptrn_openai_app_service_acr_password                                                    = var.ptrn_openai_app_service_acr_password
    ptrn_openai_app_service_acr_image                                                       = var.ptrn_openai_app_service_acr_image
    ptrn_openai_app_service_acr_scm_type                                                    = var.ptrn_openai_app_service_acr_scm_type
    ptrn_openai_app_service_dns_server                                                      = var.ptrn_openai_app_service_dns_server
    ptrn_openai_app_service_vnet_route_server                                               = var.ptrn_openai_app_service_vnet_route_server
    ptrn_openai_app_service_auth_settings_default_provider                                  = var.ptrn_openai_app_service_auth_settings_default_provider

# App Gateway
    ptrn_openai_app_gateway_rg_name                                                         = var.ptrn_openai_app_gateway_rg_name
    ptrn_openai_core_rg_logging_name                                                        = var.ptrn_openai_core_rg_logging_name
    ptrn_openai_app_gateway_subnet_address_prefix                                           = var.ptrn_openai_app_gateway_subnet_address_prefix
    ptrn_openai_app_gateway_frontend_tls_cert                                                      = var.ptrn_openai_app_gateway_frontend_tls_cert
    ptrn_openai_app_gateway_frontend_tls_cert_pass                                                 = var.ptrn_openai_app_gateway_frontend_tls_cert_pass
    ptrn_openai_app_gateway_backend_address                                                        = var.ptrn_openai_app_gateway_backend_address
    ptrn_openai_app_gateway_backend_host_name                                                      = var.ptrn_openai_app_gateway_backend_host_name
    ptrn_openai_app_gateway_https_listener_hostname                                                = var.ptrn_openai_app_gateway_https_listener_hostname
    ptrn_openai_app_gateway_pick_host_name                                                         = var.ptrn_openai_app_gateway_pick_host_name
    ptrn_openai_app_gateway_pick_host_backend                                                      = var.ptrn_openai_app_gateway_pick_host_backend
      ptrn_openai_app_gateway_subnet_hostnum                                                       = var.ptrn_openai_app_gateway_subnet_hostnum
      ptrn_openai_app_gateway_min_capacity                                                         = var.ptrn_openai_app_gateway_min_capacity
      ptrn_openai_app_gateway_max_capacity                                                         = var.ptrn_openai_app_gateway_max_capacity
      ptrn_openai_app_gateway_probe_name                                                           = var.ptrn_openai_app_gateway_probe_name
      ptrn_openai_app_gateway_probe_host                                                           = var.ptrn_openai_app_gateway_probe_host
      ptrn_openai_app_gateway_probe_path                                                           = var.ptrn_openai_app_gateway_probe_path
      ptrn_openai_app_gateway_nsg_rules                                                            = var.ptrn_openai_app_gateway_nsg_rules
      ptrn_openai_app_gateway_probe_status_code                                                    = var.ptrn_openai_app_gateway_probe_status_code
      ptrn_openai_app_gateway_additional_backend_address_pool                                      = var.ptrn_openai_app_gateway_additional_backend_address_pool
      ptrn_openai_app_gateway_additional_http_settings                                             = var.ptrn_openai_app_gateway_additional_http_settings
      ptrn_openai_app_gateway_additional_http_listener                                             = var.ptrn_openai_app_gateway_additional_http_listener
      ptrn_openai_app_gateway_additional_route_rules                                               = var.ptrn_openai_app_gateway_additional_route_rules
      ptrn_openai_app_gateway_storage_account_nsg_flow_log_id                                      = var.ptrn_openai_app_gateway_storage_account_nsg_flow_log_id
      ptrn_openai_app_gateway_nsg_flow_log_postfix                                                 = var.ptrn_openai_app_gateway_nsg_flow_log_postfix

# SQL SERVER

  ptrn_openai_azure_sql_server_postfix                                                  = var.ptrn_openai_azure_sql_server_postfix
  ptrn_openai_azure_sql_server_resource_group_name                                      = var.ptrn_openai_azure_sql_server_resource_group_name
  ptrn_openai_azure_sql_server_administrator                                            = var.ptrn_openai_azure_sql_server_administrator
  ptrn_openai_azure_sql_server_password                                                 = var.ptrn_openai_azure_sql_server_password
  ptrn_openai_azure_sql_server_firewall_rules                                           = var.ptrn_openai_azure_sql_server_firewall_rules
  ptrn_openai_azure_sql_server_vnet_rules                                               = var.ptrn_openai_azure_sql_server_vnet_rules
  ptrn_openai_azure_sql_server_nacl_allowed_subnets                                     = var.ptrn_openai_azure_sql_server_nacl_allowed_subnets 

  ptrn_openai_azure_sql_server_storage_account_subnet_ids                               = var.ptrn_openai_azure_sql_server_storage_account_subnet_ids 
  ptrn_openai_azure_sql_server_storage_account_ip_rules                                 = var.ptrn_openai_azure_sql_server_storage_account_ip_rules


  ptrn_openai_azure_sql_server_azuread_login_username                                            = var.ptrn_openai_azure_sql_server_azuread_login_username      
  ptrn_openai_azure_sql_server_azuread_object_id                                                 = var.ptrn_openai_azure_sql_server_azuread_object_id
  ptrn_openai_azure_sql_server_private_dns_zone_ids                                              = var.ptrn_openai_azure_sql_server_private_dns_zone_ids
  ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids                                     = var.ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids 
  ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids                              = var.ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids

# TF STATE
  ptrn_openai_storage_account_postfix         = var.ptrn_openai_storage_account_postfix
  ptrn_openai_storage_account_env             = var.ptrn_openai_storage_account_env

# SQL DB
  ptrn_openai_azure_sql_database_postfix        = var.ptrn_openai_azure_sql_database_postfix
  ptrn_openai_azure_sql_database_sku            = var.ptrn_openai_azure_sql_database_sku
  ptrn_openai_azure_sql_server_id               = var.ptrn_openai_azure_sql_server_id
  ptrn_openai_azure_storage_account_endpoint             = var.ptrn_openai_azure_storage_account_endpoint
  ptrn_openai_azure_storage_account_access_key           = var.ptrn_openai_azure_storage_account_access_key
  ptrn_openai_azure_sql_database_elastic_pool_id         = var.ptrn_openai_azure_sql_database_elastic_pool_id

# SQL ELASTIC 
 ptrn_openai_azure_sql_elastic_pool_enable                     = var.ptrn_openai_azure_sql_elastic_pool_enable
 ptrn_openai_azure_sql_elastic_pool_postfix                    = var.ptrn_openai_azure_sql_elastic_pool_postfix 
 ptrn_openai_core_rg_data_name                                 = var.ptrn_openai_core_rg_data_name

# API MGMT
  ptrn_openai_core_route_table_id                    = var.ptrn_openai_core_route_table_id
  ptrn_openai_api_mgmt_subnet_vnet_rg_name           = var.ptrn_openai_api_mgmt_subnet_vnet_rg_name
  ptrn_openai_api_mgmt_subnet_vnet_name              = var.ptrn_openai_api_mgmt_subnet_vnet_name
  ptrn_openai_api_mgmt_subnet_prefix                 = var.ptrn_openai_api_mgmt_subnet_prefix  
  ptrn_openai_api_mgmt_publisher_name                = var.ptrn_openai_api_mgmt_publisher_name
  ptrn_openai_api_mgmt_publisher_email               = var.ptrn_openai_api_mgmt_publisher_email
  ptrn_openai_api_mgmt_inbound_cidrs                 = var.ptrn_openai_api_mgmt_inbound_cidrs 
  ptrn_openai_api_mgmt_proxies                       = var.ptrn_openai_api_mgmt_proxies 
  ptrn_openai_api_mgmt_developer_portals             = var.ptrn_openai_api_mgmt_developer_portals  
}
//**********************************************************************************************
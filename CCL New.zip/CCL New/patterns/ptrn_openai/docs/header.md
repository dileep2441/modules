# Azure Openai Pattern 

This is the Azure OpenAI Pattern. It'll deploy the following Components:
* Application Gateway & WAF
* App service Plan
* App services
* Azure Container Registry
* Azure SQL Database
* Azure SQL Server
* Azure SQL Elastic Pool
* cognitive services (AOAI)
* Storage account
* Redis Cache (regular and enterprise cluster)
* APIM
* App Insights

## Usage Deploy module Iaas WebApp Patterns

```Jenkis Pipeline
// Certificates
//***************************************************************************************************
1. Get the valid external certificate .pfx format for the WebApp Windows VM, this certificate is will using in the Application Gateway Frond-End and the application container in windows VM for example IIS.

2 Enter in the page https://base64encode.org, upload the certificate .pfx format in encode files to base64 format option, then select encode button and finally download the txt file.

3. In Jenkins pipeline project create the credentials kind secret text, one called JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT and paste the txt file encode information. create another secret text called JENKINS_APP_GATEWAY_FRONTEND_TLS_PASS and enter the certificate private key.

4. In component factory repository you need to guarantee in pattern/scripts the funcions.sh script, and you need to guarantee in pattern/script/pattern_main.sh in terraform pattern plan the following instruction: source ./scripts/functions.sh appgw_cert.

5. Upload the certificate -pfx format in the webapp container and asign the port 443 or protocol HTTPS.

6. Create the dns external and internal with the Application Gateway public ip. 

7. The same certificate en step 1 needs to be using in the Application Gateway and Winddows VM app container for example IIS. In the patter module usage you send the dns created with the subjet name certificate for the webapp in variable ptrn_iaas_webapp_app_gateway_backend_host_name and variable ptrn_iaas_webapp_app_gateway_http_listener_hostname .

```terraform
//1. Deploy module Iaas WebApp Pattern with backup, redis cache, bastion and elastic pool modules optional enable or desabled
//***************************************************************************************************
module "ptrn_iaas_webapp" {
source                                                            = "../tf-azure-component-library/patterns/ptrn_iaas_webapp"
env                                                               = var.env
postfix                                                           = var.postfix
location                                                          = var.location
ptrn_iaas_webapp_core_rg_network_name                             = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
ptrn_iaas_webapp_core_rg_vnet_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name 
ptrn_iaas_webapp_core_rg_logging_name                             = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
ptrn_iaas_webapp_core_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
ptrn_iaas_webapp_core_log_analytics_workspace_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
ptrn_iaas_webapp_core_rg_vnet_id                                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
ptrn_iaas_webapp_core_log_analytics_workspace_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.primary_shared_key
ptrn_iaas_webapp_core_route_table_id                              = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
ptrn_iaas_webapp_core_rg_data_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
ptrn_iaas_webapp_subnet_address_prefixes                          = ["60.0.1.0/24"]
ptrn_iaas_sql_subnet_address_prefixes                             = ["60.0.2.0/24"]
ptrn_iaas_webapp_app_gateway_subnet_address_prefix                = ["60.0.3.0/24"]
ptrn_iaas_webapp_app_gateway_subnet_service_endpoints             = ["Microsoft.Web"]
ptrn_iaas_webapp_set_private_ip_listener                          = true # true peninsula / false Island
ptrn_iaas_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS
ptrn_iaas_webapp_app_gateway_http_listener_hostname               = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_backend_host_name                    = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_pick_host_name                       = false
ptrn_iaas_webapp_app_gateway_pick_host_backend                    = true
ptrn_iaas_webapp_app_gateway_probe_path                           = "/"
ptrn_iaas_webapp_azure_bastion_enable                             = true # deploy required in peninsula / false in island
ptrn_iaas_webapp_azure_bastion_subnet_prefix                      = ["60.0.4.0/27"]
ptrn_iaas_webapp_windows_vm_deploy_rg                             = true
ptrn_iaas_webapp_windows_vm_enable_backup                         = true
ptrn_iaas_webapp_cl_windows_vm_image_id                           = "/subscriptions/9decc107-211f-4220-9559-6a29be4d2351/resourceGroups/rg-latamsbox-pr-sharedsvc-sharedimage/providers/Microsoft.Compute/galleries/sharedsvc_nprod_goldenimages/images/adds_golden_image"
ptrn_iaas_webapp_cl_windows_vm_app_name                           = "webappiaaspattern"
ptrn_iaas_webapp_cl_windows_computer_name                         = "webappvm1"
ptrn_iaas_webapp_cl_windows_vm_admin_user                         = "adminame"
ptrn_iaas_webapp_cl_windows_vm_admin_pass                         = "Abc1234567890."
ptrn_iaas_webapp_windows_vm_deploy_subnet_nsg                     = true
ptrn_iaas_webapp_windows_vm_enable_devops_agent                   = false
ptrn_iaas_webapp_azure_sql_server_postfix                         = "global"
ptrn_iaas_webapp_azure_sql_server_administrator                   = "sqladmin"
ptrn_iaas_webapp_azure_sql_server_password                        = "Portal123456!"
ptrn_iaas_webapp_azure_sql_server_storage_account_private_dns_zone_ids = [var.storage_account_private_dns_zone_ids ]
ptrn_iaas_webapp_azure_sql_database_postfix                       = "globaldb"
ptrn_iaas_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_iaas_webapp_azure_sql_elastic_pool_enable in false dont send values for variable sku ptrn_iaas_webapp_azure_sql_database_sku
ptrn_iaas_webapp_azure_sql_elastic_pool_enable                    = true # true deploy module / false not deploy module
ptrn_iaas_webapp_azure_sql_elastic_pool_postfix                   = "globaldb"
ptrn_iaas_webapp_redis_cache_enable                               = true # true deploy module / false not deploy module
ptrn_iaas_webapp_redis_cache_subnet_prefix                        = ["60.0.5.0/24"]
ptrn_iaas_webapp_redis_cache_postfix                              = "WebApp1"
}
//***************************************************************************************************
```

```terraform
//2. Deploy module Iaas WebApp Pattern with key vault to save Application Gateway certificates and Managed Identity asigned
//***************************************************************************************************
//Get the current client config
//***************************************************************************************************
data "azurerm_client_config" "current" {}

//Get the Principle(Object) Id of Application Gateway's Managed Identity
//***************************************************************************************************
resource "azurerm_user_assigned_identity" "appgateway_keyvault_integration" {
  name                = "ptrn-iaas-webap-pappgwy-msi"
  location            = var.location
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
}

//Deploy Key vault
//***************************************************************************************************
module "cl_keyvault" {
  source                                   = "../tf-azure-component-library/components/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_keyvault_private_dns_zone_ids         = [azurerm_private_dns_zone.azure_private_dns_zone_kv.id]
  cl_keyvault_nacl_allowed_ips             = ["199.206.0.0/15"]
  // ToDo: Remove app gateway subnet if dependency fails
  cl_keyvault_nacl_allowed_subnets         = [module.ptrn_iaas_webapp.ptrn_privatelink_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [module.ptrn_iaas_webapp.ptrn_privatelink_subnet .id]
}

resource "azurerm_private_dns_zone" "azure_private_dns_zone_kv" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "linkdnstosubnet_app_kv" {
  name                  = "linkkv"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.azure_private_dns_zone_kv.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}

//Access policy for Jenkins Service Principle
//***************************************************************************************************
resource "azurerm_key_vault_access_policy" "jenkins_spn" {
  key_vault_id = module.cl_keyvault.cl_keyvault.id
  tenant_id    = var.tenant_id
  object_id    = data.azurerm_client_config.current.object_id

  certificate_permissions = ["Get", "List", "Create", "Update", "Import", "GetIssuers", "ListIssuers", "SetIssuers"]
  key_permissions         = ["Get", "List", "Create", "Update"]
  secret_permissions      = ["Get", "List", "Set"]
  storage_permissions     = []
}

//Access policy for Application Gateway's Managed Identitity
//***************************************************************************************************
resource "azurerm_key_vault_access_policy" "appgateway_certificate" {
  key_vault_id = module.cl_keyvault.cl_keyvault.id
  tenant_id    = var.tenant_id
  object_id    = azurerm_user_assigned_identity.appgateway_keyvault_integration.principal_id

  certificate_permissions = ["Get", "List"]
  key_permissions         = ["Get", "List"]
  secret_permissions      = ["Get", "List"]
  storage_permissions     = []
}

//Add secrets/certificates to keyvault
//***************************************************************************************************
resource "azurerm_key_vault_certificate" "appgateway_cert" {
  name         = "ptrn-iaas-webapp-appgateway-cert"
  key_vault_id = module.cl_keyvault.cl_keyvault.id

  certificate {
    contents = filebase64(var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX)
    password = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS
  }

  certificate_policy {
    issuer_parameters {
      name = "Unknown"
    }

    key_properties {
      exportable = true
      key_size   = 2048
      key_type   = "RSA"
      reuse_key  = false
    }

    secret_properties {
      content_type = "application/x-pkcs12"
    }
  }
  depends_on = [azurerm_key_vault_access_policy.jenkins_spn]
}

//Deploy Iaas pattern webapp
//***************************************************************************************************
module "ptrn_iaas_webapp" {
source                                                            = "../tf-azure-component-library/patterns/ptrn_iaas_webapp"
env                                                               = var.env
postfix                                                           = var.postfix
location                                                          = var.location
ptrn_iaas_webapp_core_rg_network_name                             = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
ptrn_iaas_webapp_core_rg_vnet_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name 
ptrn_iaas_webapp_core_rg_logging_name                             = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
ptrn_iaas_webapp_core_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
ptrn_iaas_webapp_core_log_analytics_workspace_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
ptrn_iaas_webapp_core_rg_vnet_id                                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
ptrn_iaas_webapp_core_log_analytics_workspace_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.primary_shared_key
ptrn_iaas_webapp_core_route_table_id                              = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
ptrn_iaas_webapp_core_rg_data_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
ptrn_iaas_webapp_subnet_address_prefixes                          = ["60.0.1.0/24"]
ptrn_iaas_sql_subnet_address_prefixes                             = ["60.0.2.0/24"]
ptrn_iaas_webapp_app_gateway_subnet_address_prefix                = ["60.0.3.0/24"]
ptrn_iaas_webapp_app_gateway_subnet_service_endpoints             = ["Microsoft.Web"]
ptrn_iaas_webapp_set_private_ip_listener                          = true
ptrn_iaas_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS
ptrn_iaas_webapp_app_gateway_http_listener_hostname               = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_backend_host_name                    = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_pick_host_name                       = false
ptrn_iaas_webapp_app_gateway_pick_host_backend                    = true
ptrn_iaas_webapp_app_gateway_probe_path                           = "/"
ptrn_iaas_webapp_azure_bastion_enable                             = true
ptrn_iaas_webapp_azure_bastion_subnet_prefix                      = ["60.0.4.0/27"]
ptrn_iaas_webapp_windows_vm_enable_encryption_at_host_enabled     = false
ptrn_iaas_webapp_windows_vm_deploy_rg                             = true
ptrn_iaas_webapp_windows_vm_enable_backup                         = true
ptrn_iaas_webapp_cl_windows_vm_image_id                           = "/subscriptions/9decc107-211f-4220-9559-6a29be4d2351/resourceGroups/rg-latamsbox-pr-sharedsvc-sharedimage/providers/Microsoft.Compute/galleries/sharedsvc_nprod_goldenimages/images/adds_golden_image"
ptrn_iaas_webapp_cl_windows_vm_app_name                           = "webappiaaspattern"
ptrn_iaas_webapp_cl_windows_computer_name                         = "webappvm1"
ptrn_iaas_webapp_cl_windows_vm_admin_user                         = "adminame"
ptrn_iaas_webapp_cl_windows_vm_admin_pass                         = "Abc1234567890."
ptrn_iaas_webapp_windows_vm_deploy_subnet_nsg                     = true
ptrn_iaas_webapp_windows_vm_enable_devops_agent                   = false
ptrn_iaas_webapp_azure_sql_server_postfix                         = "global"
ptrn_iaas_webapp_azure_sql_server_administrator                   = "sqladmin"
ptrn_iaas_webapp_azure_sql_server_password                        = "Portal123456!"
ptrn_iaas_webapp_azure_sql_server_storage_account_private_dns_zone_ids = [var.storage_account_private_dns_zone_ids ]
ptrn_iaas_webapp_azure_sql_database_postfix                       = "globaldb"
ptrn_iaas_webapp_azure_sql_database_sku                           = "ElasticPool"
ptrn_iaas_webapp_azure_sql_elastic_pool_enable                    = true
ptrn_iaas_webapp_azure_sql_elastic_pool_postfix                   = "globaldb"
ptrn_iaas_webapp_redis_cache_enable                               = true
ptrn_iaas_webapp_redis_cache_subnet_prefix                        = ["60.0.5.0/24"]
ptrn_iaas_webapp_redis_cache_postfix                              = "WebApp1"
ptrn_iaas_webapp_windows_vm_identity_type                         = "SystemAssigned"
ptrn_iaas_webapp_app_gateway_identity_ids                         = [azurerm_user_assigned_identity.appgateway_keyvault_integration.id]
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_keyvault_id        = azurerm_key_vault_certificate.appgateway_cert.secret_id
}
//***************************************************************************************************
```
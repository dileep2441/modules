# Azure ETL Pattern

This is the Azure ETL pattern. It will deploy Azure Data Fabric, an ADLSv2 as storage, an Databricks Instance, a shared VNET for all components and a keyvault for store secrets.

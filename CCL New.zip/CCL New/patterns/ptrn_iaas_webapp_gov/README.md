<!-- BEGIN_TF_DOCS -->

# Iaas WebApp Patterns

The module Iaas WebApp Patterns was created in orde to integrate the differentes components for consume a web applicacion hosted in windows VM´s  with the security requirements, in the following pattern we will deploy an Application Gateway like front-end for external and internal webapp consumption, a windows VM to hosted the webap, an azure sql to save the webapp data. Azure Cache for Redis, SQL elastic pools and azure bastion are optional components in the Iaas pattern.  Azure bastion is only available to deploy in peninsula enviroments, also in case to desabled SQL elastic pools after being deployed is necessary to remove the databases from the elastic pool.





## Resources

| Name | Type |
|------|------|
| [azurerm_network_interface_application_gateway_backend_address_pool_association.ptrn_iaas_webapp_app_gateway_vm_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_application_gateway_backend_address_pool_association) | resource |
| [azurerm_subnet.ptrn_iaas_webapp_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.ptrn_privatelink_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_sql_subnet_address_prefixes"></a> [ptrn\_iaas\_sql\_subnet\_address\_prefixes](#input\_ptrn\_iaas\_sql\_subnet\_address\_prefixes) | subnet virtual machine | `list(string)` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_app_gateway_additional_backend_address_pool"></a> [ptrn\_iaas\_webapp\_app\_gateway\_additional\_backend\_address\_pool](#input\_ptrn\_iaas\_webapp\_app\_gateway\_additional\_backend\_address\_pool) | (Optional) Array for additional backend address pool. | <pre>map(object({<br>    name  = string<br>    fqdns = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_additional_http_listener"></a> [ptrn\_iaas\_webapp\_app\_gateway\_additional\_http\_listener](#input\_ptrn\_iaas\_webapp\_app\_gateway\_additional\_http\_listener) | (Optional) Array for additional HTTP listeners. | <pre>map(object({<br>    name                      = string<br>    protocol                  = string<br>    host_name                 = string<br>    frontend_port_name        = string<br>    ssl_certificate_name      = string    <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_additional_http_settings"></a> [ptrn\_iaas\_webapp\_app\_gateway\_additional\_http\_settings](#input\_ptrn\_iaas\_webapp\_app\_gateway\_additional\_http\_settings) | (Optional) Array for additional HTTP settings. | <pre>map(object({<br>    name                                = string<br>    request_timeout                     = number<br>    probe_name                          = string<br>    host_name                           = string<br>    pick_host_name_from_backend_address = bool<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_additional_probes"></a> [ptrn\_iaas\_webapp\_app\_gateway\_additional\_probes](#input\_ptrn\_iaas\_webapp\_app\_gateway\_additional\_probes) | (Optional) Array for additional health probes. | <pre>map(object({<br>    name                = string<br>    host                = string<br>    path                = string<br>    interval            = number<br>    timeout             = number<br>    unhealthy_threshold = number<br>    protocol            = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_additional_redirect_configurations"></a> [ptrn\_iaas\_webapp\_app\_gateway\_additional\_redirect\_configurations](#input\_ptrn\_iaas\_webapp\_app\_gateway\_additional\_redirect\_configurations) | (Optional) Array for additional redirect configurations. | <pre>map(object({<br>    name                  = string<br>    redirect_type         = string<br>    target_listener_name  = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_additional_route_rules"></a> [ptrn\_iaas\_webapp\_app\_gateway\_additional\_route\_rules](#input\_ptrn\_iaas\_webapp\_app\_gateway\_additional\_route\_rules) | (Optional) Array for additional routing rules. | <pre>map(object({<br>    name                        = string<br>    rule_type                   = string<br>    http_listener_name          = string<br>    backend_address_pool        = string<br>    backend_http_settings_name  = string<br>    redirect_configuration_name = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_additional_ssl_certificate"></a> [ptrn\_iaas\_webapp\_app\_gateway\_additional\_ssl\_certificate](#input\_ptrn\_iaas\_webapp\_app\_gateway\_additional\_ssl\_certificate) | (Optional) Array for additional SSL Certificates. | <pre>map(object({<br>    name                = string<br>    data                = string<br>    password            = string<br>    key_vault_secret_id = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_backend_address"></a> [ptrn\_iaas\_webapp\_app\_gateway\_backend\_address](#input\_ptrn\_iaas\_webapp\_app\_gateway\_backend\_address) | (Optional) The backend ip or fqdns address from the address pool | `list` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_backend_host_name"></a> [ptrn\_iaas\_webapp\_app\_gateway\_backend\_host\_name](#input\_ptrn\_iaas\_webapp\_app\_gateway\_backend\_host\_name) | (Optional) Host header to be sent to the backend servers. Cannot be set if pick\_host\_name\_from\_backend\_address is set to true | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_diagnostics"></a> [ptrn\_iaas\_webapp\_app\_gateway\_diagnostics](#input\_ptrn\_iaas\_webapp\_app\_gateway\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ApplicationGatewayAccessLog",<br>    "ApplicationGatewayPerformanceLog",<br>    "ApplicationGatewayFirewallLog"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_disable_bgp_route_propagation"></a> [ptrn\_iaas\_webapp\_app\_gateway\_disable\_bgp\_route\_propagation](#input\_ptrn\_iaas\_webapp\_app\_gateway\_disable\_bgp\_route\_propagation) | (Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_domain_name_label"></a> [ptrn\_iaas\_webapp\_app\_gateway\_domain\_name\_label](#input\_ptrn\_iaas\_webapp\_app\_gateway\_domain\_name\_label) | (Optional) Label for the Domain Name. Will be used to make up the FQDN. If a domain name label is specified, an A DNS record is created for the public IP in the Microsoft Azure DNS system. | `string` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_firewall_mode"></a> [ptrn\_iaas\_webapp\_app\_gateway\_firewall\_mode](#input\_ptrn\_iaas\_webapp\_app\_gateway\_firewall\_mode) | (Required) Resource group where the Core VNet exists. | `string` | `"Detection"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_frontend_tls_cert"></a> [ptrn\_iaas\_webapp\_app\_gateway\_frontend\_tls\_cert](#input\_ptrn\_iaas\_webapp\_app\_gateway\_frontend\_tls\_cert) | (Required) The name of the ssl cert file in pfx format that exists in the same folder that TF plan/apply is executed on. The file must not be base64 encrypted. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_app_gateway_frontend_tls_cert_keyvault_id"></a> [ptrn\_iaas\_webapp\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id](#input\_ptrn\_iaas\_webapp\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id) | (Optional) Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in Azure KeyVault. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_frontend_tls_cert_pass"></a> [ptrn\_iaas\_webapp\_app\_gateway\_frontend\_tls\_cert\_pass](#input\_ptrn\_iaas\_webapp\_app\_gateway\_frontend\_tls\_cert\_pass) | (Required) The password for the front end ssl cert file | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_app_gateway_http_listener_hostname"></a> [ptrn\_iaas\_webapp\_app\_gateway\_http\_listener\_hostname](#input\_ptrn\_iaas\_webapp\_app\_gateway\_http\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTP Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_http_settings_timeout"></a> [ptrn\_iaas\_webapp\_app\_gateway\_http\_settings\_timeout](#input\_ptrn\_iaas\_webapp\_app\_gateway\_http\_settings\_timeout) | (Optional) The timeout for HTTP response. | `number` | `600` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_https_listener_hostname"></a> [ptrn\_iaas\_webapp\_app\_gateway\_https\_listener\_hostname](#input\_ptrn\_iaas\_webapp\_app\_gateway\_https\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTPS Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_identity_ids"></a> [ptrn\_iaas\_webapp\_app\_gateway\_identity\_ids](#input\_ptrn\_iaas\_webapp\_app\_gateway\_identity\_ids) | (Optional) Specifies a list with a single user managed identity id to be assigned to the Application Gateway | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_log_analytics_solutions"></a> [ptrn\_iaas\_webapp\_app\_gateway\_log\_analytics\_solutions](#input\_ptrn\_iaas\_webapp\_app\_gateway\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>     publisher = string #(Required) The publisher of the solution<br>     product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureAppGatewayAnalytics": {<br>    "product": "OMSGallery/AzureAppGatewayAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_max_capacity"></a> [ptrn\_iaas\_webapp\_app\_gateway\_max\_capacity](#input\_ptrn\_iaas\_webapp\_app\_gateway\_max\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `5` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_min_capacity"></a> [ptrn\_iaas\_webapp\_app\_gateway\_min\_capacity](#input\_ptrn\_iaas\_webapp\_app\_gateway\_min\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `1` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_nsg_flow_log_postfix"></a> [ptrn\_iaas\_webapp\_app\_gateway\_nsg\_flow\_log\_postfix](#input\_ptrn\_iaas\_webapp\_app\_gateway\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_app_gateway_nsg_rules"></a> [ptrn\_iaas\_webapp\_app\_gateway\_nsg\_rules](#input\_ptrn\_iaas\_webapp\_app\_gateway\_nsg\_rules) | (Optional) Define additional NSG rules for app gateway subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_pick_host_backend"></a> [ptrn\_iaas\_webapp\_app\_gateway\_pick\_host\_backend](#input\_ptrn\_iaas\_webapp\_app\_gateway\_pick\_host\_backend) | (Optional) Define additional NSG rules for app gateway subnet. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_pick_host_name"></a> [ptrn\_iaas\_webapp\_app\_gateway\_pick\_host\_name](#input\_ptrn\_iaas\_webapp\_app\_gateway\_pick\_host\_name) | (Optional) Define additional NSG rules for app gateway subnet. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_probe_host"></a> [ptrn\_iaas\_webapp\_app\_gateway\_probe\_host](#input\_ptrn\_iaas\_webapp\_app\_gateway\_probe\_host) | (Optional) The site url from the Health probes | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_probe_interval"></a> [ptrn\_iaas\_webapp\_app\_gateway\_probe\_interval](#input\_ptrn\_iaas\_webapp\_app\_gateway\_probe\_interval) | (Optional) The probe interval from the Health probes | `number` | `10` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_probe_name"></a> [ptrn\_iaas\_webapp\_app\_gateway\_probe\_name](#input\_ptrn\_iaas\_webapp\_app\_gateway\_probe\_name) | (Optional) The probe name from Health probes | `string` | `"https-probe"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_probe_path"></a> [ptrn\_iaas\_webapp\_app\_gateway\_probe\_path](#input\_ptrn\_iaas\_webapp\_app\_gateway\_probe\_path) | (Optional) The probe path from the Health probes | `string` | `"/"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_probe_protocol"></a> [ptrn\_iaas\_webapp\_app\_gateway\_probe\_protocol](#input\_ptrn\_iaas\_webapp\_app\_gateway\_probe\_protocol) | (Optional) The probe protocol from the Health probes | `string` | `"Https"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_probe_timeout"></a> [ptrn\_iaas\_webapp\_app\_gateway\_probe\_timeout](#input\_ptrn\_iaas\_webapp\_app\_gateway\_probe\_timeout) | (Optional) The timeout from the Health probes | `number` | `30` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_probe_unhealthy_threshold"></a> [ptrn\_iaas\_webapp\_app\_gateway\_probe\_unhealthy\_threshold](#input\_ptrn\_iaas\_webapp\_app\_gateway\_probe\_unhealthy\_threshold) | (Optional) The unhealthy threshold from the Health probes | `number` | `3` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_public_ip_allocation_method"></a> [ptrn\_iaas\_webapp\_app\_gateway\_public\_ip\_allocation\_method](#input\_ptrn\_iaas\_webapp\_app\_gateway\_public\_ip\_allocation\_method) | (Optional) The allocation method for this IP address. Possible values are Static or Dynamic. | `string` | `"Static"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_public_ip_sku"></a> [ptrn\_iaas\_webapp\_app\_gateway\_public\_ip\_sku](#input\_ptrn\_iaas\_webapp\_app\_gateway\_public\_ip\_sku) | (Optional) The SKU of the Public IP. Accepted values are Basic and Standard | `string` | `"Standard"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_reverse_fqdn"></a> [ptrn\_iaas\_webapp\_app\_gateway\_reverse\_fqdn](#input\_ptrn\_iaas\_webapp\_app\_gateway\_reverse\_fqdn) | (Optional) A fully qualified domain name that resolves to this public IP address | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_rewrite_rules"></a> [ptrn\_iaas\_webapp\_app\_gateway\_rewrite\_rules](#input\_ptrn\_iaas\_webapp\_app\_gateway\_rewrite\_rules) | (Optional) Array for rewrite rules. | <pre>list(object({<br>    name            = string<br>    rule_sequence   = number<br>    conditions = list(object({<br>      variable    = string<br>      pattern     = string<br>      ignore_case = bool<br>      negate      = bool<br>    }))<br>    request_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))<br>    response_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))  <br>    urls  = list(object({<br>      path          = string<br>      query_string  = string<br>      reroute       = string<br>    }))         <br>  }))</pre> | `[]` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_ssl_policy_name"></a> [ptrn\_iaas\_webapp\_app\_gateway\_ssl\_policy\_name](#input\_ptrn\_iaas\_webapp\_app\_gateway\_ssl\_policy\_name) | (Optional) The Name from SSL Policy | `string` | `"AppGwSslPolicy20170401S"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_ssl_policy_protocol_version"></a> [ptrn\_iaas\_webapp\_app\_gateway\_ssl\_policy\_protocol\_version](#input\_ptrn\_iaas\_webapp\_app\_gateway\_ssl\_policy\_protocol\_version) | (Optional) The Minimun Protocol Version from SSL Policy | `string` | `"TLSv1_2"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_ssl_policy_type"></a> [ptrn\_iaas\_webapp\_app\_gateway\_ssl\_policy\_type](#input\_ptrn\_iaas\_webapp\_app\_gateway\_ssl\_policy\_type) | (Optional) The Type from SSL Policy | `string` | `"Predefined"` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_subnet_address_prefix"></a> [ptrn\_iaas\_webapp\_app\_gateway\_subnet\_address\_prefix](#input\_ptrn\_iaas\_webapp\_app\_gateway\_subnet\_address\_prefix) | (Required) The address prefix of the application gateway subnet. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_app_gateway_subnet_hostnum"></a> [ptrn\_iaas\_webapp\_app\_gateway\_subnet\_hostnum](#input\_ptrn\_iaas\_webapp\_app\_gateway\_subnet\_hostnum) | The hostnumber from the subnet prefix for the private IP. | `number` | `15` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_subnet_service_endpoints"></a> [ptrn\_iaas\_webapp\_app\_gateway\_subnet\_service\_endpoints](#input\_ptrn\_iaas\_webapp\_app\_gateway\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet | `list` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_app_gateway_tags"></a> [ptrn\_iaas\_webapp\_app\_gateway\_tags](#input\_ptrn\_iaas\_webapp\_app\_gateway\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_ptrn_iaas_webapp_azure_backup_diagnostics"></a> [ptrn\_iaas\_webapp\_azure\_backup\_diagnostics](#input\_ptrn\_iaas\_webapp\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_azure_backup_retention_daily_count"></a> [ptrn\_iaas\_webapp\_azure\_backup\_retention\_daily\_count](#input\_ptrn\_iaas\_webapp\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets"></a> [ptrn\_iaas\_webapp\_azure\_backup\_rsv\_allowed\_subnets](#input\_ptrn\_iaas\_webapp\_azure\_backup\_rsv\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this RSV. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_backup_tags"></a> [ptrn\_iaas\_webapp\_azure\_backup\_tags](#input\_ptrn\_iaas\_webapp\_azure\_backup\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_ptrn_iaas_webapp_azure_backup_time"></a> [ptrn\_iaas\_webapp\_azure\_backup\_time](#input\_ptrn\_iaas\_webapp\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_ptrn_iaas_webapp_azure_backup_timezone"></a> [ptrn\_iaas\_webapp\_azure\_backup\_timezone](#input\_ptrn\_iaas\_webapp\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_ptrn_iaas_webapp_azure_bastion_diagnostics"></a> [ptrn\_iaas\_webapp\_azure\_bastion\_diagnostics](#input\_ptrn\_iaas\_webapp\_azure\_bastion\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "BastionAuditLogs"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_azure_bastion_enable"></a> [ptrn\_iaas\_webapp\_azure\_bastion\_enable](#input\_ptrn\_iaas\_webapp\_azure\_bastion\_enable) | (Optional) Enable te creation for azure bastion | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_azure_bastion_nsg_rules"></a> [ptrn\_iaas\_webapp\_azure\_bastion\_nsg\_rules](#input\_ptrn\_iaas\_webapp\_azure\_bastion\_nsg\_rules) | (Optional) Define additional NSG rules for bastion subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_azure_bastion_subnet_prefix"></a> [ptrn\_iaas\_webapp\_azure\_bastion\_subnet\_prefix](#input\_ptrn\_iaas\_webapp\_azure\_bastion\_subnet\_prefix) | (Required) The prefix of the azure bastion subnet. | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_azure_bastion_subnet_service_endpoints"></a> [ptrn\_iaas\_webapp\_azure\_bastion\_subnet\_service\_endpoints](#input\_ptrn\_iaas\_webapp\_azure\_bastion\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet | `list` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_bastion_tags"></a> [ptrn\_iaas\_webapp\_azure\_bastion\_tags](#input\_ptrn\_iaas\_webapp\_azure\_bastion\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_LTR_monthly_retention"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_monthly\_retention](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_monthly\_retention) | (Optional) The monthly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D. | `string` | `"P1M"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_LTR_week_of_year"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_week\_of\_year](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_week\_of\_year) | (Optional) The week of year to take the yearly backup in an ISO 8601 format. Value has to be between 1 and 52. | `number` | `1` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_LTR_weekly_retention"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_weekly\_retention](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_weekly\_retention) | (Optional) The weekly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D. | `string` | `"P1W"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_LTR_yearly_retention"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_yearly\_retention](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_LTR\_yearly\_retention) | (Optional) The yearly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 10 years. e.g. P1Y, P12M, P52W or P365D. | `string` | `"P1Y"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_STR_retention"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_STR\_retention](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_STR\_retention) | (Required) Point In Time Restore configuration. Value has to be between 7 and 35. | `number` | `35` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_audit_retention_days"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_audit\_retention\_days](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `7` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_collation"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_collation](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_collation) | (Optional) Specifies the collation of the database. Changing this forces a new resource to be created. | `string` | `"SQL_Latin1_General_CP1_CI_AS"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_create_mode"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_create\_mode](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_create\_mode) | (Optional) The create mode of the database. Possible values are Copy, Default, OnlineSecondary, PointInTimeRestore, Recovery, Restore, RestoreExternalBackup, RestoreExternalBackupSecondary, RestoreLongTermRetentionBackup and Secondary. | `string` | `"Default"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_diagnostics"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_diagnostics](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "SQLInsights",<br>    "AutomaticTuning",<br>    "QueryStoreRuntimeStatistics",<br>    "QueryStoreWaitStatistics",<br>    "Errors",<br>    "DatabaseWaitStatistics",<br>    "Timeouts",<br>    "Blocks",<br>    "Deadlocks"<br>  ],<br>  "metrics": [<br>    "Basic",<br>    "InstanceAndAppAdvanced",<br>    "WorkloadManagement"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_disabled_alerts"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_disabled\_alerts](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_disabled\_alerts) | (Optional) Specifies a list of alerts which should be disabled. Possible values include Access\_Anomaly, Sql\_Injection and Sql\_Injection\_Vulnerability. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_elastic_pool_id"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_elastic\_pool\_id](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_elastic\_pool\_id) | (Optional) The Elastic Pool id to Integrate the DB with one azure sql elastic pool. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_license"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_license](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_license) | (Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_postfix"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_postfix](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_postfix) | (Required) A string that is appended to the end of the database name to identify it. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_read"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_read](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_read) | (Optional) If enabled, connections that have application intent set to readonly in their connection string may be routed to a readonly secondary replica. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_redudant"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_redudant](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_redudant) | (Optional) Whether or not this database is zone redundant, which means the replicas of this database will be spread across multiple availability zones. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_replica_count"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_replica\_count](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_replica\_count) | (Optional) The number of readonly secondary replicas associated with the database to which readonly application intent connections may be routed. This property is only settable for Hyperscale edition databases. | `number` | `null` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_size"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_size](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_size) | (Optional) The max size of the database in gigabytes. | `number` | `1` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_sku"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_sku](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_sku) | (Optional) Specifies the name of the sku used by the database. Changing this forces a new resource to be created. Single Database default value: BC\_Gen5\_2. If the database require be include in Elastic Pool group, in variable sku default value: ElasticPool. | `string` | `"BC_Gen5_2"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_tags"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_tags](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_threat_email_admins"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_email\_admins](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_email\_admins) | (Optional) Should the account administrators be emailed when this alert is triggered? | `string` | `"Disabled"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_threat_emails"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_emails](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_emails) | (Optional) A list of email addresses which alerts should be sent to. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_threat_logs_retention"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_logs\_retention](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_logs\_retention) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_threat_policy_state"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_policy\_state](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_policy\_state) | (Optional) The State of the Policy. Possible values are Enabled, Disabled or New. | `string` | `"Enabled"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_database_threat_server_default"></a> [ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_server\_default](#input\_ptrn\_iaas\_webapp\_azure\_sql\_database\_threat\_server\_default) | (Optional) Should the default server policy be used? | `string` | `"Disabled"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_database_max_dtu_capacity"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_database\_max\_dtu\_capacity](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_database\_max\_dtu\_capacity) | The maximum capacity any one database can consume in the Elastic Pool. Default to the max Elastic Pool capacity. | `string` | `"1"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_database_min_capacity"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_database\_min\_capacity](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_database\_min\_capacity) | The minimum capacity all databases are guaranteed in the Elastic Pool. Defaults to 0. | `string` | `"0"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_diagnostic"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_diagnostic](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_enable"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_enable](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_enable) | (Optional) Enable te creation for sql elastic pool | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_license_type"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_license\_type](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_license\_type) | (Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_max_size"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_max\_size](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_max\_size) | Maximum size of the Elastic Pool in gigabytes | `string` | `"1024"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_postfix"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_postfix](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `string` | `"globaldb"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_sku"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_sku](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_sku) | SKU for the Elastic Pool with tier and eDTUs capacity. Premium tier with zone redundancy is mandatory for high availability. Possible values for tier are Basic, Standard, or Premium. Example tier=Standard, capacity=50. See https://docs.microsoft.com/en-us/azure/sql-database/sql-database-dtu-resource-limits-elastic-pools | <pre>object({<br>    name     = string,<br>    tier     = string,<br>    family   = string,<br>    capacity = string<br>  })</pre> | <pre>{<br>  "capacity": "4",<br>  "family": "Gen5",<br>  "name": "BC_Gen5",<br>  "tier": "BusinessCritical"<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_elastic_pool_zone_redundant"></a> [ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_zone\_redundant](#input\_ptrn\_iaas\_webapp\_azure\_sql\_elastic\_pool\_zone\_redundant) | Whether or not the Elastic Pool is zone redundant, SKU tier must be Premium to use it. This is mandatory for high availability. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_administrator"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_administrator](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_administrator) | (Required) The administrator login name for the new server. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_alert_email_enabled"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_email\_enabled](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_email\_enabled) | (Optional) Boolean flag which specifies if the alert is sent to the account administrators or not. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_alert_emails"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_emails](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_emails) | (Optional) Specifies an array of e-mail addresses to which the alert is sent. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_alert_retention_days"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_retention\_days](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_retention\_days) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `90` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_alert_state"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_state](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_alert\_state) | (Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific database server. Allowed values are: Disabled, Enabled. | `string` | `"Enabled"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_audit_retention_days"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_audit\_retention\_days](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `90` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_connection_policy"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_connection\_policy](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_connection\_policy) | (Optional) The connection policy the server will use. Possible values are Default, Proxy, and Redirect. | `string` | `"Default"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_disabled_alerts"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_disabled\_alerts](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_disabled\_alerts) | (Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql\_Injection, Sql\_Injection\_Vulnerability, Access\_Anomaly, Data\_Exfiltration, Unsafe\_Action. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_firewall_rules"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_firewall\_rules](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_firewall\_rules) | (Optional) Define additional firewall rules | <pre>map(object({<br>    start_ip                 = string<br>    end_ip                   = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_log_analytics_solution"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_log\_analytics\_solution](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_log\_analytics\_solution) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureSQLAnalytics": {<br>    "product": "OMSGallery/AzureSQLAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_login_username"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_login\_username](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_login\_username) | (Required) Login username Mandatory if azuread\_administrator is true | `string` | `null` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_nacl_allowed_subnets"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_nacl\_allowed\_subnets](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure SQL Server. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_object_id"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_object\_id](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_object\_id) | (Required) AD Objetct id Mandatory if azuread\_administrator is true | `string` | `null` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_password"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_password](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_password) | (Required) The password associated with the cl\_azure\_sql\_server\_administrator user. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_postfix"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_postfix](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_public_network_access"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_public\_network\_access](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_public\_network\_access) | (Optional) Whether or not public network access is allowed for this server. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_sa_allowed_pe_subnet_ids"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_sa\_allowed\_pe\_subnet\_ids](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_sa\_allowed\_pe\_subnet\_ids) | (Required) A list of Ip addresses that can access the storage account. It is recommended that you add your automation tool's IP range here. | `list` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_sa\_allowed\_vnet\_subnet\_ids](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_sa\_allowed\_vnet\_subnet\_ids) | (Required) A list of Subnets of the vnet that can access the sql server storage account. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_security_email_subscription"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_security\_email\_subscription](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_security\_email\_subscription) | (Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_security_emails"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_security\_emails](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_security\_emails) | (Optional) Specifies an array of e-mail addresses to which the scan notification is sent. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_security_scans"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_security\_scans](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_security\_scans) | (Optional) Boolean flag which specifies if recurring scans is enabled or disabled. | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_storage_account_blob_retention_days"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_storage\_account\_blob\_retention\_days](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `365` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_storage_account_diagnostics"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_storage\_account\_diagnostics](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_storage_account_tier"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_storage\_account\_tier](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for Azure SQL server audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_tags"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_tags](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_tls"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_tls](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_tls) | (Optional) The Minimum TLS Version for all SQL Database and SQL Data Warehouse databases associated with the server. Valid values are: 1.0, 1.1 and 1.2. | `string` | `"1.2"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_version"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_version](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_version) | (Optional) The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server). | `string` | `"12.0"` | no |
| <a name="input_ptrn_iaas_webapp_azure_sql_server_vnet_rules"></a> [ptrn\_iaas\_webapp\_azure\_sql\_server\_vnet\_rules](#input\_ptrn\_iaas\_webapp\_azure\_sql\_server\_vnet\_rules) | (Optional) Define additional virtual network rules | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_azure_storage_account_secondary_access_key"></a> [ptrn\_iaas\_webapp\_azure\_storage\_account\_secondary\_access\_key](#input\_ptrn\_iaas\_webapp\_azure\_storage\_account\_secondary\_access\_key) | (Optional) Specifies whether cl\_azure\_storage\_account\_access\_key value is the storage's secondary key. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_cl_windows_computer_name"></a> [ptrn\_iaas\_webapp\_cl\_windows\_computer\_name](#input\_ptrn\_iaas\_webapp\_cl\_windows\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_cl_windows_log_analytics_workspace_id"></a> [ptrn\_iaas\_webapp\_cl\_windows\_log\_analytics\_workspace\_id](#input\_ptrn\_iaas\_webapp\_cl\_windows\_log\_analytics\_workspace\_id) | (Required) cl\_windows workspace id. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_cl_windows_vm_admin_pass"></a> [ptrn\_iaas\_webapp\_cl\_windows\_vm\_admin\_pass](#input\_ptrn\_iaas\_webapp\_cl\_windows\_vm\_admin\_pass) | (Required) The password of the windows OS admin. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_cl_windows_vm_admin_user"></a> [ptrn\_iaas\_webapp\_cl\_windows\_vm\_admin\_user](#input\_ptrn\_iaas\_webapp\_cl\_windows\_vm\_admin\_user) | (Required) The name of the windows OS admin. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_cl_windows_vm_app_name"></a> [ptrn\_iaas\_webapp\_cl\_windows\_vm\_app\_name](#input\_ptrn\_iaas\_webapp\_cl\_windows\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_cl_windows_vm_availability_zone"></a> [ptrn\_iaas\_webapp\_cl\_windows\_vm\_availability\_zone](#input\_ptrn\_iaas\_webapp\_cl\_windows\_vm\_availability\_zone) | (Required) Specifies the Availability Zone in which this Windows Virtual Machine should be located. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_cl_windows_vm_image_id"></a> [ptrn\_iaas\_webapp\_cl\_windows\_vm\_image\_id](#input\_ptrn\_iaas\_webapp\_cl\_windows\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_log_analytics_workspace_id"></a> [ptrn\_iaas\_webapp\_core\_log\_analytics\_workspace\_id](#input\_ptrn\_iaas\_webapp\_core\_log\_analytics\_workspace\_id) | (Required) Core workspace id. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_log_analytics_workspace_name"></a> [ptrn\_iaas\_webapp\_core\_log\_analytics\_workspace\_name](#input\_ptrn\_iaas\_webapp\_core\_log\_analytics\_workspace\_name) | (Required) Core workspace name. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_log_analytics_workspace_primary_shared_key"></a> [ptrn\_iaas\_webapp\_core\_log\_analytics\_workspace\_primary\_shared\_key](#input\_ptrn\_iaas\_webapp\_core\_log\_analytics\_workspace\_primary\_shared\_key) | (Required) Core workspace primary shared key. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_rg_data_name"></a> [ptrn\_iaas\_webapp\_core\_rg\_data\_name](#input\_ptrn\_iaas\_webapp\_core\_rg\_data\_name) | (Required) Core resource group data name. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_rg_logging_name"></a> [ptrn\_iaas\_webapp\_core\_rg\_logging\_name](#input\_ptrn\_iaas\_webapp\_core\_rg\_logging\_name) | (Required) Core logging name. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_rg_network_name"></a> [ptrn\_iaas\_webapp\_core\_rg\_network\_name](#input\_ptrn\_iaas\_webapp\_core\_rg\_network\_name) | (Required) Core network name. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_rg_vnet_id"></a> [ptrn\_iaas\_webapp\_core\_rg\_vnet\_id](#input\_ptrn\_iaas\_webapp\_core\_rg\_vnet\_id) | (Required) Core network id. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_rg_vnet_name"></a> [ptrn\_iaas\_webapp\_core\_rg\_vnet\_name](#input\_ptrn\_iaas\_webapp\_core\_rg\_vnet\_name) | (Required) Core vnet name. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_core_route_table_id"></a> [ptrn\_iaas\_webapp\_core\_route\_table\_id](#input\_ptrn\_iaas\_webapp\_core\_route\_table\_id) | (Required) Core route table id. | `string` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_private_endpoint_subresource_names"></a> [ptrn\_iaas\_webapp\_private\_endpoint\_subresource\_names](#input\_ptrn\_iaas\_webapp\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "sqlServer"<br>]</pre> | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_allowed_subnets"></a> [ptrn\_iaas\_webapp\_redis\_cache\_allowed\_subnets](#input\_ptrn\_iaas\_webapp\_redis\_cache\_allowed\_subnets) | (Required) One or more Subnet ID's which should be able to access this redis cache. | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_capacity"></a> [ptrn\_iaas\_webapp\_redis\_cache\_capacity](#input\_ptrn\_iaas\_webapp\_redis\_cache\_capacity) | (Optional) The size of the Redis cache to deploy. Valid values for a SKU family of C (Basic/Standard) are 0, 1, 2, 3, 4, 5, 6, and for P (Premium) family are 1, 2, 3, 4. | `number` | `1` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_configuration_maxfragmentationmemory_reserved"></a> [ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxfragmentationmemory\_reserved](#input\_ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxfragmentationmemory\_reserved) | (Optional) lue in megabytes reserved to accommodate for memory fragmentation. | `number` | `50` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_configuration_maxmemory_delta"></a> [ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxmemory\_delta](#input\_ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxmemory\_delta) | (Optional) The max-memory delta for this Redis instance. | `number` | `50` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_configuration_maxmemory_policy"></a> [ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxmemory\_policy](#input\_ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxmemory\_policy) | (Optional) How Redis will select what to remove when maxmemory is reached. | `string` | `"volatile-lru"` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_configuration_maxmemory_reserved"></a> [ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxmemory\_reserved](#input\_ptrn\_iaas\_webapp\_redis\_cache\_configuration\_maxmemory\_reserved) | (Optional) Value in megabytes reserved for non-cache usage e.g. failover. | `number` | `50` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_diagnostic"></a> [ptrn\_iaas\_webapp\_redis\_cache\_diagnostic](#input\_ptrn\_iaas\_webapp\_redis\_cache\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_enable"></a> [ptrn\_iaas\_webapp\_redis\_cache\_enable](#input\_ptrn\_iaas\_webapp\_redis\_cache\_enable) | Enable/disabled creation module Redis Cache | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_enable_non_ssl_port"></a> [ptrn\_iaas\_webapp\_redis\_cache\_enable\_non\_ssl\_port](#input\_ptrn\_iaas\_webapp\_redis\_cache\_enable\_non\_ssl\_port) | (Optional) Enable the non ssl port for redis cache. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_family"></a> [ptrn\_iaas\_webapp\_redis\_cache\_family](#input\_ptrn\_iaas\_webapp\_redis\_cache\_family) | (Optional) The SKU family/pricing group to use. Valid values are C (for Basic/Standard SKU family) and P (for Premium). | `string` | `"P"` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_minimum_tls_version"></a> [ptrn\_iaas\_webapp\_redis\_cache\_minimum\_tls\_version](#input\_ptrn\_iaas\_webapp\_redis\_cache\_minimum\_tls\_version) | (Optional) The minimum TLS version. | `string` | `"1.2"` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_postfix"></a> [ptrn\_iaas\_webapp\_redis\_cache\_postfix](#input\_ptrn\_iaas\_webapp\_redis\_cache\_postfix) | (Required) The postfix for the redis cache. Use this to make the name globally unique. | `any` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_redis_cache_public_network_access_enabled"></a> [ptrn\_iaas\_webapp\_redis\_cache\_public\_network\_access\_enabled](#input\_ptrn\_iaas\_webapp\_redis\_cache\_public\_network\_access\_enabled) | (Optional) Enable public network access for Redis cache. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_rdb_backup_enabled"></a> [ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_enabled](#input\_ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_enabled) | (Optional) Is Backup Enabled? Only supported on Premium SKU's | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_rdb_backup_frequency"></a> [ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_frequency](#input\_ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_frequency) | (Optional) The Backup Frequency in Minutes. Only supported on Premium SKU's | `number` | `360` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_rdb_backup_max_snapshot_count"></a> [ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_max\_snapshot\_count](#input\_ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_max\_snapshot\_count) | (Optional) The maximum number of snapshots to create as a backup. Only supported for Premium SKU's | `number` | `1` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_rdb_backup_storage_account_endpoint"></a> [ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_storage\_account\_endpoint](#input\_ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_storage\_account\_endpoint) | (Optional) Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_rdb_backup_storage_account_key"></a> [ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_storage\_account\_key](#input\_ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_storage\_account\_key) | (Optional) storage account key. Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_rdb_backup_storage_account_name"></a> [ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_storage\_account\_name](#input\_ptrn\_iaas\_webapp\_redis\_cache\_rdb\_backup\_storage\_account\_name) | (Optional) Name of backup storage account name. Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_redis_cache_sku_name"></a> [ptrn\_iaas\_webapp\_redis\_cache\_sku\_name](#input\_ptrn\_iaas\_webapp\_redis\_cache\_sku\_name) | (Optional) The SKU of Redis to use. Possible values are Basic, Standard and Premium. | `string` | `"Premium"` | no |
| <a name="input_ptrn_iaas_webapp_set_private_ip_listener"></a> [ptrn\_iaas\_webapp\_set\_private\_ip\_listener](#input\_ptrn\_iaas\_webapp\_set\_private\_ip\_listener) | (Optional) A boolean variable indicating which environment the app gateway is being deployed into. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_storage_account_nsg_flow_log_id"></a> [ptrn\_iaas\_webapp\_storage\_account\_nsg\_flow\_log\_id](#input\_ptrn\_iaas\_webapp\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_ptrn_iaas_webapp_subnet_address_prefixes"></a> [ptrn\_iaas\_webapp\_subnet\_address\_prefixes](#input\_ptrn\_iaas\_webapp\_subnet\_address\_prefixes) | subnet virtual machine | `list(string)` | n/a | yes |
| <a name="input_ptrn_iaas_webapp_tags"></a> [ptrn\_iaas\_webapp\_tags](#input\_ptrn\_iaas\_webapp\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_azurerm_subnet_service_enpoints"></a> [ptrn\_iaas\_webapp\_windows\_vm\_azurerm\_subnet\_service\_enpoints](#input\_ptrn\_iaas\_webapp\_windows\_vm\_azurerm\_subnet\_service\_enpoints) | (Optional) The Size of the windows vm. | `list (string)` | <pre>[<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_backup_policy_vm_id"></a> [ptrn\_iaas\_webapp\_windows\_vm\_backup\_policy\_vm\_id](#input\_ptrn\_iaas\_webapp\_windows\_vm\_backup\_policy\_vm\_id) | (Optional) The backup policy from the backup vault. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_bastion_enable"></a> [ptrn\_iaas\_webapp\_windows\_vm\_bastion\_enable](#input\_ptrn\_iaas\_webapp\_windows\_vm\_bastion\_enable) | (Optional) Enable te creation for azure bastion | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_deploy_rg"></a> [ptrn\_iaas\_webapp\_windows\_vm\_deploy\_rg](#input\_ptrn\_iaas\_webapp\_windows\_vm\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the VM. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_deploy_subnet"></a> [ptrn\_iaas\_webapp\_windows\_vm\_deploy\_subnet](#input\_ptrn\_iaas\_webapp\_windows\_vm\_deploy\_subnet) | (Optional) A boolean to enable/disable the deployment of a subnet for the VM. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_deploy_subnet_nsg"></a> [ptrn\_iaas\_webapp\_windows\_vm\_deploy\_subnet\_nsg](#input\_ptrn\_iaas\_webapp\_windows\_vm\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_devops_agent_deployment_group"></a> [ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_deployment\_group](#input\_ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_deployment\_group) | (Optional) Deployment Group of Azure DevOps | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_devops_agent_org_url"></a> [ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_org\_url](#input\_ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_org\_url) | (Optional) Organization of Azure DevOps | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_devops_agent_pat"></a> [ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_pat](#input\_ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_pat) | (Optional) A Personal Access Token (PAT) is used as an alternate password to authenticate into Azure DevOps. | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_devops_agent_team_project"></a> [ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_team\_project](#input\_ptrn\_iaas\_webapp\_windows\_vm\_devops\_agent\_team\_project) | (Optional) Team Project of Azure DevOps | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_domain_name"></a> [ptrn\_iaas\_webapp\_windows\_vm\_domain\_name](#input\_ptrn\_iaas\_webapp\_windows\_vm\_domain\_name) | (Optional) Name of the domain to join | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_domain_password"></a> [ptrn\_iaas\_webapp\_windows\_vm\_domain\_password](#input\_ptrn\_iaas\_webapp\_windows\_vm\_domain\_password) | (Optional) Password of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_domain_user_upn"></a> [ptrn\_iaas\_webapp\_windows\_vm\_domain\_user\_upn](#input\_ptrn\_iaas\_webapp\_windows\_vm\_domain\_user\_upn) | (Optional) UPN of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_enable_automatic_updates"></a> [ptrn\_iaas\_webapp\_windows\_vm\_enable\_automatic\_updates](#input\_ptrn\_iaas\_webapp\_windows\_vm\_enable\_automatic\_updates) | (Optional) Boolean to enable automatic updates. | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_enable_backup"></a> [ptrn\_iaas\_webapp\_windows\_vm\_enable\_backup](#input\_ptrn\_iaas\_webapp\_windows\_vm\_enable\_backup) | (Optional) Toggle the backup feature. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_enable_devops_agent"></a> [ptrn\_iaas\_webapp\_windows\_vm\_enable\_devops\_agent](#input\_ptrn\_iaas\_webapp\_windows\_vm\_enable\_devops\_agent) | (Optional) A boolean variable indicating if devops agent should be installed or not. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_enable_domain_join"></a> [ptrn\_iaas\_webapp\_windows\_vm\_enable\_domain\_join](#input\_ptrn\_iaas\_webapp\_windows\_vm\_enable\_domain\_join) | (Optional) Toggle the domain join feature. | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_enable_encryption_at_host_enabled"></a> [ptrn\_iaas\_webapp\_windows\_vm\_enable\_encryption\_at\_host\_enabled](#input\_ptrn\_iaas\_webapp\_windows\_vm\_enable\_encryption\_at\_host\_enabled) | (Optional) Boolean to enable encryption\_at\_host\_enabled. | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_enable_log_analytics_settings"></a> [ptrn\_iaas\_webapp\_windows\_vm\_enable\_log\_analytics\_settings](#input\_ptrn\_iaas\_webapp\_windows\_vm\_enable\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_identity_ids"></a> [ptrn\_iaas\_webapp\_windows\_vm\_identity\_ids](#input\_ptrn\_iaas\_webapp\_windows\_vm\_identity\_ids) | (Optional) A list of User Managed Identity ID's which should be assigned to the Windows Virtual Machine | `list(string)` | `[]` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_identity_type"></a> [ptrn\_iaas\_webapp\_windows\_vm\_identity\_type](#input\_ptrn\_iaas\_webapp\_windows\_vm\_identity\_type) | (Optional) Managed identity type for VM | `string` | `"SystemAssigned"` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_license_type"></a> [ptrn\_iaas\_webapp\_windows\_vm\_license\_type](#input\_ptrn\_iaas\_webapp\_windows\_vm\_license\_type) | (Optional) Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows\_Client and Windows\_Server. | `string` | `"Windows_Server"` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_managed_disks"></a> [ptrn\_iaas\_webapp\_windows\_vm\_managed\_disks](#input\_ptrn\_iaas\_webapp\_windows\_vm\_managed\_disks) | (Optional) Map containing the managed disks attributes | <pre>map(object({<br>    storage_account_type = string<br>    disk_size            = string<br>    lun                  = string<br>    caching              = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_os_disk_caching"></a> [ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_caching](#input\_ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_caching) | (Optional) The caching for the os disk of the windows vm. | `string` | `"ReadWrite"` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_os_disk_disk_size_gb"></a> [ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_disk\_size\_gb](#input\_ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_disk\_size\_gb) | (Optional) The disk size gb for the os disk of the windows vm. | `string` | `"128"` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_os_disk_storage_account_type"></a> [ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_storage\_account\_type](#input\_ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"Standard_LRS"` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_os_disk_write_accelerator_enabled"></a> [ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_write\_accelerator\_enabled](#input\_ptrn\_iaas\_webapp\_windows\_vm\_os\_disk\_write\_accelerator\_enabled) | (Optional) Boolean to enable write accelerator enabled. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_os_ultra_ssd_enabled"></a> [ptrn\_iaas\_webapp\_windows\_vm\_os\_ultra\_ssd\_enabled](#input\_ptrn\_iaas\_webapp\_windows\_vm\_os\_ultra\_ssd\_enabled) | (Optional) Boolean to enable ultra ssd enabled. | `bool` | `false` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_ou_path"></a> [ptrn\_iaas\_webapp\_windows\_vm\_ou\_path](#input\_ptrn\_iaas\_webapp\_windows\_vm\_ou\_path) | (Optional) OU path to us during domain join | `string` | `""` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_provision_vm_agent"></a> [ptrn\_iaas\_webapp\_windows\_vm\_provision\_vm\_agent](#input\_ptrn\_iaas\_webapp\_windows\_vm\_provision\_vm\_agent) | (Optional) Boolean to enable provision vm agent. | `bool` | `true` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_recovery_vault_name"></a> [ptrn\_iaas\_webapp\_windows\_vm\_recovery\_vault\_name](#input\_ptrn\_iaas\_webapp\_windows\_vm\_recovery\_vault\_name) | (Optional) The name of recovery backup vault. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_rg_backup_name"></a> [ptrn\_iaas\_webapp\_windows\_vm\_rg\_backup\_name](#input\_ptrn\_iaas\_webapp\_windows\_vm\_rg\_backup\_name) | (Optional) The RG destination of the windows vm backup. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_rg_name"></a> [ptrn\_iaas\_webapp\_windows\_vm\_rg\_name](#input\_ptrn\_iaas\_webapp\_windows\_vm\_rg\_name) | (Optional) The name of the windows VM resource group if cl\_windows\_vm\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_size"></a> [ptrn\_iaas\_webapp\_windows\_vm\_size](#input\_ptrn\_iaas\_webapp\_windows\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_DS1_v2"` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_subnet_prefix"></a> [ptrn\_iaas\_webapp\_windows\_vm\_subnet\_prefix](#input\_ptrn\_iaas\_webapp\_windows\_vm\_subnet\_prefix) | (Optional) The prefix of the windows vm subnet. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_tags"></a> [ptrn\_iaas\_webapp\_windows\_vm\_tags](#input\_ptrn\_iaas\_webapp\_windows\_vm\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_timezone"></a> [ptrn\_iaas\_webapp\_windows\_vm\_timezone](#input\_ptrn\_iaas\_webapp\_windows\_vm\_timezone) | (Optional) The timezone of the windows vm. | `any` | `null` | no |
| <a name="input_ptrn_iaas_webapp_windows_vm_user_defined_nsg_rules"></a> [ptrn\_iaas\_webapp\_windows\_vm\_user\_defined\_nsg\_rules](#input\_ptrn\_iaas\_webapp\_windows\_vm\_user\_defined\_nsg\_rules) | (Optional) Define additional NSG rules | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | n/a | `any` | n/a | yes |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_app_gateway"></a> [cl\_app\_gateway](#output\_cl\_app\_gateway) | n/a |
| <a name="output_cl_azure_backup"></a> [cl\_azure\_backup](#output\_cl\_azure\_backup) | n/a |
| <a name="output_cl_azure_sql_database"></a> [cl\_azure\_sql\_database](#output\_cl\_azure\_sql\_database) | n/a |
| <a name="output_cl_azure_sql_elastic_pool"></a> [cl\_azure\_sql\_elastic\_pool](#output\_cl\_azure\_sql\_elastic\_pool) | n/a |
| <a name="output_cl_azure_sql_server"></a> [cl\_azure\_sql\_server](#output\_cl\_azure\_sql\_server) | // Outputs Iaas WebApp Pattern ********************************************************************************************** |
| <a name="output_cl_redis_cache"></a> [cl\_redis\_cache](#output\_cl\_redis\_cache) | n/a |
| <a name="output_cl_windows_vmachine"></a> [cl\_windows\_vmachine](#output\_cl\_windows\_vmachine) | n/a |
| <a name="output_ptrn_privatelink_subnet"></a> [ptrn\_privatelink\_subnet](#output\_ptrn\_privatelink\_subnet) | n/a |

## Usage Deploy module Iaas WebApp Patterns

```Scope
// Scope Deploy module Iaas WebApp Patterns
//***************************************************************************************************
The module Iaas WebApp Patterns was created in orde to integrate the differentes components for consume a web applicacion hosted in windows VM´s  with the security requirements, in the following pattern we will deploy an Application Gateway like front-end for external and internal webapp consumption, a windows VM to hosted the webap, an azure sql to save the webapp data. Azure Cache for Redis, SQL elastic pools and azure bastion are optional components in the Iaas pattern.  Azure bastion is only available to deploy in peninsula enviroments, also in case to desabled SQL elastic pools after being deployed is necessary to remove the databases from the elastic pool.
//***************************************************************************************************

```Jenkis Pipeline
// Certificates
//***************************************************************************************************
1. Get the valid external certificate .pfx format for the WebApp Windows VM, this certificate is will using in the Application Gateway Frond-End and the application container in windows VM for example IIS.

2 Enter in the page https://base64encode.org, upload the certificate .pfx format in encode files to base64 format option, then select encode button and finally download the txt file.

3. In Jenkins pipeline project create the credentials kind secret text, one called JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT and paste the txt file encode information. create another secret text called JENKINS_APP_GATEWAY_FRONTEND_TLS_PASS and enter the certificate private key.

4. In component factory repository you need to guarantee in pattern/scripts the funcions.sh script, and you need to guarantee in pattern/script/pattern_main.sh in terraform pattern plan the following instruction: source ./scripts/functions.sh appgw_cert.

5. Upload the certificate -pfx format in the webapp container and asign the port 443 or protocol HTTPS.

6. Create the dns external and internal with the Application Gateway public ip. 

7. The same certificate en step 1 needs to be using in the Application Gateway and Winddows VM app container for example IIS. In the patter module usage you send the dns created with the subjet name certificate for the webapp in variable ptrn_iaas_webapp_app_gateway_backend_host_name and variable ptrn_iaas_webapp_app_gateway_http_listener_hostname .

```terraform
//1. Deploy module Iaas WebApp Pattern with backup, redis cache, bastion and elastic pool modules optional enable or desabled
//***************************************************************************************************
module "ptrn_iaas_webapp" {
source                                                            = "../dn-tads_tf-azure-component-library/patterns/ptrn_iaas_webapp_gov"
env                                                               = var.env
postfix                                                           = "iaas-ptrn"
location                                                          = var.location
suffix                                                            = var.suffix
tags                                                              = var.tags
ptrn_iaas_webapp_core_rg_network_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
ptrn_iaas_webapp_core_rg_vnet_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name 
ptrn_iaas_webapp_core_rg_logging_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
ptrn_iaas_webapp_core_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
ptrn_iaas_webapp_cl_windows_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.workspace_id
ptrn_iaas_webapp_core_log_analytics_workspace_name                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
ptrn_iaas_webapp_core_rg_vnet_id                                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
ptrn_iaas_webapp_core_log_analytics_workspace_primary_shared_key  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.primary_shared_key
ptrn_iaas_webapp_core_route_table_id                              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
ptrn_iaas_webapp_core_rg_data_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
ptrn_iaas_webapp_subnet_address_prefixes                          = ["10.61.133.208/28"]
ptrn_iaas_sql_subnet_address_prefixes                             = ["10.61.133.224/28"]
ptrn_iaas_webapp_app_gateway_subnet_address_prefix                = ["10.61.133.160/27"]
ptrn_iaas_webapp_set_private_ip_listener                          = true # true peninsula / false Island
ptrn_iaas_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
ptrn_iaas_webapp_app_gateway_http_listener_hostname               = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_backend_host_name                    = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_nsg_flow_log_postfix                 = "appgw"
ptrn_iaas_webapp_app_gateway_pick_host_name                       = false
ptrn_iaas_webapp_app_gateway_pick_host_backend                    = true
ptrn_iaas_webapp_app_gateway_probe_path                           = "/"
ptrn_iaas_webapp_azure_bastion_enable                             = true # deploy required in peninsula / false in island
ptrn_iaas_webapp_azure_bastion_subnet_prefix                      = "20.141.52.148"
ptrn_iaas_webapp_windows_vm_deploy_rg                             = true
ptrn_iaas_webapp_windows_vm_enable_backup                         = true
ptrn_iaas_webapp_cl_windows_vm_image_id                           = "/subscriptions/06ccb1fb-ef2a-4326-b4ac-b711af550383/resourceGroups/rg-nprd-pr-gov-ss-image_gallery/providers/Microsoft.Compute/galleries/ignprdprgovssgvnp/images/image-2019-r1-std"
ptrn_iaas_webapp_cl_windows_vm_app_name                           = "webappiaaspattern"
ptrn_iaas_webapp_cl_windows_computer_name                         = "webappvm1"
ptrn_iaas_webapp_cl_windows_vm_admin_user                         = "adminame"
ptrn_iaas_webapp_cl_windows_vm_admin_pass                         = "Abc1234567890"
ptrn_iaas_webapp_windows_vm_domain_name                           = var.ptrn_iaas_webapp_windows_vm_domain_name
ptrn_iaas_webapp_windows_vm_ou_path                               = var.ptrn_iaas_webapp_windows_vm_ou_path
ptrn_iaas_webapp_windows_vm_domain_user_upn                       = var.ptrn_iaas_webapp_windows_vm_domain_user_upn
ptrn_iaas_webapp_windows_vm_domain_password                       = var.PTRN_IAAS_WEBAPP_WINDOWS_VM_DOMAIN_PASSWORD
ptrn_iaas_webapp_cl_windows_vm_availability_zone                  = "2"
ptrn_iaas_webapp_windows_vm_bastion_enable                        = true
ptrn_iaas_webapp_windows_vm_deploy_subnet_nsg                     = true
ptrn_iaas_webapp_windows_vm_enable_devops_agent                   = false
ptrn_iaas_webapp_azure_sql_server_postfix                         = "global"
ptrn_iaas_webapp_azure_sql_server_administrator                   = "sqladmin"
ptrn_iaas_webapp_azure_sql_server_password                        = "Portal123456!"
ptrn_iaas_webapp_azure_sql_database_postfix                       = "globaldb"
ptrn_iaas_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_iaas_webapp_azure_sql_elastic_pool_enable in false dont send values for variable sku ptrn_iaas_webapp_azure_sql_database_sku
ptrn_iaas_webapp_azure_sql_elastic_pool_enable                    = true # true deploy module / false not deploy module
ptrn_iaas_webapp_azure_sql_elastic_pool_postfix                   = "globaldb"
ptrn_iaas_webapp_redis_cache_enable                               = true # true deploy module / false not deploy module
ptrn_iaas_webapp_redis_cache_postfix                              = "WebApp1"
ptrn_iaas_webapp_redis_cache_allowed_subnets                      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_login_username                  = "xxxxx@kpmg"
ptrn_iaas_webapp_azure_sql_server_object_id                       = ""
ptrn_iaas_webapp_storage_account_nsg_flow_log_id                  = var.ptrn_iaas_webapp_storage_account_nsg_flow_log_id
ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets                    = var.ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets
}
//***************************************************************************************************
```

```terraform
//2. Deploy module Iaas WebApp Pattern with key vault to save Application Gateway certificates and Managed Identity asigned
//***************************************************************************************************
//Get the current client config
//***************************************************************************************************
data "azurerm_client_config" "current" {}

//Get the Principle(Object) Id of Application Gateway's Managed Identity
//***************************************************************************************************
resource "azurerm_user_assigned_identity" "appgateway_keyvault_integration" {
  name                = "ptrn-iaas-webap-pappgwy-msi"
  location            = var.location
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
}

//Deploy Key vault
//Note: KeyVault Adminstrator role needs to be granted to SPN on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//Note:  KeyVault Secrets user/crypto user/certificates officer role needs to be granted to Application Gateway's Managed Identitity on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//***************************************************************************************************
module "cl_keyvault" {
  source                                   = "../dn-tads_tf-azure-component-library/components/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  suffix                                   = var.suffix
  tags                                     = var.tags
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_keyvault_nacl_allowed_ips             = ["199.206.0.0/15"]
  // ToDo: Remove app gateway subnet if dependency fails
  cl_keyvault_nacl_allowed_subnets         = [module.ptrn_iaas_webapp.ptrn_privatelink_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [module.ptrn_iaas_webapp.ptrn_privatelink_subnet.id]
}

//Add secrets/certificates to keyvault
//***************************************************************************************************
resource "azurerm_key_vault_certificate" "appgateway_cert" {
  name         = "ptrn-iaas-webapp-appgateway-cert"
  key_vault_id = module.cl_keyvault.cl_keyvault.id

  certificate {
    contents = filebase64(var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA)
    password = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  }

  certificate_policy {
    issuer_parameters {
      name = "Unknown"
    }

    key_properties {
      exportable = true
      key_size   = 2048
      key_type   = "RSA"
      reuse_key  = false
    }

    secret_properties {
      content_type = "application/x-pkcs12"
    }
  }
}

//Deploy Iaas pattern webapp
//***************************************************************************************************
module "ptrn_iaas_webapp" {
source                                                            = "../dn-tads_tf-azure-component-library/patterns/ptrn_iaas_webapp_gov"
env                                                               = var.env
postfix                                                           = "iaas-ptrn"
location                                                          = var.location
suffix                                                            = var.suffix
tags                                                              = var.tags
ptrn_iaas_webapp_core_rg_network_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
ptrn_iaas_webapp_core_rg_vnet_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name 
ptrn_iaas_webapp_core_rg_logging_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
ptrn_iaas_webapp_core_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
ptrn_iaas_webapp_cl_windows_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.workspace_id
ptrn_iaas_webapp_core_log_analytics_workspace_name                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
ptrn_iaas_webapp_core_rg_vnet_id                                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
ptrn_iaas_webapp_core_log_analytics_workspace_primary_shared_key  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.primary_shared_key
ptrn_iaas_webapp_core_route_table_id                              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
ptrn_iaas_webapp_core_rg_data_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
ptrn_iaas_webapp_subnet_address_prefixes                          = ["10.61.133.208/28"]
ptrn_iaas_sql_subnet_address_prefixes                             = ["10.61.133.224/28"]
ptrn_iaas_webapp_app_gateway_subnet_address_prefix                = ["10.61.133.160/27"]
ptrn_iaas_webapp_set_private_ip_listener                          = true # true peninsula / false Island
ptrn_iaas_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
ptrn_iaas_webapp_app_gateway_http_listener_hostname               = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_backend_host_name                    = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_nsg_flow_log_postfix                 = "appgw"
ptrn_iaas_webapp_app_gateway_pick_host_name                       = false
ptrn_iaas_webapp_app_gateway_pick_host_backend                    = true
ptrn_iaas_webapp_app_gateway_probe_path                           = "/"
ptrn_iaas_webapp_azure_bastion_enable                             = true # deploy required in peninsula / false in island
ptrn_iaas_webapp_azure_bastion_subnet_prefix                      = "20.141.52.148"
ptrn_iaas_webapp_windows_vm_deploy_rg                             = true
ptrn_iaas_webapp_windows_vm_enable_backup                         = true
ptrn_iaas_webapp_cl_windows_vm_image_id                           = "/subscriptions/06ccb1fb-ef2a-4326-b4ac-b711af550383/resourceGroups/rg-nprd-pr-gov-ss-image_gallery/providers/Microsoft.Compute/galleries/ignprdprgovssgvnp/images/image-2019-r1-std"
ptrn_iaas_webapp_cl_windows_vm_app_name                           = "webappiaaspattern"
ptrn_iaas_webapp_cl_windows_computer_name                         = "webappvm1"
ptrn_iaas_webapp_cl_windows_vm_admin_user                         = "adminame"
ptrn_iaas_webapp_cl_windows_vm_admin_pass                         = "Abc1234567890"
ptrn_iaas_webapp_windows_vm_domain_name                           = var.ptrn_iaas_webapp_windows_vm_domain_name
ptrn_iaas_webapp_windows_vm_ou_path                               = var.ptrn_iaas_webapp_windows_vm_ou_path
ptrn_iaas_webapp_windows_vm_domain_user_upn                       = var.ptrn_iaas_webapp_windows_vm_domain_user_upn
ptrn_iaas_webapp_windows_vm_domain_password                       = var.PTRN_IAAS_WEBAPP_WINDOWS_VM_DOMAIN_PASSWORD
ptrn_iaas_webapp_cl_windows_vm_availability_zone                  = "2"
ptrn_iaas_webapp_windows_vm_bastion_enable                        = true
ptrn_iaas_webapp_windows_vm_deploy_subnet_nsg                     = true
ptrn_iaas_webapp_windows_vm_enable_devops_agent                   = false
ptrn_iaas_webapp_azure_sql_server_postfix                         = "global"
ptrn_iaas_webapp_azure_sql_server_administrator                   = "sqladmin"
ptrn_iaas_webapp_azure_sql_server_password                        = "Portal123456!"
ptrn_iaas_webapp_azure_sql_database_postfix                       = "globaldb"
ptrn_iaas_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_iaas_webapp_azure_sql_elastic_pool_enable in false dont send values for variable sku ptrn_iaas_webapp_azure_sql_database_sku
ptrn_iaas_webapp_azure_sql_elastic_pool_enable                    = true # true deploy module / false not deploy module
ptrn_iaas_webapp_azure_sql_elastic_pool_postfix                   = "globaldb"
ptrn_iaas_webapp_redis_cache_enable                               = true # true deploy module / false not deploy module
ptrn_iaas_webapp_redis_cache_postfix                              = "WebApp1"
ptrn_iaas_webapp_redis_cache_allowed_subnets                      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_login_username                  = "xxxxx-@kpmg"
ptrn_iaas_webapp_azure_sql_server_object_id                       = ""
ptrn_iaas_webapp_storage_account_nsg_flow_log_id                  = var.ptrn_iaas_webapp_storage_account_nsg_flow_log_id
ptrn_iaas_webapp_app_gateway_identity_ids                         = [azurerm_user_assigned_identity.appgateway_keyvault_integration.id]
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_keyvault_id        = azurerm_key_vault_certificate.appgateway_cert.secret_id
ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets                    = var.ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets
}
//***************************************************************************************************
```
<!-- END_TF_DOCS -->
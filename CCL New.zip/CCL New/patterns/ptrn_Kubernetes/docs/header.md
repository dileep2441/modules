# Azure Kubernetes Service Pattern 

This is the Azure Kubernetes Service Pattern. It'll deploy the following Components:
* Application Gateway
* Kubernetes Cluster
* Kubernetes system  node pool
* Optional Kubernetes user node pool
* Azure Container Registry
* Optional Azure SQL Database
* Optional Cosmosdb
* Optional Bastion
* Optional Windows VM

It will also deploy other components such subnet kubernetes cluster node pool, private endpoints network for intercomunication between components.
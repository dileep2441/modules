
## Usage

```terraform
//**********************************************************************************************
module "identity" {
    source                                                  = "../dn-tads_tf-azure-component-library/government/core/core_us_gov_identity"
    env                                                     = var.env
    postfix                                                 = var.postfix
    location                                                = var.location
    hub_env                                                 = var.env
    suffix                                                  = var.suffix
    tags                                                    = var.tags
    identity_vnet_address_space                             = var.identity_vnet_address_space
    identity_vnet_dns_servers                               = var.identity_vnet_dns_servers
    identity_dns_lan_sub_address_prefix                     = var.identity_dns_lan_sub_address_prefix  
    identity_dns_mgmt_sub_address_prefix                    = var.identity_dns_mgmt_sub_address_prefix
    identity_dc_sub_address_prefix                          = var.identity_dc_sub_address_prefix
    identity_ad_sync_sub_address_prefix                     = var.identity_ad_sync_sub_address_prefix
    identity_deploy_private_link_subnet                     = true
    identity_private_link_subnet_address_prefixes           = var.identity_private_link_subnet_address_prefixes  
    identity_private_link_subnet_service_endpoints          = var.identity_private_link_subnet_service_endpoints
    identity_dc_vm_computer_name                            = var.identity_dc_vm_computer_name
    identity_dc_vm_image_id                                 = var.identity_dc_vm_image_id 
    identity_dc_vm_admin_user                               = var.identity_dc_vm_admin_user 
    identity_dc_vm_admin_pass                               = var.identity_dc_vm_admin_pass 
    identity_dc_vm_size                                     = var.identity_dc_vm_size 
    identity_dc_vm_os_disk_disk_size_gb                     = var.identity_dc_vm_os_disk_disk_size_gb 
    identity_dc_vm_logging_disk_size                        = var.identity_dc_vm_logging_disk_size
    identity_dc_vm_data_disk_size                           = var.identity_dc_vm_data_disk_size
    identity_to_ihub_peering_network_id                     = var.identity_to_ihub_peering_network_id
    identity_to_sharedsvcs_peering_network_id               = var.identity_to_sharedsvcs_peering_network_id
    identity_bastion_sub_address_prefix                     = var.identity_bastion_sub_address_prefix 
    identity_rg_security_enable                             = true
    identity_keyvault_enable                                = false #remove temporally
    identity_private_link_subnet_enforce_endpoint_network_policies = true
    #identity_keyvault_nacl_allowed_subnets                     = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-sharedsvc-vnet/subnets/nprd-pr-sharedghr-kubernetes-nodes-sn"]
    #identity_keyvault_nacl_allowed_ips                     = ["199.207.253.96","199.206.0.0/15","199.207.253.101"]
    identity_keyvault_deploy_private_dns_zone               = true


    

    identity_ad_sync_vm_computer_name                       = var.identity_ad_sync_vm_computer_name
    identity_ad_sync_vm_image_id                            = var.identity_ad_sync_vm_image_id 
    identity_ad_sync_vm_admin_user                          = var.identity_ad_sync_vm_admin_user 
    identity_ad_sync_vm_admin_pass                          = var.identity_ad_sync_vm_admin_pass 
    identity_ad_sync_vm_size                                = var.identity_ad_sync_vm_size 
    identity_default_internet_route_peninsula_next_hop_ip   = var. identity_default_internet_route_peninsula_next_hop_ip
    identity_dns_vm_deploy_rg                               = var.identity_dns_vm_deploy_rg
    identity_dns_vm_deploy_subnet_nsg                       = var.identity_dns_vm_deploy_subnet_nsg
    identity_dns_vm_publisher                               = var.identity_dns_vm_publisher
    identity_dns_vm_offer                                   = var.identity_dns_vm_offer 
    identity_dns_vm_sku                                     = var.identity_dns_vm_sku 
    identity_dns_vm_computer_name                           = var.identity_dns_vm_computer_name 
   # identity_dns_vm_license_type                            = var.identity_dns_vm_license_type
    identity_dns_vm_version                                 = var.identity_dns_vm_version
    identity_dns_vm_os_disk_caching                         = var.identity_dns_vm_os_disk_caching
    identity_dns_vm_os_disk_storage_account_type            = var.identity_dns_vm_os_disk_storage_account_type
    identity_dns_vm_os_disk_disk_size_gb                    = var.identity_dns_vm_os_disk_disk_size_gb
    identity_dns_vm_os_disk_write_accelerator_enabled       = var.identity_dns_vm_os_disk_write_accelerator_enabled
    identity_dns_vm_os_ultra_ssd_enabled                    = var.identity_dns_vm_os_ultra_ssd_enabled 
    identity_dns_vm_os                                      = var.identity_dns_vm_os
    identity_dns_vm_enable_automatic_updates                = var.identity_dns_vm_enable_automatic_updates
    identity_dns_vm_provision_vm_agent                      = var.identity_dns_vm_provision_vm_agent
    identity_dns_vm_timezone                                = var.identity_dns_vm_timezone
    identity_dns_vm_enable_encryption_at_host               = var.identity_dns_vm_enable_encryption_at_host
    identity_dns_vm_enable_backup                           = var.identity_dns_vm_enable_backup 
    identity_dns_vm_enable_log_analytics_settings           = var.identity_dns_vm_enable_log_analytics_settings 
    identity_dns_vm_enable_antimalware_protection           = var.identity_dns_vm_enable_antimalware_protection 
    identity_dns_vm_enable_domain_join                      = var.identity_dns_vm_enable_domain_join
    identity_dns_vm_enable_guest_config                     = var.identity_dns_vm_enable_guest_config
    identity_dns_vm_bastion_enable                          = var.identity_dns_vm_bastion_enable
    identity_dns_vm_deploy_nsg_rules                        = var.identity_dns_vm_deploy_nsg_rules
    identity_dns_vm_size                                    = var.identity_dns_vm_size
    identity_dns_vm_admin_user                              = var.identity_dns_vm_admin_user
    identity_dns_vm_admin_pass                              = var.identity_dns_vm_admin_pass
    identity_dns_vm_from_marketplace                        = var.identity_dns_vm_from_marketplace
    identity_dns_vm_boot_sa_postfix                         = var.identity_dns_vm_boot_sa_postfix
    identity_dns_vm_nsg_sa_postfix                          = var.identity_dns_vm_nsg_sa_postfix
    identity_dns_vm_user_defined_nsg_rules                  = var.identity_dns_vm_user_defined_nsg_rules
    
}
//**********************************************************************************************
    
    
// Complete the Peerring SharedServices to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "sharedsvcs_peering_core" {
  provider                     = azurerm.shs
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_shared_services_resource_group_map, var.env)  
  virtual_network_name         = lookup(local.core_shared_services_network_name_map, var.env) 
  remote_virtual_network_id    = module.identity.identity_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = false
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = false

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
}
//**********************************************************************************************

// Complete Peering IHub to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "ihub_peering_spoke" {
  provider                     = azurerm.ihub 
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_ihub_resource_group_name_map, var.env) 
  virtual_network_name         = lookup(local.core_ihub_resource_network_name_map, var.env)
  remote_virtual_network_id    = module.identity.identity_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = true

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
}
//**********************************************************************************************
```
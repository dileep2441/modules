
## Usage

```terraform
data "azurerm_virtual_network" "core_data_shdsvc_vnet_ihub" {
  count               = var.ihub_deploy_ss_peering ? 1 : 0
  provider            = azurerm.shs
  name                = "nprd-pr-shdsvsch-vnet"
  resource_group_name = "rg-nprd-pr-shdsvsch-network"
}
data "azurerm_virtual_network" "core_data_idty_vnet_ihub" {
  count               = var.ihub_deploy_idty_peering ? 1 : 0
  provider            = azurerm.idty
  name                = "nprd-pr-idtych-vnet"
  resource_group_name = "rg-nprd-pr-idtych-network"
}


// Deploy the Latam Peninsula Core Platform in a Box
//********************************************************************************************
 module "core_latam_ch_peninsula_ihub" {
    source                                                      = "../dn-tads_tf-azure-component-library/core/core_latam_ch_peninsula_ihub"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location 
    hub_env                                                     = var.env                                 
    tags                                                        = var.tags
    ihub_vgw_lgw_conn_shared_key                                = var.SHARED_KEY_LATAM_CH
    ihub_vnet_dns_servers                                       = var.ihub_vnet_dns_servers
    ihub_vnet_address_space                                     = var.ihub_vnet_address_space
    ihub_gateway_sub_address_prefix                             = var.ihub_gateway_sub_address_prefix
    ihub_internal_sub_address_prefix                            = var.ihub_internal_sub_address_prefix
    ihub_mgmt_sub_address_prefix                                = var.ihub_mgmt_sub_address_prefix
    ihub_perimeter_sub_address_prefix                           = var.ihub_perimeter_sub_address_prefix
    ihub_private_link_subnet_address_prefixes                   = var.ihub_private_link_subnet_address_prefixes
    ihub_azure_defender_resources                               = var.ihub_azure_defender_resources
    #Peering
    ihub_shared_services_peering_network_id                     = var.ihub_deploy_ss_peering ? data.azurerm_virtual_network.core_data_shdsvc_vnet_ihub[0].id : null
    ihub_idty_peering_network_id                                = var.ihub_deploy_idty_peering ? data.azurerm_virtual_network.core_data_idty_vnet_ihub[0].id : null
    ihub_deploy_ss_peering                                      = var.ihub_deploy_ss_peering 
    ihub_deploy_idty_peering                                    = var.ihub_deploy_idty_peering 
    #key vault
    ihub_keyvault_postfix                                       = var.ihub_keyvault_postfix
    ihub_keyvault_nacl_allowed_ips                              = concat(var.ihub_keyvault_nacl_allowed_ips, [var.GITHUBIP])
    #ihub_keyvault_private_dns_zone_ids                          =
    #Route table
    ihub_route_table_loopback_fw1_address_prefix                 = var.ihub_route_table_loopback_fw1_address_prefix
    ihub_route_table_loopback_fw2_address_prefix                 = var.ihub_route_table_loopback_fw2_address_prefix
    #palo alto internal LB
    ihub_internal_lb_private_ip_address                          = var.ihub_internal_lb_private_ip_address    
    #palo alto VMs
    ihub_PA_LOCAL_USER                                           = var.PA_USER_LATAM_CH
    ihub_PA_LOCAL_PASS                                           = var.PA_PASSWORD_LATAM_CH  
    ihub_pa_vm_management_privateip                              = var.ihub_pa_vm_management_privateip
    ihub_pa_vm_perimeter_privateip                               = var.ihub_pa_vm_perimeter_privateip
    ihub_pa_vm_internal_privateip                                = var.ihub_pa_vm_internal_privateip
    availability_zones                                           = var.ihub_pa_vm_availability_zones
}
//**********************************************************************************************
```
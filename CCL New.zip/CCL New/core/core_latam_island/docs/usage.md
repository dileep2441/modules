## Usage

#### Without Core Key Vault enabled 
```terraform
module "core_latam_island" {
    source                          = "../tf-azure-component-library/core/core_latam_island"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    core_vnet_address_space         = ["172.19.0.0/16"]
}
```

#### With Core Key Vault enabled 
```terraform
module "core_latam_island" {
  source                                                              = "../tf-azure-component-library/core/core_latam_island"
  env                                                                 = var.env
  postfix                                                             = var.postfix
  location                                                            = var.location
  core_vnet_address_space                                             = ["10.0.0.0/16"]

  
  core_rg_security_enable                                             = true
  core_keyvault_enable                                                = true
  core_private_link_subnet_address_prefixes                           = var.subnet_address_prefixes
  core_private_link_subnet_enforce_endpoint_network_policies          = true
  core_keyvault_nacl_allowed_ips                                      = ["199.207.253.96","199.206.0.0/15","199.207.253.101"]
}
```
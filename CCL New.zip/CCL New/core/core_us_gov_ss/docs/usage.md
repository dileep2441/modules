
## Usage

```terraform
// Deploy Gov Cloud Shared Services
//**********************************************************************************************
module "sharedsvcs_us_gov_ss" {
    source                          = "../dn-tads_tf-azure-component-library/core/core_us_gov_ss" #"../dn-tads_tf-azure-gov_component-library/core/core_us_gov_ss"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    hub_env                         = var.env
    suffix                          = var.suffix
    dns_location                    = var.dns_location
    tags                            = var.tags
    #Network
    sharedsvcs_vnet_address_space                                    = var.sharedsvcs_vnet_address_space
    sharedsvcs_vnet_dns_servers                                      = var.sharedsvcs_vnet_dns_servers
    sharedsvcs_mgmt_sub_address_prefix                               = var.sharedsvcs_mgmt_sub_address_prefix
    sharedsvcs_bastion_sub_address_prefix                            = var.sharedsvcs_bastion_sub_address_prefix
    sharedsvcs_ivanti_sub_address_prefix                             = var.sharedsvcs_ivanti_sub_address_prefix
    sharedsvcs_private_link_seondary_subnet_address_prefixes         = var.sharedsvcs_private_link_seondary_subnet_address_prefixes
    sharedsvcs_deploy_secondary_private_link_subnet                  = var.sharedsvcs_deploy_secondary_private_link_subnet
    sharedsvcs_azure_defender_resources                              = var.sharedsvcs_azure_defender_resources
    sharedsvcs_private_link_subnet_service_endpoints                 = var.sharedsvcs_private_link_subnet_service_endpoints
    sharedsvcs_to_idty_peering_network_id                            = var.sharedsvcs_to_idty_peering_network_id
    sharedsvcs_private_link_subnet_enforce_endpoint_network_policies = var.sharedsvcs_private_link_subnet_enforce_endpoint_network_policies
    sharedsvcs_deploy_private_link_subnet                            = var.sharedsvcs_deploy_private_link_subnet 
    sharedsvcs_private_link_subnet_address_prefixes                  = var.sharedsvcs_private_link_subnet_address_prefixes
    sharedsvcs_to_ihub_peering_network_id                            = var.sharedsvcs_to_ihub_peering_network_id
    sharedsvcs_to_avd_peering_network_id                             = var.sharedsvcs_to_avd_peering_network_id
    ihub_internal_lb_private_ip_address                              = var.ihub_internal_lb_private_ip_address
    sharedsvcs_nsg_flow_log_postfix                                  = var.sharedsvcs_nsg_flow_log_postfix
    sharedsvcs_bastion_nsg_flow_log_postfix                          = var.sharedsvcs_bastion_nsg_flow_log_postfix
    sharedsvcs_private_dns_zone_id_map                               = var.sharedsvcs_private_dns_zone_id_map
    sharedsvcs_deploy_cross_vnet_global_peering_ss_prod_idty_dr      = var.sharedsvcs_deploy_cross_vnet_global_peering_ss_prod_idty_dr
    sharedsvcs_deploy_cross_vnet_global_peering_ss_dr_idty_prod      = var.sharedsvcs_deploy_cross_vnet_global_peering_ss_dr_idty_prod
    sharedsvcs_to_idty_prod_peering_network_id                        = var.sharedsvcs_to_idty_prod_peering_network_id 
    sharedsvcs_to_idty_dr_peering_network_id                         = var.sharedsvcs_to_idty_dr_peering_network_id  
    sharedsvcs_deploy_avd_peering                                       = var.sharedsvcs_deploy_avd_peering 
    sharedsvcs_deploy_ihub_peering                                      = var.sharedsvcs_deploy_ihub_peering 
    sharedsvcs_deploy_idty_peering                                      = var.sharedsvcs_deploy_idty_peering
    sharedsvcs_deploy_prod_ss_to_dr_ss_peering                          = var.sharedsvcs_deploy_prod_ss_to_dr_ss_peering
    sharedsvcs_deploy_dr_ss_to_prod_ss_peering                          = var.sharedsvcs_deploy_dr_ss_to_prod_ss_peering
    sharedsvcs_prod_to_ss_dr_peering_network_id                         = var.sharedsvcs_prod_to_ss_dr_peering_network_id
    sharedsvcs_dr_to_ss_prod_peering_network_id                         = var.sharedsvcs_dr_to_ss_prod_peering_network_id
    sharedsvcs_backup_deploy_private_dns_zone                           = var.sharedsvcs_backup_deploy_private_dns_zone  
    sharedsvcs_keyvault_deploy_private_dns_zone                         = var.sharedsvcs_keyvault_deploy_private_dns_zone
    sharedsvcs_nsg_sa_deploy_private_dns_zone                           = var.sharedsvcs_nsg_sa_deploy_private_dns_zone 
    sharedsvcs_storage_account_file_share_allowed_pe_subnet_ids         = var.sharedsvcs_storage_account_file_share_allowed_pe_subnet_ids   
    sharedsvcs_storage_account_file_share_allowed_vnet_subnet_ids       = var.sharedsvcs_storage_account_file_share_allowed_vnet_subnet_ids
    sharedsvcs_storage_account_file_share_allowed_ips                   = var.sharedsvcs_storage_account_file_share_allowed_ips 
    sharedsvcs_deploy_management_teams                                  = var.sharedsvcs_deploy_management_teams
    sharedsvcs_deploy_management_sharepoint                             = var. sharedsvcs_deploy_management_sharepoint
    sharedsvcs_deploy_vm_password                                        = var.sharedsvcs_deploy_vm_password
    
    sharedsvcs_deploy_forensic                                  = var.sharedsvcs_deploy_forensic
    sharedsvcs_forensic_vm_computer_name_admin_username         = var.sharedsvcs_forensic_vm_computer_name_admin_username
    sharedsvcs_forensic_vm_computer_name                        = var.sharedsvcs_forensic_vm_computer_name
    sharedsvcs_forensic_vm_image_id                             = var.sharedsvcs_forensic_vm_image_id 
    sharedsvcs_forensic_vm_size                                 = var.sharedsvcs_forensic_vm_size
    sharedsvcs_forensic_vm_os_disk_disk_size_gb                 = var.sharedsvcs_forensic_vm_os_disk_disk_size_gb
    sharedsvcs_forensic_vm_second_disk_size                     = var.sharedsvcs_forensic_vm_second_disk_size     
    
    #KeyVault
    sharedsvcs_deploy_kv_secrets                                              = var.sharedsvcs_deploy_kv_secrets
    sharedsvcs_enable_domain_join                                             = var.sharedsvcs_enable_domain_join
    sharedsvcs_rg_security_enable                                             = var.sharedsvcs_rg_security_enable    
    sharedsvcs_keyvault_enable                                                = var. sharedsvcs_keyvault_enable 
    sharedsvcs_keyvault_nacl_allowed_subnets                                  = var.sharedsvcs_keyvault_nacl_allowed_subnets
    sharedsvcs_keyvault_nacl_allowed_ips                                      = var.sharedsvcs_keyvault_nacl_allowed_ips

    
    #KV Secrets
    sharedsvcs_bigfix_vm_computer_name_admin_username               = var.sharedsvcs_bigfix_vm_computer_name_admin_username
    sharedsvcs_management_intune_vm_computer_name_admin_username    = var.sharedsvcs_management_intune_vm_computer_name_admin_username
    sharedsvcs_management_exchange_vm_computer_name_admin_username  = var.sharedsvcs_management_exchange_vm_computer_name_admin_username
    sharedsvcs_management_powerbi_vm_computer_name_admin_username   = var.sharedsvcs_management_powerbi_vm_computer_name_admin_username
    sharedsvcs_management_avd_vm_computer_name_admin_username       = var.sharedsvcs_management_avd_vm_computer_name_admin_username
    sharedsvcs_management_purview_vm_computer_name_admin_username   = var.sharedsvcs_management_purview_vm_computer_name_admin_username
    sharedsvcs_management_idty_vm_computer_name_admin_username      = var.sharedsvcs_management_idty_vm_computer_name_admin_username
    sharedsvcs_mgmt_vm_computer_name_admin_username                 = var.sharedsvcs_mgmt_vm_computer_name_admin_username
    sharedsvcs_personalization_vm_computer_name_admin_username      = var.sharedsvcs_personalization_vm_computer_name_admin_username
    sharedsvcs_sql_vm_computer_name_admin_username                  = var.sharedsvcs_sql_vm_computer_name_admin_username
    sharedsvcs_management_sharepoint_vm_computer_name_admin_username  = var.sharedsvcs_management_sharepoint_vm_computer_name_admin_username
    sharedsvcs_management_teams_vm_computer_name_admin_username       = var.sharedsvcs_management_teams_vm_computer_name_admin_username

    sharedsvcs_log_analytics_supported              = var.sharedsvcs_log_analytics_supported 
    sharedsvcs_deploy_availability_set              = var.sharedsvcs_deploy_availability_set
    sharedsvcs_avail_zones_supported                = var.sharedsvcs_avail_zones_supported
    sharedsvcs_alt_log_analytics_workspace          = var.sharedsvcs_alt_log_analytics_workspace
    sharedsvcs_alt_log_analytics_workspace_name     = var.sharedsvcs_alt_log_analytics_workspace_name
    sharedsvcs_alt_log_analytics_workspace_id       = var.sharedsvcs_alt_log_analytics_workspace_id
    sharedsvcs_alt_log_analytics_vm_workspace_id    = var.sharedsvcs_alt_log_analytics_vm_workspace_id
    sharedsvcs_alt_log_analytics_workspace_primary_shared_key = var.sharedsvcs_alt_log_analytics_workspace_primary_shared_key

    #Ivanti
    sharedsvcs_ivanti_internal_load_balancer_count       = var.sharedsvcs_ivanti_internal_load_balancer_count
    sharedsvcs_internal_lb_private_ip_address            = var.sharedsvcs_internal_lb_private_ip_address
    sharedsvcs_internal_lb_probe_protocol                = var.sharedsvcs_internal_lb_probe_protocol
    sharedsvcs_internal_lb_mgmt_probe_port               = var.sharedsvcs_internal_lb_mgmt_probe_port
    sharedsvcs_internal_lb_personalization_probe_port    = var.sharedsvcs_internal_lb_personalization_probe_port
    sharedsvcs_internal_lb_sql_probe_port                = var.sharedsvcs_internal_lb_sql_probe_port
    sharedsvcs_internal_lb_rule_protocol                 = var.sharedsvcs_internal_lb_rule_protocol
    sharedsvcs_internal_lb_rule_fe_port                  = var.sharedsvcs_internal_lb_rule_fe_port
    sharedsvcs_internal_lb_rule_be_port                  = var.sharedsvcs_internal_lb_rule_be_port
    sharedsvcs_internal_sql_lb_rule_fe_port             = var.sharedsvcs_internal_sql_lb_rule_fe_port
    sharedsvcs_internal_sql_lb_rule_be_port             = var.sharedsvcs_internal_sql_lb_rule_be_port


    #bigFixVms
    sharedsvcs_deploy_bigfix                                             = var.sharedsvcs_deploy_bigfix
    sharedsvcs_bigfix_vm_computer_name                                  = var.sharedsvcs_bigfix_vm_computer_name //fix names
    sharedsvcs_bigfix_vm_image_id                                       = var.sharedsvcs_bigfix_vm_image_id
    sharedsvcs_bigfix_vm_size                                           = var.sharedsvcs_bigfix_vm_size
    sharedsvcs_bigfix_vm_os_disk_disk_size_gb                           = var.sharedsvcs_bigfix_vm_os_disk_disk_size_gb
    sharedsvcs_bigfix_vm_logging_disk_size                              = var.sharedsvcs_bigfix_vm_logging_disk_size
    sharedsvcs_bigfix_vm_data_disk_size                                 = var.sharedsvcs_bigfix_vm_data_disk_size

    #pentestVms
    sharedsvcs_deploy_pentest                                             = var.sharedsvcs_deploy_pentest
    sharedsvcs_pentest_vm_computer_name                                  = var.sharedsvcs_pentest_vm_computer_name //fix names
    sharedsvcs_pentest_vm_image_id                                       = var.sharedsvcs_pentest_vm_image_id
    sharedsvcs_pentest_vm_size                                           = var.sharedsvcs_pentest_vm_size
    sharedsvcs_pentest_vm_os_disk_disk_size_gb                           = var.sharedsvcs_pentest_vm_os_disk_disk_size_gb
    
    #MgmtVms
    sharedsvcs_deploy_management                                                 = var.sharedsvcs_deploy_management
    sharedsvcs_management_m365_vm_computer_name                                  = var.sharedsvcs_management_m365_vm_computer_name 
    sharedsvcs_management_m365_vm_image_id                                       = var.sharedsvcs_management_m365_vm_image_id
    sharedsvcs_management_m365_vm_size                                           = var.sharedsvcs_management_m365_vm_size
    sharedsvcs_management_m365_vm_os_disk_disk_size_gb                           = var.sharedsvcs_management_m365_vm_os_disk_disk_size_gb      
    
    sharedsvcs_deploy_management_idty                                            = var.sharedsvcs_deploy_management_idty
    sharedsvcs_management_idty_vm_computer_name                                  = var.sharedsvcs_management_idty_vm_computer_name 
    sharedsvcs_management_idty_vm_image_id                                       = var.sharedsvcs_management_idty_vm_image_id
    sharedsvcs_management_idty_vm_size                                           = var.sharedsvcs_management_idty_vm_size
    sharedsvcs_management_idty_vm_os_disk_disk_size_gb                           = var.sharedsvcs_management_idty_vm_os_disk_disk_size_gb
   
    
    sharedsvcs_deploy_management_purview                                        = var.sharedsvcs_deploy_management_purview
    sharedsvcs_management_purview_vm_computer_name                              = var.sharedsvcs_management_purview_vm_computer_name
    sharedsvcs_management_purview_vm_image_id                                   = var.sharedsvcs_management_purview_vm_image_id
    sharedsvcs_management_purview_vm_size                                       = var.sharedsvcs_management_purview_vm_size
    sharedsvcs_management_purview_vm_os_disk_disk_size_gb                       = var.sharedsvcs_management_purview_vm_os_disk_disk_size_gb 

    # # // powerbi Mgmt VMs
    sharedsvcs_deploy_management_powerbi                                        = var.sharedsvcs_deploy_management_powerbi
    sharedsvcs_management_powerbi_vm_computer_name                              = var.sharedsvcs_management_powerbi_vm_computer_name
    sharedsvcs_management_powerbi_vm_image_id                                   = var.sharedsvcs_management_powerbi_vm_image_id
    sharedsvcs_management_powerbi_vm_size                                       = var.sharedsvcs_management_powerbi_vm_size
    sharedsvcs_management_powerbi_vm_os_disk_disk_size_gb                       = var.sharedsvcs_management_powerbi_vm_os_disk_disk_size_gb 

    # # // avd Mgmt VMs
    sharedsvcs_deploy_management_avd                                        = var.sharedsvcs_deploy_management_avd
    sharedsvcs_management_avd_vm_computer_name                              = var.sharedsvcs_management_avd_vm_computer_name
    sharedsvcs_management_avd_vm_image_id                                   = var.sharedsvcs_management_avd_vm_image_id
    sharedsvcs_management_avd_vm_size                                       = var.sharedsvcs_management_avd_vm_size
    sharedsvcs_management_avd_vm_os_disk_disk_size_gb                       = var.sharedsvcs_management_avd_vm_os_disk_disk_size_gb 
    
    # # // exchange Mgmt VMs
    sharedsvcs_deploy_management_exchange                                   = var.sharedsvcs_deploy_management_exchange
    sharedsvcs_management_exchange_vm_computer_name                         = var.sharedsvcs_management_exchange_vm_computer_name
    sharedsvcs_management_exchange_vm_image_id                              = var.sharedsvcs_management_exchange_vm_image_id
    sharedsvcs_management_exchange_vm_size                                  = var.sharedsvcs_management_exchange_vm_size
    sharedsvcs_management_exchange_vm_os_disk_disk_size_gb                  = var.sharedsvcs_management_exchange_vm_os_disk_disk_size_gb

    # # // intune Mgmt VMs
    sharedsvcs_deploy_management_intune                                     = var.sharedsvcs_deploy_management_intune
    sharedsvcs_management_intune_vm_computer_name                           = var.sharedsvcs_management_intune_vm_computer_name
    sharedsvcs_management_intune_vm_image_id                                = var.sharedsvcs_management_intune_vm_image_id
    sharedsvcs_management_intune_vm_size                                    = var.sharedsvcs_management_intune_vm_size
    sharedsvcs_management_intune_vm_os_disk_disk_size_gb                    = var.sharedsvcs_management_intune_vm_os_disk_disk_size_gb


    #Ivanti Mgmt Vms
    sharedsvcs_deploy_ivantimgmt                                      = var.sharedsvcs_deploy_ivantimgmt
    sharedsvcs_mgmt_vm_computer_name                                  = var.sharedsvcs_mgmt_vm_computer_name
    sharedsvcs_mgmt_vm_image_id                                       = var.sharedsvcs_mgmt_vm_image_id
    sharedsvcs_mgmt_vm_size                                           = var.sharedsvcs_mgmt_vm_size
    sharedsvcs_mgmt_vm_os_disk_disk_size_gb                           = var.sharedsvcs_mgmt_vm_os_disk_disk_size_gb

    #personalization Vms
    sharedsvcs_deploy_persvm                                                     = var.sharedsvcs_deploy_persvm
    sharedsvcs_personalization_vm_computer_name                                  = var.sharedsvcs_personalization_vm_computer_name
    sharedsvcs_personalization_vm_image_id                                       = var.sharedsvcs_personalization_vm_image_id
    sharedsvcs_personalization_vm_size                                           = var.sharedsvcs_personalization_vm_size
    sharedsvcs_personalization_vm_os_disk_disk_size_gb                           = var.sharedsvcs_personalization_vm_os_disk_disk_size_gb

    #SQL Vms
    sharedsvcs_deploy_sqlvm                                          = var.sharedsvcs_deploy_sqlvm
    sharedsvcs_sql_vm_computer_name                                  = var.sharedsvcs_sql_vm_computer_name
    sharedsvcs_sql_vm_image_id                                       = var.sharedsvcs_sql_vm_image_id
    sharedsvcs_sql_vm_os_disk_disk_size_gb                           = var.sharedsvcs_sql_vm_os_disk_disk_size_gb
    sharedsvcs_sql_vm_data_disk1_size                                 = var.sharedsvcs_sql_vm_data_disk1_size
    sharedsvcs_sql_vm_data_disk2_size                                 = var.sharedsvcs_sql_vm_data_disk2_size
    sharedsvcs_sql_vm_data_disk3_size                                 = var.sharedsvcs_sql_vm_data_disk3_size
    sharedsvcs_sql_vm_data_disk4_size                                 = var.sharedsvcs_sql_vm_data_disk4_size
    
    #wsus Vms
    sharedsvcs_deploy_wsus                                            = var.sharedsvcs_deploy_wsus
    sharedsvcs_wsus_vm_computer_name                                  = var.sharedsvcs_wsus_vm_computer_name
    sharedsvcs_wsus_vm_app_name                                       = var.sharedsvcs_wsus_vm_app_name
    sharedsvcs_wsus_vm_image_id                                       = var.sharedsvcs_wsus_vm_image_id
    sharedsvcs_wsus_vm_size                                           = var.sharedsvcs_wsus_vm_size
    sharedsvcs_wsus_vm_admin_user                                     = var.sharedsvcs_wsus_vm_admin_user
    sharedsvcs_wsus_vm_os_disk_disk_size_gb                           = var.sharedsvcs_wsus_vm_os_disk_disk_size_gb
    sharedsvcs_wsus_vm_data_disk_size                                 = var.sharedsvcs_wsus_vm_data_disk_size
    sharedsvcs_wsus_vm_data_disk2_size                                = var.sharedsvcs_wsus_vm_data_disk2_size
    sharedsvcs_wsus_vm_private_ip                                     = var.sharedsvcs_wsus_vm_private_ip

    #jumpserver Vms
    sharedsvcs_deploy_jumpserver                                            = var.sharedsvcs_deploy_jumpserver
    sharedsvcs_jumpserver_vm_computer_name                                  = var.sharedsvcs_jumpserver_vm_computer_name
    sharedsvcs_jumpserver_vm_app_name                                       = var.sharedsvcs_jumpserver_vm_app_name
    sharedsvcs_jumpserver_vm_image_id                                       = var.sharedsvcs_jumpserver_vm_image_id
    sharedsvcs_jumpserver_vm_size                                           = var.sharedsvcs_jumpserver_vm_size
    sharedsvcs_jumpserver_vm_admin_user                                     = var.sharedsvcs_jumpserver_vm_admin_user
    sharedsvcs_jumpserver_vm_os_disk_disk_size_gb                           = var.sharedsvcs_jumpserver_vm_os_disk_disk_size_gb
    sharedsvcs_jumpserver_vm_data_disk_size                                 = var.sharedsvcs_jumpserver_vm_data_disk_size
    sharedsvcs_jumpserver_vm_private_ip                                     = var.sharedsvcs_jumpserver_vm_private_ip
    
    #shared vm vars
    sharedsvcs_vm_domain_name                                        = var.sharedsvcs_vm_domain_name
    sharedsvcs_vm_ou_path                                            = var.sharedsvcs_vm_ou_path
    sharedsvcs_vm_domain_user_upn                                    = var.sharedsvcs_vm_domain_user_upn
    sharedsvccs_vm_domain_password                                   = var.env == "nprd-pr" ? var.SHAREDSVCCS_VM_DOMAIN_PASSWORD_NONPROD : var.SHAREDSVCCS_VM_DOMAIN_PASSWORD_PROD

    #FileShare Vars
    sharedsvcs_deploy_fileshare                                      = var.sharedsvcs_deploy_fileshare
    sharedsvcs_storage_account_file_shares                           = var.sharedsvcs_storage_account_file_shares
    sharedsvcs_storage_account_tier                                  = var.sharedsvcs_storage_account_tier
    sharedsvcs_storage_account_kind                                  = var.sharedsvcs_storage_account_kind
    sharedsvcs_storage_account_private_dns_zone_file_ids             = var.sharedsvcs_storage_account_private_dns_zone_file_ids
    sharedsvcs_fileshare_vm_computer_name                            = var.sharedsvcs_fileshare_vm_computer_name
    sharedsvcs_fileshare_vm_app_name                                 = var.sharedsvcs_fileshare_vm_app_name
    sharedsvcs_fileshare_vm_image_id                                 = var.sharedsvcs_fileshare_vm_image_id
    sharedsvcs_fileshare_vm_size                                     = var.sharedsvcs_fileshare_vm_size
    sharedsvcs_fileshare_vm_admin_user                               = var.sharedsvcs_fileshare_vm_admin_user
    sharedsvcs_fileshare_vm_os_disk_disk_size_gb                     = var.sharedsvcs_fileshare_vm_os_disk_disk_size_gb
    sharedsvcs_fileshare_vm_data_disk_size                           = var.sharedsvcs_fileshare_vm_data_disk_size
    sharedsvcs_fileshare_vm_private_ip                               = var.sharedsvcs_fileshare_vm_private_ip

 #criblVms
        sharedsvcs_cribl_local_user                         = var.sharedsvcs_cribl_local_user
        sharedsvcs_cribl_network_interface_count            = var.sharedsvcs_cribl_network_interface_count
        cribl_worker_names                                  = var.cribl_worker_names
        cribl_master_names                                  = var.cribl_master_names
        cribl_master_private_ip_address_allocation          = var.cribl_master_private_ip_address_allocation
        cribl_worker_private_ip_address_allocation          = var.cribl_worker_private_ip_address_allocation
        cribl_backend_addesspool_associations_names         = var.cribl_backend_addesspool_associations_names
        sharedsvcs_internal_cribl_lb_private_ip_address    = var.sharedsvcs_internal_cribl_lb_private_ip_address
        cribl = {
            vm_size                 = var.cribl.vm_size
            vm_prefix               = var.cribl.vm_prefix
            vm_image_id             = var.cribl.vm_image_id
            vm_publisher            = var.cribl.vm_publisher
            vm_offer                = var.cribl.vm_offer
            vm_sku                  = var.cribl.vm_sku
            vm_version              = var.cribl.vm_version
            vm_storage_os_disk_size = var.cribl.vm_storage_os_disk_size
            vm_os                   = var.cribl.vm_os
            vm_from_marketplace     = var.cribl.vm_from_marketplace
            management_privateip    = var.cribl.management_privateip
        }
}
//**********************************************************************************************
```
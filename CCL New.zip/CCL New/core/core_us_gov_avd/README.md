<!-- BEGIN_TF_DOCS -->

# Azure AVD Platform Module
Azure Virtual Desktop (formerly Windows Virtual Desktop) is a service that gives users easy and secure access to their Virtualized Desktops and RemoteApps. AVD will host pools of VMs for full desktop virtualization and users to run required applications and tools.



## Resources

| Name | Type |
|------|------|
| [azurerm_network_security_group.hosts-nsg-sn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_watcher_flow_log.avd_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_private_dns_zone.avd_backup_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.avd_keyvault_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.avd_nsg_sa_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.avd_backup_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_dns_zone_virtual_network_link.avd_nsg_sa_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_dns_zone_virtual_network_link.keyvault_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_resource_group.avd_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.avd_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.avd_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.avd_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.AVD-to-IHub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.avd_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_storage_container.avd_nsg_sa_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_subnet.avd_hpool1_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.avd_hpool2_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.avd_hpool3_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.avd_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.hostpool1-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.hostpool2-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.hostpool3-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.avd_hpool1_rt_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.avd_hpool2_rt_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.avd_hpool3_rt_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_network.avd_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.avd_dr_peering_avd_prod](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.avd_prod_peering_avd_dr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering_avd_to_idt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering_avd_to_ihub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering_avd_to_sharedsvc](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_avd_alt_log_analytics_workspace"></a> [avd\_alt\_log\_analytics\_workspace](#input\_avd\_alt\_log\_analytics\_workspace) | n/a | `any` | n/a | yes |
| <a name="input_avd_alt_log_analytics_workspace_id"></a> [avd\_alt\_log\_analytics\_workspace\_id](#input\_avd\_alt\_log\_analytics\_workspace\_id) | n/a | `any` | n/a | yes |
| <a name="input_avd_alt_log_analytics_workspace_name"></a> [avd\_alt\_log\_analytics\_workspace\_name](#input\_avd\_alt\_log\_analytics\_workspace\_name) | n/a | `any` | n/a | yes |
| <a name="input_avd_backup_deploy_private_dns_zone"></a> [avd\_backup\_deploy\_private\_dns\_zone](#input\_avd\_backup\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the backup private endpoint. | `bool` | `false` | no |
| <a name="input_avd_deploy_private_link_subnet"></a> [avd\_deploy\_private\_link\_subnet](#input\_avd\_deploy\_private\_link\_subnet) | (Optional) A boolean to enable/disable the deployment of a private link subnet for the key vault. | `bool` | `true` | no |
| <a name="input_avd_dr_deploy_avd_prod_peering"></a> [avd\_dr\_deploy\_avd\_prod\_peering](#input\_avd\_dr\_deploy\_avd\_prod\_peering) | (Optional) boolean for enabling peering-avd-dr-to-avd-prod | `bool` | `false` | no |
| <a name="input_avd_dr_to_avd_prod_peering_network_id"></a> [avd\_dr\_to\_avd\_prod\_peering\_network\_id](#input\_avd\_dr\_to\_avd\_prod\_peering\_network\_id) | (Optional) AVD Prod networking ID | `string` | `""` | no |
| <a name="input_avd_fslogix_storage_account_file_shares"></a> [avd\_fslogix\_storage\_account\_file\_shares](#input\_avd\_fslogix\_storage\_account\_file\_shares) | n/a | `any` | n/a | yes |
| <a name="input_avd_hpool1_sub_address_prefix"></a> [avd\_hpool1\_sub\_address\_prefix](#input\_avd\_hpool1\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `list(string)` | n/a | yes |
| <a name="input_avd_hpool2_sub_address_prefix"></a> [avd\_hpool2\_sub\_address\_prefix](#input\_avd\_hpool2\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `list(string)` | n/a | yes |
| <a name="input_avd_hpool3_sub_address_prefix"></a> [avd\_hpool3\_sub\_address\_prefix](#input\_avd\_hpool3\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `list(string)` | n/a | yes |
| <a name="input_avd_idt_peering_network_id"></a> [avd\_idt\_peering\_network\_id](#input\_avd\_idt\_peering\_network\_id) | (Required) peering id for the identity vnet | `string` | n/a | yes |
| <a name="input_avd_ihub_peering_network_id"></a> [avd\_ihub\_peering\_network\_id](#input\_avd\_ihub\_peering\_network\_id) | (Required) peering id for the ihub vnet | `string` | n/a | yes |
| <a name="input_avd_keyvault_allowed_pe_subnet_ids"></a> [avd\_keyvault\_allowed\_pe\_subnet\_ids](#input\_avd\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_avd_keyvault_az_svcs_bypass"></a> [avd\_keyvault\_az\_svcs\_bypass](#input\_avd\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_avd_keyvault_deploy_private_dns_zone"></a> [avd\_keyvault\_deploy\_private\_dns\_zone](#input\_avd\_keyvault\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the key vault private endpoint. | `bool` | `false` | no |
| <a name="input_avd_keyvault_diagnostics"></a> [avd\_keyvault\_diagnostics](#input\_avd\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_avd_keyvault_enable"></a> [avd\_keyvault\_enable](#input\_avd\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `false` | no |
| <a name="input_avd_keyvault_enabled_for_deployment"></a> [avd\_keyvault\_enabled\_for\_deployment](#input\_avd\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_avd_keyvault_enabled_for_disk_encryption"></a> [avd\_keyvault\_enabled\_for\_disk\_encryption](#input\_avd\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_avd_keyvault_enabled_for_template_deployment"></a> [avd\_keyvault\_enabled\_for\_template\_deployment](#input\_avd\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_avd_keyvault_log_analytics_solutions"></a> [avd\_keyvault\_log\_analytics\_solutions](#input\_avd\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_avd_keyvault_nacl_allowed_ips"></a> [avd\_keyvault\_nacl\_allowed\_ips](#input\_avd\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_avd_keyvault_nacl_allowed_subnets"></a> [avd\_keyvault\_nacl\_allowed\_subnets](#input\_avd\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_avd_keyvault_nacl_default_action"></a> [avd\_keyvault\_nacl\_default\_action](#input\_avd\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_avd_keyvault_private_dns_zone_ids"></a> [avd\_keyvault\_private\_dns\_zone\_ids](#input\_avd\_keyvault\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_avd_keyvault_purge_protection_enabled"></a> [avd\_keyvault\_purge\_protection\_enabled](#input\_avd\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_avd_keyvault_sku_name"></a> [avd\_keyvault\_sku\_name](#input\_avd\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_avd_log_analytics_supported"></a> [avd\_log\_analytics\_supported](#input\_avd\_log\_analytics\_supported) | n/a | `any` | n/a | yes |
| <a name="input_avd_log_analytics_workspace_count_performance_counters"></a> [avd\_log\_analytics\_workspace\_count\_performance\_counters](#input\_avd\_log\_analytics\_workspace\_count\_performance\_counters) | n/a | `any` | n/a | yes |
| <a name="input_avd_nsg_flow_log_postfix"></a> [avd\_nsg\_flow\_log\_postfix](#input\_avd\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | n/a | yes |
| <a name="input_avd_nsg_sa_deploy_private_dns_zone"></a> [avd\_nsg\_sa\_deploy\_private\_dns\_zone](#input\_avd\_nsg\_sa\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the nsg sa private endpoint. | `bool` | `false` | no |
| <a name="input_avd_office_storage_account_file_shares"></a> [avd\_office\_storage\_account\_file\_shares](#input\_avd\_office\_storage\_account\_file\_shares) | n/a | `any` | n/a | yes |
| <a name="input_avd_private_link_subnet_address_prefixes"></a> [avd\_private\_link\_subnet\_address\_prefixes](#input\_avd\_private\_link\_subnet\_address\_prefixes) | (Optional) The address prefixes for the subnet of key vault. | `list(string)` | `[]` | no |
| <a name="input_avd_private_link_subnet_enforce_endpoint_network_policies"></a> [avd\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_avd\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Optional) | `bool` | `true` | no |
| <a name="input_avd_private_link_subnet_service_endpoints"></a> [avd\_private\_link\_subnet\_service\_endpoints](#input\_avd\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_avd_prod_deploy_avd_dr_peering"></a> [avd\_prod\_deploy\_avd\_dr\_peering](#input\_avd\_prod\_deploy\_avd\_dr\_peering) | (Optional) boolean for enabling peering-avd-prod-to-avd-dr | `bool` | `false` | no |
| <a name="input_avd_prod_to_avd_dr_peering_network_id"></a> [avd\_prod\_to\_avd\_dr\_peering\_network\_id](#input\_avd\_prod\_to\_avd\_dr\_peering\_network\_id) | (Optional) AVD DR networking ID | `string` | `""` | no |
| <a name="input_avd_rg_security_enable"></a> [avd\_rg\_security\_enable](#input\_avd\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to avd\_rg\_data | `bool` | `false` | no |
| <a name="input_avd_route_table_disable_bgp_propagation"></a> [avd\_route\_table\_disable\_bgp\_propagation](#input\_avd\_route\_table\_disable\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `true` | no |
| <a name="input_avd_shared_services_peering_network_id"></a> [avd\_shared\_services\_peering\_network\_id](#input\_avd\_shared\_services\_peering\_network\_id) | (Required) peering id for the shared services vnet | `string` | n/a | yes |
| <a name="input_avd_storage_account_allowed_ips"></a> [avd\_storage\_account\_allowed\_ips](#input\_avd\_storage\_account\_allowed\_ips) | (Optional) A list of Ip addresses that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_avd_storage_account_allowed_vnet_subnet_ids"></a> [avd\_storage\_account\_allowed\_vnet\_subnet\_ids](#input\_avd\_storage\_account\_allowed\_vnet\_subnet\_ids) | (optional) list the subnet whitelisting for the storage account | `list(string)` | `[]` | no |
| <a name="input_avd_storage_account_blob_retention_days"></a> [avd\_storage\_account\_blob\_retention\_days](#input\_avd\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `365` | no |
| <a name="input_avd_storage_account_file_share_directory_type"></a> [avd\_storage\_account\_file\_share\_directory\_type](#input\_avd\_storage\_account\_file\_share\_directory\_type) | (Optional) Specifies the directory service used. Possible values are AADDS and AD. | `string` | `null` | no |
| <a name="input_avd_storage_account_file_share_domain_guid"></a> [avd\_storage\_account\_file\_share\_domain\_guid](#input\_avd\_storage\_account\_file\_share\_domain\_guid) | (Optional) Specifies the domain GUID. | `string` | `null` | no |
| <a name="input_avd_storage_account_file_share_domain_name"></a> [avd\_storage\_account\_file\_share\_domain\_name](#input\_avd\_storage\_account\_file\_share\_domain\_name) | (Optional) Specifies the primary domain that the AD DNS server is authoritative for. | `string` | `null` | no |
| <a name="input_avd_storage_account_file_share_domain_sid"></a> [avd\_storage\_account\_file\_share\_domain\_sid](#input\_avd\_storage\_account\_file\_share\_domain\_sid) | (Optional) Specifies the security identifier (SID). | `string` | `null` | no |
| <a name="input_avd_storage_account_file_share_forest_name"></a> [avd\_storage\_account\_file\_share\_forest\_name](#input\_avd\_storage\_account\_file\_share\_forest\_name) | (Optional) Specifies the Active Directory forest. | `string` | `null` | no |
| <a name="input_avd_storage_account_file_share_netbios_domain_name"></a> [avd\_storage\_account\_file\_share\_netbios\_domain\_name](#input\_avd\_storage\_account\_file\_share\_netbios\_domain\_name) | (Optional) Specifies the NetBIOS domain name. | `string` | `null` | no |
| <a name="input_avd_storage_account_fix_suffix"></a> [avd\_storage\_account\_fix\_suffix](#input\_avd\_storage\_account\_fix\_suffix) | (Optional) toggle to use the original suffix for the SA or not. | `bool` | n/a | yes |
| <a name="input_avd_storage_account_fslogix_file_share_allowed_vnet_subnet_ids"></a> [avd\_storage\_account\_fslogix\_file\_share\_allowed\_vnet\_subnet\_ids](#input\_avd\_storage\_account\_fslogix\_file\_share\_allowed\_vnet\_subnet\_ids) | (optional) list the subnet whitelisting for the storage account | `list(string)` | `[]` | no |
| <a name="input_avd_storage_account_fslogix_file_share_office_ad_auth_enable"></a> [avd\_storage\_account\_fslogix\_file\_share\_office\_ad\_auth\_enable](#input\_avd\_storage\_account\_fslogix\_file\_share\_office\_ad\_auth\_enable) | n/a | `any` | n/a | yes |
| <a name="input_avd_storage_account_fslogix_file_share_office_allowed_vnet_subnet_ids"></a> [avd\_storage\_account\_fslogix\_file\_share\_office\_allowed\_vnet\_subnet\_ids](#input\_avd\_storage\_account\_fslogix\_file\_share\_office\_allowed\_vnet\_subnet\_ids) | (optional) list the subnet whitelisting for the storage account | `list(string)` | `[]` | no |
| <a name="input_avd_storage_account_fslogix_file_share_personal_ad_auth_enable"></a> [avd\_storage\_account\_fslogix\_file\_share\_personal\_ad\_auth\_enable](#input\_avd\_storage\_account\_fslogix\_file\_share\_personal\_ad\_auth\_enable) | File share for fslogix variable "avd\_storage\_account\_file\_shares" {} | `any` | n/a | yes |
| <a name="input_avd_storage_account_kind"></a> [avd\_storage\_account\_kind](#input\_avd\_storage\_account\_kind) | n/a | `any` | n/a | yes |
| <a name="input_avd_storage_account_office_file_share_storage_sid"></a> [avd\_storage\_account\_office\_file\_share\_storage\_sid](#input\_avd\_storage\_account\_office\_file\_share\_storage\_sid) | (Optional) Specifies the security identifier (SID) for Azure Storage. | `string` | `null` | no |
| <a name="input_avd_storage_account_personal_file_share_storage_sid"></a> [avd\_storage\_account\_personal\_file\_share\_storage\_sid](#input\_avd\_storage\_account\_personal\_file\_share\_storage\_sid) | (Optional) Specifies the security identifier (SID) for Azure Storage. | `string` | `null` | no |
| <a name="input_avd_storage_account_private_link_access_enabled"></a> [avd\_storage\_account\_private\_link\_access\_enabled](#input\_avd\_storage\_account\_private\_link\_access\_enabled) | set to true to enable private link access | `bool` | `false` | no |
| <a name="input_avd_storage_account_private_link_access_endpoint_resource_id"></a> [avd\_storage\_account\_private\_link\_access\_endpoint\_resource\_id](#input\_avd\_storage\_account\_private\_link\_access\_endpoint\_resource\_id) | n/a | `any` | n/a | yes |
| <a name="input_avd_storage_account_private_link_access_endpoint_tenant_id"></a> [avd\_storage\_account\_private\_link\_access\_endpoint\_tenant\_id](#input\_avd\_storage\_account\_private\_link\_access\_endpoint\_tenant\_id) | n/a | `any` | n/a | yes |
| <a name="input_avd_storage_account_tier"></a> [avd\_storage\_account\_tier](#input\_avd\_storage\_account\_tier) | n/a | `any` | n/a | yes |
| <a name="input_avd_vnet_address_space"></a> [avd\_vnet\_address\_space](#input\_avd\_vnet\_address\_space) | (Required) The address space for the virtual network. | `list(string)` | n/a | yes |
| <a name="input_avd_vnet_dns_servers"></a> [avd\_vnet\_dns\_servers](#input\_avd\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_dns_location"></a> [dns\_location](#input\_dns\_location) | (Required) The abbreviated cloud region used for private dns zone creation. | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_private_ip_address"></a> [ihub\_internal\_lb\_private\_ip\_address](#input\_ihub\_internal\_lb\_private\_ip\_address) | n/a | `string` | `null` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  resource_name_no_dash    = replace("${var.env}${var.postfix}${var.suffix}", "-", "")
  timeout_duration = "2h"
  
  # KeyVault
  avd_rg_keyvault_name            = var.avd_keyvault_enable && var.avd_rg_security_enable ?  azurerm_resource_group.avd_rg_security[0].name  : azurerm_resource_group.avd_rg_data.name
  avd_private_link_subnet          = var.avd_deploy_private_link_subnet ? [azurerm_subnet.avd_private_link_subnet[0].id]              : var.avd_keyvault_allowed_pe_subnet_ids
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_avd_hpool1_subnet"></a> [avd\_hpool1\_subnet](#output\_avd\_hpool1\_subnet) | n/a |
| <a name="output_avd_hpool2_subnet"></a> [avd\_hpool2\_subnet](#output\_avd\_hpool2\_subnet) | n/a |
| <a name="output_avd_peering_to_sharedsvc"></a> [avd\_peering\_to\_sharedsvc](#output\_avd\_peering\_to\_sharedsvc) | n/a |
| <a name="output_avd_private_link_subnet"></a> [avd\_private\_link\_subnet](#output\_avd\_private\_link\_subnet) | n/a |
| <a name="output_avd_rg_network"></a> [avd\_rg\_network](#output\_avd\_rg\_network) | n/a |
| <a name="output_avd_vnet"></a> [avd\_vnet](#output\_avd\_vnet) | Outputs ********************************************************************************************** |
| <a name="output_cl_log_analytics_workspace"></a> [cl\_log\_analytics\_workspace](#output\_cl\_log\_analytics\_workspace) | n/a |
| <a name="output_peering_avd_to_idt"></a> [peering\_avd\_to\_idt](#output\_peering\_avd\_to\_idt) | n/a |
| <a name="output_peering_avd_to_ihub"></a> [peering\_avd\_to\_ihub](#output\_peering\_avd\_to\_ihub) | n/a |


## Usage

```terraform
//**********************************************************************************************
module "avd_us_gov" {
    source                          = "../dn-tads_tf-azure-component-library/core/core_us_gov_avd"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    suffix                          = var.suffix
    dns_location                    = "ugv"
    hub_env                         = var.env
    tags                           = var.tags
    avd_vnet_address_space         = var.avd_vnet_address_space
    avd_vnet_dns_servers           = var.avd_vnet_dns_servers
    avd_private_link_subnet_address_prefixes = var.avd_private_link_subnet_address_prefixes
    avd_nsg_flow_log_postfix         = var.avd_nsg_flow_log_postfix
    avd_storage_account_fix_suffix               = var.avd_storage_account_fix_suffix              
    avd_storage_account_tier                                  = var.avd_storage_account_tier
    avd_storage_account_kind                                  = var.avd_storage_account_kind
    avd_storage_account_allowed_ips                           = var.avd_storage_account_allowed_ips
    avd_storage_account_private_link_access_enabled           = var.avd_storage_account_private_link_access_enabled 
    avd_storage_account_private_link_access_endpoint_resource_id = var.avd_storage_account_private_link_access_endpoint_resource_id
    avd_storage_account_private_link_access_endpoint_tenant_id   = var.avd_storage_account_private_link_access_endpoint_tenant_id
    avd_log_analytics_supported                                     = var.avd_log_analytics_supported
    avd_alt_log_analytics_workspace                                 = var.avd_alt_log_analytics_workspace
    avd_alt_log_analytics_workspace_name                            = var.avd_alt_log_analytics_workspace_name
    avd_alt_log_analytics_workspace_id                              = var.avd_alt_log_analytics_workspace_id
    avd_storage_account_fslogix_file_share_office_allowed_vnet_subnet_ids   = var.avd_storage_account_fslogix_file_share_office_allowed_vnet_subnet_ids
    avd_storage_account_fslogix_file_share_allowed_vnet_subnet_ids          = var.avd_storage_account_fslogix_file_share_allowed_vnet_subnet_ids
    avd_storage_account_allowed_vnet_subnet_ids                             = var.avd_storage_account_allowed_vnet_subnet_ids
    avd_fslogix_storage_account_file_shares                                 = var.avd_fslogix_storage_account_file_shares
    avd_office_storage_account_file_shares                                  = var.avd_office_storage_account_file_shares

    #fileshare AD Auth
      avd_storage_account_fslogix_file_share_personal_ad_auth_enable = var.avd_storage_account_fslogix_file_share_personal_ad_auth_enable
      avd_storage_account_fslogix_file_share_office_ad_auth_enable   = var.avd_storage_account_fslogix_file_share_office_ad_auth_enable
      avd_storage_account_file_share_directory_type   = var.avd_storage_account_file_share_directory_type
      avd_storage_account_file_share_domain_guid  = var.avd_storage_account_file_share_domain_guid 
      avd_storage_account_file_share_domain_name  = var.avd_storage_account_file_share_domain_name 
      avd_storage_account_file_share_domain_sid   = var.avd_storage_account_file_share_domain_sid
      avd_storage_account_file_share_forest_name  = var.avd_storage_account_file_share_forest_name
      avd_storage_account_file_share_netbios_domain_name  = var.avd_storage_account_file_share_netbios_domain_name 
      avd_storage_account_personal_file_share_storage_sid = var.avd_storage_account_personal_file_share_storage_sid 
      avd_storage_account_office_file_share_storage_sid   = var.avd_storage_account_office_file_share_storage_sid
      avd_log_analytics_workspace_count_performance_counters = var.avd_log_analytics_workspace_count_performance_counters
#       avd_storage_account_fslogix_file_share_wdac_allowed_vnet_subnet_ids = var.avd_storage_account_fslogix_file_share_wdac_allowed_vnet_subnet_ids
#       avd_wdac_storage_account_file_shares                                = var.avd_wdac_storage_account_file_shares
#       avd_storage_account_wdac_file_share_storage_sid                     = var.avd_storage_account_wdac_file_share_storage_sid
#       avd_storage_account_wdac_file_share_ad_auth_enable        = var.avd_storage_account_wdac_file_share_ad_auth_enable


    #KV
    avd_rg_security_enable                                             = var.avd_rg_security_enable    
    avd_keyvault_enable                                                = var.avd_keyvault_enable 
    avd_keyvault_nacl_allowed_subnets                                  = var.avd_keyvault_nacl_allowed_subnets
    avd_keyvault_nacl_allowed_ips                                      = var.avd_keyvault_nacl_allowed_ips
 
    #peering
    avd_shared_services_peering_network_id    = var.avd_shared_services_peering_network_id
    avd_ihub_peering_network_id               = var.avd_ihub_peering_network_id
    avd_idt_peering_network_id                = var.avd_idt_peering_network_id
    avd_prod_to_avd_dr_peering_network_id       = var.avd_prod_to_avd_dr_peering_network_id 
    avd_dr_to_avd_prod_peering_network_id       = var.avd_dr_to_avd_prod_peering_network_id
    avd_dr_deploy_avd_prod_peering              = var.avd_dr_deploy_avd_prod_peering
    avd_prod_deploy_avd_dr_peering              = var.avd_prod_deploy_avd_dr_peering
    
    #route
    ihub_internal_lb_private_ip_address       = var.ihub_internal_lb_private_ip_address
    avd_route_table_disable_bgp_propagation   = false
    avd_hpool1_sub_address_prefix             = var.avd_hpool1_sub_address_prefix
    avd_hpool2_sub_address_prefix             = var.avd_hpool2_sub_address_prefix
    avd_hpool3_sub_address_prefix             = var.avd_hpool3_sub_address_prefix

}
//**********************************************************************************************
resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  count               = var.deploy_avd_log_analytics_link_scoped_service ? 1 : 0
  depends_on          = [module.avd_us_gov]
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.avd_sharedsvcs_logging_rg, var.env)
  scope_name          = lookup(local.avd_sharedsvcs_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = module.avd_us_gov.cl_log_analytics_workspace[0].cl_log_analytics_workspace.id
}
```
<!-- END_TF_DOCS -->
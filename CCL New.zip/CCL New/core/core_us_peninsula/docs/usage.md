## Usage

#### Without Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                          = "../tf-azure-component-library/core/core_us_peninsula"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    hub_env                         = "nprd-pr"
    core_vnet_address_space         = ["10.0.1.0/24"]
    gateway_sub_address_prefix      = ["10.0.1.0/27"]
}
```

#### With Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                                                              = "../tf-azure-component-library/core/core_us_peninsula"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    hub_env                                                             = "nprd-pr"
    core_vnet_address_space                                             = ["10.0.1.0/24"]
    gateway_sub_address_prefix                                          = ["10.0.1.0/27"]

    core_rg_security_enable                                             = true
    core_keyvault_enable                                                = true
    core_private_link_subnet_address_prefixes                           = var.subnet_address_prefixes
    core_private_link_subnet_enforce_endpoint_network_policies          = true
    core_keyvault_nacl_allowed_ips                                      = ["199.207.253.96","199.206.0.0/15","199.207.253.101"]
}
```
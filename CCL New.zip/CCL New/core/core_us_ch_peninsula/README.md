# Core US CH Peninsula

This is the U.S. CH Peninsula Core component for the U.S. CH Peninsula spoke. It establishes a baseline cloud environment where other components can be deployed into.
Specifically the core module lays the foundational infrastructure required to establish network connectivity  of the Azure cloud resources to the KPMG infrastructure.
This module deploys vnets, vnet peering, route tables, network gateways, key vault, log analytics workspace, security center, public IPs, etc.


#### Important Note:
// We need to reach out to CloudOps team to Manually peer with Transit Vnet from Non Prod Shared Services. 
Non-prod shared services Vnet ID :  "/subscriptions/4bd13677-8836-4cee-b8ec-8db6d6e0f026/resourceGroups/rg-nprd-pr-transit-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-transit-vnet"


#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified on Jenkinsfile:
```jenkinsfile
stage("Terraform *** ") {
    agent {
        docker {
            image 'dn-cloud-docker.artifactory.us.kworld.kpmg.com/azure-terraform-0-15-4:latest'
            ...
```
Specify TF version in `core_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "hub_env" {
  type        = string
  description = "(Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings"
}

variable "core_vnet_address_space" {
  type        = list(string)
  description = "(Required) The address space for the virtual network."
}

variable "gateway_sub_address_prefix" {
  type        = list(string)
  description = "(Required) The address prefix for the gateway subnet."
}

variable "vgw_lgw_conn_shared_key" {
  type        = string
  description = "(Required) The shared key to use for the VGW to LGW connections."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map(any)
  default     = {}
}

variable "core_vnet_dns_servers" {
  description = "(Optional) A list of DNS servers to use. If left empty, defaults to Azure servers."
  type        = list(string)
  default     = []
}

variable "core_route_table_disable_bgp_propagation" {
  description = "(Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it."
  type        = bool
  default     = true
}
variable "core_azure_defender_resources" {
    description = "(Optional) A list of resources with Azure Defender Enabled."
    type        = list
    default     = ["VirtualMachines", "AppServices", "ContainerRegistry", "KeyVaults", "KubernetesService", "SqlServers", "SqlServerVirtualMachines", "StorageAccounts", "Arm", "Dns"]
}
//**********************************************************************************************

// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h"

  core_keyvault_private_dns_zone = var.core_keyvault_enable && var.core_keyvault_deploy_private_dns_zone ? [azurerm_private_dns_zone.core_keyvault_azure_private_dns_zone[0].id] : var.core_keyvault_private_dns_zone_ids
  core_rg_keyvault_name          = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_shared_services_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-sharedsvc-vnet"
    "prod-pr" = "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-network/providers/Microsoft.Network/virtualNetworks/vnet-prod-shared"
    "prod-dr" = "/subscriptions/153c5e81-83af-4fb0-b548-b16e9ee8f45b/resourceGroups/rg-dr-shared-network/providers/Microsoft.Network/virtualNetworks/vnet-dr-shared"
  }

  core_first_remote_nva_pip = {
    "nprd-pr" = "52.138.102.104"    
    "prod-pr" = "137.135.105.155"   
    "prod-dr" = "104.42.249.54"
  }

  core_first_bgp_peering_address = {
    "nprd-pr" = "10.4.65.205"
    "prod-pr" = "10.47.129.203" 
    "prod-dr" = "10.47.161.203" 
  }

  core_first_connection_address_space = {
    "nprd-pr" = ["10.4.65.205/32"]
    "prod-pr" = ["10.47.129.203/32"]  
    "prod-dr" = ["10.47.161.203/32"]
  }

  core_second_remote_nva_pip = {
    "nprd-pr" = "52.138.102.58"   
    "prod-pr" = "137.135.105.219"
    "prod-dr" = "13.88.182.186"
  }

  core_second_bgp_peering_address = {
    "nprd-pr" = "10.4.65.206"
    "prod-pr" = "10.47.129.204"
    "prod-dr" = "10.47.161.204"
  }

  core_second_connection_address_space = {
    "nprd-pr" = ["10.4.65.206/32"]
    "prod-pr" = ["10.47.129.204/32"]
    "prod-dr" = ["10.47.161.204/32"]
  }

  core_remote_bgp_asn = {
    "nprd-pr" = "65200"   
    "prod-pr" = "65250"
    "prod-dr" = "65255"
  }

  core_bgp_asn = {
    "nprd-pr" = "65203"
    "prod-pr" = "65253"
    "prod-dr" = "65227"
  }

  //private dns map for log Analytics Workspace

   core_shared_services_private_dns_zone_id_map = {
    "nprd-pr" = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net",
                "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net" ]
    "prod-pr" = ["/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.monitor.azure.com",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ods.opinsights.azure.com",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.oms.opinsights.azure.com",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.agentsvc.azure-automation.net",
                 "/subscriptions/4803a165-bc99-4492-8bd2-1e7a878008bb/resourceGroups/rg-prod-shared-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"]
    "prod-dr" = [""]
  }


  core_subscription_diagnostics_settings = {
    logs    = ["Administrative", "Security", "ServiceHealth", "Alert", "Recommendation", "Policy", "Autoscale", "ResourceHealth"]
    metrics = []
  }

  core_vgw_diagnostics_settings = {
    logs    = ["GatewayDiagnosticLog", "IKEDiagnosticLog", "P2SDiagnosticLog", "RouteDiagnosticLog", "TunnelDiagnosticLog"]
    metrics = ["AllMetrics"]
  }

  core_vnet_diagnostics_settings = {
    logs    = ["VMProtectionAlerts"]
    metrics = ["AllMetrics"]
  }

  core_public_ip_diagnostics_settings = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
//**********************************************************************************************

// Optional Variables - KeyVault
//**********************************************************************************************
variable "core_rg_security_enable" {
  description = "(Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to core_rg_data"
  type        = bool
  default     = false
}
variable "core_keyvault_enable" {
  description = "(Optional) Enable the creation for azure key vault"
  type        = bool
  default     = false
}
variable "core_keyvault_deploy_private_dns_zone" {
  description = "(Optional) A boolean to enable/disable the deployment of a private dns zone for the key vault private endpoint."
  type        = bool
  default     = true
}
variable "core_keyvault_sku_name" {
    description = "(Optional) The Name of the SKU used for Key Vault"
    type        = string
    default     = "standard"
}
variable "core_keyvault_enabled_for_deployment" {
    type        = bool
    description = "(Optional) Boolean to enable vms to be able to fetch from keyvault."
    default     = true
}
variable "core_keyvault_enabled_for_disk_encryption" {
    type        = bool
    description = "(Optional) Boolean to enable vms to use keyvault certificates for disk encryption."
    default     = true
}
variable "core_keyvault_enabled_for_template_deployment" {
    type        = bool
    description = "(Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault."
    default     = false
}
variable "core_keyvault_purge_protection_enabled" {
    type        = bool
    description = "(Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed."
    default     = true
}
variable "core_keyvault_nacl_default_action" {
    description = "(Optional) The Default Action to use when no rules match from ip_rules / virtual_network_subnet_ids."
    type        = string
    default     = "Deny"
}
variable "core_keyvault_az_svcs_bypass" {
    type        = string
    description = "(Optional) Specifies which traffic can bypass the network rules."
    default     = "AzureServices"
}
variable "core_keyvault_nacl_allowed_ips" {
    type        = list(string)
    description = "(Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault."
    default     = []
}
variable "core_keyvault_nacl_allowed_subnets" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access this Key Vault."
    default     = []
}
variable "core_keyvault_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
variable "core_keyvault_allowed_pe_subnet_ids" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault."
    default     = []
}
variable "core_keyvault_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["AuditEvent"]
    metrics = ["AllMetrics"]
  }
}
variable "core_keyvault_log_analytics_solutions" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    KeyVaultAnalytics = {
      publisher = "Microsoft"
      product   = "OMSGallery/KeyVaultAnalytics"
    }
  }
}
variable "core_private_link_subnet_address_prefixes" {
  description = "(Optional) The address prefixes for the subnet of key vault."
  type        = list(string)
  default     = []
}
variable "core_private_link_subnet_enforce_endpoint_network_policies" {
  description = "(Optional) "
  type        = bool
  default     = true
}
variable "core_private_link_subnet_service_endpoints" {
  description = "(Optional) "
  type        = list(string)
  default     = []
}
//**********************************************************************************************


// Optional Variables - Reovery Service Vault
//**********************************************************************************************
variable "core_azure_backup_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["AzureBackupReport","CoreAzureBackup","AddonAzureBackupJobs","AddonAzureBackupAlerts","AddonAzureBackupPolicy","AddonAzureBackupStorage","AddonAzureBackupProtectedInstance","AzureSiteRecoveryJobs","AzureSiteRecoveryEvents","AzureSiteRecoveryReplicatedItems","AzureSiteRecoveryReplicationStats","AzureSiteRecoveryRecoveryPoints","AzureSiteRecoveryReplicationDataUploadRate","AzureSiteRecoveryProtectedDiskDataChurn"]
    metrics = []
  }
}
variable "core_azure_backup_timezone" {
  description = "Specifies the timezone for VM backup schedules. Defaults to `UTC`."
  type        = string
  default     = "UTC"
}
variable "core_azure_backup_time" {
  description = "(Optional) The time of day to perform the backup in 24hour format."
  type        = string
  default     = "23:00"
}
variable "core_azure_backup_retention_daily_count" {
  description = "(Optional) The number of days Azure Recovery Services will retain the backup for."
  type = number
  default = 10
}
variable "core_azure_backup_deploy_rsv" {
  description = "(Optional) If true, deploy rsv."
  default     = true
}
variable "core_azure_backup_enable_vm_backup" {
  description = "(Optional) Toggle the vm backup feature."
  default     = false
}
variable "core_azure_backup_enable_file_storage_backup" {
  description = "(Optional) Toggle the file storage backup feature."
  default     = false
}
variable "core_azure_backup_enable_blob_storage_backup" {
  description = "(Optional) Toggle the blob storage backup feature."
  default     = false
}
//**********************************************************************************************
```

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "core_rg_network" {
  value = azurerm_resource_group.core_rg_network
}
output "core_rg_logging" {
  value = azurerm_resource_group.core_rg_logging
}
output "core_rg_data" {
  value = azurerm_resource_group.core_rg_data
}
output "core_rg_security" {
  value = azurerm_resource_group.core_rg_security
}
output "core_vnet" {
  value = azurerm_virtual_network.core_vnet
}
output "core_gateway_subnet" {
  value = azurerm_subnet.core_gateway_subnet
}
output "core_route_table" {
  value = azurerm_route_table.core_route_table
}
output "core_default_internet_route" {
  value = azurerm_route.core_default_internet_route
}
output "core_log_analytics_workspace" {
  value = module.cl_log_analytics_workspace
}
output "core_security_center_pricing" {
  value = azurerm_security_center_subscription_pricing.core_security_center_pricing
}
output "core_primary_local_network_gateway" {
  value = azurerm_local_network_gateway.core_primary_local_network_gateway
}
output "core_secondary_local_network_gateway" {
  value = azurerm_local_network_gateway.core_secondary_local_network_gateway
}
output "core_primary_vgw_pip" {
  value = azurerm_public_ip.core_primary_vgw_pip
}
output "core_secondary_vgw_pip" {
  value = azurerm_public_ip.core_secondary_vgw_pip
}
output "core_virtual_network_gateway" {
  value = azurerm_virtual_network_gateway.core_virtual_network_gateway
}
output "core_primary_vgw_to_lgw_connection" {
  value = azurerm_virtual_network_gateway_connection.core_primary_vgw_to_lgw_connection
}
output "core_secondary_vgw_to_lgw_connection" {
  value = azurerm_virtual_network_gateway_connection.core_secondary_vgw_to_lgw_connection
}
output "core_peering" {
  value = azurerm_virtual_network_peering.core_peering
}
output "core_keyvault_azure_private_dns_zone" {
  value = azurerm_private_dns_zone.core_keyvault_azure_private_dns_zone
}
output "core_private_link_subnet" {
  value = azurerm_subnet.core_private_link_subnet
}
output "core_keyvault" {
  value = module.cl_keyvault
}
output "core_backup" {
  value = module.cl_azure_backup
}
//**********************************************************************************************
```

## Usage

#### Without Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                          = "../tf-azure-component-library/core/core_us_peninsula"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    hub_env                         = "nprd-pr"
    core_vnet_address_space         = ["10.0.1.0/24"]
    gateway_sub_address_prefix      = ["10.0.1.0/27"]
    vgw_lgw_conn_shared_key         = var.vgw_lgw_conn_shared_key 
}

//NOTE: Spoke SPN must have contributor role over the private link scope resource in shared services subscription.
resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_us
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_us_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_us_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```

#### With Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                                                              = "../tf-azure-component-library/core/core_us_peninsula"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    hub_env                                                             = "nprd-pr"
    core_vnet_address_space                                             = ["10.0.1.0/24"]
    gateway_sub_address_prefix                                          = ["10.0.1.0/27"]
    vgw_lgw_conn_shared_key                                             = var.vgw_lgw_conn_shared_key 
    core_rg_security_enable                                             = true
    core_keyvault_enable                                                = true
    core_private_link_subnet_address_prefixes                           = var.subnet_address_prefixes
    core_private_link_subnet_service_endpoints                          = var.core_private_link_subnet_service_endpoints
    core_private_link_subnet_enforce_endpoint_network_policies          = true
    core_keyvault_nacl_allowed_subnets                                  = []
  }
  
//NOTE: Spoke SPN must have contributor role over the private link scope resource in shared services subscription.
resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_us
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_us_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_us_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```
<!-- BEGIN_TF_DOCS -->

# Core US Peninsula

This is the U.S. Country Hosting Peninsula Core component for the U.S. Peninsula spoke. It establishes a baseline cloud environment where other components can be deployed into.
Specifically the core module lays the foundational infrastructure required to establish network connectivity  of the Azure cloud resources to the KPMG infrastructure.
This module deploys vnets, vnet peering, route tables, network gateways, key vault, log analytics workspace, security center, public IPs, etc.

#### Note:
To get this code to work, it needs Terraform version 1.0 and azurerm provider version 3.22.0
Specify TF version in `core_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  version = "3.22.0"
  features {}
}

//Alias provider require to add the private link scoped service from spoke LAW to AMPLS in shared services subscription
provider "azurerm" {
  alias = "shs"
  version = "3.22.0"
  subscription_id = var.sharedsvcs_subscription_id
  features {}
}
//**********************************************************************************************


// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 1.0"
  backend "azurerm" {}
}
//**********************************************************************************************
```

## Resources

| Name | Type |
|------|------|
| [azurerm_local_network_gateway.core_primary_local_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/local_network_gateway) | resource |
| [azurerm_local_network_gateway.core_secondary_local_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/local_network_gateway) | resource |
| [azurerm_monitor_diagnostic_setting.core_primary_vgw_pip_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.core_secondary_vgw_pip_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.core_virtual_network_gateway_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.core_vnet_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_dns_zone.core_keyvault_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.keyvault_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_public_ip.core_primary_vgw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.core_secondary_vgw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_resource_group.core_rg_azure_qualys](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.core_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.core_default_internet_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.core_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_security_center_auto_provisioning.core_security_center_auto_provisioning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_auto_provisioning) | resource |
| [azurerm_security_center_contact.core_security_center_contact_info](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_contact) | resource |
| [azurerm_security_center_setting.core_security_center_wdatp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_setting) | resource |
| [azurerm_security_center_subscription_pricing.core_security_center_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_subnet.core_gateway_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.core_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_virtual_network.core_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_gateway.core_virtual_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway) | resource |
| [azurerm_virtual_network_gateway_connection.core_primary_vgw_to_lgw_connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway_connection) | resource |
| [azurerm_virtual_network_gateway_connection.core_secondary_vgw_to_lgw_connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway_connection) | resource |
| [azurerm_virtual_network_peering.core_peering](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_core_azure_backup_deploy_rsv"></a> [core\_azure\_backup\_deploy\_rsv](#input\_core\_azure\_backup\_deploy\_rsv) | (Optional) If true, deploy rsv. | `bool` | `true` | no |
| <a name="input_core_azure_backup_diagnostics"></a> [core\_azure\_backup\_diagnostics](#input\_core\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_core_azure_backup_enable_blob_storage_backup"></a> [core\_azure\_backup\_enable\_blob\_storage\_backup](#input\_core\_azure\_backup\_enable\_blob\_storage\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_enable_file_storage_backup"></a> [core\_azure\_backup\_enable\_file\_storage\_backup](#input\_core\_azure\_backup\_enable\_file\_storage\_backup) | (Optional) Toggle the file storage backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_enable_vm_backup"></a> [core\_azure\_backup\_enable\_vm\_backup](#input\_core\_azure\_backup\_enable\_vm\_backup) | (Optional) Toggle the vm backup feature. | `bool` | `false` | no |
| <a name="input_core_azure_backup_retention_daily_count"></a> [core\_azure\_backup\_retention\_daily\_count](#input\_core\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_core_azure_backup_time"></a> [core\_azure\_backup\_time](#input\_core\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_core_azure_backup_timezone"></a> [core\_azure\_backup\_timezone](#input\_core\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_core_azure_defender_resources"></a> [core\_azure\_defender\_resources](#input\_core\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "AppServices",<br>  "ContainerRegistry",<br>  "KeyVaults",<br>  "KubernetesService",<br>  "SqlServers",<br>  "SqlServerVirtualMachines",<br>  "StorageAccounts",<br>  "Arm",<br>  "Dns"<br>]</pre> | no |
| <a name="input_core_keyvault_allowed_pe_subnet_ids"></a> [core\_keyvault\_allowed\_pe\_subnet\_ids](#input\_core\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_az_svcs_bypass"></a> [core\_keyvault\_az\_svcs\_bypass](#input\_core\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_core_keyvault_deploy_private_dns_zone"></a> [core\_keyvault\_deploy\_private\_dns\_zone](#input\_core\_keyvault\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the key vault private endpoint. | `bool` | `false` | no |
| <a name="input_core_keyvault_diagnostics"></a> [core\_keyvault\_diagnostics](#input\_core\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_core_keyvault_enable"></a> [core\_keyvault\_enable](#input\_core\_keyvault\_enable) | (Optional) Enable the creation for azure key vault | `bool` | `false` | no |
| <a name="input_core_keyvault_enabled_for_deployment"></a> [core\_keyvault\_enabled\_for\_deployment](#input\_core\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_disk_encryption"></a> [core\_keyvault\_enabled\_for\_disk\_encryption](#input\_core\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_core_keyvault_enabled_for_template_deployment"></a> [core\_keyvault\_enabled\_for\_template\_deployment](#input\_core\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_core_keyvault_log_analytics_solutions"></a> [core\_keyvault\_log\_analytics\_solutions](#input\_core\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_core_keyvault_nacl_allowed_ips"></a> [core\_keyvault\_nacl\_allowed\_ips](#input\_core\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_nacl_allowed_subnets"></a> [core\_keyvault\_nacl\_allowed\_subnets](#input\_core\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_nacl_default_action"></a> [core\_keyvault\_nacl\_default\_action](#input\_core\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_core_keyvault_postfix"></a> [core\_keyvault\_postfix](#input\_core\_keyvault\_postfix) | (Required) The bespoke name of the kv app or project you are deploying. | `string` | `"ch"` | no |
| <a name="input_core_keyvault_private_dns_zone_ids"></a> [core\_keyvault\_private\_dns\_zone\_ids](#input\_core\_keyvault\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_core_keyvault_purge_protection_enabled"></a> [core\_keyvault\_purge\_protection\_enabled](#input\_core\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_core_keyvault_sku_name"></a> [core\_keyvault\_sku\_name](#input\_core\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_core_private_link_subnet_address_prefixes"></a> [core\_private\_link\_subnet\_address\_prefixes](#input\_core\_private\_link\_subnet\_address\_prefixes) | (Optional) The address prefixes for the subnet of key vault. | `list(string)` | `[]` | no |
| <a name="input_core_private_link_subnet_enforce_endpoint_network_policies"></a> [core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_core\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Optional) | `bool` | `true` | no |
| <a name="input_core_private_link_subnet_service_endpoints"></a> [core\_private\_link\_subnet\_service\_endpoints](#input\_core\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | `[]` | no |
| <a name="input_core_rg_security_enable"></a> [core\_rg\_security\_enable](#input\_core\_rg\_security\_enable) | (Optional) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to core\_rg\_data | `bool` | `false` | no |
| <a name="input_core_route_next_hop_in_ip_address"></a> [core\_route\_next\_hop\_in\_ip\_address](#input\_core\_route\_next\_hop\_in\_ip\_address) | (Optional) Contains the IP address packets should be forwarded to. Next hop values are only allowed in routes where the next hop type is VirtualAppliance. | `string` | `"10.4.64.30"` | no |
| <a name="input_core_security_center_wdatp_enable"></a> [core\_security\_center\_wdatp\_enable](#input\_core\_security\_center\_wdatp\_enable) | n/a | `bool` | `true` | no |
| <a name="input_core_vgw_generation"></a> [core\_vgw\_generation](#input\_core\_vgw\_generation) | (Optional) The Generation of the Virtual Network gateway. Possible values include Generation1, Generation2 or None. Changing this forces a new resource to be created. | `string` | `"Generation2"` | no |
| <a name="input_core_vgw_pip_allocation_method"></a> [core\_vgw\_pip\_allocation\_method](#input\_core\_vgw\_pip\_allocation\_method) | (Required) Defines the allocation method for this IP address. Possible values are Static or Dynamic | `string` | `"Static"` | no |
| <a name="input_core_vgw_pip_sku"></a> [core\_vgw\_pip\_sku](#input\_core\_vgw\_pip\_sku) | (Optional) The SKU of the Public IP. | `string` | `"Standard"` | no |
| <a name="input_core_vnet_address_space"></a> [core\_vnet\_address\_space](#input\_core\_vnet\_address\_space) | (Required) The address space for the virtual network. | `list(string)` | n/a | yes |
| <a name="input_core_vnet_dns_servers"></a> [core\_vnet\_dns\_servers](#input\_core\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_gateway_sub_address_prefix"></a> [gateway\_sub\_address\_prefix](#input\_gateway\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `list(string)` | `[]` | no |
| <a name="input_hub_env"></a> [hub\_env](#input\_hub\_env) | (Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |
| <a name="input_vgw_lgw_conn_shared_key"></a> [vgw\_lgw\_conn\_shared\_key](#input\_vgw\_lgw\_conn\_shared\_key) | (Required) The shared key to use for the VGW to LGW connections. | `string` | `null` | no |

## Local Values

```terraform
locals {
  timeout_duration = "2h"

  core_keyvault_private_dns_zone = var.core_keyvault_enable && var.core_keyvault_deploy_private_dns_zone ? [azurerm_private_dns_zone.core_keyvault_azure_private_dns_zone[0].id] : var.core_keyvault_private_dns_zone_ids
  core_rg_keyvault_name          = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_shared_services_peering_network_id_map = {
    "nprd-pr" = "/subscriptions/734fea36-c123-4c5e-9e9d-b4679e9e372b/resourceGroups/rg-nprd-pr-sharedsvcs-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-sharedsvcs-vnet"   
  }

  core_first_remote_nva_pip = {
    "nprd-pr" = "52.138.102.104"    
    "prod-pr" = "137.135.105.155"   
    "prod-dr" = "104.42.249.54"
  }

  core_first_bgp_peering_address = {
    "nprd-pr" = "10.4.65.205"
    "prod-pr" = "10.47.129.203" 
    "prod-dr" = "10.47.161.203" 
  }

  core_first_connection_address_space = {
    "nprd-pr" = ["10.4.65.205/32"]
    "prod-pr" = ["10.47.129.203/32"]  
    "prod-dr" = ["10.47.161.203/32"]
  }

  core_second_remote_nva_pip = {
    "nprd-pr" = "52.138.102.58"   
    "prod-pr" = "137.135.105.219"
    "prod-dr" = "13.88.182.186"
  }

  core_second_bgp_peering_address = {
    "nprd-pr" = "10.4.65.206"
    "prod-pr" = "10.47.129.204"
    "prod-dr" = "10.47.161.204"
  }

  core_second_connection_address_space = {
    "nprd-pr" = ["10.4.65.206/32"]
    "prod-pr" = ["10.47.129.204/32"]
    "prod-dr" = ["10.47.161.204/32"]
  }

  core_remote_bgp_asn = {
    "nprd-pr" = "65200"   
    "prod-pr" = "65250"
    "prod-dr" = "65255"
  }

  core_bgp_asn = {
    "nprd-pr" = "65203"
    "prod-pr" = "65253"
    "prod-dr" = "65227"
  }

  core_subscription_diagnostics_settings = {
    logs    = ["Administrative", "Security", "ServiceHealth", "Alert", "Recommendation", "Policy", "Autoscale", "ResourceHealth"]
    metrics = []
  }

  core_vgw_diagnostics_settings = {
    logs    = ["GatewayDiagnosticLog", "IKEDiagnosticLog", "P2SDiagnosticLog", "RouteDiagnosticLog", "TunnelDiagnosticLog"]
    metrics = ["AllMetrics"]
  }

  core_vnet_diagnostics_settings = {
    logs    = ["VMProtectionAlerts"]
    metrics = ["AllMetrics"]
  }

  core_public_ip_diagnostics_settings = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_core_backup"></a> [core\_backup](#output\_core\_backup) | n/a |
| <a name="output_core_default_internet_route"></a> [core\_default\_internet\_route](#output\_core\_default\_internet\_route) | n/a |
| <a name="output_core_gateway_subnet"></a> [core\_gateway\_subnet](#output\_core\_gateway\_subnet) | n/a |
| <a name="output_core_keyvault"></a> [core\_keyvault](#output\_core\_keyvault) | n/a |
| <a name="output_core_keyvault_azure_private_dns_zone"></a> [core\_keyvault\_azure\_private\_dns\_zone](#output\_core\_keyvault\_azure\_private\_dns\_zone) | n/a |
| <a name="output_core_log_analytics_workspace"></a> [core\_log\_analytics\_workspace](#output\_core\_log\_analytics\_workspace) | n/a |
| <a name="output_core_peering"></a> [core\_peering](#output\_core\_peering) | n/a |
| <a name="output_core_primary_local_network_gateway"></a> [core\_primary\_local\_network\_gateway](#output\_core\_primary\_local\_network\_gateway) | n/a |
| <a name="output_core_primary_vgw_pip"></a> [core\_primary\_vgw\_pip](#output\_core\_primary\_vgw\_pip) | n/a |
| <a name="output_core_primary_vgw_to_lgw_connection"></a> [core\_primary\_vgw\_to\_lgw\_connection](#output\_core\_primary\_vgw\_to\_lgw\_connection) | n/a |
| <a name="output_core_private_link_subnet"></a> [core\_private\_link\_subnet](#output\_core\_private\_link\_subnet) | n/a |
| <a name="output_core_rg_azure_qualys"></a> [core\_rg\_azure\_qualys](#output\_core\_rg\_azure\_qualys) | n/a |
| <a name="output_core_rg_data"></a> [core\_rg\_data](#output\_core\_rg\_data) | n/a |
| <a name="output_core_rg_logging"></a> [core\_rg\_logging](#output\_core\_rg\_logging) | n/a |
| <a name="output_core_rg_network"></a> [core\_rg\_network](#output\_core\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_core_rg_security"></a> [core\_rg\_security](#output\_core\_rg\_security) | n/a |
| <a name="output_core_route_table"></a> [core\_route\_table](#output\_core\_route\_table) | n/a |
| <a name="output_core_secondary_local_network_gateway"></a> [core\_secondary\_local\_network\_gateway](#output\_core\_secondary\_local\_network\_gateway) | n/a |
| <a name="output_core_secondary_vgw_pip"></a> [core\_secondary\_vgw\_pip](#output\_core\_secondary\_vgw\_pip) | n/a |
| <a name="output_core_secondary_vgw_to_lgw_connection"></a> [core\_secondary\_vgw\_to\_lgw\_connection](#output\_core\_secondary\_vgw\_to\_lgw\_connection) | n/a |
| <a name="output_core_security_center_pricing"></a> [core\_security\_center\_pricing](#output\_core\_security\_center\_pricing) | n/a |
| <a name="output_core_virtual_network_gateway"></a> [core\_virtual\_network\_gateway](#output\_core\_virtual\_network\_gateway) | n/a |
| <a name="output_core_vnet"></a> [core\_vnet](#output\_core\_vnet) | n/a |

## Usage

#### With Core Key Vault enabled
```terraform
// Deploy the US CH Peninsula Core
// Without Core Key Vault enabled, please send the value in false to variable: core_keyvault_enable = false
//**********************************************************************************************
module "core_us_peninsula" {
    source                                            = "../dn-tads_tf-azure-component-library/core/core_us_ch_peninsula"
    env                                               = var.env
    postfix                                           = var.postfix
    location                                          = var.location
    hub_env                                           = var.env
    core_vnet_address_space                           = var.core_vnet_address_space
    core_vnet_dns_servers                             = var.core_vnet_dns_servers
    gateway_sub_address_prefix                        = var.gateway_sub_address_prefix
    core_private_link_subnet_address_prefixes         = var.core_private_link_subnet_address_prefixes
    core_private_link_subnet_service_endpoints        = var.core_private_link_subnet_service_endpoints
    vgw_lgw_conn_shared_key                           = var.SHARED_KEY
    core_rg_security_enable                           = var.core_rg_security_enable
    core_keyvault_enable                              = var.core_keyvault_enable
    core_keyvault_postfix                             = var.core_keyvault_postfix
    core_keyvault_nacl_allowed_subnets                = var.core_keyvault_nacl_allowed_subnets
    core_keyvault_private_dns_zone_ids                = var.core_keyvault_private_dns_zone_ids
    core_azure_backup_enable_vm_backup                = var.core_azure_backup_enable_vm_backup 
    core_azure_backup_enable_file_storage_backup      = var.core_azure_backup_enable_file_storage_backup
    core_azure_backup_enable_blob_storage_backup      = var.core_azure_backup_enable_blob_storage_backup
    core_keyvault_nacl_allowed_ips                    = var.core_keyvault_nacl_allowed_ips
    tags                                              = var.tags
}
//**********************************************************************************************


//Add private link scoped service from spoke LAW to AMPLS in shared services
//NOTE: Spoke SPN must have contributor role over the private link scope resource in shared services subscription.
//The alias provider azurerm.shs require the resources names from shared services subscription(LAW RG name,AMPLS name,LAW Id)
//**********************************************************************************************
resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = var.ampls_sharedsvcs_logging_rg
  scope_name          = var.ampls_sharedsvcs_log_analytics_private_link_scope_name
  linked_resource_id  = module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
//**********************************************************************************************


// Complete the Peerring SharedServices to Spoke
//NOTE: Spoke SPN must have network contributor role over the vnet resource in shared services subscription.
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "sharedsvcs_peering_core" {
 depends_on                   = [module.core_us_peninsula]
 provider                     = azurerm.shs
 name                         = "peer-to-${var.postfix}-vnet"
 resource_group_name          = var.core_shared_services_resource_group_map  
 virtual_network_name         = var.core_shared_services_network_name_map 
 remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
 allow_virtual_network_access = true
 allow_forwarded_traffic      = true
 use_remote_gateways          = false

 #allow_gateway_transit' must be set to false for vnet Global Peering
 allow_gateway_transit        = false

 timeouts {
   create                     = local.timeout_duration
   delete                     = local.timeout_duration
 }
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
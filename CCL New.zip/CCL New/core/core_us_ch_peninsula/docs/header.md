# Core US Peninsula

This is the U.S. Country Hosting Peninsula Core component for the U.S. Peninsula spoke. It establishes a baseline cloud environment where other components can be deployed into.
Specifically the core module lays the foundational infrastructure required to establish network connectivity  of the Azure cloud resources to the KPMG infrastructure.
This module deploys vnets, vnet peering, route tables, network gateways, key vault, log analytics workspace, security center, public IPs, etc.
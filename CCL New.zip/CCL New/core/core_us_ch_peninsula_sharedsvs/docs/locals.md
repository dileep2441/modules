## Local values

```terraform
locals {
  timeout_duration = "2h"

  core_rg_keyvault_name          = var.core_keyvault_enable && var.core_rg_security_enable ? azurerm_resource_group.core_rg_security[0].name : azurerm_resource_group.core_rg_data.name

  core_first_remote_nva_pip = {
    "nprd-pr" = "52.138.102.104"    
    "prod-pr" = "137.135.105.155"   
    "prod-dr" = "104.42.249.54"
  }

  core_first_bgp_peering_address = {
    "nprd-pr" = "10.4.65.205"
    "prod-pr" = "10.47.129.203" 
    "prod-dr" = "10.47.161.203" 
  }

  core_first_connection_address_space = {
    "nprd-pr" = ["10.4.65.205/32"]
    "prod-pr" = ["10.47.129.203/32"]  
    "prod-dr" = ["10.47.161.203/32"]
  }

  core_second_remote_nva_pip = {
    "nprd-pr" = "52.138.102.58"   
    "prod-pr" = "137.135.105.219"
    "prod-dr" = "13.88.182.186"
  }

  core_second_bgp_peering_address = {
    "nprd-pr" = "10.4.65.206"
    "prod-pr" = "10.47.129.204"
    "prod-dr" = "10.47.161.204"
  }

  core_second_connection_address_space = {
    "nprd-pr" = ["10.4.65.206/32"]
    "prod-pr" = ["10.47.129.204/32"]
    "prod-dr" = ["10.47.161.204/32"]
  }

  core_remote_bgp_asn = {
    "nprd-pr" = "65200"   
    "prod-pr" = "65250"
    "prod-dr" = "65255"
  }

  core_bgp_asn = {
    "nprd-pr" = "65203"
    "prod-pr" = "65253"
    "prod-dr" = "65227"
  }

  core_subscription_diagnostics_settings = {
    logs    = ["Administrative", "Security", "ServiceHealth", "Alert", "Recommendation", "Policy", "Autoscale", "ResourceHealth"]
    metrics = []
  }

  core_vgw_diagnostics_settings = {
    logs    = ["GatewayDiagnosticLog", "IKEDiagnosticLog", "P2SDiagnosticLog", "RouteDiagnosticLog", "TunnelDiagnosticLog"]
    metrics = ["AllMetrics"]
  }

  core_vnet_diagnostics_settings = {
    logs    = ["VMProtectionAlerts"]
    metrics = ["AllMetrics"]
  }

  core_public_ip_diagnostics_settings = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }

   core_private_dns_zones = toset(var.core_private_dns_zone)
   
   core_shared_image_gallery_name = {
        "sbox-pr"  = "sboxpr"
        "nprd-pr"  = "nprdpr"
        "nprd-dr"  = "nprddr"
        "prod-pr"  = "prodpr" 
        "prod-dr"  = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```

```terraform
// US CH SharedServices DR Local variables
***************************************************************************************************

locals {
  core_prod_private_dns_zones = toset(var.core_prod_private_dns_zone) #the variable var.core_prod_private_dns_zone needs to be have the same value from core_us_ch_peninsula_sharedsvs variable core_private_dns_zone in the CCL.
}
***************************************************************************************************
```


<!-- BEGIN_TF_DOCS -->

# Azure Ihub Platform Module
This subscription is responsible for ingress/egress traffic that comes in or comes out from the Spoke subscriptions. iHub subscription will host Azure Virtual Gateways for on-prem connectivity with Cisco appliances in full-mesh configuration and Palo Alto Firewalls for network traffic control. iHub also responsible for routing traffic between subscriptions, on-prem (Peninsula model) and to the Internet.



## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.ihub_nsg_storage_account_advanced_threat_protection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_advanced_threat_protection.ihub_storage_account_advanced_threat_protection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_availability_set.ihub_palo_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_express_route_circuit.circuit](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/express_route_circuit) | resource |
| [azurerm_express_route_circuit_peering.circuit_peering](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/express_route_circuit_peering) | resource |
| [azurerm_key_vault_secret.secret-localpassword-pa](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_key_vault_secret.secret-localusername-pa](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_lb.pa_load_balancer_external](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb) | resource |
| [azurerm_lb.pa_load_balancer_internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb) | resource |
| [azurerm_lb_backend_address_pool.backend_addesspool_ext](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_backend_address_pool) | resource |
| [azurerm_lb_backend_address_pool.backend_addesspool_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_backend_address_pool) | resource |
| [azurerm_lb_probe.lb_probe_ext](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_probe.lb_probe_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_probe) | resource |
| [azurerm_lb_rule.lb_rule_ext](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_lb_rule.lb_rule_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lb_rule) | resource |
| [azurerm_local_network_gateway.ihub_primary_local_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/local_network_gateway) | resource |
| [azurerm_local_network_gateway.ihub_secondary_local_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/local_network_gateway) | resource |
| [azurerm_marketplace_agreement.accept-palo-alto-eula](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/marketplace_agreement) | resource |
| [azurerm_monitor_diagnostic_setting.ihub_nsg_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.ihub_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.pa_load_balancer_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_interface.network_interface_internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface.network_interface_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface.network_interface_perimeter](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_ext](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_interface_backend_address_pool_association.backend_addesspool_associations_int](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_backend_address_pool_association) | resource |
| [azurerm_network_security_group.internal-nsg-sn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.management-nsg-sn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.perimeter-nsg-sn](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.Hub-in-Mgmt-deny-all](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Hub-in-internal-nsg-internal-traffic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Hub-in-mgmt-nsg-allow-kpmg-external](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Hub-in-mgmt-nsg-allow-kpmg-internal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Hub-in-mgmt-nsg-internal-traffic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.Hub-in-perimeter-nsg-internal-traffic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_watcher_flow_log.ihub_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_private_dns_zone.ihub_keyvault_azure_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone.ihub_nsg_storage_account_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.ihub_nsg_storage_account_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_dns_zone_virtual_network_link.keyvault_private_dns_vnet_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_endpoint.ihub_nsg_storage_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_public_ip.ihub_exproute_vgw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.ihub_primary_vgw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.ihub_secondary_vgw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip_internal_pa1](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip_internal_pa2](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip_mgmt_pa1](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip_mgmt_pa2](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip_pa_lb_ext](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip_perimeter_pa1](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip_perimeter_pa2](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_resource_group.ihub_rg_backup](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.ihub_rg_data](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.ihub_rg_exproute](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.ihub_rg_logging](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.ihub_rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.ihub_rg_palo](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.ihub_rg_security](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route.Internet-to-PaloAlto](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route.loopback-fw1](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route.loopback-fw2](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.ihub_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_route_table.ihub_route_table_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_security_center_auto_provisioning.ihub_security_center_auto_provisioning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_auto_provisioning) | resource |
| [azurerm_security_center_contact.ihub_security_center_contact_info](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_contact) | resource |
| [azurerm_security_center_setting.ihub_security_center_wdatp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_setting) | resource |
| [azurerm_security_center_subscription_pricing.ihub_security_center_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_storage_account.ihub_nsg_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account.ihub_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.ihub_nsg_storage_account_network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_subnet.ihub_gateway_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.ihub_internal_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.ihub_mgmt_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.ihub_perimeter_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.ihub_private_link_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.internal-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.management-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.perimeter-nsg-sn_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.join_default](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_subnet_route_table_association.join_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_machine.virtual_machine](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_virtual_machine.virtual_machine_with_avail_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_virtual_network.ihub_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_gateway.ihub_virtual_network_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway) | resource |
| [azurerm_virtual_network_gateway.ihub_virtual_network_gateway-express-route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway) | resource |
| [azurerm_virtual_network_gateway_connection.exproute-vnet-connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway_connection) | resource |
| [azurerm_virtual_network_gateway_connection.ihub_primary_vgw_to_lgw_connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway_connection) | resource |
| [azurerm_virtual_network_gateway_connection.ihub_secondary_vgw_to_lgw_connection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_gateway_connection) | resource |
| [azurerm_virtual_network_peering.peering_ihub_to_avd](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering_ihub_to_idty](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.peering_ihub_to_sharedsvc](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_availability_zones"></a> [availability\_zones](#input\_availability\_zones) | (Required) The llist of availability zones to be leveraged by palo alto VMs | `list(string)` | <pre>[<br>  "1",<br>  "2",<br>  "3"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_ihub_PA_LOCAL_PASS"></a> [ihub\_PA\_LOCAL\_PASS](#input\_ihub\_PA\_LOCAL\_PASS) | (Required) The local admin password for palo alto VM | `string` | n/a | yes |
| <a name="input_ihub_PA_LOCAL_USER"></a> [ihub\_PA\_LOCAL\_USER](#input\_ihub\_PA\_LOCAL\_USER) | (Required) The local admin username for palo alto VM | `string` | n/a | yes |
| <a name="input_ihub_alt_log_analytics_workspace"></a> [ihub\_alt\_log\_analytics\_workspace](#input\_ihub\_alt\_log\_analytics\_workspace) | (Optional) Set to true if resource diagnostic settings need to be sent to an alternative log analytics workspace. | `bool` | `false` | no |
| <a name="input_ihub_alt_log_analytics_workspace_id"></a> [ihub\_alt\_log\_analytics\_workspace\_id](#input\_ihub\_alt\_log\_analytics\_workspace\_id) | (Optional) ID of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_ihub_alt_log_analytics_workspace_name"></a> [ihub\_alt\_log\_analytics\_workspace\_name](#input\_ihub\_alt\_log\_analytics\_workspace\_name) | (Optional) name of alternative log analytics workspace. | `string` | `null` | no |
| <a name="input_ihub_avail_zones_supported"></a> [ihub\_avail\_zones\_supported](#input\_ihub\_avail\_zones\_supported) | (Optional) Set to true if availability zones are supported in region. | `bool` | `true` | no |
| <a name="input_ihub_avd_peering_network_id"></a> [ihub\_avd\_peering\_network\_id](#input\_ihub\_avd\_peering\_network\_id) | (Required) peering id for the AVD vnet | `string` | n/a | yes |
| <a name="input_ihub_azure_defender_resources"></a> [ihub\_azure\_defender\_resources](#input\_ihub\_azure\_defender\_resources) | (Optional) A list of resources with Azure Defender Enabled. | `list` | <pre>[<br>  "VirtualMachines",<br>  "SqlServers",<br>  "StorageAccounts",<br>  "SqlServerVirtualMachines",<br>  "KubernetesService",<br>  "ContainerRegistry",<br>  "Dns",<br>  "Arm",<br>  "OpenSourceRelationalDatabases",<br>  "Containers"<br>]</pre> | no |
| <a name="input_ihub_bgp_asn"></a> [ihub\_bgp\_asn](#input\_ihub\_bgp\_asn) | (Required) BGP ASN for virtual network gateway | `string` | n/a | yes |
| <a name="input_ihub_boot_storage_account_postfix"></a> [ihub\_boot\_storage\_account\_postfix](#input\_ihub\_boot\_storage\_account\_postfix) | (Required) A unique identifier for the storage account. Part of the naming scheme. | `string` | `""` | no |
| <a name="input_ihub_deploy_avd_peering"></a> [ihub\_deploy\_avd\_peering](#input\_ihub\_deploy\_avd\_peering) | n/a | `bool` | `true` | no |
| <a name="input_ihub_deploy_exproute_connection"></a> [ihub\_deploy\_exproute\_connection](#input\_ihub\_deploy\_exproute\_connection) | (Optional) Toogle exproute connection with VGW | `bool` | `false` | no |
| <a name="input_ihub_deploy_idty_peering"></a> [ihub\_deploy\_idty\_peering](#input\_ihub\_deploy\_idty\_peering) | n/a | `bool` | `true` | no |
| <a name="input_ihub_deploy_kv_secret"></a> [ihub\_deploy\_kv\_secret](#input\_ihub\_deploy\_kv\_secret) | n/a | `bool` | `true` | no |
| <a name="input_ihub_deploy_private_link_subnet"></a> [ihub\_deploy\_private\_link\_subnet](#input\_ihub\_deploy\_private\_link\_subnet) | (Required) A boolean to enable/disable the deployment of a private link subnet for the key vault. | `bool` | `false` | no |
| <a name="input_ihub_deploy_ss_peering"></a> [ihub\_deploy\_ss\_peering](#input\_ihub\_deploy\_ss\_peering) | n/a | `bool` | `true` | no |
| <a name="input_ihub_exp_route_active_active"></a> [ihub\_exp\_route\_active\_active](#input\_ihub\_exp\_route\_active\_active) | (Required) Set to true to enable active-active express route gateway | `bool` | `false` | no |
| <a name="input_ihub_exp_route_bandwidth_in_mbps"></a> [ihub\_exp\_route\_bandwidth\_in\_mbps](#input\_ihub\_exp\_route\_bandwidth\_in\_mbps) | (Required) The bandwidth in Mbps of the circuit being created. | `number` | n/a | yes |
| <a name="input_ihub_exp_route_circuit_peering_shared_key"></a> [ihub\_exp\_route\_circuit\_peering\_shared\_key](#input\_ihub\_exp\_route\_circuit\_peering\_shared\_key) | (Optional) shared key for express route circuit peering | `string` | `""` | no |
| <a name="input_ihub_exp_route_circuit_peering_shared_key_avail"></a> [ihub\_exp\_route\_circuit\_peering\_shared\_key\_avail](#input\_ihub\_exp\_route\_circuit\_peering\_shared\_key\_avail) | (Required) Set to true when express route circuit peering shared key is known | `bool` | `false` | no |
| <a name="input_ihub_exp_route_enable_bgp"></a> [ihub\_exp\_route\_enable\_bgp](#input\_ihub\_exp\_route\_enable\_bgp) | (Required) Set to true to enable enable border gateway protocol for express route gateway | `bool` | `false` | no |
| <a name="input_ihub_exp_route_family"></a> [ihub\_exp\_route\_family](#input\_ihub\_exp\_route\_family) | (Required) The billing mode for bandwidth. Possible values are MeteredData or UnlimitedData. | `string` | n/a | yes |
| <a name="input_ihub_exp_route_peer_asn"></a> [ihub\_exp\_route\_peer\_asn](#input\_ihub\_exp\_route\_peer\_asn) | (Optional) The Either a 16-bit or a 32-bit ASN. Can either be public or private.. | `any` | n/a | yes |
| <a name="input_ihub_exp_route_peering_location"></a> [ihub\_exp\_route\_peering\_location](#input\_ihub\_exp\_route\_peering\_location) | (Required) The name of the peering location and not the Azure resource location. | `string` | n/a | yes |
| <a name="input_ihub_exp_route_primary_peer_address_prefix"></a> [ihub\_exp\_route\_primary\_peer\_address\_prefix](#input\_ihub\_exp\_route\_primary\_peer\_address\_prefix) | (Required) A /30 subnet for the primary link. | `string` | n/a | yes |
| <a name="input_ihub_exp_route_secondary_peer_address_prefix"></a> [ihub\_exp\_route\_secondary\_peer\_address\_prefix](#input\_ihub\_exp\_route\_secondary\_peer\_address\_prefix) | (Required) A /30 subnet for the secondary link. | `string` | n/a | yes |
| <a name="input_ihub_exp_route_service_provider_name"></a> [ihub\_exp\_route\_service\_provider\_name](#input\_ihub\_exp\_route\_service\_provider\_name) | (Required) The name of the ExpressRoute Service Provider. | `string` | n/a | yes |
| <a name="input_ihub_exp_route_sku"></a> [ihub\_exp\_route\_sku](#input\_ihub\_exp\_route\_sku) | (Required) sku for the express route gateway | `string` | n/a | yes |
| <a name="input_ihub_exp_route_tier"></a> [ihub\_exp\_route\_tier](#input\_ihub\_exp\_route\_tier) | (Required) The service tier. Possible values are Basic, Local, Standard or Premium. | `string` | n/a | yes |
| <a name="input_ihub_exp_route_vlan_id"></a> [ihub\_exp\_route\_vlan\_id](#input\_ihub\_exp\_route\_vlan\_id) | (Required) A valid VLAN ID to establish this peering on. | `string` | n/a | yes |
| <a name="input_ihub_external_lb_pip_sku"></a> [ihub\_external\_lb\_pip\_sku](#input\_ihub\_external\_lb\_pip\_sku) | (Optional) list of SKU's , every item of list is optional (default value Basic) | `string` | `"standard"` | no |
| <a name="input_ihub_external_lb_probe_interval_in_seconds"></a> [ihub\_external\_lb\_probe\_interval\_in\_seconds](#input\_ihub\_external\_lb\_probe\_interval\_in\_seconds) | (Optional) Port on which the Probe queries the backend endpoint | `number` | `5` | no |
| <a name="input_ihub_external_lb_probe_number_of_probes"></a> [ihub\_external\_lb\_probe\_number\_of\_probes](#input\_ihub\_external\_lb\_probe\_number\_of\_probes) | (Optional) The number of failed probe attempts after which the backend endpoint is removed from rotation. The default value is 2 | `number` | `2` | no |
| <a name="input_ihub_external_lb_probe_port"></a> [ihub\_external\_lb\_probe\_port](#input\_ihub\_external\_lb\_probe\_port) | (Required) Port on which the Probe queries the backend endpoint | `string` | n/a | yes |
| <a name="input_ihub_external_lb_probe_protocol"></a> [ihub\_external\_lb\_probe\_protocol](#input\_ihub\_external\_lb\_probe\_protocol) | (Optional) Specifies the protocol of the end point | `string` | n/a | yes |
| <a name="input_ihub_external_lb_probe_request_path"></a> [ihub\_external\_lb\_probe\_request\_path](#input\_ihub\_external\_lb\_probe\_request\_path) | (Optional) The URI used for requesting health status from the backend endpoint | `string` | `null` | no |
| <a name="input_ihub_external_lb_rule_be_port"></a> [ihub\_external\_lb\_rule\_be\_port](#input\_ihub\_external\_lb\_rule\_be\_port) | (Required) The port used for internal connections on the endpoint | `string` | n/a | yes |
| <a name="input_ihub_external_lb_rule_disable_outbound_snat"></a> [ihub\_external\_lb\_rule\_disable\_outbound\_snat](#input\_ihub\_external\_lb\_rule\_disable\_outbound\_snat) | (Optional) Load Balancer Rule to enable snat | `bool` | `false` | no |
| <a name="input_ihub_external_lb_rule_enable_floating_ip"></a> [ihub\_external\_lb\_rule\_enable\_floating\_ip](#input\_ihub\_external\_lb\_rule\_enable\_floating\_ip) | (Optional) Load Balancer Rule to enable Floating IPs | `bool` | `true` | no |
| <a name="input_ihub_external_lb_rule_enable_tcp_reset"></a> [ihub\_external\_lb\_rule\_enable\_tcp\_reset](#input\_ihub\_external\_lb\_rule\_enable\_tcp\_reset) | (Optional) Load Balancer Rule to enable TCP Reset | `bool` | `false` | no |
| <a name="input_ihub_external_lb_rule_fe_ip_configuration_name"></a> [ihub\_external\_lb\_rule\_fe\_ip\_configuration\_name](#input\_ihub\_external\_lb\_rule\_fe\_ip\_configuration\_name) | (Required) The name of the frontend IP configuration to which the rule is associated | `string` | n/a | yes |
| <a name="input_ihub_external_lb_rule_fe_port"></a> [ihub\_external\_lb\_rule\_fe\_port](#input\_ihub\_external\_lb\_rule\_fe\_port) | (Required) The port for the external endpoint | `string` | n/a | yes |
| <a name="input_ihub_external_lb_rule_idle_timeout_in_minutes"></a> [ihub\_external\_lb\_rule\_idle\_timeout\_in\_minutes](#input\_ihub\_external\_lb\_rule\_idle\_timeout\_in\_minutes) | (Optional) Specifies the idle timeout in minutes for TCP connections | `number` | `4` | no |
| <a name="input_ihub_external_lb_rule_load_distribution"></a> [ihub\_external\_lb\_rule\_load\_distribution](#input\_ihub\_external\_lb\_rule\_load\_distribution) | (Optional) Specifies the load balancing distribution type to be used by the Load Balancer | `string` | `"SourceIPProtocol"` | no |
| <a name="input_ihub_external_lb_rule_protocol"></a> [ihub\_external\_lb\_rule\_protocol](#input\_ihub\_external\_lb\_rule\_protocol) | (Required) The transport protocol for the external endpoint | `string` | n/a | yes |
| <a name="input_ihub_external_lb_sku"></a> [ihub\_external\_lb\_sku](#input\_ihub\_external\_lb\_sku) | (Optional) list of SKU's , every item of list is optional (default value Basic) | `string` | `"standard"` | no |
| <a name="input_ihub_first_bgp_peering_address"></a> [ihub\_first\_bgp\_peering\_address](#input\_ihub\_first\_bgp\_peering\_address) | (Required) BGP Peering address of first local network gateway | `string` | n/a | yes |
| <a name="input_ihub_first_remote_asr_private_ip"></a> [ihub\_first\_remote\_asr\_private\_ip](#input\_ihub\_first\_remote\_asr\_private\_ip) | (Required) ASR private IP of first local network gateway | `string` | n/a | yes |
| <a name="input_ihub_first_remote_bgp_asn"></a> [ihub\_first\_remote\_bgp\_asn](#input\_ihub\_first\_remote\_bgp\_asn) | (Required) BGP ASN for local network gateway | `string` | n/a | yes |
| <a name="input_ihub_gateway_sub_address_prefix"></a> [ihub\_gateway\_sub\_address\_prefix](#input\_ihub\_gateway\_sub\_address\_prefix) | (Required) The address prefix for the gateway subnet. | `string` | n/a | yes |
| <a name="input_ihub_idty_peering_network_id"></a> [ihub\_idty\_peering\_network\_id](#input\_ihub\_idty\_peering\_network\_id) | (Required) peering id for the Identity vnet | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_private_ip_address"></a> [ihub\_internal\_lb\_private\_ip\_address](#input\_ihub\_internal\_lb\_private\_ip\_address) | n/a | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_private_ip_address_allocation"></a> [ihub\_internal\_lb\_private\_ip\_address\_allocation](#input\_ihub\_internal\_lb\_private\_ip\_address\_allocation) | Static | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_probe_interval_in_seconds"></a> [ihub\_internal\_lb\_probe\_interval\_in\_seconds](#input\_ihub\_internal\_lb\_probe\_interval\_in\_seconds) | (Optional) Port on which the Probe queries the backend endpoint | `number` | `5` | no |
| <a name="input_ihub_internal_lb_probe_number_of_probes"></a> [ihub\_internal\_lb\_probe\_number\_of\_probes](#input\_ihub\_internal\_lb\_probe\_number\_of\_probes) | (Optional) The number of failed probe attempts after which the backend endpoint is removed from rotation. The default value is 2 | `number` | `2` | no |
| <a name="input_ihub_internal_lb_probe_port"></a> [ihub\_internal\_lb\_probe\_port](#input\_ihub\_internal\_lb\_probe\_port) | (Required) Port on which the Probe queries the backend endpoint | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_probe_protocol"></a> [ihub\_internal\_lb\_probe\_protocol](#input\_ihub\_internal\_lb\_probe\_protocol) | (Optional) Specifies the protocol of the end point | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_probe_request_path"></a> [ihub\_internal\_lb\_probe\_request\_path](#input\_ihub\_internal\_lb\_probe\_request\_path) | (Optional) The URI used for requesting health status from the backend endpoint | `string` | `null` | no |
| <a name="input_ihub_internal_lb_rule_be_port"></a> [ihub\_internal\_lb\_rule\_be\_port](#input\_ihub\_internal\_lb\_rule\_be\_port) | (Required) The port used for internal connections on the endpoint | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_rule_disable_outbound_snat"></a> [ihub\_internal\_lb\_rule\_disable\_outbound\_snat](#input\_ihub\_internal\_lb\_rule\_disable\_outbound\_snat) | (Optional) Load Balancer Rule to enable snat | `bool` | `false` | no |
| <a name="input_ihub_internal_lb_rule_enable_floating_ip"></a> [ihub\_internal\_lb\_rule\_enable\_floating\_ip](#input\_ihub\_internal\_lb\_rule\_enable\_floating\_ip) | (Optional) Load Balancer Rule to enable Floating IPs | `bool` | `true` | no |
| <a name="input_ihub_internal_lb_rule_enable_tcp_reset"></a> [ihub\_internal\_lb\_rule\_enable\_tcp\_reset](#input\_ihub\_internal\_lb\_rule\_enable\_tcp\_reset) | (Optional) Load Balancer Rule to enable TCP Reset | `bool` | `false` | no |
| <a name="input_ihub_internal_lb_rule_fe_ip_configuration_name"></a> [ihub\_internal\_lb\_rule\_fe\_ip\_configuration\_name](#input\_ihub\_internal\_lb\_rule\_fe\_ip\_configuration\_name) | (Required) The name of the frontend IP configuration to which the rule is associated | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_rule_fe_port"></a> [ihub\_internal\_lb\_rule\_fe\_port](#input\_ihub\_internal\_lb\_rule\_fe\_port) | (Required) The port for the internal endpoint | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_rule_idle_timeout_in_minutes"></a> [ihub\_internal\_lb\_rule\_idle\_timeout\_in\_minutes](#input\_ihub\_internal\_lb\_rule\_idle\_timeout\_in\_minutes) | (Optional) Specifies the idle timeout in minutes for TCP connections | `number` | `4` | no |
| <a name="input_ihub_internal_lb_rule_load_distribution"></a> [ihub\_internal\_lb\_rule\_load\_distribution](#input\_ihub\_internal\_lb\_rule\_load\_distribution) | (Optional) Specifies the load balancing distribution type to be used by the Load Balancer | `string` | `"SourceIPProtocol"` | no |
| <a name="input_ihub_internal_lb_rule_protocol"></a> [ihub\_internal\_lb\_rule\_protocol](#input\_ihub\_internal\_lb\_rule\_protocol) | (Required) The transport protocol for the internal endpoint | `string` | n/a | yes |
| <a name="input_ihub_internal_lb_sku"></a> [ihub\_internal\_lb\_sku](#input\_ihub\_internal\_lb\_sku) | (Optional) list of SKU's , every item of list is optional (default value Basic) | `string` | `"standard"` | no |
| <a name="input_ihub_internal_sub_address_prefix"></a> [ihub\_internal\_sub\_address\_prefix](#input\_ihub\_internal\_sub\_address\_prefix) | (Required) The address prefix for the internal subnet. | `string` | n/a | yes |
| <a name="input_ihub_keyvault_allowed_pe_subnet_ids"></a> [ihub\_keyvault\_allowed\_pe\_subnet\_ids](#input\_ihub\_keyvault\_allowed\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_ihub_keyvault_az_svcs_bypass"></a> [ihub\_keyvault\_az\_svcs\_bypass](#input\_ihub\_keyvault\_az\_svcs\_bypass) | (Optional) Specifies which traffic can bypass the network rules. | `string` | `"AzureServices"` | no |
| <a name="input_ihub_keyvault_deploy_private_dns_zone"></a> [ihub\_keyvault\_deploy\_private\_dns\_zone](#input\_ihub\_keyvault\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the key vault private endpoint. | `bool` | `false` | no |
| <a name="input_ihub_keyvault_diagnostics"></a> [ihub\_keyvault\_diagnostics](#input\_ihub\_keyvault\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AuditEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ihub_keyvault_enable"></a> [ihub\_keyvault\_enable](#input\_ihub\_keyvault\_enable) | (Required) Enable the creation for azure key vault | `bool` | `false` | no |
| <a name="input_ihub_keyvault_enabled_for_deployment"></a> [ihub\_keyvault\_enabled\_for\_deployment](#input\_ihub\_keyvault\_enabled\_for\_deployment) | (Optional) Boolean to enable vms to be able to fetch from keyvault. | `bool` | `true` | no |
| <a name="input_ihub_keyvault_enabled_for_disk_encryption"></a> [ihub\_keyvault\_enabled\_for\_disk\_encryption](#input\_ihub\_keyvault\_enabled\_for\_disk\_encryption) | (Optional) Boolean to enable vms to use keyvault certificates for disk encryption. | `bool` | `true` | no |
| <a name="input_ihub_keyvault_enabled_for_template_deployment"></a> [ihub\_keyvault\_enabled\_for\_template\_deployment](#input\_ihub\_keyvault\_enabled\_for\_template\_deployment) | (Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault. | `bool` | `false` | no |
| <a name="input_ihub_keyvault_log_analytics_solutions"></a> [ihub\_keyvault\_log\_analytics\_solutions](#input\_ihub\_keyvault\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "KeyVaultAnalytics": {<br>    "product": "OMSGallery/KeyVaultAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ihub_keyvault_nacl_allowed_ips"></a> [ihub\_keyvault\_nacl\_allowed\_ips](#input\_ihub\_keyvault\_nacl\_allowed\_ips) | (Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault. | `list(string)` | `[]` | no |
| <a name="input_ihub_keyvault_nacl_allowed_subnets"></a> [ihub\_keyvault\_nacl\_allowed\_subnets](#input\_ihub\_keyvault\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Key Vault. | `list(string)` | `[]` | no |
| <a name="input_ihub_keyvault_nacl_default_action"></a> [ihub\_keyvault\_nacl\_default\_action](#input\_ihub\_keyvault\_nacl\_default\_action) | (Optional) The Default Action to use when no rules match from ip\_rules / virtual\_network\_subnet\_ids. | `string` | `"Deny"` | no |
| <a name="input_ihub_keyvault_purge_protection_enabled"></a> [ihub\_keyvault\_purge\_protection\_enabled](#input\_ihub\_keyvault\_purge\_protection\_enabled) | (Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed. | `bool` | `true` | no |
| <a name="input_ihub_keyvault_sku_name"></a> [ihub\_keyvault\_sku\_name](#input\_ihub\_keyvault\_sku\_name) | (Optional) The Name of the SKU used for Key Vault | `string` | `"standard"` | no |
| <a name="input_ihub_load_balancer_diagnostics"></a> [ihub\_load\_balancer\_diagnostics](#input\_ihub\_load\_balancer\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ihub_local_azure_ip_address_enabled"></a> [ihub\_local\_azure\_ip\_address\_enabled](#input\_ihub\_local\_azure\_ip\_address\_enabled) | (Required) set to true to enable private IP for virtual network gateway connection | `bool` | `false` | no |
| <a name="input_ihub_log_analytics_supported"></a> [ihub\_log\_analytics\_supported](#input\_ihub\_log\_analytics\_supported) | (Optional) Set to true if log analytics workspace is supported in region. | `bool` | `true` | no |
| <a name="input_ihub_mgmt_sub_address_prefix"></a> [ihub\_mgmt\_sub\_address\_prefix](#input\_ihub\_mgmt\_sub\_address\_prefix) | (Required) The address prefix for the mgmt subnet. | `string` | n/a | yes |
| <a name="input_ihub_nsg_count"></a> [ihub\_nsg\_count](#input\_ihub\_nsg\_count) | (Optional) Number of NSGs in databricks component. | `number` | `3` | no |
| <a name="input_ihub_nsg_name"></a> [ihub\_nsg\_name](#input\_ihub\_nsg\_name) | (Optional) NSG postfix names. | `list` | <pre>[<br>  "mgmt",<br>  "perimeter",<br>  "internal"<br>]</pre> | no |
| <a name="input_ihub_nsg_storage_account_allowed_ips"></a> [ihub\_nsg\_storage\_account\_allowed\_ips](#input\_ihub\_nsg\_storage\_account\_allowed\_ips) | (Optional) A list of Ip addresses that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_ihub_nsg_storage_account_postfix"></a> [ihub\_nsg\_storage\_account\_postfix](#input\_ihub\_nsg\_storage\_account\_postfix) | ********************************************************************************************** NSGs Variables ********************************************************************************************** | `any` | n/a | yes |
| <a name="input_ihub_nsg_storage_account_private_dns_zone_ids"></a> [ihub\_nsg\_storage\_account\_private\_dns\_zone\_ids](#input\_ihub\_nsg\_storage\_account\_private\_dns\_zone\_ids) | (Required) the centralized blob private dns zone resource id | `list(string)` | `[]` | no |
| <a name="input_ihub_pa_computer_names"></a> [ihub\_pa\_computer\_names](#input\_ihub\_pa\_computer\_names) | (Optional): Custom os computer names to give to the VMs. | `list(string)` | `null` | no |
| <a name="input_ihub_pa_network_interface_count"></a> [ihub\_pa\_network\_interface\_count](#input\_ihub\_pa\_network\_interface\_count) | (Required) The count for Palo Alto NICs | `number` | `2` | no |
| <a name="input_ihub_pa_pip_sku"></a> [ihub\_pa\_pip\_sku](#input\_ihub\_pa\_pip\_sku) | (Required) sku type for public ip | `string` | `"standard"` | no |
| <a name="input_ihub_pa_virtual_networks"></a> [ihub\_pa\_virtual\_networks](#input\_ihub\_pa\_virtual\_networks) | (Optional): List of virtual networks Interfaces to select from. Optional if ihub\_pa\_virtual\_networks\_list is provided. | `list(string)` | `null` | no |
| <a name="input_ihub_pa_vm_names"></a> [ihub\_pa\_vm\_names](#input\_ihub\_pa\_vm\_names) | (Optional): Custom names to give to the VMs. | `list(string)` | `null` | no |
| <a name="input_ihub_pa_vm_timezone"></a> [ihub\_pa\_vm\_timezone](#input\_ihub\_pa\_vm\_timezone) | (Required) The ihub\_pa\_vm\_timezone of the vms. Required if OS = Windows | `string` | `"UTC"` | no |
| <a name="input_ihub_pa_zones"></a> [ihub\_pa\_zones](#input\_ihub\_pa\_zones) | (Optional) A collection containing the availability zone to allocate the Public IP in | `string` | `null` | no |
| <a name="input_ihub_perimeter_sub_address_prefix"></a> [ihub\_perimeter\_sub\_address\_prefix](#input\_ihub\_perimeter\_sub\_address\_prefix) | (Required) The address prefix for the perimeter subnet. | `string` | n/a | yes |
| <a name="input_ihub_private_link_subnet_address_prefixes"></a> [ihub\_private\_link\_subnet\_address\_prefixes](#input\_ihub\_private\_link\_subnet\_address\_prefixes) | (Required) The address prefixes for the subnet of key vault. | `string` | `""` | no |
| <a name="input_ihub_private_link_subnet_enforce_endpoint_network_policies"></a> [ihub\_private\_link\_subnet\_enforce\_endpoint\_network\_policies](#input\_ihub\_private\_link\_subnet\_enforce\_endpoint\_network\_policies) | (Required) Enable or Disable network policies for the private link endpoint on the subnet. | `bool` | `false` | no |
| <a name="input_ihub_private_link_subnet_service_endpoints"></a> [ihub\_private\_link\_subnet\_service\_endpoints](#input\_ihub\_private\_link\_subnet\_service\_endpoints) | (Optional) | `list(string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_ihub_rg_security_enable"></a> [ihub\_rg\_security\_enable](#input\_ihub\_rg\_security\_enable) | (Required) Enable the creation for Security Resource Group, if this value is false, related resources should be moved to ihub\_rg\_data | `bool` | `false` | no |
| <a name="input_ihub_route_table_bgp_propagation"></a> [ihub\_route\_table\_bgp\_propagation](#input\_ihub\_route\_table\_bgp\_propagation) | (Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it. | `bool` | `false` | no |
| <a name="input_ihub_route_table_loopback_fw1_address_prefix"></a> [ihub\_route\_table\_loopback\_fw1\_address\_prefix](#input\_ihub\_route\_table\_loopback\_fw1\_address\_prefix) | (Required) The address prefix for the first firewall loopback route. | `string` | n/a | yes |
| <a name="input_ihub_route_table_loopback_fw2_address_prefix"></a> [ihub\_route\_table\_loopback\_fw2\_address\_prefix](#input\_ihub\_route\_table\_loopback\_fw2\_address\_prefix) | (Required) The address prefix for the second firewall loopback route. | `string` | n/a | yes |
| <a name="input_ihub_second_bgp_peering_address"></a> [ihub\_second\_bgp\_peering\_address](#input\_ihub\_second\_bgp\_peering\_address) | (Required) BGP Peering address of second local network gateway | `string` | n/a | yes |
| <a name="input_ihub_second_remote_asr_private_ip"></a> [ihub\_second\_remote\_asr\_private\_ip](#input\_ihub\_second\_remote\_asr\_private\_ip) | (Required) ASR private IP of second local network gateway | `string` | n/a | yes |
| <a name="input_ihub_second_remote_bgp_asn"></a> [ihub\_second\_remote\_bgp\_asn](#input\_ihub\_second\_remote\_bgp\_asn) | (Required) BGP ASN for local network gateway | `string` | n/a | yes |
| <a name="input_ihub_shared_services_peering_network_id"></a> [ihub\_shared\_services\_peering\_network\_id](#input\_ihub\_shared\_services\_peering\_network\_id) | (Required) peering id for the shared services vnet | `string` | n/a | yes |
| <a name="input_ihub_storage_account_access_tier"></a> [ihub\_storage\_account\_access\_tier](#input\_ihub\_storage\_account\_access\_tier) | (Optional) Defines the access tier for BlobStorage, FileStorage and StorageV2 accounts. Valid options are Hot and Cool | `any` | `null` | no |
| <a name="input_ihub_storage_account_blob_enable_backup"></a> [ihub\_storage\_account\_blob\_enable\_backup](#input\_ihub\_storage\_account\_blob\_enable\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_ihub_storage_account_blob_retention_days"></a> [ihub\_storage\_account\_blob\_retention\_days](#input\_ihub\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_ihub_storage_account_deploy_private_dns_zone"></a> [ihub\_storage\_account\_deploy\_private\_dns\_zone](#input\_ihub\_storage\_account\_deploy\_private\_dns\_zone) | (Optional) A boolean to enable/disable the deployment of a private dns zone for the SA private endpoint. | `bool` | `false` | no |
| <a name="input_ihub_storage_account_diagnostics"></a> [ihub\_storage\_account\_diagnostics](#input\_ihub\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ihub_storage_account_kind"></a> [ihub\_storage\_account\_kind](#input\_ihub\_storage\_account\_kind) | (Optional)  Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. | `string` | `"StorageV2"` | no |
| <a name="input_ihub_storage_account_large_file_share"></a> [ihub\_storage\_account\_large\_file\_share](#input\_ihub\_storage\_account\_large\_file\_share) | Is Large File Share Enabled? | `bool` | `false` | no |
| <a name="input_ihub_storage_account_queue_enabled"></a> [ihub\_storage\_account\_queue\_enabled](#input\_ihub\_storage\_account\_queue\_enabled) | (Optional) If set to true, create queues | `bool` | `false` | no |
| <a name="input_ihub_storage_account_replication_to_LRS"></a> [ihub\_storage\_account\_replication\_to\_LRS](#input\_ihub\_storage\_account\_replication\_to\_LRS) | If set to true, it overrides the replication to LRS | `bool` | `false` | no |
| <a name="input_ihub_storage_account_tier"></a> [ihub\_storage\_account\_tier](#input\_ihub\_storage\_account\_tier) | (Optional) The pricing tier for the storage account. | `string` | `"Standard"` | no |
| <a name="input_ihub_storage_account_tls_version"></a> [ihub\_storage\_account\_tls\_version](#input\_ihub\_storage\_account\_tls\_version) | (Optional) The minimum supported TLS version for the storage account. Possible values are TLS1\_0, TLS1\_1, and TLS1\_2. | `string` | `"TLS1_2"` | no |
| <a name="input_ihub_vgw_active_active"></a> [ihub\_vgw\_active\_active](#input\_ihub\_vgw\_active\_active) | (Required) Set to true to enable active-active virtual network gateway | `bool` | `false` | no |
| <a name="input_ihub_vgw_enable_bgp"></a> [ihub\_vgw\_enable\_bgp](#input\_ihub\_vgw\_enable\_bgp) | (Required) Set to true to enable border gateway protocol for virtual network gateway | `bool` | `false` | no |
| <a name="input_ihub_vgw_enable_privateip"></a> [ihub\_vgw\_enable\_privateip](#input\_ihub\_vgw\_enable\_privateip) | (Required) set to true to enable private IP for virtual network gateway | `bool` | `true` | no |
| <a name="input_ihub_vgw_generation"></a> [ihub\_vgw\_generation](#input\_ihub\_vgw\_generation) | (Optional) The Generation of the Virtual Network gateway. Possible values include Generation1, Generation2 or None. Changing this forces a new resource to be created. | `string` | `"Generation2"` | no |
| <a name="input_ihub_vgw_lgw_conn_shared_key"></a> [ihub\_vgw\_lgw\_conn\_shared\_key](#input\_ihub\_vgw\_lgw\_conn\_shared\_key) | (Required) The shared key to use for the VGW to LGW connections. | `string` | n/a | yes |
| <a name="input_ihub_vgw_sku"></a> [ihub\_vgw\_sku](#input\_ihub\_vgw\_sku) | (Required) sku for virtual network gateway | `string` | n/a | yes |
| <a name="input_ihub_vnet_address_space"></a> [ihub\_vnet\_address\_space](#input\_ihub\_vnet\_address\_space) | (Required) The address space for the virtual network. | `string` | n/a | yes |
| <a name="input_ihub_vnet_dns_servers"></a> [ihub\_vnet\_dns\_servers](#input\_ihub\_vnet\_dns\_servers) | (Optional) A list of DNS servers to use. If left empty, defaults to Azure servers. | `list(string)` | `[]` | no |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `string` | n/a | yes |
| <a name="input_paloalto"></a> [paloalto](#input\_paloalto) | (Required) Details that will be used to create the Palo Alto Firewall | <pre>object({<br>    wvd_count               = string,<br>    vm_size                 = string,<br>    vm_prefix               = string,<br>    vm_image_id             = string,<br>    vm_publisher            = string,<br>    vm_offer                = string,<br>    vm_sku                  = string,<br>    vm_version              = string,<br>    vm_storage_os_disk_size = string,<br>    vm_os                   = string,<br>    vm_from_marketplace     = string,<br>    management_privateip    = list(string),<br>    perimeter_privateip     = list(string),<br>    internal_privateip      = list(string)<br>  })</pre> | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `string` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
 # ihub_keyvault_private_dns_zone    = var.ihub_keyvault_enable && var.ihub_keyvault_deploy_private_dns_zone    ? [azurerm_private_dns_zone.ihub_keyvault_azure_private_dns_zone[0].id] : var.ihub_keyvault_private_dns_zone_ids
  ihub_private_link_subnet          = var.ihub_deploy_private_link_subnet ? [azurerm_subnet.ihub_private_link_subnet[0].id]              : var.ihub_keyvault_allowed_pe_subnet_ids
  ihub_rg_keyvault_name             = var.ihub_keyvault_enable && var.ihub_rg_security_enable ?  azurerm_resource_group.ihub_rg_security[0].name  : azurerm_resource_group.ihub_rg_data.name
  ihub_storage_account_replication_to_LRS    = (var.ihub_storage_account_replication_to_LRS || var.env == "nprd-pr"  ? true : false ) 
  ihub_storage_account_replication_type      = (var.ihub_storage_account_tier != "Premium" ? "GRS" : "LRS")

  ihub_storage_account_name_no_dash          = replace("${var.env}${var.postfix}${var.suffix}", "-", "")        
  ihub_storage_account_blob_properties       = (var.ihub_storage_account_kind == "FileStorage" || var.ihub_storage_account_blob_enable_backup ? false : true)
  ihub_storage_account_infra_encryption_enabled = (var.ihub_storage_account_kind == "StorageV2" || (var.ihub_storage_account_kind == "BlockBlobStorage" && var.ihub_storage_account_tier == "Premium") ? true : false)

  ihub_storage_account_queue_enabled         = (var.ihub_storage_account_tier == "Standard" && var.ihub_storage_account_kind != "BlobStorage" && var.ihub_storage_account_queue_enabled ? true : false)
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ihub_Internet-to-PaloAlto"></a> [ihub\_Internet-to-PaloAlto](#output\_ihub\_Internet-to-PaloAlto) | n/a |
| <a name="output_ihub_exproute-vnet-connection"></a> [ihub\_exproute-vnet-connection](#output\_ihub\_exproute-vnet-connection) | n/a |
| <a name="output_ihub_exproute_circuit"></a> [ihub\_exproute\_circuit](#output\_ihub\_exproute\_circuit) | n/a |
| <a name="output_ihub_exproute_circuit_peering"></a> [ihub\_exproute\_circuit\_peering](#output\_ihub\_exproute\_circuit\_peering) | n/a |
| <a name="output_ihub_gateway_subnet"></a> [ihub\_gateway\_subnet](#output\_ihub\_gateway\_subnet) | n/a |
| <a name="output_ihub_internal_subnet"></a> [ihub\_internal\_subnet](#output\_ihub\_internal\_subnet) | n/a |
| <a name="output_ihub_keyvault"></a> [ihub\_keyvault](#output\_ihub\_keyvault) | n/a |
| <a name="output_ihub_log_analytics_workspace"></a> [ihub\_log\_analytics\_workspace](#output\_ihub\_log\_analytics\_workspace) | n/a |
| <a name="output_ihub_mgmt_subnet"></a> [ihub\_mgmt\_subnet](#output\_ihub\_mgmt\_subnet) | n/a |
| <a name="output_ihub_nsg_storage_account"></a> [ihub\_nsg\_storage\_account](#output\_ihub\_nsg\_storage\_account) | n/a |
| <a name="output_ihub_pa_load_balancer_external"></a> [ihub\_pa\_load\_balancer\_external](#output\_ihub\_pa\_load\_balancer\_external) | n/a |
| <a name="output_ihub_pa_load_balancer_internal"></a> [ihub\_pa\_load\_balancer\_internal](#output\_ihub\_pa\_load\_balancer\_internal) | n/a |
| <a name="output_ihub_pa_virtual_machine"></a> [ihub\_pa\_virtual\_machine](#output\_ihub\_pa\_virtual\_machine) | n/a |
| <a name="output_ihub_peering_to_avd"></a> [ihub\_peering\_to\_avd](#output\_ihub\_peering\_to\_avd) | n/a |
| <a name="output_ihub_peering_to_identity"></a> [ihub\_peering\_to\_identity](#output\_ihub\_peering\_to\_identity) | n/a |
| <a name="output_ihub_peering_to_sharedsvc"></a> [ihub\_peering\_to\_sharedsvc](#output\_ihub\_peering\_to\_sharedsvc) | n/a |
| <a name="output_ihub_perimeter_subnet"></a> [ihub\_perimeter\_subnet](#output\_ihub\_perimeter\_subnet) | n/a |
| <a name="output_ihub_primary_local_network_gateway"></a> [ihub\_primary\_local\_network\_gateway](#output\_ihub\_primary\_local\_network\_gateway) | n/a |
| <a name="output_ihub_primary_vgw_pip"></a> [ihub\_primary\_vgw\_pip](#output\_ihub\_primary\_vgw\_pip) | n/a |
| <a name="output_ihub_primary_vgw_to_lgw_connection"></a> [ihub\_primary\_vgw\_to\_lgw\_connection](#output\_ihub\_primary\_vgw\_to\_lgw\_connection) | n/a |
| <a name="output_ihub_private_link_subnet"></a> [ihub\_private\_link\_subnet](#output\_ihub\_private\_link\_subnet) | n/a |
| <a name="output_ihub_rg_data"></a> [ihub\_rg\_data](#output\_ihub\_rg\_data) | n/a |
| <a name="output_ihub_rg_exproute"></a> [ihub\_rg\_exproute](#output\_ihub\_rg\_exproute) | n/a |
| <a name="output_ihub_rg_logging"></a> [ihub\_rg\_logging](#output\_ihub\_rg\_logging) | n/a |
| <a name="output_ihub_rg_network"></a> [ihub\_rg\_network](#output\_ihub\_rg\_network) | Outputs ********************************************************************************************** |
| <a name="output_ihub_rg_palo"></a> [ihub\_rg\_palo](#output\_ihub\_rg\_palo) | n/a |
| <a name="output_ihub_rg_security"></a> [ihub\_rg\_security](#output\_ihub\_rg\_security) | n/a |
| <a name="output_ihub_route_table"></a> [ihub\_route\_table](#output\_ihub\_route\_table) | n/a |
| <a name="output_ihub_secondary_local_network_gateway"></a> [ihub\_secondary\_local\_network\_gateway](#output\_ihub\_secondary\_local\_network\_gateway) | n/a |
| <a name="output_ihub_secondary_vgw_pip"></a> [ihub\_secondary\_vgw\_pip](#output\_ihub\_secondary\_vgw\_pip) | n/a |
| <a name="output_ihub_secondary_vgw_to_lgw_connection"></a> [ihub\_secondary\_vgw\_to\_lgw\_connection](#output\_ihub\_secondary\_vgw\_to\_lgw\_connection) | n/a |
| <a name="output_ihub_security_center_pricing"></a> [ihub\_security\_center\_pricing](#output\_ihub\_security\_center\_pricing) | n/a |
| <a name="output_ihub_storage_account"></a> [ihub\_storage\_account](#output\_ihub\_storage\_account) | n/a |
| <a name="output_ihub_virtual_network_gateway"></a> [ihub\_virtual\_network\_gateway](#output\_ihub\_virtual\_network\_gateway) | n/a |
| <a name="output_ihub_virtual_network_gateway-express-route"></a> [ihub\_virtual\_network\_gateway-express-route](#output\_ihub\_virtual\_network\_gateway-express-route) | n/a |
| <a name="output_ihub_vnet"></a> [ihub\_vnet](#output\_ihub\_vnet) | n/a |


## Usage

```terraform
// Deploy the US Gov Peninsula Ihub
//**********************************************************************************************
module "core_us_gov_ihub" {
    source                          = "../dn-tads_tf-azure-component-library/core/core_us_gov_ihub"   #"../dn-tads_tf-azure-gov_component-library/core/core_us_gov_ihub"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    suffix                          = var.suffix
    tags                            = var.tags
    ihub_vgw_lgw_conn_shared_key    = var.SHARED_KEY
    ihub_vnet_dns_servers           = var.ihub_vnet_dns_servers
    ihub_vnet_address_space         = var.ihub_vnet_address_space
    ihub_gateway_sub_address_prefix      = var.ihub_gateway_sub_address_prefix
    ihub_internal_sub_address_prefix     = var.ihub_internal_sub_address_prefix
    ihub_mgmt_sub_address_prefix         = var.ihub_mgmt_sub_address_prefix
    ihub_perimeter_sub_address_prefix    = var.ihub_perimeter_sub_address_prefix
    ihub_deploy_exproute_connection      = var.ihub_deploy_exproute_connection #true
    ihub_log_analytics_supported         = var.ihub_log_analytics_supported #true
    ihub_avail_zones_supported           = var.ihub_avail_zones_supported # true
    ihub_alt_log_analytics_workspace        = var.ihub_alt_log_analytics_workspace
    ihub_alt_log_analytics_workspace_id     = var.ihub_alt_log_analytics_workspace_id
    ihub_alt_log_analytics_workspace_name   = var.ihub_alt_log_analytics_workspace_name

    #Peering
    ihub_shared_services_peering_network_id    = var.ihub_shared_services_peering_network_id
    ihub_avd_peering_network_id                = var.ihub_avd_peering_network_id
    ihub_idty_peering_network_id               = var.ihub_idty_peering_network_id 
    ihub_deploy_avd_peering                    = var.ihub_deploy_avd_peering # true
    ihub_deploy_ss_peering                     = var.ihub_deploy_ss_peering # true
    ihub_deploy_idty_peering                   = var.ihub_deploy_idty_peering # true


    #NSGs
    ihub_nsg_storage_account_postfix            = var.ihub_nsg_storage_account_postfix

    #key vault
    ihub_rg_security_enable                                             = var.ihub_rg_security_enable  #true
    ihub_keyvault_enable                                                = var.ihub_keyvault_enable #true
    ihub_deploy_private_link_subnet                                     = var.ihub_deploy_private_link_subnet  #true
    ihub_private_link_subnet_address_prefixes                           = var.ihub_private_link_subnet_address_prefixes
    ihub_private_link_subnet_enforce_endpoint_network_policies          = var.ihub_private_link_subnet_enforce_endpoint_network_policies #true


    ihub_deploy_kv_secret                                              = var.ihub_deploy_kv_secret #true
    ihub_keyvault_nacl_allowed_subnets                                 = var.ihub_keyvault_nacl_allowed_subnets



    #Route table
    ihub_route_table_loopback_fw1_address_prefix = var.ihub_route_table_loopback_fw1_address_prefix
    ihub_route_table_loopback_fw2_address_prefix = var.ihub_route_table_loopback_fw2_address_prefix

    
    #VGW
    ihub_vgw_active_active                    = var.ihub_vgw_active_active #true
    ihub_vgw_enable_bgp                       = var.ihub_vgw_enable_bgp #true
    ihub_vgw_sku                              = var.ihub_vgw_sku
    ihub_vgw_enable_privateip                 = var.ihub_vgw_enable_privateip  #true
    ihub_local_azure_ip_address_enabled       = var.ihub_local_azure_ip_address_enabled #true
    ihub_first_remote_asr_private_ip          = var.ihub_first_remote_asr_private_ip  
    ihub_first_bgp_peering_address            = var.ihub_first_bgp_peering_address       
    ihub_second_remote_asr_private_ip         = var.ihub_second_remote_asr_private_ip 
    ihub_second_bgp_peering_address           = var.ihub_second_bgp_peering_address    
    ihub_first_remote_bgp_asn                 = var.ihub_first_remote_bgp_asn 
    ihub_second_remote_bgp_asn                = var.ihub_second_remote_bgp_asn
    ihub_bgp_asn                              = var.ihub_bgp_asn
    
    #boot diagnostics
    ihub_boot_storage_account_postfix              = var.ihub_boot_storage_account_postfix
    
    #express route
    ihub_exp_route_service_provider_name         = var.ihub_exp_route_service_provider_name
    ihub_exp_route_bandwidth_in_mbps             = var.ihub_exp_route_bandwidth_in_mbps
    ihub_exp_route_peering_location              = var.ihub_exp_route_peering_location
    ihub_exp_route_tier                          = var.ihub_exp_route_tier 
    ihub_exp_route_family                        = var.ihub_exp_route_family
    ihub_exp_route_primary_peer_address_prefix   = var.ihub_exp_route_primary_peer_address_prefix
    ihub_exp_route_secondary_peer_address_prefix = var.ihub_exp_route_secondary_peer_address_prefix
    ihub_exp_route_vlan_id                       = var.ihub_exp_route_vlan_id
    ihub_exp_route_peer_asn                      = var.ihub_exp_route_peer_asn
    ihub_exp_route_sku                           = var.ihub_exp_route_sku
    ihub_exp_route_active_active                 = var.ihub_exp_route_active_active #false
    ihub_exp_route_enable_bgp                    = var.ihub_exp_route_enable_bgp #false
    ihub_exp_route_circuit_peering_shared_key    = var.ihub_exp_route_circuit_peering_shared_key
    ihub_exp_route_circuit_peering_shared_key_avail = var.ihub_exp_route_circuit_peering_shared_key_avail #false

    
    #palo alto external LB
    ihub_external_lb_probe_protocol                = var.ihub_external_lb_probe_protocol
    ihub_external_lb_probe_port                    = var.ihub_external_lb_probe_port                    
    ihub_external_lb_rule_fe_ip_configuration_name = var.ihub_external_lb_rule_fe_ip_configuration_name
    ihub_external_lb_rule_protocol                 = var.ihub_external_lb_rule_protocol
    ihub_external_lb_rule_fe_port                  = var.ihub_external_lb_rule_fe_port
    ihub_external_lb_rule_be_port                  = var.ihub_external_lb_rule_be_port

    
    #palo alto internal LB
    ihub_internal_lb_probe_protocol                = var.ihub_internal_lb_probe_protocol
    ihub_internal_lb_probe_port                    = var.ihub_internal_lb_probe_port                     
    ihub_internal_lb_rule_fe_ip_configuration_name = var.ihub_internal_lb_rule_fe_ip_configuration_name 
    ihub_internal_lb_rule_protocol                 = var.ihub_internal_lb_rule_protocol
    ihub_internal_lb_rule_fe_port                  = var.ihub_internal_lb_rule_fe_port
    ihub_internal_lb_rule_be_port                  = var.ihub_internal_lb_rule_be_port
    ihub_internal_lb_private_ip_address            = var.ihub_internal_lb_private_ip_address    
    ihub_internal_lb_private_ip_address_allocation = var.ihub_internal_lb_private_ip_address_allocation

    #palo alto VMs
    ihub_PA_LOCAL_USER                         = var.ihub_PA_LOCAL_USER 
    ihub_PA_LOCAL_PASS                         = var.ihub_PA_LOCAL_PASS   
    paloalto = {
        wvd_count               = var.paloalto.wvd_count
        vm_size                 = var.paloalto.vm_size
        vm_prefix               = var.paloalto.vm_prefix
        vm_image_id             = var.paloalto.vm_image_id   
        vm_publisher            = var.paloalto.vm_publisher 
        vm_offer                = var.paloalto.vm_offer 
        vm_sku                  = var.paloalto.vm_sku
        vm_version              = var.paloalto.vm_version
        vm_storage_os_disk_size = var.paloalto.vm_storage_os_disk_size
        vm_os                   = var.paloalto.vm_os    
        vm_from_marketplace     = var.paloalto.vm_from_marketplace  
        management_privateip    = var.paloalto.management_privateip
        perimeter_privateip     = var.paloalto.perimeter_privateip
        internal_privateip      = var.paloalto.internal_privateip  
    }
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  count               = var.deploy_ihub_log_analytics_link_scoped_service ? 1 : 0
  depends_on          = [module.core_us_gov_ihub]
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.ihub_sharedsvcs_logging_rg, var.env)
  scope_name          = lookup(local.ihub_sharedsvcs_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = data.terraform_remote_state.core.outputs.core_us_gov_ihub.ihub_log_analytics_workspace[0].cl_log_analytics_workspace.id
}
//**********************************************************************************************

```
<!-- END_TF_DOCS -->
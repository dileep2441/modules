## Local values

```terraform
locals {
  timeout_duration = "2h"
 # ihub_keyvault_private_dns_zone    = var.ihub_keyvault_enable && var.ihub_keyvault_deploy_private_dns_zone    ? [azurerm_private_dns_zone.ihub_keyvault_azure_private_dns_zone[0].id] : var.ihub_keyvault_private_dns_zone_ids
  ihub_private_link_subnet          = var.ihub_deploy_private_link_subnet ? [azurerm_subnet.ihub_private_link_subnet[0].id]              : var.ihub_keyvault_allowed_pe_subnet_ids
  ihub_rg_keyvault_name             = var.ihub_keyvault_enable && var.ihub_rg_security_enable ?  azurerm_resource_group.ihub_rg_security[0].name  : azurerm_resource_group.ihub_rg_data.name
  ihub_storage_account_replication_to_LRS    = (var.ihub_storage_account_replication_to_LRS || var.env == "nprd-pr"  ? true : false ) 
  ihub_storage_account_replication_type      = (var.ihub_storage_account_tier != "Premium" ? "GRS" : "LRS")

  ihub_storage_account_name_no_dash          = replace("${var.env}${var.postfix}${var.suffix}", "-", "")        
  ihub_storage_account_blob_properties       = (var.ihub_storage_account_kind == "FileStorage" || var.ihub_storage_account_blob_enable_backup ? false : true)
  ihub_storage_account_infra_encryption_enabled = (var.ihub_storage_account_kind == "StorageV2" || (var.ihub_storage_account_kind == "BlockBlobStorage" && var.ihub_storage_account_tier == "Premium") ? true : false)

  ihub_storage_account_queue_enabled         = (var.ihub_storage_account_tier == "Standard" && var.ihub_storage_account_kind != "BlobStorage" && var.ihub_storage_account_queue_enabled ? true : false)
}
```


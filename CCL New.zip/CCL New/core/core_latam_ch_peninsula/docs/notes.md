#### Note:
To get this code to work, it needs Terraform version 1.0 and azurerm provider version 3.22.0
Specify TF version in `core_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  version = "3.22.0"
  features {}
}

//Alias provider require to add the private link scoped service from spoke LAW to AMPLS in shared services subscription
provider "azurerm" {
  alias = "shs"
  version = "3.22.0"
  subscription_id = var.sharedsvcs_subscription_id
  features {}
}
//**********************************************************************************************


// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 1.0"
  backend "azurerm" {}
}
//**********************************************************************************************
```
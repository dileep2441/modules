# Azure Core US Peninsula
This is the US Peninsula Core component for the US Peninsula spoke. It establishes a baseline cloud environment where other components can be deployed into.
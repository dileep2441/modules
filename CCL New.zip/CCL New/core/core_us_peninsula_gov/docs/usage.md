

## Usage

#### Without Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                          = "/dn-tads_tf-azure-component-library/core/core_us_peninsula_gov"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    tags                            = var.tags
    hub_env                         = "nprd-pr"
    core_vnet_address_space         = ["10.0.1.0/24"]
    gateway_sub_address_prefix      = ["10.0.1.0/27"]
    core_enable_sa_nsg_flow_logs    = true/false 

    // (if core_enable_sa_nsg_flow_logs = true)
    core_storage_account_allowed_pe_subnet_ids = var.core_storage_account_allowed_pe_subnet_ids
    core_storage_account_allowed_vnet_subnet_ids  = var.core_storage_account_allowed_vnet_subnet_ids 
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.identity_sharedsvcs_logging_rg, var.env)
  scope_name          = lookup(local.identity_sharedsvcs_log_analytics_private_link_scope_name, var.env)
  depends_on          = [module.core_us_peninsula]
  linked_resource_id  = module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```

#### With Core Key Vault enabled
```terraform
module "core_us_peninsula" {
    source                                                              = "/dn-tads_tf-azure-component-library/core/core_us_peninsula_gov"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    suffix                                                              = var.suffix
    tags                                                                = var.tags
    hub_env                                                             = "nprd-pr"
    core_vnet_address_space                                             = ["10.0.1.0/24"]
    gateway_sub_address_prefix                                          = ["10.0.1.0/27"]

    core_rg_security_enable                                             = true
    core_keyvault_enable                                                = true
    core_private_link_subnet_address_prefixes                           = var.core_private_link_subnet_address_prefixes  
    core_private_link_subnet_enforce_endpoint_network_policies          = true
    core_enable_sa_nsg_flow_logs                                        = true/false
    core_keyvault_nacl_allowed_subnets                                  = []
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_gov
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_gov_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_gov_log_analytics_private_link_scope_name, var.env)
  depends_on          = [module.core_us_peninsula]
  linked_resource_id  =  module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```

#### With Service Vault VM and Blob Backup Enabled
```terraform
module "core_us_peninsula" {
    source                                                              = "../dn-tads_tf-azure-component-library/core/core_us_peninsula_gov"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    suffix                                                              = var.suffix
    tags                                                                = var.tags
    hub_env                                                             = var.hub_env #"nprd-pr"
    core_vnet_address_space                                             = var.core_vnet_address_space #["10.61.154.0/24"]
    gateway_sub_address_prefix                                          = var.gateway_sub_address_prefix #["10.61.154.0/27"]


    core_rg_security_enable                                             = true
    core_keyvault_enable                                                = true
    core_private_link_subnet_address_prefixes                           = var.core_private_link_subnet_address_prefixes  # ["10.61.154.32/27"]
    core_private_link_subnet_enforce_endpoint_network_policies          = true
    core_enable_sa_nsg_flow_logs                                        = true
    core_keyvault_nacl_allowed_subnets                                  = var.core_keyvault_nacl_allowed_subnets #[]
    
    core_azure_backup_deploy_rsv                                        = true 
    core_azure_backup_enable_vm_backup                                  = true
    core_azure_backup_enable_file_storage_backup                        = false
    core_azure_backup_enable_blob_storage_backup                        = true
}

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_gov
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_gov_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_gov_log_analytics_private_link_scope_name, var.env)
  depends_on          = [module.core_us_peninsula]
  linked_resource_id  =  module.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}
```

#### Complete the Peering connection, the SPN must have network contributor role over SharedServices, Ihub, Identity and AVD virtual network
```terraform
# Define the providers
provider "azurerm" {
  alias           = "shs"
  version         = "3.6.0"
  subscription_id = lookup(local.core_shared_services_gov_id_map, var.env)
  environment     = "usgovernment"
  features {}
      skip_provider_registration = true
}

provider "azurerm" {
  alias           = "ihub"
  version         = "3.6.0"
  subscription_id = lookup(local.core_ihub_gov_id_map, var.env)
  environment     = "usgovernment"
  features {}
      skip_provider_registration = true
}

provider "azurerm" {
  alias           = "idty"
  version         = "3.6.0"
  subscription_id = lookup(local.core_idty_gov_id_map, var.env)
  environment     = "usgovernment"
  features {}
      skip_provider_registration = true
}

#Complete the peering
// Complete the Peerring SharedServices to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "sharedsvcs_peering_core" {
 provider                     = azurerm.shs
 name                         = "peer-to-${var.postfix}-vnet"
 resource_group_name          = lookup(local.core_shared_services_gov_resource_group_map, var.env)  
 virtual_network_name         = lookup(local.core_shared_services_gov_network_name_map, var.env) 
 remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
 allow_virtual_network_access = true
 allow_forwarded_traffic      = true
 use_remote_gateways          = false

 #allow_gateway_transit' must be set to false for vnet Global Peering
 allow_gateway_transit = false

 timeouts {
   create = local.timeout_duration
   delete = local.timeout_duration
 }
 depends_on          = [module.core_us_peninsula]
}
//**********************************************************************************************

// Complete Peering Identity to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "idty_peering_spoke" {
  provider                     = azurerm.idty
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_idty_gov_resource_group_name_map, var.env)
  virtual_network_name         = lookup(local.core_idty_gov_resource_network_name_map, var.env)
  remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = false

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
  depends_on          = [module.core_us_peninsula]
}
//**********************************************************************************************

// Complete Peering Ihub to Spoke
//**********************************************************************************************
resource "azurerm_virtual_network_peering" "ihub_peering_spoke" {
  provider                     = azurerm.ihub
  name                         = "peer-to-${var.postfix}-vnet"
  resource_group_name          = lookup(local.core_ihub_gov_resource_group_name_map, var.env)
  virtual_network_name         = lookup(local.core_ihub_gov_resource_network_name_map, var.env)
  remote_virtual_network_id    = module.core_us_peninsula.core_vnet.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  use_remote_gateways          = false

  # 'allow_gateway_transit' must be set to false for vnet Global Peering
  allow_gateway_transit = true

  timeouts {
    create = local.timeout_duration
    delete = local.timeout_duration
  }
  depends_on          =    [module.core_us_peninsula]
}
//**********************************************************************************************




```
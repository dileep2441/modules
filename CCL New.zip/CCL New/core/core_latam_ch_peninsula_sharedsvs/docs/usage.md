
## Usage

```terraform
data "azurerm_virtual_network" "core_data_shdsvc_vnet_ihub" {
  count               = var.sharedsvs_deploy_ihub_peering ? 1 : 0
  provider            = azurerm.ihub
  name                = "nprd-pr-ihubch-vnet"
  resource_group_name = "rg-nprd-pr-ihubch-network"
}
data "azurerm_virtual_network" "core_data_shdsvc_vnet_idty" {
  count               = var.sharedsvs_deploy_idty_peering ? 1 : 0
  provider            = azurerm.idty
  name                = "nprd-pr-idtych-vnet"
  resource_group_name = "rg-nprd-pr-idtych-network"
}


// Deploy the Latam Peninsula Core Platform in a Box
//********************************************************************************************
 module "core_latam_ch_peninsula_sharedsvs" {
  source                                                          = "../dn-tads_tf-azure-component-library/core/core_latam_ch_peninsula_sharedsvs"
  env                                                             = var.env
  postfix                                                         = var.postfix
  location                                                        = var.location
  hub_env                                                         = var.env
  sharedsvs_vnet_address_space                                    = var.sharedsvs_vnet_address_space
  sharedsvs_vnet_dns_servers                                      = var.sharedsvs_vnet_dns_servers
  sharedsvs_keyvault_postfix                                      = var.sharedsvs_keyvault_postfix
  sharedsvs_azure_defender_resources                              = var.sharedsvs_azure_defender_resources
  sharedsvs_private_link_subnet_address_prefixes                  = var.sharedsvs_private_link_subnet_address_prefixes
  sharedsvs_route_table_disable_bgp_propagation                   = var.sharedsvs_route_table_disable_bgp_propagation
  sharedsvs_azure_bastion_subnet_prefix                           = var.sharedsvs_azure_bastion_subnet_prefix
  sharedsvs_mgmt_sub_address_prefix                               = var.sharedsvs_mgmt_sub_address_prefix
  sharedsvs_imgbuilder_sub_address_prefix                         = var.sharedsvs_imgbuilder_sub_address_prefix
  sharedsvs_azure_vm_image_build_number                           = var.BUILD_NUMBER
  sharedsvs_azure_vm_image_builder_distribute_replicationRegions  = var.sharedsvs_azure_vm_image_builder_distribute_replicationRegions
  sharedsvs_windows_vm_deploy                                     = var.sharedsvs_windows_vm_deploy
  sharedsvs_windows_vm_jumpbox_computer_name                      = var.sharedsvs_windows_vm_jumpbox_computer_name
  sharedsvs_windows_vm_jumpbox_image_id                           = var.sharedsvs_vm_image_id
  sharedsvs_windows_vm_enable_domain_join                         = var.sharedsvs_windows_vm_enable_domain_join
  sharedsvs_windows_vm_domain_user_upn                            = var.DOMAIN_USER_LATAM_CH
  sharedsvs_windows_vm_domain_password                            = var.DOMAIN_PASSWORD_LATAM_CH
  sharedsvs_windows_vm_log_analytics_workspace_sentinel_id        = var.GLOBAL_CH_LAW_SENTINEL_ID
  sharedsvs_windows_vm_log_analytics_primary_sentinel_shared_key  = var.GLOBAL_CH_LAW_SENTINEL_SHARED_KEY
  sharedsvs_keyvault_nacl_allowed_ips                             = concat(var.sharedsvs_keyvault_nacl_allowed_ips, [var.GITHUBIP])
  sharedsvs_ptrn_kubernetes_deploy                                = var.sharedsvs_ptrn_kubernetes_deploy
  sharedsvs_ptrn_kubernetes_postfix                               = var.sharedsvs_ptrn_kubernetes_postfix
  sharedsvs_ptrn_kubernetes_subnet_nodes_address_prefixes         = var.sharedsvs_ptrn_kubernetes_subnet_nodes_address_prefixes
  sharedsvs_ptrn_kubernetes_kubernetes_version                    = var.sharedsvs_ptrn_kubernetes_kubernetes_version
  sharedsvs_ptrn_kubernetes_rbac_aad_admin_group_object_ids       = var.sharedsvs_ptrn_kubernetes_rbac_aad_admin_group_object_ids
  sharedsvs_azure_container_registry_georeplication_location      = var.sharedsvs_azure_container_registry_georeplication_location
  tags                                                            = var.tags  
  #Dns Resolver
  sharedsvs_azure_dns_resolver_subnet_inbound_prefix              = var.sharedsvs_azure_dns_resolver_subnet_inbound_prefix
  sharedsvs_azure_dns_resolver_subnet_outbound_prefix             = var.sharedsvs_azure_dns_resolver_subnet_outbound_prefix
  sharedsvs_azure_dns_resolver_forwarding_rule_onprem_domain_name = var.sharedsvs_azure_dns_resolver_forwarding_rule_onprem_domain_name
  sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address  = var.sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address
  sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address2 = var.sharedsvs_azure_dns_resolver_forwarding_rule_onprem_ip_address2
  #peering
  sharedsvs_to_idty_peering_network_id                            = var.sharedsvs_deploy_idty_peering ? data.azurerm_virtual_network.core_data_shdsvc_vnet_idty[0].id : null
  sharedsvs_to_ihub_peering_network_id                            = var.sharedsvs_deploy_ihub_peering ? data.azurerm_virtual_network.core_data_shdsvc_vnet_ihub[0].id : null
  ihub_internal_lb_private_ip_address                             = var.ihub_internal_lb_private_ip_address
  sharedsvs_deploy_ihub_peering                                   = var.sharedsvs_deploy_ihub_peering 
  sharedsvs_deploy_idty_peering                                   = var.sharedsvs_deploy_idty_peering
  #KV Secrets
  sharedsvs_vm_admin_username                                     = var.LOCAL_ADMIN_USER_VM
  #bigFixVms
  sharedsvs_bigfix_vm_computer_name                               = var.sharedsvs_bigfix_vm_computer_name //fix names
  sharedsvs_bigfix_vm_image_id                                    = var.sharedsvs_vm_image_id
  #wsus Vms
  sharedsvs_wsus_vm_computer_name                                 = var.sharedsvs_wsus_vm_computer_name
  sharedsvs_wsus_vm_image_id                                      = var.sharedsvs_vm_image_id
  #criblVms
  sharedsvs_crible_vm_deploy                                      = var.sharedsvs_crible_vm_deploy
  sharedsvs_cribl_local_user                                      = var.PA_USER_LATAM_CH
  cribl_worker_names                                              = var.cribl_worker_names
  cribl_master_names                                              = var.cribl_master_names
  cribl_backend_addesspool_associations_names                     = var.cribl_worker_names
  cribl                                                           = {
      vm_size                                                     = var.cribl.vm_size
      vm_prefix                                                   = var.cribl.vm_prefix
      vm_image_id                                                 = var.cribl.vm_image_id
      vm_publisher                                                = var.cribl.vm_publisher
      vm_offer                                                    = var.cribl.vm_offer
      vm_sku                                                      = var.cribl.vm_sku
      vm_version                                                  = var.cribl.vm_version
      vm_storage_os_disk_size                                     = var.cribl.vm_storage_os_disk_size
      vm_os                                                       = var.cribl.vm_os
      vm_from_marketplace                                         = var.cribl.vm_from_marketplace
    }
}
//**********************************************************************************************
```
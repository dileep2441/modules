
## Usage
# Backups for VMs
```terraform
 // Azure Backup
 // IMPORTANT - contributor role on RSV managed identity must be assigned bby cloudops for the following RGs (in order to successfully create RSV private endpoint): spoke vnet rg, rg where pe is to be created and private dns zone rg.
// https://docs.microsoft.com/en-us/azure/backup/private-endpoints
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  tags     = var.tags
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv       = true
  cl_azure_backup_enable_vm_backup = true
  cl_azure_backup_rsv_allowed_subnets        = var.cl_azure_backup_rsv_allowed_subnets
}
//**********************************************************************************************
```

# Backups for File Storage
```terraform
 // Azure Backup
 // IMPORTANT - contributor role on RSV managed identity must be assigned bby cloudops for the following RGs (in order to successfully create RSV private endpoint): spoke vnet rg, rg where pe is to be created and private dns zone rg.
// https://docs.microsoft.com/en-us/azure/backup/private-endpoints
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  tags     = var.tags
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv                 = true
  cl_azure_backup_enable_file_storage_backup = true
  cl_azure_backup_rsv_allowed_subnets        = var.cl_azure_backup_rsv_allowed_subnets
}
//**********************************************************************************************
```

# Backups for Blob Storage
```terraform
 // Azure Backup
// IMPORTANT: Must assign the blob storage backup vault "Storage Account Backup Contributor" role on the blob storage account. 
// https://docs.microsoft.com/en-us/azure/backup/blob-backup-configure-manage#grant-permissions-to-the-backup-vault-on-storage-accounts 
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup_gov"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  tags     = var.tags
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_backup_enable_blob_storage_backup = true
}
//**********************************************************************************************
```

 
## Local values

```terraform
locals {
  cl_azure_backup_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ugv.backup.windowsazure.us"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ugv.backup.windowsazure.us"]
    "prod-dr" = ["/subscriptions/f5e90ed5-4b29-443e-998f-bb5e1dc24351/resourceGroups/rg-prod-dr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.ugt.backup.windowsazure.us"]
  }
  timeout_duration = "2h"
}
```
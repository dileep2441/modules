<!-- BEGIN_TF_DOCS -->

# Azure Application Gateway Component

Azure Application Gateway is a web traffic load balancer that manages traffic to your web applications via application layer load balancing.
This means creating routing rules for traffic based on the attributes of an HTTP request (ex: URL based routing).
This specific component deploys an Application Gateway it's associated Public IPs, Route Table, NSGs, Log Analytics and Diagnostics Settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/application-gateway/overview

## Notes

You will need to store a base64 certificate and cert password in jenkins credentials used by JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX and JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS variables.
Some modifications on JenkinsFile will be required to import this Credentials variables.

The powershell command converts your pfx certificate file to base64 format:
```powershell
$fileContentBytes = get-content '<yourcertificate.pfx>' -Encoding Byte [System.Convert]::ToBase64String($fileContentBytes) | Out-File 'certbase64.txt'
```

## Resources

| Name | Type |
|------|------|
| [azurerm_application_gateway.cl_app_gateway_island](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_gateway) | resource |
| [azurerm_application_gateway.cl_app_gateway_peninsula](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_gateway) | resource |
| [azurerm_log_analytics_solution.cl_app_gateway_log_analytics_solution](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_monitor_diagnostic_setting.cl_app_gateway_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_app_gateway_public_ip_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_app_gateway_sn_nsg_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_app_gateway_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_app_gateway_nsg_rules_add](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_app_gateway_nsgrule_GatewayManager](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_app_gateway_nsgrule_InternetCommunication](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_watcher_flow_log.cl_app_gateway_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_public_ip.cl_app_gateway_public_ip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_route.cl_app_gateway_rt_default_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.cl_app_gateway_route_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_subnet.cl_app_gateway_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_app_gateway_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.cl_app_gateway_rt_associate_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_web_application_firewall_policy.cl_app_gateway_wafpolicy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/web_application_firewall_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_app_gateway_additional_backend_address_pool"></a> [cl\_app\_gateway\_additional\_backend\_address\_pool](#input\_cl\_app\_gateway\_additional\_backend\_address\_pool) | (Optional) Array for additional backend address pool. | <pre>map(object({<br>    name  = string<br>    fqdns = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_additional_http_listener"></a> [cl\_app\_gateway\_additional\_http\_listener](#input\_cl\_app\_gateway\_additional\_http\_listener) | (Optional) Array for additional HTTP listeners. | <pre>map(object({<br>    name                 = string<br>    protocol             = string<br>    host_name            = string<br>    frontend_port_name   = string<br>    ssl_certificate_name = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_additional_http_settings"></a> [cl\_app\_gateway\_additional\_http\_settings](#input\_cl\_app\_gateway\_additional\_http\_settings) | (Optional) Array for additional HTTP settings. | <pre>map(object({<br>    name                                = string<br>    request_timeout                     = number<br>    probe_name                          = string<br>    host_name                           = string<br>    pick_host_name_from_backend_address = bool<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_additional_probes"></a> [cl\_app\_gateway\_additional\_probes](#input\_cl\_app\_gateway\_additional\_probes) | (Optional) Array for additional health probes. | <pre>map(object({<br>    name                = string<br>    host                = string<br>    path                = string<br>    interval            = number<br>    timeout             = number<br>    unhealthy_threshold = number<br>    protocol            = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_additional_redirect_configurations"></a> [cl\_app\_gateway\_additional\_redirect\_configurations](#input\_cl\_app\_gateway\_additional\_redirect\_configurations) | (Optional) Array for additional redirect configurations. | <pre>map(object({<br>    name                 = string<br>    redirect_type        = string<br>    target_listener_name = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_additional_route_rules"></a> [cl\_app\_gateway\_additional\_route\_rules](#input\_cl\_app\_gateway\_additional\_route\_rules) | (Optional) Array for additional routing rules. | <pre>map(object({<br>    name                        = string<br>    rule_type                   = string<br>    http_listener_name          = string<br>    backend_address_pool        = string<br>    backend_http_settings_name  = string<br>    redirect_configuration_name = string<br>    priority                    = number<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_additional_ssl_certificate"></a> [cl\_app\_gateway\_additional\_ssl\_certificate](#input\_cl\_app\_gateway\_additional\_ssl\_certificate) | (Optional) Array for additional ssl certificates. | <pre>map(object({<br>    name                = string<br>    data                = string<br>    password            = string<br>    key_vault_secret_id = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_backend_address"></a> [cl\_app\_gateway\_backend\_address](#input\_cl\_app\_gateway\_backend\_address) | (Optional) The backend ip or fqdns address from the address pool | `list` | `null` | no |
| <a name="input_cl_app_gateway_backend_host_name"></a> [cl\_app\_gateway\_backend\_host\_name](#input\_cl\_app\_gateway\_backend\_host\_name) | (Optional) Host header to be sent to the backend servers. Cannot be set if pick\_host\_name\_from\_backend\_address is set to true | `any` | `null` | no |
| <a name="input_cl_app_gateway_core_sa_enabled"></a> [cl\_app\_gateway\_core\_sa\_enabled](#input\_cl\_app\_gateway\_core\_sa\_enabled) | (Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs. | `bool` | `true` | no |
| <a name="input_cl_app_gateway_diagnostics"></a> [cl\_app\_gateway\_diagnostics](#input\_cl\_app\_gateway\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ApplicationGatewayAccessLog",<br>    "ApplicationGatewayFirewallLog"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_app_gateway_disable_bgp_route_propagation"></a> [cl\_app\_gateway\_disable\_bgp\_route\_propagation](#input\_cl\_app\_gateway\_disable\_bgp\_route\_propagation) | (Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable | `bool` | `true` | no |
| <a name="input_cl_app_gateway_domain_name_label"></a> [cl\_app\_gateway\_domain\_name\_label](#input\_cl\_app\_gateway\_domain\_name\_label) | (Optional) Label for the Domain Name. Will be used to make up the FQDN. If a domain name label is specified, an A DNS record is created for the public IP in the Microsoft Azure DNS system. | `string` | `null` | no |
| <a name="input_cl_app_gateway_firewall_mode"></a> [cl\_app\_gateway\_firewall\_mode](#input\_cl\_app\_gateway\_firewall\_mode) | (Optional) Resource group where the Core VNet exists. | `string` | `"Prevention"` | no |
| <a name="input_cl_app_gateway_frontend_tls_cert"></a> [cl\_app\_gateway\_frontend\_tls\_cert](#input\_cl\_app\_gateway\_frontend\_tls\_cert) | (Optional) The name of the ssl cert file in pfx format that exists in the same folder that TF plan/apply is executed on. The file must not be base64 encrypted. | `string` | `""` | no |
| <a name="input_cl_app_gateway_frontend_tls_cert_keyvault_id"></a> [cl\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id](#input\_cl\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id) | (Optional) Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in Azure KeyVault. | `any` | `null` | no |
| <a name="input_cl_app_gateway_frontend_tls_cert_pass"></a> [cl\_app\_gateway\_frontend\_tls\_cert\_pass](#input\_cl\_app\_gateway\_frontend\_tls\_cert\_pass) | (Optional) The password for the front end ssl cert file | `string` | `""` | no |
| <a name="input_cl_app_gateway_http_listener_hostname"></a> [cl\_app\_gateway\_http\_listener\_hostname](#input\_cl\_app\_gateway\_http\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTP Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_cl_app_gateway_http_settings_timeout"></a> [cl\_app\_gateway\_http\_settings\_timeout](#input\_cl\_app\_gateway\_http\_settings\_timeout) | (Optional) The timeout for HTTP response. | `number` | `600` | no |
| <a name="input_cl_app_gateway_https_listener_hostname"></a> [cl\_app\_gateway\_https\_listener\_hostname](#input\_cl\_app\_gateway\_https\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTPS Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_cl_app_gateway_identity_ids"></a> [cl\_app\_gateway\_identity\_ids](#input\_cl\_app\_gateway\_identity\_ids) | (Optional) Specifies a list with a single user managed identity id to be assigned to the Application Gateway | `list(string)` | `[]` | no |
| <a name="input_cl_app_gateway_log_analytics_solutions"></a> [cl\_app\_gateway\_log\_analytics\_solutions](#input\_cl\_app\_gateway\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureAppGatewayAnalytics": {<br>    "product": "OMSGallery/AzureAppGatewayAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_cl_app_gateway_log_analytics_workspace_id"></a> [cl\_app\_gateway\_log\_analytics\_workspace\_id](#input\_cl\_app\_gateway\_log\_analytics\_workspace\_id) | (Required) The log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_app_gateway_log_analytics_workspace_name"></a> [cl\_app\_gateway\_log\_analytics\_workspace\_name](#input\_cl\_app\_gateway\_log\_analytics\_workspace\_name) | (Required) The log analytics workspace name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_app_gateway_logging_rg_name"></a> [cl\_app\_gateway\_logging\_rg\_name](#input\_cl\_app\_gateway\_logging\_rg\_name) | (Required) The resource group for the Application Gateway log analytics solution. | `any` | n/a | yes |
| <a name="input_cl_app_gateway_max_capacity"></a> [cl\_app\_gateway\_max\_capacity](#input\_cl\_app\_gateway\_max\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `5` | no |
| <a name="input_cl_app_gateway_min_capacity"></a> [cl\_app\_gateway\_min\_capacity](#input\_cl\_app\_gateway\_min\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `1` | no |
| <a name="input_cl_app_gateway_nsg_flow_log_postfix"></a> [cl\_app\_gateway\_nsg\_flow\_log\_postfix](#input\_cl\_app\_gateway\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | n/a | yes |
| <a name="input_cl_app_gateway_nsg_rules"></a> [cl\_app\_gateway\_nsg\_rules](#input\_cl\_app\_gateway\_nsg\_rules) | (Optional) Define additional NSG rules for app gateway subnet. | <pre>map(object({<br>    name                         = string<br>    priority                     = number<br>    direction                    = string<br>    access                       = string<br>    protocol                     = string<br>    source_port_range            = string<br>    source_port_ranges           = list(string)<br>    destination_port_range       = string<br>    destination_port_ranges      = list(string)<br>    source_address_prefix        = string<br>    source_address_prefixes      = list(string)<br>    destination_address_prefix   = string<br>    destination_address_prefixes = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_gateway_nsg_sa_allowed_pe_subnet_ids"></a> [cl\_app\_gateway\_nsg\_sa\_allowed\_pe\_subnet\_ids](#input\_cl\_app\_gateway\_nsg\_sa\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_app_gateway_nsg_sa_allowed_vnet_subnet_ids"></a> [cl\_app\_gateway\_nsg\_sa\_allowed\_vnet\_subnet\_ids](#input\_cl\_app\_gateway\_nsg\_sa\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_app_gateway_nsg_sa_private_dns_zone_ids"></a> [cl\_app\_gateway\_nsg\_sa\_private\_dns\_zone\_ids](#input\_cl\_app\_gateway\_nsg\_sa\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_app_gateway_pick_host_backend"></a> [cl\_app\_gateway\_pick\_host\_backend](#input\_cl\_app\_gateway\_pick\_host\_backend) | (Optional) True/false to pick the host from the backend configuration | `bool` | `true` | no |
| <a name="input_cl_app_gateway_pick_host_name"></a> [cl\_app\_gateway\_pick\_host\_name](#input\_cl\_app\_gateway\_pick\_host\_name) | (Optional) True/false to pick a host from backend pool or overwrite the host name. | `bool` | `true` | no |
| <a name="input_cl_app_gateway_probe_host"></a> [cl\_app\_gateway\_probe\_host](#input\_cl\_app\_gateway\_probe\_host) | (Optional) The site url from the Health probes | `string` | `null` | no |
| <a name="input_cl_app_gateway_probe_interval"></a> [cl\_app\_gateway\_probe\_interval](#input\_cl\_app\_gateway\_probe\_interval) | (Optional) The probe interval from the Health probes | `number` | `10` | no |
| <a name="input_cl_app_gateway_probe_name"></a> [cl\_app\_gateway\_probe\_name](#input\_cl\_app\_gateway\_probe\_name) | (Optional) The probe name from Health probes | `string` | `"https-probe"` | no |
| <a name="input_cl_app_gateway_probe_path"></a> [cl\_app\_gateway\_probe\_path](#input\_cl\_app\_gateway\_probe\_path) | (Optional) The probe path from the Health probes | `string` | `"/"` | no |
| <a name="input_cl_app_gateway_probe_protocol"></a> [cl\_app\_gateway\_probe\_protocol](#input\_cl\_app\_gateway\_probe\_protocol) | (Optional) The probe protocol from the Health probes | `string` | `"Https"` | no |
| <a name="input_cl_app_gateway_probe_status_code"></a> [cl\_app\_gateway\_probe\_status\_code](#input\_cl\_app\_gateway\_probe\_status\_code) | (Required if the default is changed) A list of allowed status codes for this Health Probe | `list` | <pre>[<br>  "200-399"<br>]</pre> | no |
| <a name="input_cl_app_gateway_probe_timeout"></a> [cl\_app\_gateway\_probe\_timeout](#input\_cl\_app\_gateway\_probe\_timeout) | (Optional) The timeout from the Health probes | `number` | `30` | no |
| <a name="input_cl_app_gateway_probe_unhealthy_threshold"></a> [cl\_app\_gateway\_probe\_unhealthy\_threshold](#input\_cl\_app\_gateway\_probe\_unhealthy\_threshold) | (Optional) The unhealthy threshold from the Health probes | `number` | `3` | no |
| <a name="input_cl_app_gateway_public_ip_allocation_method"></a> [cl\_app\_gateway\_public\_ip\_allocation\_method](#input\_cl\_app\_gateway\_public\_ip\_allocation\_method) | (Optional) The allocation method for this IP address. Possible values are Static or Dynamic. | `string` | `"Static"` | no |
| <a name="input_cl_app_gateway_public_ip_sku"></a> [cl\_app\_gateway\_public\_ip\_sku](#input\_cl\_app\_gateway\_public\_ip\_sku) | (Optional) The SKU of the Public IP. Accepted values are Basic and Standard | `string` | `"Standard"` | no |
| <a name="input_cl_app_gateway_resource_group_name"></a> [cl\_app\_gateway\_resource\_group\_name](#input\_cl\_app\_gateway\_resource\_group\_name) | (Required) The name of the resource group where the application gateway will be deployed to. | `any` | n/a | yes |
| <a name="input_cl_app_gateway_reverse_fqdn"></a> [cl\_app\_gateway\_reverse\_fqdn](#input\_cl\_app\_gateway\_reverse\_fqdn) | (Optional) A fully qualified domain name that resolves to this public IP address | `any` | `null` | no |
| <a name="input_cl_app_gateway_rewrite_rules"></a> [cl\_app\_gateway\_rewrite\_rules](#input\_cl\_app\_gateway\_rewrite\_rules) | (Optional) Array for rewrite rules. | <pre>list(object({<br>    name            = string<br>    rule_sequence   = number<br>    conditions = list(object({<br>      variable    = string<br>      pattern     = string<br>      ignore_case = bool<br>      negate      = bool<br>    }))<br>    request_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))<br>    response_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))<br>    urls  = list(object({<br>      path          = string<br>      query_string  = string<br>      reroute       = string<br>    }))<br>  }))</pre> | `[]` | no |
| <a name="input_cl_app_gateway_sa_nsg_rg_name"></a> [cl\_app\_gateway\_sa\_nsg\_rg\_name](#input\_cl\_app\_gateway\_sa\_nsg\_rg\_name) | (Optional) storage account name for which nsg flows logs will be collected. | `string` | `null` | no |
| <a name="input_cl_app_gateway_sn_nsg_diagnostics"></a> [cl\_app\_gateway\_sn\_nsg\_diagnostics](#input\_cl\_app\_gateway\_sn\_nsg\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "NetworkSecurityGroupRuleCounter",<br>    "NetworkSecurityGroupEvent"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_app_gateway_ssl_policy_name"></a> [cl\_app\_gateway\_ssl\_policy\_name](#input\_cl\_app\_gateway\_ssl\_policy\_name) | (Optional) The Name from SSL Policy | `string` | `"AppGwSslPolicy20170401S"` | no |
| <a name="input_cl_app_gateway_ssl_policy_protocol_version"></a> [cl\_app\_gateway\_ssl\_policy\_protocol\_version](#input\_cl\_app\_gateway\_ssl\_policy\_protocol\_version) | (Optional) The Minimun Protocol Version from SSL Policy | `string` | `"TLSv1_2"` | no |
| <a name="input_cl_app_gateway_ssl_policy_type"></a> [cl\_app\_gateway\_ssl\_policy\_type](#input\_cl\_app\_gateway\_ssl\_policy\_type) | (Optional) The Type from SSL Policy | `string` | `"Predefined"` | no |
| <a name="input_cl_app_gateway_storage_account_nsg_flow_log_id"></a> [cl\_app\_gateway\_storage\_account\_nsg\_flow\_log\_id](#input\_cl\_app\_gateway\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_cl_app_gateway_subnet_address_prefix"></a> [cl\_app\_gateway\_subnet\_address\_prefix](#input\_cl\_app\_gateway\_subnet\_address\_prefix) | (Required) The address prefix of the application gateway subnet. | `any` | n/a | yes |
| <a name="input_cl_app_gateway_subnet_hostnum"></a> [cl\_app\_gateway\_subnet\_hostnum](#input\_cl\_app\_gateway\_subnet\_hostnum) | (Optional) The hostnumber from the subnet prefix for the private IP. | `number` | `15` | no |
| <a name="input_cl_app_gateway_subnet_service_endpoints"></a> [cl\_app\_gateway\_subnet\_service\_endpoints](#input\_cl\_app\_gateway\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet | `list` | `[]` | no |
| <a name="input_cl_app_gateway_vnet_name"></a> [cl\_app\_gateway\_vnet\_name](#input\_cl\_app\_gateway\_vnet\_name) | (Required) The name of the vnet which the app gateway subnet will be deployed into. | `any` | n/a | yes |
| <a name="input_cl_app_gateway_vnet_rg_name"></a> [cl\_app\_gateway\_vnet\_rg\_name](#input\_cl\_app\_gateway\_vnet\_rg\_name) | (Required) Resource group where the Core VNet exists. | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_set_private_ip_listener"></a> [set\_private\_ip\_listener](#input\_set\_private\_ip\_listener) | (Optional) A boolean variable indicating which environment the app gateway is being deployed into. | `bool` | `true` | no |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_app_gateway   = var.set_private_ip_listener ? azurerm_application_gateway.cl_app_gateway_peninsula[0] : azurerm_application_gateway.cl_app_gateway_island[0]

  # IP configurations
  gateway_ip_configuration_name          = "gw-ip-conf"
  frontend_ip_configuration_name_private = "private-ip"
  frontend_ip_configuration_name_public  = "public-ip"

  # Frontend configurations
  frontend_port_http_name  = "frontend-port-80"
  frontend_port_http       = 80
  frontend_port_https_name = "frontend-port-443"
  frontend_port_https      = 443


  # Listener configurations
  https_listener_peninsula = {
    name                           = "https-listener-private"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_private
    frontend_port_name             = local.frontend_port_https_name
    protocol                       = "Https"
    ssl_certificate_name           = "frontend_ssl_cert"
  }
  http_listener_peninsula = {
    name                           = "http-listener-private"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_private
    frontend_port_name             = local.frontend_port_http_name
    protocol                       = "Http"
  }
  https_listener_island = {
    name                           = "https-listener-public"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_public
    frontend_port_name             = local.frontend_port_https_name
    protocol                       = "Https"
    ssl_certificate_name           = "frontend_ssl_cert"
  }
  http_listener_island = {
    name                           = "http-listener-public"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_public
    frontend_port_name             = local.frontend_port_http_name
    protocol                       = "Http"
  }
  ssl_certificate_name = "frontend_ssl_cert"

  redirect_configuration_peninsula = {
    name                 = "http-to-https-redirect-private"
    redirect_type        = "Permanent"
    target_listener_name = local.https_listener_peninsula.name
  }

  redirect_configuration_island = {
    name                 = "http-to-https-redirect-public"
    redirect_type        = "Permanent"
    target_listener_name = local.https_listener_island.name
  }

  # Backend  configurations
  backend_address_pool_name = "backend-address-pool"

  backend_http_settings = {
    name                  = "backend-https-settings"
    cookie_based_affinity = "Disabled"
    port                  = 443
    protocol              = "Https"
  }

  # Routing rules configurations
  request_routing_rule_peninsula_http_to_https = {
    name                        = "http-to-https-rule-private"
    rule_type                   = "Basic"
    http_listener_name          = local.http_listener_peninsula.name
    redirect_configuration_name = local.redirect_configuration_peninsula.name
  }
  request_routing_rule_peninsula_https = {
    name                       = "backend-https-rule-private"
    rule_type                  = "Basic"
    http_listener_name         = local.https_listener_peninsula.name
    backend_address_pool_name  = local.backend_address_pool_name
    backend_http_settings_name = local.backend_http_settings.name
  }
  request_routing_rule_island_http_to_https = {
    name                        = "http-to-https-rule-public"
    rule_type                   = "Basic"
    http_listener_name          = local.http_listener_island.name
    redirect_configuration_name = local.redirect_configuration_island.name
  }
  request_routing_rule_island_https = {
    name                       = "backend-https-rule-public"
    rule_type                  = "Basic"
    http_listener_name         = local.https_listener_island.name
    backend_address_pool_name  = local.backend_address_pool_name
    backend_http_settings_name = local.backend_http_settings.name
  }
  # AppGw Public Ip Diagnotics settings
  app_gw_public_ip_diagnotics_settings = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_backend_address_pool_name"></a> [backend\_address\_pool\_name](#output\_backend\_address\_pool\_name) | n/a |
| <a name="output_cl_app_gateway"></a> [cl\_app\_gateway](#output\_cl\_app\_gateway) | n/a |
| <a name="output_cl_app_gateway_diagnostic_setting"></a> [cl\_app\_gateway\_diagnostic\_setting](#output\_cl\_app\_gateway\_diagnostic\_setting) | n/a |
| <a name="output_cl_app_gateway_log_analytics_solution"></a> [cl\_app\_gateway\_log\_analytics\_solution](#output\_cl\_app\_gateway\_log\_analytics\_solution) | n/a |
| <a name="output_cl_app_gateway_nsg"></a> [cl\_app\_gateway\_nsg](#output\_cl\_app\_gateway\_nsg) | n/a |
| <a name="output_cl_app_gateway_public_ip"></a> [cl\_app\_gateway\_public\_ip](#output\_cl\_app\_gateway\_public\_ip) | n/a |
| <a name="output_cl_app_gateway_route_table"></a> [cl\_app\_gateway\_route\_table](#output\_cl\_app\_gateway\_route\_table) | n/a |
| <a name="output_cl_app_gateway_rt_associate_subnet"></a> [cl\_app\_gateway\_rt\_associate\_subnet](#output\_cl\_app\_gateway\_rt\_associate\_subnet) | output "cl\_app\_gateway\_rt\_default\_route" { value = azurerm\_route.cl\_app\_gateway\_rt\_default\_route } |
| <a name="output_cl_app_gateway_subnet"></a> [cl\_app\_gateway\_subnet](#output\_cl\_app\_gateway\_subnet) | Outputs ********************************************************************************************** |



## Usage

```terraform
module "cl_app_gateway" {
  source                                      = "../dn-tads_tf-azure-component-library/components/cl_application_gateway_gov"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
 tags                                         = var.tags
  suffix                                      = var.suffix
  set_private_ip_listener                     = <true/false>
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["70.0.0.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  cl_app_gateway_core_sa_enabled                               = true
  cl_app_gateway_storage_account_nsg_flow_log_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
  cl_app_gateway_nsg_flow_log_postfix                          = var.cl_app_gateway_nsg_flow_log_postfix 
  cl_app_gateway_nsg_rules = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_app_gateway_additional_probes = {
    portal_health_probe = {
      name                = "apim-portal-probe"
      host                = "portal.azisapinp.amr.kpmg.com"
      path                = "/internal-status-0123456789abcdef"
      interval            = 30
      timeout             = 300
      unhealthy_threshold = 8
      protocol            = "Https"
    }
  }
  cl_app_gateway_additional_backend_address_pool = {
    kauth_backend_address_pool = {
      name  = "kauth-backend-address-pool"
      fqdns = [module.cl_app_service_app_k_auth.cl_app_service.default_site_hostname]
    }           
  }
  cl_app_gateway_additional_http_settings = {
    kauth_http_settings = {
      name                                = "kauth-https-settings"
      request_timeout                     = 180
      probe_name                          = "https-probe"
      pick_host_name_from_backend_address = true
    }   
  }
  cl_app_gateway_additional_http_listener = {
    kauth_http_listener = {
      name                  = "kauth-http-listener-public"
      protocol              = "Http"
      host_name             = "kauth.dev.taxdigital.kpmg.com.br"
      frontend_port_name    = "frontend-port-80"
      ssl_certificate_name  = null      
    }       
  }
  cl_app_gateway_additional_route_rules = {
    kauth_http_to_https_route_rule = {
      name                        = "kauth-http-to-https-rule-public"
      rule_type                   = "Basic"
      backend_address_pool        = null
      http_listener_name          = "kauth-http-listener-public"
      backend_http_settings_name  = null
      redirect_configuration_name = "kauth-http-to-https-redirect"
      priority                    = 3
    }
  }
  cl_app_gateway_additional_redirect_configurations = {
    kauth_http_settings = {
      name                  = "kauth-http-to-https-redirect"
      redirect_type         = "Permanent"
      target_listener_name  = "kauth-https-listener-public"
    }    
  }
  cl_app_gateway_rewrite_rules = [
    {
        name = "test",
        rule_sequence = 100,
        conditions = [
          {
            variable    = "HTTP header"
            pattern     = "(https?):VV.*azurewebsites\.net(.*)$"
            ignore_case = false
            negate      = false
          }
        ],
        request_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        response_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        urls  = [
          {
            path          = "/article.aspx"
            query_string  = "id={var_uri_path_1}"
            reroute       = "/page.aspx"
          }
        ]
    }
]       
}

```
<!-- END_TF_DOCS -->
<!-- BEGIN_TF_DOCS -->

# Azure Search Service

Azure Cognitive Search (formerly known as "Azure Search") is a cloud search service that gives developers infrastructure, APIs, and tools for building a rich search experience over private, heterogeneous content in web, mobile, and enterprise applications.

Search is foundational to any app that surfaces text to users, where common scenarios include catalog or document search, online retail apps, or data exploration over proprietary content. When you create a search service, you'll work with the following capabilities:

- A search engine for full text search over a search index containing user-owned content
- Rich indexing, with lexical analysis and optional AI enrichment for content extraction and transformation
- Rich query syntax for text search, fuzzy search, autocomplete, geo-search and more
- Programmability through REST APIs and client libraries in Azure SDKs
- Azure integration at the data layer, machine learning layer, and AI (Cognitive Services)

Across the Azure platform, Cognitive Search can integrate with other Azure services in the form of indexers that automate data ingestion/retrieval from Azure data sources, and skillsets that incorporate consumable AI from Cognitive Services, such as image and natural language processing, or custom AI that you create in Azure Machine Learning or wrap inside Azure Functions.

For more information, please visit: https://learn.microsoft.com/en-us/azure/search/




#### Note:
For OpenAI kind, it needs AzureRM provider for Terraform version 3.40.0 or later.
It can be specified on Terraform backend:

```terraform
terraform {
  required_version = ">= 1.3.0"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">= 3.40.0"
    }
  }
}
```

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_search_service_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_search_service_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.cl_search_service_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_search_service.cl_search_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/search_service) | resource |
| [azurerm_search_shared_private_link_service.cl_search_service_shared_private_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/search_shared_private_link_service) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_search_service_allowed_ips"></a> [cl\_search\_service\_allowed\_ips](#input\_cl\_search\_service\_allowed\_ips) | (Optional) A list of IPv4 addresses or CIDRs that are allowed access to the search service endpoint. If cl\_search\_service\_public\_network\_access\_enabled = true | `list(string)` | <pre>[<br>  "199.206.0.0/15"<br>]</pre> | no |
| <a name="input_cl_search_service_deploy_rg"></a> [cl\_search\_service\_deploy\_rg](#input\_cl\_search\_service\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the Azure Search Service | `bool` | `true` | no |
| <a name="input_cl_search_service_deploy_shared_private_link"></a> [cl\_search\_service\_deploy\_shared\_private\_link](#input\_cl\_search\_service\_deploy\_shared\_private\_link) | (Optional) A boolean to enable/disable the deployment of a shared private link for the Azure Search Service | `bool` | `false` | no |
| <a name="input_cl_search_service_diagnostic"></a> [cl\_search\_service\_diagnostic](#input\_cl\_search\_service\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string)})` | <pre>{<br>  "logs": [<br>    "OperationLogs"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_search_service_identity_type"></a> [cl\_search\_service\_identity\_type](#input\_cl\_search\_service\_identity\_type) | (Optional) Specifies the identity type of the Azure Search Service. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_search_service_log_analytics_workspace_id"></a> [cl\_search\_service\_log\_analytics\_workspace\_id](#input\_cl\_search\_service\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_search_service_partition_count"></a> [cl\_search\_service\_partition\_count](#input\_cl\_search\_service\_partition\_count) | (Optional) The number of partitions which should be created. | `string` | `"1"` | no |
| <a name="input_cl_search_service_pe_subnet_ids"></a> [cl\_search\_service\_pe\_subnet\_ids](#input\_cl\_search\_service\_pe\_subnet\_ids) | (Optional) One or more Subnet ID's which should be able to access the Azure Search Service | `list(string)` | `[]` | no |
| <a name="input_cl_search_service_postfix"></a> [cl\_search\_service\_postfix](#input\_cl\_search\_service\_postfix) | (Required) The postfix for the Azure Search Service. | `any` | n/a | yes |
| <a name="input_cl_search_service_private_dns_zone_ids"></a> [cl\_search\_service\_private\_dns\_zone\_ids](#input\_cl\_search\_service\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_search_service_private_endpoint_subresource_names"></a> [cl\_search\_service\_private\_endpoint\_subresource\_names](#input\_cl\_search\_service\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "searchService"<br>]</pre> | no |
| <a name="input_cl_search_service_public_network_access_enabled"></a> [cl\_search\_service\_public\_network\_access\_enabled](#input\_cl\_search\_service\_public\_network\_access\_enabled) | (Optional) Whether or not public network access is allowed for this resource | `bool` | `false` | no |
| <a name="input_cl_search_service_replica_count"></a> [cl\_search\_service\_replica\_count](#input\_cl\_search\_service\_replica\_count) | (Optional) The number of replica's which should be created. | `string` | `"1"` | no |
| <a name="input_cl_search_service_resource_group_name"></a> [cl\_search\_service\_resource\_group\_name](#input\_cl\_search\_service\_resource\_group\_name) | (Required) Specifies the Azure Search Service resource group | `any` | n/a | yes |
| <a name="input_cl_search_service_rg_name"></a> [cl\_search\_service\_rg\_name](#input\_cl\_search\_service\_rg\_name) | (Optional) The name of the Azure Search Service resource group if cl\_search\_service\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_search_service_shared_private_link"></a> [cl\_search\_service\_shared\_private\_link](#input\_cl\_search\_service\_shared\_private\_link) | (Optional) Specify the values for the Shared private Link creation. | <pre>map(object({<br>        name                          = string ## "Specify the name of the Shared private Link"<br>        subresource_name              = string ## "Specify the sub resource name which the Azure Search Private Endpoint is able to connect to. The subresource name of the resource; for example: blob, sql or vault." # https://learn.microsoft.com/en-us/azure/search/search-indexer-howto-access-private?tabs=portal-create<br>        target_resource_id            = string ## "Specify the ID of the Shared Private Link Enabled Remote Resource which this Azure Search Private Endpoint should be connected to" <br>    }))</pre> | `{}` | no |
| <a name="input_cl_search_service_shared_private_link_request_message"></a> [cl\_search\_service\_shared\_private\_link\_request\_message](#input\_cl\_search\_service\_shared\_private\_link\_request\_message) | (Optional) Specify the request message for requesting approval of the Shared Private Link Enabled Remote Resource | `string` | `"Please approve"` | no |
| <a name="input_cl_search_service_sku"></a> [cl\_search\_service\_sku](#input\_cl\_search\_service\_sku) | (Optional) The SKU which should be used for this Search Service. Possible values are basic, free, standard, standard2, standard3, storage\_optimized\_l1 and storage\_optimized\_l2. | `string` | `"standard"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_search_service"></a> [cl\_search\_service](#output\_cl\_search\_service) | Azure Search Service |
| <a name="output_cl_search_service_diagnostic_setting"></a> [cl\_search\_service\_diagnostic\_setting](#output\_cl\_search\_service\_diagnostic\_setting) | Monitor Diagnostic |
| <a name="output_cl_search_service_private_endpoint"></a> [cl\_search\_service\_private\_endpoint](#output\_cl\_search\_service\_private\_endpoint) | Azure Search Service private endpoint |
| <a name="output_cl_search_service_rg"></a> [cl\_search\_service\_rg](#output\_cl\_search\_service\_rg) | Resource Group for Azure Search Service |

## Usage Azure Search Service with Private endpoint

```terraform
//********************************************************************************************
//Create a Azure Search Service
//********************************************************************************************

module "cl_search_service" {
   source                                                 = "../dn-tads_tf-azure-component-library/components/cl_search_service"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_search_service_postfix                              = "srchvang"
   cl_search_service_deploy_rg                            = true
   cl_search_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_search_service_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_search_service_nacl_allowed_subnets                 = [data.terraform_remote_state.core.outputs.core_latam_island.core_private_link_subnet.id]
   cl_search_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.srch_private_dns_zone.id]
   tags                                                   = var.tags
}

resource "azurerm_private_dns_zone" "srch_private_dns_zone" {
  name                = "privatelink.search.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "srch_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-srch-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.srch_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************


## Usage Azure Search Service with Private endpoint and Shared Private Links

```terraform
//********************************************************************************************
//Create a Azure Search Service
//********************************************************************************************

module "cl_search_service" {
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_search_service"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  cl_search_service_postfix                              = "srchvang"
  cl_search_service_deploy_rg                            = false
  cl_search_service_rg_name                              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_search_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_search_service_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_search_service_nacl_allowed_subnets                 = [data.terraform_remote_state.core.outputs.core_latam_island.core_private_link_subnet.id]
  cl_search_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.srch_private_dns_zone.id]
  cl_search_service_deploy_shared_private_link           = true
  cl_search_service_shared_private_link = {
    shared_private_link_sa = {
     name                         = "shared-private-link-sa"
     subresource_name             = "blob"
     target_resource_id           = "##Storage account resource ID##"
    }
    shared_private_link_kv = {
     name                         = "shared-private-link-kv"
     subresource_name             = "vault"
     target_resource_id           = "##Key vault resource ID##"
    }
  }
  tags                                                   = var.tags
}

resource "azurerm_private_dns_zone" "srch_private_dns_zone" {
  name                = "privatelink.search.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "srch_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-srch-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.srch_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************
<!-- END_TF_DOCS -->
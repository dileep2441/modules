# Azure Synapse Component

Azure Synapse is a analytics service that brings together data integration, enterprise data warehousing, and big data analytics. 
With these capabilties - synapse allows to ingest, transform and manage data for immediate BI and machine learning needs.
This component will deploy a random password and KV secret for SQL admin for AZ Synapse. It also creates a workspace, dedicated sql pool, private link hub, diagnostics and private endpoint for AZ synapse.

For more information, please visit: https://docs.microsoft.com/en-us/azure/synapse-analytics/overview-what-is 

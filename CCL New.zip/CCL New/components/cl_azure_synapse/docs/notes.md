## Information
## Enabled extended auditing policy to Azure Synpase Workspace and Sql Pool's:
```terraform
1. Deploy the infrastructure to Azure Synpase
3. Before to deploy the extended_auditing_policy, with a Admin CloudOps request the role assignment to the Storage Account created for audit in component Azure Synapse
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/ to manage identity for Azure Synapse name
4. Add the variable to enabled the deploy for the extended_auditing_policy in Azure Synapse Workspace and Sql Pool's
   
   cl_azure_synapse_enabled_audit_security_logs = true
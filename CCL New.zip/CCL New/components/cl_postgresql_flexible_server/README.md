<!-- BEGIN_TF_DOCS -->

# Azure PostgreSQL - Flexible Server

Azure Database for PostgreSQL flexible server is a fully managed database service designed to provide more granular control and flexibility over database management functions and configuration settings. The service generally provides more flexibility and server configuration customizations based on user requirements. The flexible server architecture allows users to collocate the database engine with the client tier for lower latency and choose high availability within a single availability zone and across multiple availability zones. Azure Database for PostgreSQL flexible server instances also provide better cost optimization controls with the ability to stop/start your server and a burstable compute tier ideal for workloads that don't need full compute capacity continuously. The service supports the community version of PostgreSQL 11, 12, 13, 14, 15 and 16. The service is available in various Azure regions.

For more information, please visit: https://learn.microsoft.com/en-us/azure/postgresql/flexible-server/overview



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_postgresql_flexible_server_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_postgresql_flexible_server.cl_postgresql_flexible_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server) | resource |
| [azurerm_postgresql_flexible_server_configuration.security_server_parameters](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server_configuration) | resource |
| [azurerm_security_center_subscription_pricing.cl_postgresql_flexible_server_defender](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing) | resource |
| [azurerm_subnet.cl_postgresql_flexible_server_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_user_assigned_identity.cl_postgresql_flexible_server_user_assigned_identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_postgresql_flexible_server_active_directory_auth_enabled"></a> [cl\_postgresql\_flexible\_server\_active\_directory\_auth\_enabled](#input\_cl\_postgresql\_flexible\_server\_active\_directory\_auth\_enabled) | (Optional) Whether or not Active Directory authentication is allowed to access the PostgreSQL Flexible Server. Defaults to false. | `bool` | `true` | no |
| <a name="input_cl_postgresql_flexible_server_admin_login"></a> [cl\_postgresql\_flexible\_server\_admin\_login](#input\_cl\_postgresql\_flexible\_server\_admin\_login) | (Optional) The Administrator login for the PostgreSQL Flexible Server. Required when create\_mode is Default and authentication.password\_auth\_enabled is true. | `string` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_admin_password"></a> [cl\_postgresql\_flexible\_server\_admin\_password](#input\_cl\_postgresql\_flexible\_server\_admin\_password) | (Optional) The Password associated with the administrator\_login for the PostgreSQL Flexible Server. Required when create\_mode is Default and authentication.password\_auth\_enabled is true. | `string` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_auto_grow_enabled"></a> [cl\_postgresql\_flexible\_server\_auto\_grow\_enabled](#input\_cl\_postgresql\_flexible\_server\_auto\_grow\_enabled) | (Optional) Enable grow database as needed. | `bool` | `false` | no |
| <a name="input_cl_postgresql_flexible_server_availability_zone"></a> [cl\_postgresql\_flexible\_server\_availability\_zone](#input\_cl\_postgresql\_flexible\_server\_availability\_zone) | (Optional) Specifies the Availability Zone in which the PostgreSQL Flexible Server should be located. | `string` | `"1"` | no |
| <a name="input_cl_postgresql_flexible_server_backup_retention_days"></a> [cl\_postgresql\_flexible\_server\_backup\_retention\_days](#input\_cl\_postgresql\_flexible\_server\_backup\_retention\_days) | (Optional) Number of backup retention days. | `number` | `21` | no |
| <a name="input_cl_postgresql_flexible_server_create_mode"></a> [cl\_postgresql\_flexible\_server\_create\_mode](#input\_cl\_postgresql\_flexible\_server\_create\_mode) | (Optional) The creation mode which can be used to restore or replicate existing servers. Possible values are Default, PointInTimeRestore, Replica and Update. | `string` | `"Default"` | no |
| <a name="input_cl_postgresql_flexible_server_defender_deploy"></a> [cl\_postgresql\_flexible\_server\_defender\_deploy](#input\_cl\_postgresql\_flexible\_server\_defender\_deploy) | (Optional) to set azurerm\_security\_center\_subscription\_pricing as standard for open source databases, if already enabled in subscription set to false | `bool` | `true` | no |
| <a name="input_cl_postgresql_flexible_server_delegated_subnet_id"></a> [cl\_postgresql\_flexible\_server\_delegated\_subnet\_id](#input\_cl\_postgresql\_flexible\_server\_delegated\_subnet\_id) | (Optional) The ID of the virtual network subnet to create the PostgreSQL Flexible Server. The provided subnet should not have any other resource deployed in it and this subnet will be delegated to the PostgreSQL Flexible Server, if not already delegated. Changing this forces a new PostgreSQL Flexible Server to be created. | `string` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_delegation_name"></a> [cl\_postgresql\_flexible\_server\_delegation\_name](#input\_cl\_postgresql\_flexible\_server\_delegation\_name) | (Optional) name for the subnet delegation | `string` | `"postgresflexibleserverdelegation"` | no |
| <a name="input_cl_postgresql_flexible_server_deploy_subnet"></a> [cl\_postgresql\_flexible\_server\_deploy\_subnet](#input\_cl\_postgresql\_flexible\_server\_deploy\_subnet) | (Optional) A boolean to enable/disable the deployment of a subnet for the PostgreSQL Flexible Server | `bool` | `true` | no |
| <a name="input_cl_postgresql_flexible_server_diagnostic"></a> [cl\_postgresql\_flexible\_server\_diagnostic](#input\_cl\_postgresql\_flexible\_server\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "PostgreSQLLogs",<br>    "PostgreSQLFlexDatabaseXacts",<br>    "PostgreSQLFlexQueryStoreRuntime",<br>    "PostgreSQLFlexQueryStoreWaitStats",<br>    "PostgreSQLFlexSessions",<br>    "PostgreSQLFlexTableStats"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_postgresql_flexible_server_geo_redundant_backup_enabled"></a> [cl\_postgresql\_flexible\_server\_geo\_redundant\_backup\_enabled](#input\_cl\_postgresql\_flexible\_server\_geo\_redundant\_backup\_enabled) | (Optional) Enable or disable georedundant backup. | `bool` | `false` | no |
| <a name="input_cl_postgresql_flexible_server_high_availability_mode"></a> [cl\_postgresql\_flexible\_server\_high\_availability\_mode](#input\_cl\_postgresql\_flexible\_server\_high\_availability\_mode) | (Required) The high availability mode for the PostgreSQL Flexible Server. Possible value are SameZone or ZoneRedundant. | `string` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_identity_type"></a> [cl\_postgresql\_flexible\_server\_identity\_type](#input\_cl\_postgresql\_flexible\_server\_identity\_type) | (Required) Specifies the type of Managed Service Identity that should be configured on this PostgreSQL Flexible Server. The only possible value is UserAssigned. | `string` | `"UserAssigned"` | no |
| <a name="input_cl_postgresql_flexible_server_log_analytics_workspace_id"></a> [cl\_postgresql\_flexible\_server\_log\_analytics\_workspace\_id](#input\_cl\_postgresql\_flexible\_server\_log\_analytics\_workspace\_id) | (Required) The ID for the network resources | `any` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_maintenance_window_day_of_week"></a> [cl\_postgresql\_flexible\_server\_maintenance\_window\_day\_of\_week](#input\_cl\_postgresql\_flexible\_server\_maintenance\_window\_day\_of\_week) | (Optional) The day of week for maintenance window, where the week starts on a Sunday, i.e. Sunday = 0, Monday = 1. Defaults to 0. | `string` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_maintenance_window_start_hour"></a> [cl\_postgresql\_flexible\_server\_maintenance\_window\_start\_hour](#input\_cl\_postgresql\_flexible\_server\_maintenance\_window\_start\_hour) | (Optional) The start hour for maintenance window. Defaults to 0. | `number` | `0` | no |
| <a name="input_cl_postgresql_flexible_server_maintenance_window_start_minute"></a> [cl\_postgresql\_flexible\_server\_maintenance\_window\_start\_minute](#input\_cl\_postgresql\_flexible\_server\_maintenance\_window\_start\_minute) | (Optional) The start minute for maintenance window. Defaults to 0. | `number` | `0` | no |
| <a name="input_cl_postgresql_flexible_server_parameters"></a> [cl\_postgresql\_flexible\_server\_parameters](#input\_cl\_postgresql\_flexible\_server\_parameters) | (Required) Specifies the name of the PostgreSQL Configuration, which needs to be a valid PostgreSQL configuration name. Changing this forces a new resource to be created. | `map(any)` | <pre>{<br>  "azure.accepted_password_auth_method": "scram-sha-256",<br>  "log_duration": "on",<br>  "log_statement": "mod",<br>  "logfiles.download_enable": "ON",<br>  "logfiles.retention_days": "7",<br>  "password_encryption": "scram-sha-256",<br>  "pgaudit.log": "FUNCTION,ROLE,WRITE",<br>  "pgaudit.role": "auditor",<br>  "search_path": "$user",<br>  "ssl_max_protocol_version": "TLSv1.3",<br>  "ssl_min_protocol_version": "TLSv1.3"<br>}</pre> | no |
| <a name="input_cl_postgresql_flexible_server_password_auth_enabled"></a> [cl\_postgresql\_flexible\_server\_password\_auth\_enabled](#input\_cl\_postgresql\_flexible\_server\_password\_auth\_enabled) | (Optional) Whether or not password authentication is allowed to access the PostgreSQL Flexible Server. Defaults to true. | `bool` | `false` | no |
| <a name="input_cl_postgresql_flexible_server_pe_subnet_ids"></a> [cl\_postgresql\_flexible\_server\_pe\_subnet\_ids](#input\_cl\_postgresql\_flexible\_server\_pe\_subnet\_ids) | (Required) The subnet ids where the private endoint will be created. | `list` | `[]` | no |
| <a name="input_cl_postgresql_flexible_server_postfix"></a> [cl\_postgresql\_flexible\_server\_postfix](#input\_cl\_postgresql\_flexible\_server\_postfix) | (Required) The posftfix for PostgreSQL Flexible Server. Part of the naming scheme. | `string` | `"server"` | no |
| <a name="input_cl_postgresql_flexible_server_private_dns_zone_id"></a> [cl\_postgresql\_flexible\_server\_private\_dns\_zone\_id](#input\_cl\_postgresql\_flexible\_server\_private\_dns\_zone\_id) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `string` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_public_network_access_enabled"></a> [cl\_postgresql\_flexible\_server\_public\_network\_access\_enabled](#input\_cl\_postgresql\_flexible\_server\_public\_network\_access\_enabled) | (Optional) Enable or disable access from public network. | `bool` | `false` | no |
| <a name="input_cl_postgresql_flexible_server_resource_group_name"></a> [cl\_postgresql\_flexible\_server\_resource\_group\_name](#input\_cl\_postgresql\_flexible\_server\_resource\_group\_name) | (Required) The name of the Resource Group where the PostgreSQL Flexible Server should exist. Changing this forces a new PostgreSQL Flexible Server to be created. | `any` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_service_actions"></a> [cl\_postgresql\_flexible\_server\_service\_actions](#input\_cl\_postgresql\_flexible\_server\_service\_actions) | (Optional) name for the subnet delegation service | `list` | <pre>[<br>  "Microsoft.Network/virtualNetworks/subnets/join/action"<br>]</pre> | no |
| <a name="input_cl_postgresql_flexible_server_service_delegation_name"></a> [cl\_postgresql\_flexible\_server\_service\_delegation\_name](#input\_cl\_postgresql\_flexible\_server\_service\_delegation\_name) | (Optional) name for the subnet delegation service | `string` | `"Microsoft.DBforPostgreSQL/flexibleServers"` | no |
| <a name="input_cl_postgresql_flexible_server_sku_name"></a> [cl\_postgresql\_flexible\_server\_sku\_name](#input\_cl\_postgresql\_flexible\_server\_sku\_name) | PostgreSQL Flexible SKU Name | `string` | `"GP_Standard_D2s_v3"` | no |
| <a name="input_cl_postgresql_flexible_server_standby_availability_zone"></a> [cl\_postgresql\_flexible\_server\_standby\_availability\_zone](#input\_cl\_postgresql\_flexible\_server\_standby\_availability\_zone) | (Optional) Specifies the Availability Zone in which the standby Flexible Server should be located. | `number` | `1` | no |
| <a name="input_cl_postgresql_flexible_server_storage"></a> [cl\_postgresql\_flexible\_server\_storage](#input\_cl\_postgresql\_flexible\_server\_storage) | PostgreSQL Flexible Storage in MB | `string` | `"32768"` | no |
| <a name="input_cl_postgresql_flexible_server_subnet_id"></a> [cl\_postgresql\_flexible\_server\_subnet\_id](#input\_cl\_postgresql\_flexible\_server\_subnet\_id) | (Optional) The subnet ID where the PostgreSQL Flexible Server will be deployed to. Use this only if cl\_postgresql\_flexible\_server\_subnet\_id = false. | `any` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_subnet_prefix"></a> [cl\_postgresql\_flexible\_server\_subnet\_prefix](#input\_cl\_postgresql\_flexible\_server\_subnet\_prefix) | (Optional) The prefix of the PostgreSQL Flexible Server subnet with address prefix 0.0.0.0/27 & Only one instance per subnet is recommended | `list(string)` | `[]` | no |
| <a name="input_cl_postgresql_flexible_server_subnet_service_enpoints"></a> [cl\_postgresql\_flexible\_server\_subnet\_service\_enpoints](#input\_cl\_postgresql\_flexible\_server\_subnet\_service\_enpoints) | (Optional) specify the subnet service endpoints to open. | `list(string)` | <pre>[<br>  "Microsoft.Sql",<br>  "Microsoft.Storage"<br>]</pre> | no |
| <a name="input_cl_postgresql_flexible_server_tenant_id"></a> [cl\_postgresql\_flexible\_server\_tenant\_id](#input\_cl\_postgresql\_flexible\_server\_tenant\_id) | (Optional) The Tenant ID of the Azure Active Directory which is used by the Active Directory authentication. active\_directory\_auth\_enabled must be set to true. | `bool` | `null` | no |
| <a name="input_cl_postgresql_flexible_server_version"></a> [cl\_postgresql\_flexible\_server\_version](#input\_cl\_postgresql\_flexible\_server\_version) | PostgreSQL Flexible Server version to deploy | `string` | `"15"` | no |
| <a name="input_cl_postgresql_flexible_server_vnet_name"></a> [cl\_postgresql\_flexible\_server\_vnet\_name](#input\_cl\_postgresql\_flexible\_server\_vnet\_name) | (Required) The name of the core vnet required for the PostgreSQL Flexible Server subnet. | `any` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_vnet_rg_name"></a> [cl\_postgresql\_flexible\_server\_vnet\_rg\_name](#input\_cl\_postgresql\_flexible\_server\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration                               = "2h"
  cl_postgresql_flexible_server_delegated_subnet = var.cl_postgresql_flexible_server_deploy_subnet == true ? azurerm_subnet.cl_postgresql_flexible_server_subnet[0].id : var.cl_postgresql_flexible_server_delegated_subnet_id
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_postgresql_flexible_server"></a> [cl\_postgresql\_flexible\_server](#output\_cl\_postgresql\_flexible\_server) | Outputs ********************************************************************************************** |
| <a name="output_cl_postgresql_flexible_server_diagnostic_setting"></a> [cl\_postgresql\_flexible\_server\_diagnostic\_setting](#output\_cl\_postgresql\_flexible\_server\_diagnostic\_setting) | n/a |
| <a name="output_cl_postgresql_flexible_server_subnet"></a> [cl\_postgresql\_flexible\_server\_subnet](#output\_cl\_postgresql\_flexible\_server\_subnet) | n/a |

## Usage

```terraform
// Deploy PostgreSQL - Flexible Server
//**********************************************************************************************
module "cl_postgresql_flexible_server" {
  source                                                   = "../dn-tads_tf-azure-component-library/components/cl_postgresql_flexible_server"
  env                                                      = var.env
  postfix                                                  = var.postfix
  location                                                 = var.location
  cl_postgresql_flexible_server_postfix                    = var.cl_postgresql_flexible_server_postfix
  cl_postgresql_flexible_server_resource_group_name        = var.cl_postgresql_flexible_server_resource_group_name
  cl_postgresql_flexible_server_vnet_rg_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.resource_group_name
  cl_postgresql_flexible_server_vnet_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_postgresql_flexible_server_subnet_prefix              = ["x.x.xx.x/27"]
  cl_postgresql_flexible_server_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_postgresql_flexible_server_private_dns_zone_id        = [var.cl_postgresql_flexible_server_private_dns_zone_id]
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
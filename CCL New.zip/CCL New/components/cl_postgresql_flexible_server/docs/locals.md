## Local values

```terraform
locals {
  timeout_duration                               = "2h"
  cl_postgresql_flexible_server_delegated_subnet = var.cl_postgresql_flexible_server_deploy_subnet == true ? azurerm_subnet.cl_postgresql_flexible_server_subnet[0].id : var.cl_postgresql_flexible_server_delegated_subnet_id
}
```
<!-- BEGIN_TF_DOCS -->

# Azure Dns Private Resolver

Azure DNS Private Resolver is a new service that enables you to query Azure DNS private zones from an on-premises environment and vice versa without deploying VM based DNS servers.

For more information, please visit: https://learn.microsoft.com/en-us/azure/dns/dns-private-resolver-overview 

#### Note:
```
Requirements
Name	     Version
terraform >= 1.3.0
azurerm	  ~> 3.40.0
```

## Resources

| Name | Type |
|------|------|
| [azurerm_private_dns_resolver.cl_azure_dns_resolver](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver) | resource |
| [azurerm_private_dns_resolver_dns_forwarding_ruleset.cl_azure_dns_resolver_dns_forwarding_ruleset](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_dns_forwarding_ruleset) | resource |
| [azurerm_private_dns_resolver_forwarding_rule.cl_azure_dns_resolver_forwarding_rule_onprem](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_forwarding_rule) | resource |
| [azurerm_private_dns_resolver_forwarding_rule.cl_azure_dns_resolver_forwarding_rule_onprem_additional](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_forwarding_rule) | resource |
| [azurerm_private_dns_resolver_inbound_endpoint.cl_azure_dns_resolver_inbound_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_inbound_endpoint) | resource |
| [azurerm_private_dns_resolver_outbound_endpoint.cl_azure_dns_resolver_outbound_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_outbound_endpoint) | resource |
| [azurerm_private_dns_resolver_virtual_network_link.cl_azure_dns_resolver_virtual_network_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_resolver_virtual_network_link) | resource |
| [azurerm_resource_group.cl_azure_dns_resolver_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subnet.cl_azure_dns_resolver_subnet_inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.cl_azure_dns_resolver_subnet_outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_dns_resolver_additional_forwarding_rules_enable"></a> [cl\_azure\_dns\_resolver\_additional\_forwarding\_rules\_enable](#input\_cl\_azure\_dns\_resolver\_additional\_forwarding\_rules\_enable) | (Optional) set to true if more DNS forwarding rules are to be added | `bool` | `false` | no |
| <a name="input_cl_azure_dns_resolver_deploy_rg"></a> [cl\_azure\_dns\_resolver\_deploy\_rg](#input\_cl\_azure\_dns\_resolver\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for Azure Dns Private Resolver. | `bool` | `true` | no |
| <a name="input_cl_azure_dns_resolver_dns_forwarding_rulese_name"></a> [cl\_azure\_dns\_resolver\_dns\_forwarding\_rulese\_name](#input\_cl\_azure\_dns\_resolver\_dns\_forwarding\_rulese\_name) | (Required) Specifies the name which should be used for this Private DNS Resolver Dns Forwarding Ruleset. Changing this forces a new Private DNS Resolver Dns Forwarding Ruleset to be created. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_additional_names"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_additional\_names](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_additional\_names) | (optional) Name of the  additional Private DNS Resolver Forwarding Rule. | `map(any)` | `{}` | no |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_domain_name"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_domain\_name](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_domain\_name) | (Require) The domain name for the Private DNS Resolver Forwarding Rule in Onprem. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_enabled"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_enabled](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_enabled) | (Optional) Specifies the state of the Private DNS Resolver Forwarding Rule. Defaults to true. | `bool` | `true` | no |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_ip_address"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address) | (Required) DNS server IP address. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_ip_address2"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address2](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_ip\_address2) | (Required) DNS server IP address. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_name"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_name](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_name) | (Required) Name of the Private DNS Resolver Forwarding Rule. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_forwarding_rule_onprem_port"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_port](#input\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem\_port) | (Optional) DNS server port. | `number` | `53` | no |
| <a name="input_cl_azure_dns_resolver_inbound_endpoint_name"></a> [cl\_azure\_dns\_resolver\_inbound\_endpoint\_name](#input\_cl\_azure\_dns\_resolver\_inbound\_endpoint\_name) | (Required) Specifies the name which should be used for this Private DNS Resolver Inbound Endpoint. Changing this forces a new Private DNS Resolver Inbound Endpoint to be created. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_outbound_endpoint_name"></a> [cl\_azure\_dns\_resolver\_outbound\_endpoint\_name](#input\_cl\_azure\_dns\_resolver\_outbound\_endpoint\_name) | (Required) Specifies the name which should be used for this Private DNS Resolver Outbound Endpoint. Changing this forces a new Private DNS Resolver Outbound Endpoint to be created. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_rg_name"></a> [cl\_azure\_dns\_resolver\_rg\_name](#input\_cl\_azure\_dns\_resolver\_rg\_name) | (Optional)provide the resource name to allocate the DNS Priavete Resolver | `string` | `null` | no |
| <a name="input_cl_azure_dns_resolver_subnet_inbound_prefix"></a> [cl\_azure\_dns\_resolver\_subnet\_inbound\_prefix](#input\_cl\_azure\_dns\_resolver\_subnet\_inbound\_prefix) | (Required) The address prefixes to use for the indbount endpoint subnet. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_subnet_inbound_service_endpoints"></a> [cl\_azure\_dns\_resolver\_subnet\_inbound\_service\_endpoints](#input\_cl\_azure\_dns\_resolver\_subnet\_inbound\_service\_endpoints) | (Optional) The list of Service endpoints to associate with the subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage, and Microsoft.Web. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_dns_resolver_subnet_outbound_prefix"></a> [cl\_azure\_dns\_resolver\_subnet\_outbound\_prefix](#input\_cl\_azure\_dns\_resolver\_subnet\_outbound\_prefix) | (Required) The address prefixes to use for the outbound endpoint subnet. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_subnet_outbound_service_endpoints"></a> [cl\_azure\_dns\_resolver\_subnet\_outbound\_service\_endpoints](#input\_cl\_azure\_dns\_resolver\_subnet\_outbound\_service\_endpoints) | (Optional) The list of Service endpoints to associate with the subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage, and Microsoft.Web. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_dns_resolver_vnet_id"></a> [cl\_azure\_dns\_resolver\_vnet\_id](#input\_cl\_azure\_dns\_resolver\_vnet\_id) | (Required) The ID of the Virtual Network that is linked to the Private DNS Resolver. Changing this forces a new Private DNS Resolver to be created. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_vnet_name"></a> [cl\_azure\_dns\_resolver\_vnet\_name](#input\_cl\_azure\_dns\_resolver\_vnet\_name) | (Required) The name of the virtual network to which to attach the subnet. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_cl_azure_dns_resolver_vnet_rg_name"></a> [cl\_azure\_dns\_resolver\_vnet\_rg\_name](#input\_cl\_azure\_dns\_resolver\_vnet\_rg\_name) | (Required) The name of the resource group in which to create the subnet. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_dns_resolver"></a> [cl\_azure\_dns\_resolver](#output\_cl\_azure\_dns\_resolver) | n/a |
| <a name="output_cl_azure_dns_resolver_dns_forwarding_ruleset"></a> [cl\_azure\_dns\_resolver\_dns\_forwarding\_ruleset](#output\_cl\_azure\_dns\_resolver\_dns\_forwarding\_ruleset) | n/a |
| <a name="output_cl_azure_dns_resolver_forwarding_rule_onprem"></a> [cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem](#output\_cl\_azure\_dns\_resolver\_forwarding\_rule\_onprem) | n/a |
| <a name="output_cl_azure_dns_resolver_inbound_endpoint"></a> [cl\_azure\_dns\_resolver\_inbound\_endpoint](#output\_cl\_azure\_dns\_resolver\_inbound\_endpoint) | n/a |
| <a name="output_cl_azure_dns_resolver_outbound_endpoint"></a> [cl\_azure\_dns\_resolver\_outbound\_endpoint](#output\_cl\_azure\_dns\_resolver\_outbound\_endpoint) | n/a |
| <a name="output_cl_azure_dns_resolver_rg"></a> [cl\_azure\_dns\_resolver\_rg](#output\_cl\_azure\_dns\_resolver\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_dns_resolver_subnet_inbound"></a> [cl\_azure\_dns\_resolver\_subnet\_inbound](#output\_cl\_azure\_dns\_resolver\_subnet\_inbound) | n/a |
| <a name="output_cl_azure_dns_resolver_subnet_outbound"></a> [cl\_azure\_dns\_resolver\_subnet\_outbound](#output\_cl\_azure\_dns\_resolver\_subnet\_outbound) | n/a |
| <a name="output_cl_azure_dns_resolver_virtual_network_link"></a> [cl\_azure\_dns\_resolver\_virtual\_network\_link](#output\_cl\_azure\_dns\_resolver\_virtual\_network\_link) | n/a |

## Usage

``` hcl
 module "cl_azure_dns_resolver" {
   source                                                   = "../dn-tads_tf-azure-component-library/components/cl_azure_dns_private_resolver"
   env                                                      = var.env
   postfix                                                  = var.postfix
   location                                                 = var.location
   cl_azure_dns_resolver_vnet_rg_name                       = azurerm_virtual_network.core_vnet.resource_group_name
   cl_azure_dns_resolver_vnet_name                          = azurerm_virtual_network.core_vnet.name
   cl_azure_dns_resolver_subnet_inbound_prefix              = ["10.102.76.16/28"]
   cl_azure_dns_resolver_subnet_outbound_prefix             = ["10.102.76.0/28"]
   cl_azure_dns_resolver_vnet_id                            = azurerm_virtual_network.core_vnet.id
   cl_azure_dns_resolver_inbound_endpoint_name              = "indtest"
   cl_azure_dns_resolver_outbound_endpoint_name             = "outtest" 
   cl_azure_dns_resolver_dns_forwarding_rulese_name         = "test"
   //The dns resolver forwarding_rule values depends on dns onprem for each environment (US, LATAM, US CH, US LATAM)
   cl_azure_dns_resolver_forwarding_rule_onprem_name        = "onprem-forwarder" 
   cl_azure_dns_resolver_forwarding_rule_onprem_domain_name =  "onprem.com." 
   cl_azure_dns_resolver_forwarding_rule_onprem_ip_address  = "10.36.18.83" 
   cl_azure_dns_resolver_forwarding_rule_onprem_ip_address2 = "10.50.18.83" 
 }
```
<!-- END_TF_DOCS -->
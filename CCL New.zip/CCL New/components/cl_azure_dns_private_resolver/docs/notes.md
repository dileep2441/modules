#### Note:
```
Requirements
Name	     Version
terraform >= 1.3.0
azurerm	  ~> 3.40.0
```
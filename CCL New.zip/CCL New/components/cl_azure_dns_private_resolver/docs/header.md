# Azure Dns Private Resolver

Azure DNS Private Resolver is a new service that enables you to query Azure DNS private zones from an on-premises environment and vice versa without deploying VM based DNS servers.

For more information, please visit: https://learn.microsoft.com/en-us/azure/dns/dns-private-resolver-overview 
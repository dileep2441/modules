## Usage 

```terraform
// Azure Resource Group
//**********************************************************************************************
resource "azurerm_resource_group" "machine_learning" {
  name     = "rg-${var.env}-${var.postfix}-mlws-${var.machine_learning_postfix}"
  location = var.location
  tags     = var.tags
}
//**********************************************************************************************

// Azure Application Insights
//**********************************************************************************************
module "cl_app_insights" {
  source                              = "../dn-tads_tf-azure-component-library/components/cl_app_insights_gov"
  env                                 = var.env
  postfix                             = var.postfix
  location                            = var.location
  cl_app_insights_resource_group_name = azurerm_resource_group.machine_learning.name
  cl_app_insights_application_type    = "web"
  cl_app_insights_web_test_kind       = "ping"
 }
//**********************************************************************************************

// Azure Storage account
//**********************************************************************************************
module "cl_storage_account" {
  source                                        = "../dn-tads_tf-azure-component-library/components/cl_storage_account_gov"
  env                                           = var.env
  postfix                                       = var.postfix
  location                                      = var.location
  suffix                                        = var.suffix
  cl_storage_account_resource_group_name        = azurerm_resource_group.machine_learning.name
  cl_storage_account_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_storage_account_allowed_ips                = ["199.206.0.0/15"] //allows KPMG addresses
  cl_storage_account_allowed_pe_subnet_ids      = var.cl_storage_account_allowed_pe_subnet_ids
  cl_storage_account_allowed_vnet_subnet_ids    = var.cl_storage_account_allowed_vnet_subnet_ids
  cl_storage_account_private_dns_zone_ids       = var.sa_private_dns_zone_id
}
//**********************************************************************************************

// Azure Machine Learning Workspace
//**********************************************************************************************
module "cl_machine_learning" {
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_machine_learning_gov"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  suffix                                                 = var.suffix
  cl_machine_learning_postfix                            = var.machine_learning_postfix
  cl_machine_learning_deploy_rg                          = false
  cl_machine_learning_rg_name                            = azurerm_resource_group.machine_learning.name
  cl_machine_learning_app_insights_id                    = module.cl_app_insights.cl_app_insights.id
  cl_machine_learning_storage_account_id                 = module.cl_storage_account.cl_storage_account.id
  cl_machine_learning_keyvault_id                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_keyvault[0].cl_keyvault.id
  cl_machine_learning_nacl_allowed_subnets               = [
      data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet.id
  ]
  cl_machine_learning_privatelink_api_azureml_ms_id      = var.privatelink_api_azureml_ms
  cl_machine_learning_privatelink_notebooks_azure_net_id = var.privatelink_notebooks_azure_net
  cl_machine_learning_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  tags                                                   = var.tags
}
//**********************************************************************************************
```

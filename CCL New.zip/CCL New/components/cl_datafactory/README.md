<!-- BEGIN_TF_DOCS -->

# Azure DataFactory Component

Azure Data Factory is the cloud-based ETL and data integration service that allows you to create data-driven workflows for orchestrating data movement and transforming data at scale. 
With Azure Data Factory, users can create and schedule data-driven workflows (pipelines) that can ingest data from multiple data stores. 
It allows to build complex ETL processes that transform data visually with data flows or by using compute services such as Azure HDInsight Hadoop, Azure Databricks, and Azure SQL Database.

This component will deploy DataFactory, Self-Hosted IR, Monitor Diagnostics, Log Analytics and Private Endpoint for allowed Subnets.

For more information, please visit: https://docs.microsoft.com/en-us/azure/data-factory/introduction



## Resources

| Name | Type |
|------|------|
| [azurerm_data_factory.cl_datafactory](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_factory) | resource |
| [azurerm_data_factory_integration_runtime_azure.cl_datafactory_integration_runtime_azure](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_factory_integration_runtime_azure) | resource |
| [azurerm_data_factory_integration_runtime_self_hosted.cl_datafactory_integration_runtime](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_factory_integration_runtime_self_hosted) | resource |
| [azurerm_log_analytics_solution.cl_datafactory_log_analytics_solution](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_monitor_diagnostic_setting.cl_datafactory_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_datafactory_private_endpoint_dataFactory](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_datafactory_private_endpoint_portal](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_datafactory_deploy_azure_ir"></a> [cl\_datafactory\_deploy\_azure\_ir](#input\_cl\_datafactory\_deploy\_azure\_ir) | (Optional) Deploy Azure integration runtime?. | `bool` | `false` | no |
| <a name="input_cl_datafactory_deploy_azure_ir_ttlm"></a> [cl\_datafactory\_deploy\_azure\_ir\_ttlm](#input\_cl\_datafactory\_deploy\_azure\_ir\_ttlm) | (Optional) Time to live (in minutes) setting of the cluster which will execute data flow job. Defaults to 0. | `number` | `0` | no |
| <a name="input_cl_datafactory_deploy_log_analytics"></a> [cl\_datafactory\_deploy\_log\_analytics](#input\_cl\_datafactory\_deploy\_log\_analytics) | (Optional) Boolean to enable key vault log analytics solution resource creation | `bool` | `true` | no |
| <a name="input_cl_datafactory_deploy_self_hosted_ir"></a> [cl\_datafactory\_deploy\_self\_hosted\_ir](#input\_cl\_datafactory\_deploy\_self\_hosted\_ir) | (Optional) Deploy the self-hosted integration runtime?. | `bool` | `true` | no |
| <a name="input_cl_datafactory_diagnostics"></a> [cl\_datafactory\_diagnostics](#input\_cl\_datafactory\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ActivityRuns",<br>    "PipelineRuns",<br>    "TriggerRuns",<br>    "SSISPackageEventMessages",<br>    "SSISPackageExecutableStatistics",<br>    "SSISPackageEventMessageContext",<br>    "SSISPackageExecutionComponentPhases",<br>    "SSISPackageExecutionDataStatistics",<br>    "SSISIntegrationRuntimeLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_datafactory_github_account_name"></a> [cl\_datafactory\_github\_account\_name](#input\_cl\_datafactory\_github\_account\_name) | (Optional) Specifies the GitHub account name | `string` | `""` | no |
| <a name="input_cl_datafactory_github_branch_name"></a> [cl\_datafactory\_github\_branch\_name](#input\_cl\_datafactory\_github\_branch\_name) | (Optional) Specifies the branch of the repository to get code from | `string` | `""` | no |
| <a name="input_cl_datafactory_github_git_url"></a> [cl\_datafactory\_github\_git\_url](#input\_cl\_datafactory\_github\_git\_url) | (Optional) Specifies the GitHub Enterprise host name. For example: https://github.mydomain.com. Use https://github.com for open source repositories | `string` | `""` | no |
| <a name="input_cl_datafactory_github_repository_name"></a> [cl\_datafactory\_github\_repository\_name](#input\_cl\_datafactory\_github\_repository\_name) | (Optional) Specifies the name of the git repository | `string` | `""` | no |
| <a name="input_cl_datafactory_github_root_folder"></a> [cl\_datafactory\_github\_root\_folder](#input\_cl\_datafactory\_github\_root\_folder) | (Optional) Specifies the root folder within the repository. Set to / for the top level | `string` | `"/"` | no |
| <a name="input_cl_datafactory_log_analytics_solutions"></a> [cl\_datafactory\_log\_analytics\_solutions](#input\_cl\_datafactory\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureDataFactoryAnalytics": {<br>    "product": "OMSGallery/AzureDataFactoryAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_cl_datafactory_log_analytics_workspace_id"></a> [cl\_datafactory\_log\_analytics\_workspace\_id](#input\_cl\_datafactory\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_datafactory_log_analytics_workspace_name"></a> [cl\_datafactory\_log\_analytics\_workspace\_name](#input\_cl\_datafactory\_log\_analytics\_workspace\_name) | (Required) The the log analytics workspace name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_datafactory_logging_rg_name"></a> [cl\_datafactory\_logging\_rg\_name](#input\_cl\_datafactory\_logging\_rg\_name) | (Required) The resource group for the datafactory log analytics solution. | `any` | n/a | yes |
| <a name="input_cl_datafactory_managed_virtual_network_enabled"></a> [cl\_datafactory\_managed\_virtual\_network\_enabled](#input\_cl\_datafactory\_managed\_virtual\_network\_enabled) | (Optional) Is Managed Virtual Network enabled? | `bool` | `false` | no |
| <a name="input_cl_datafactory_nacl_allowed_subnets"></a> [cl\_datafactory\_nacl\_allowed\_subnets](#input\_cl\_datafactory\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this datafactory. | `list(string)` | `[]` | no |
| <a name="input_cl_datafactory_postfix"></a> [cl\_datafactory\_postfix](#input\_cl\_datafactory\_postfix) | (Required) A string that is appended to the end of the datafactory name to identify it. | `any` | n/a | yes |
| <a name="input_cl_datafactory_private_dns_zone_ids"></a> [cl\_datafactory\_private\_dns\_zone\_ids](#input\_cl\_datafactory\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_datafactory_public_network_enabled"></a> [cl\_datafactory\_public\_network\_enabled](#input\_cl\_datafactory\_public\_network\_enabled) | (Optional) Is the datafactory visible to the public network? | `bool` | `false` | no |
| <a name="input_cl_datafactory_repository_type"></a> [cl\_datafactory\_repository\_type](#input\_cl\_datafactory\_repository\_type) | (Optional) The Repository Type (vsts, github) | `string` | `""` | no |
| <a name="input_cl_datafactory_rg_name"></a> [cl\_datafactory\_rg\_name](#input\_cl\_datafactory\_rg\_name) | (Required) The resource group for the datafactory. | `any` | n/a | yes |
| <a name="input_cl_datafactory_vsts_account_name"></a> [cl\_datafactory\_vsts\_account\_name](#input\_cl\_datafactory\_vsts\_account\_name) | (Optional) Specifies the VSTS account name | `string` | `""` | no |
| <a name="input_cl_datafactory_vsts_branch_name"></a> [cl\_datafactory\_vsts\_branch\_name](#input\_cl\_datafactory\_vsts\_branch\_name) | (Optional) Specifies the branch of the repository to get code from | `string` | `""` | no |
| <a name="input_cl_datafactory_vsts_project_name"></a> [cl\_datafactory\_vsts\_project\_name](#input\_cl\_datafactory\_vsts\_project\_name) | (Optional) Specifies the name of the VSTS project | `string` | `""` | no |
| <a name="input_cl_datafactory_vsts_repository_name"></a> [cl\_datafactory\_vsts\_repository\_name](#input\_cl\_datafactory\_vsts\_repository\_name) | (Optional) Specifies the name of the git repository | `string` | `""` | no |
| <a name="input_cl_datafactory_vsts_root_folder"></a> [cl\_datafactory\_vsts\_root\_folder](#input\_cl\_datafactory\_vsts\_root\_folder) | (Optional) Specifies the root folder within the repository. Set to / for the top level. | `string` | `"/"` | no |
| <a name="input_cl_datafactory_vsts_tenant_id"></a> [cl\_datafactory\_vsts\_tenant\_id](#input\_cl\_datafactory\_vsts\_tenant\_id) | (Optional) Specifies the Tenant ID associated with the VSTS account | `string` | `""` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_azure_data_factory"></a> [azure\_data\_factory](#output\_azure\_data\_factory) | Outputs ********************************************************************************************** |
| <a name="output_azurerm_data_factory_integration_runtime_azure"></a> [azurerm\_data\_factory\_integration\_runtime\_azure](#output\_azurerm\_data\_factory\_integration\_runtime\_azure) | n/a |
| <a name="output_azurerm_data_factory_integration_runtime_self_hosted"></a> [azurerm\_data\_factory\_integration\_runtime\_self\_hosted](#output\_azurerm\_data\_factory\_integration\_runtime\_self\_hosted) | n/a |
| <a name="output_azurerm_log_analytics_solution"></a> [azurerm\_log\_analytics\_solution](#output\_azurerm\_log\_analytics\_solution) | n/a |
| <a name="output_azurerm_monitor_diagnostic_setting"></a> [azurerm\_monitor\_diagnostic\_setting](#output\_azurerm\_monitor\_diagnostic\_setting) | n/a |
| <a name="output_azurerm_private_endpoint_datafactory_dataFactory"></a> [azurerm\_private\_endpoint\_datafactory\_dataFactory](#output\_azurerm\_private\_endpoint\_datafactory\_dataFactory) | n/a |
| <a name="output_azurerm_private_endpoint_datafactory_portal"></a> [azurerm\_private\_endpoint\_datafactory\_portal](#output\_azurerm\_private\_endpoint\_datafactory\_portal) | n/a |

## Usage

```terraform
resource "azurerm_private_dns_zone" "data_factory_private_dns_zone" {
  name                = var.datafactory_private_dns_zone_name
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "data_factory_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-adf-private-dns-vnet-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.data_factory_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_datafactory" {
    source                                        = "../dn-tads_tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]
}
```
## Usage with VSTS/ADO Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../dn-tads_tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]    

    cl_datafactory_repository_type                = "vsts" 
    cl_datafactory_vsts_account_name              = "organization_name"
    cl_datafactory_vsts_branch_name               = "master"
    cl_datafactory_vsts_project_name              = "migration" 
    cl_datafactory_vsts_repository_name           = "migration"
    cl_datafactory_vsts_root_folder               = "/" 
    cl_datafactory_vsts_tenant_id                 = "z567b2579-xxx-457d-a68e-764775adcb646"
}
```
## Usage with GITHUB Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../dn-tads_tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]

    cl_datafactory_repository_type                = "github" 
    cl_datafactory_github_account_name            = "organization_name"
    cl_datafactory_github_branch_name             = "master"
    cl_datafactory_github_git_url                 = "https://domaingithub.com/" 
    cl_datafactory_github_repository_name         = "migration"
    cl_datafactory_github_root_folder             = "/" 
}

resource "azurerm_private_dns_a_record" "data_factory_private_dns_record" {
  name                = "${var.env}-${var.postfix}-adf-pe-record"
  zone_name           = azurerm_private_dns_zone.data_factory_private_dns_zone.name
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                 = var.datafactory_private_record_ttl
  records             = module.cl_datafactory.azurerm_private_endpoint_datafactory_dataFactory[*].private_service_connection[0].private_ip_address
  tags                = var.tags
}
```
<!-- END_TF_DOCS -->
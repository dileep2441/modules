## Local values

```terraform
locals {
    timeout_duration = "2h"


  cl_windows_app_service_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/734fea36-c123-4c5e-9e9d-b4679e9e372b/resourceGroups/rg-nprd-pr-sharedsvcs-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.us"]
    "prod-pr" = ["/subscriptions/e17b69e4-59eb-4b56-a090-d08f87c300de/resourceGroups/rg-prod-pr-shrdsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privateDnsZones/privatelink.azurewebsites.us"]
    "prod-dr" = ["/subscriptions/9ba10ba3-a3cb-4a41-8b3d-d5b8d3414558/resourceGroups/rg-prod-dr-shrdsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.us"]
  }
}
```


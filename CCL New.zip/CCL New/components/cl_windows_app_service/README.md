<!-- BEGIN_TF_DOCS -->

# Azure App Service Component

App Service is a fully-managed Platform as a Service (PaaS) that lets you deploy and scale web, mobile, and API apps.
This component will deploy an app service in the target app service plan, bind the app service to the integration subnet,
configure a private endpoint, custom domain and diagnostics for the app service.

For more information, please visit: https://docs.microsoft.com/en-us/azure/app-service/overview

#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified in a Github Action Task:
```Githubaction task
    - name: Setup Terraform
      uses: hashicorp/setup-terraform@v1
      with:
        terraform_version: ${{ env.TF_VERSION }}   
```
Specify TF version in `pattern_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```

## Resources

| Name | Type |
|------|------|
| [azurerm_app_service_custom_hostname_binding.cl_windows_app_service_custom_hostname_binding](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service_custom_hostname_binding) | resource |
| [azurerm_app_service_virtual_network_swift_connection.cl_windows_app_service_network_connection_integration_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service_virtual_network_swift_connection) | resource |
| [azurerm_monitor_diagnostic_setting.cl_windows_app_service_plan_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_windows_app_service_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_windows_web_app.cl_windows_app_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_web_app) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_app_service_is_docker"></a> [cl\_app\_service\_is\_docker](#input\_cl\_app\_service\_is\_docker) | Specifies if the app service will be using containers. This will change the populations of variables on the app service and build the app\_setting on its own | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_acr_login_server"></a> [cl\_windows\_app\_service\_acr\_login\_server](#input\_cl\_windows\_app\_service\_acr\_login\_server) | Is the Azure Container Registry server | `string` | `""` | no |
| <a name="input_cl_windows_app_service_acr_password"></a> [cl\_windows\_app\_service\_acr\_password](#input\_cl\_windows\_app\_service\_acr\_password) | Is the Azure Container Registry password of the username to be used | `string` | `""` | no |
| <a name="input_cl_windows_app_service_acr_use_managed_identity_credentials"></a> [cl\_windows\_app\_service\_acr\_use\_managed\_identity\_credentials](#input\_cl\_windows\_app\_service\_acr\_use\_managed\_identity\_credentials) | (Optional) Are Managed Identity Credentials used for Azure Container Registry pull | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_acr_user_managed_identity_client_id"></a> [cl\_windows\_app\_service\_acr\_user\_managed\_identity\_client\_id](#input\_cl\_windows\_app\_service\_acr\_user\_managed\_identity\_client\_id) | (Optional) If using User Managed Identity, the User Managed Identity Client Id | `string` | `null` | no |
| <a name="input_cl_windows_app_service_acr_username"></a> [cl\_windows\_app\_service\_acr\_username](#input\_cl\_windows\_app\_service\_acr\_username) | Is the Azure Container Registry username to access the repository | `string` | `""` | no |
| <a name="input_cl_windows_app_service_always_on"></a> [cl\_windows\_app\_service\_always\_on](#input\_cl\_windows\_app\_service\_always\_on) | (Optional) Should the app be loaded at all times? | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_api_management_api_id"></a> [cl\_windows\_app\_service\_api\_management\_api\_id](#input\_cl\_windows\_app\_service\_api\_management\_api\_id) | (Optional) The API Management API ID this Windows Web App Slot is associated with. | `string` | `null` | no |
| <a name="input_cl_windows_app_service_app_command_line"></a> [cl\_windows\_app\_service\_app\_command\_line](#input\_cl\_windows\_app\_service\_app\_command\_line) | (Optional) The app command line to launch. | `string` | `""` | no |
| <a name="input_cl_windows_app_service_app_postfix"></a> [cl\_windows\_app\_service\_app\_postfix](#input\_cl\_windows\_app\_service\_app\_postfix) | (Required) The bespoke name of the app you are deploying. | `any` | n/a | yes |
| <a name="input_cl_windows_app_service_asp_id"></a> [cl\_windows\_app\_service\_asp\_id](#input\_cl\_windows\_app\_service\_asp\_id) | (Required) The resource id of the app service plan. | `any` | n/a | yes |
| <a name="input_cl_windows_app_service_auth_settings_aad_allowed_audiences"></a> [cl\_windows\_app\_service\_auth\_settings\_aad\_allowed\_audiences](#input\_cl\_windows\_app\_service\_auth\_settings\_aad\_allowed\_audiences) | (Optional) Allowed audience values to consider when validating JWTs issued by Azure Active Directory. | `any` | `null` | no |
| <a name="input_cl_windows_app_service_auth_settings_aad_client_id"></a> [cl\_windows\_app\_service\_auth\_settings\_aad\_client\_id](#input\_cl\_windows\_app\_service\_auth\_settings\_aad\_client\_id) | (Optional) The Client ID of this relying party application. Enables OpenIDConnection authentication with Azure Active Directory. | `any` | `null` | no |
| <a name="input_cl_windows_app_service_auth_settings_aad_client_secret"></a> [cl\_windows\_app\_service\_auth\_settings\_aad\_client\_secret](#input\_cl\_windows\_app\_service\_auth\_settings\_aad\_client\_secret) | (Optional) The Client Secret of this relying party application. If no secret is provided, implicit flow will be used. | `any` | `null` | no |
| <a name="input_cl_windows_app_service_auth_settings_default_provider"></a> [cl\_windows\_app\_service\_auth\_settings\_default\_provider](#input\_cl\_windows\_app\_service\_auth\_settings\_default\_provider) | (Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter. | `string` | `"AzureActiveDirectory"` | no |
| <a name="input_cl_windows_app_service_auth_settings_enabled"></a> [cl\_windows\_app\_service\_auth\_settings\_enabled](#input\_cl\_windows\_app\_service\_auth\_settings\_enabled) | (Optional) Enable or disable Authentication Settings | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_auth_settings_unauthenticated_client_action"></a> [cl\_windows\_app\_service\_auth\_settings\_unauthenticated\_client\_action](#input\_cl\_windows\_app\_service\_auth\_settings\_unauthenticated\_client\_action) | (Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage. | `any` | `null` | no |
| <a name="input_cl_windows_app_service_client_affinity_enabled"></a> [cl\_windows\_app\_service\_client\_affinity\_enabled](#input\_cl\_windows\_app\_service\_client\_affinity\_enabled) | (Optional) Should the App Service send session affinity cookies, which route client requests in the same session to the same instance? | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_client_cert_enabled"></a> [cl\_windows\_app\_service\_client\_cert\_enabled](#input\_cl\_windows\_app\_service\_client\_cert\_enabled) | (Optional) Does the App Service require client certificates for incoming requests? Defaults to false | `bool` | `true` | no |
| <a name="input_cl_windows_app_service_client_cert_mode"></a> [cl\_windows\_app\_service\_client\_cert\_mode](#input\_cl\_windows\_app\_service\_client\_cert\_mode) | (Optional) Mode of client certificates for this App Service. Possible values are Required, Optional and OptionalInteractiveUser. If this parameter is set, client\_cert\_enabled must be set to true, otherwise this parameter is ignored. | `string` | `"Required"` | no |
| <a name="input_cl_windows_app_service_connection_strings"></a> [cl\_windows\_app\_service\_connection\_strings](#input\_cl\_windows\_app\_service\_connection\_strings) | (Optional) Connection strings for App Service. | <pre>map(object({<br>    name                  = string<br>    type                  = string<br>    value                 = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_windows_app_service_cors_allowed_origins"></a> [cl\_windows\_app\_service\_cors\_allowed\_origins](#input\_cl\_windows\_app\_service\_cors\_allowed\_origins) | (Optional) A list of origins which should be able to make cross-origin calls. * can be used to allow all calls. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_cl_windows_app_service_current_stack"></a> [cl\_windows\_app\_service\_current\_stack](#input\_cl\_windows\_app\_service\_current\_stack) | (Optional) The Application Stack for the Windows Web App. Possible values include dotnet, dotnetcore, node, python, php, and java | `string` | `"dotnet"` | no |
| <a name="input_cl_windows_app_service_custom_domain_hostname"></a> [cl\_windows\_app\_service\_custom\_domain\_hostname](#input\_cl\_windows\_app\_service\_custom\_domain\_hostname) | (Optional) App service custom domain hostname. | `string` | `""` | no |
| <a name="input_cl_windows_app_service_custom_domain_thumbprint"></a> [cl\_windows\_app\_service\_custom\_domain\_thumbprint](#input\_cl\_windows\_app\_service\_custom\_domain\_thumbprint) | (Optional) The app service custom domain thumbprint. | `string` | `""` | no |
| <a name="input_cl_windows_app_service_default_documents"></a> [cl\_windows\_app\_service\_default\_documents](#input\_cl\_windows\_app\_service\_default\_documents) | (Optional) The ordering of default documents to load, if an address isn't specified. | `list` | `[]` | no |
| <a name="input_cl_windows_app_service_detailed_error_messages"></a> [cl\_windows\_app\_service\_detailed\_error\_messages](#input\_cl\_windows\_app\_service\_detailed\_error\_messages) | (Optional) Should detailed error messages be enabled. | `bool` | `true` | no |
| <a name="input_cl_windows_app_service_diagnostics"></a> [cl\_windows\_app\_service\_diagnostics](#input\_cl\_windows\_app\_service\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AppServiceAntivirusScanAuditLogs",<br>    "AppServiceHTTPLogs",<br>    "AppServiceConsoleLogs",<br>    "AppServiceAppLogs",<br>    "AppServiceFileAuditLogs",<br>    "AppServiceAuditLogs",<br>    "AppServiceIPSecAuditLogs",<br>    "AppServicePlatformLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_windows_app_service_dns_alt_server"></a> [cl\_windows\_app\_service\_dns\_alt\_server](#input\_cl\_windows\_app\_service\_dns\_alt\_server) | Custom DNS service for app service routing. | `string` | `"168.63.129.16"` | no |
| <a name="input_cl_windows_app_service_dns_server"></a> [cl\_windows\_app\_service\_dns\_server](#input\_cl\_windows\_app\_service\_dns\_server) | Custom DNS service for app service routing. | `string` | `"168.63.129.16"` | no |
| <a name="input_cl_windows_app_service_docker_container_name"></a> [cl\_windows\_app\_service\_docker\_container\_name](#input\_cl\_windows\_app\_service\_docker\_container\_name) | (Optional) The name of the Docker Container. For example azure-app-service/samples/aspnethelloworld | `string` | `null` | no |
| <a name="input_cl_windows_app_service_docker_container_tag"></a> [cl\_windows\_app\_service\_docker\_container\_tag](#input\_cl\_windows\_app\_service\_docker\_container\_tag) | (Optional) The Image Tag of the specified Docker Container to use. For example. | `string` | `null` | no |
| <a name="input_cl_windows_app_service_docker_enabled"></a> [cl\_windows\_app\_service\_docker\_enabled](#input\_cl\_windows\_app\_service\_docker\_enabled) | (Optional) determine if docker is enabled | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_dotnet_version"></a> [cl\_windows\_app\_service\_dotnet\_version](#input\_cl\_windows\_app\_service\_dotnet\_version) | (Optional) The version of .NET to use when current\_stack is set to dotnet. Possible values include v3.0, v4.0, v5.0, and v6.0. | `string` | `"v6.0"` | no |
| <a name="input_cl_windows_app_service_failed_request_tracing"></a> [cl\_windows\_app\_service\_failed\_request\_tracing](#input\_cl\_windows\_app\_service\_failed\_request\_tracing) | (Optional) Should failed request tracing be enabled | `bool` | `true` | no |
| <a name="input_cl_windows_app_service_file_system_level"></a> [cl\_windows\_app\_service\_file\_system\_level](#input\_cl\_windows\_app\_service\_file\_system\_level) | (Required) Log level. Possible values include: Verbose, Information, Warning, and Error. | `string` | `"Information"` | no |
| <a name="input_cl_windows_app_service_ftps_state"></a> [cl\_windows\_app\_service\_ftps\_state](#input\_cl\_windows\_app\_service\_ftps\_state) | (Optional) State of FTP / FTPS service for this App Service. Possible values include: AllAllowed, FtpsOnly and Disabled. | `string` | `"Disabled"` | no |
| <a name="input_cl_windows_app_service_health_check_path"></a> [cl\_windows\_app\_service\_health\_check\_path](#input\_cl\_windows\_app\_service\_health\_check\_path) | The health check path to be pinged by App Service | `string` | `""` | no |
| <a name="input_cl_windows_app_service_http2_enabled"></a> [cl\_windows\_app\_service\_http2\_enabled](#input\_cl\_windows\_app\_service\_http2\_enabled) | (Optional) Is HTTP2 Enabled on this App Service? | `bool` | `true` | no |
| <a name="input_cl_windows_app_service_https_only"></a> [cl\_windows\_app\_service\_https\_only](#input\_cl\_windows\_app\_service\_https\_only) | (Optional) Booolean to toggle if the App Service can only be accessed via HTTPS. | `bool` | `true` | no |
| <a name="input_cl_windows_app_service_identity_identity_ids"></a> [cl\_windows\_app\_service\_identity\_identity\_ids](#input\_cl\_windows\_app\_service\_identity\_identity\_ids) | (Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned. | `any` | `null` | no |
| <a name="input_cl_windows_app_service_identity_type"></a> [cl\_windows\_app\_service\_identity\_type](#input\_cl\_windows\_app\_service\_identity\_type) | (Optional) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_windows_app_service_integration_subnet_id"></a> [cl\_windows\_app\_service\_integration\_subnet\_id](#input\_cl\_windows\_app\_service\_integration\_subnet\_id) | (Optional) The ID of the integration subnet the app service will be associated to (the subnet must have a service\_delegation configured for Microsoft.Web/serverFarms). | `any` | `null` | no |
| <a name="input_cl_windows_app_service_is_custom_domain_enable"></a> [cl\_windows\_app\_service\_is\_custom\_domain\_enable](#input\_cl\_windows\_app\_service\_is\_custom\_domain\_enable) | (Optional) Is the app service using a custom domain?. | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_java_container"></a> [cl\_windows\_app\_service\_java\_container](#input\_cl\_windows\_app\_service\_java\_container) | (Optional) The Java container type to use when current\_stack is set to java. Possible values include JAVA, JETTY, and TOMCAT. Required with java\_version and java\_container\_version. | `string` | `"TOMCAT"` | no |
| <a name="input_cl_windows_app_service_java_container_version"></a> [cl\_windows\_app\_service\_java\_container\_version](#input\_cl\_windows\_app\_service\_java\_container\_version) | (Optional) The Version of the java\_container to use. Required with java\_version and java\_container | `string` | `"9.0"` | no |
| <a name="input_cl_windows_app_service_java_version"></a> [cl\_windows\_app\_service\_java\_version](#input\_cl\_windows\_app\_service\_java\_version) | (Optional) The version of Java to use when current\_stack is set to java. Possible values include 1.7, 1.8 and 11. Required with java\_container and java\_container\_version | `string` | `"1.8"` | no |
| <a name="input_cl_windows_app_service_log_analytics_workspace_id"></a> [cl\_windows\_app\_service\_log\_analytics\_workspace\_id](#input\_cl\_windows\_app\_service\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_windows_app_service_min_tls_version"></a> [cl\_windows\_app\_service\_min\_tls\_version](#input\_cl\_windows\_app\_service\_min\_tls\_version) | (Optional) The minimum supported TLS version for the app service | `string` | `"1.2"` | no |
| <a name="input_cl_windows_app_service_node_version"></a> [cl\_windows\_app\_service\_node\_version](#input\_cl\_windows\_app\_service\_node\_version) | (Optional) The version of node to use when current\_stack is set to node. Possible values include 12-LTS, 14-LTS, and 16-LTS | `string` | `"16-LTS"` | no |
| <a name="input_cl_windows_app_service_number_of_workers"></a> [cl\_windows\_app\_service\_number\_of\_workers](#input\_cl\_windows\_app\_service\_number\_of\_workers) | (Optional) The scaled number of workers (for per site scaling) of this App Service. | `number` | `1` | no |
| <a name="input_cl_windows_app_service_pe_subnet_ids"></a> [cl\_windows\_app\_service\_pe\_subnet\_ids](#input\_cl\_windows\_app\_service\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_cl_windows_app_service_php_version"></a> [cl\_windows\_app\_service\_php\_version](#input\_cl\_windows\_app\_service\_php\_version) | (Optional) The version of PHP to use when current\_stack is set to php. Possible values include v7.4 | `string` | `"v7.4"` | no |
| <a name="input_cl_windows_app_service_plan_deploy_integration_subnet"></a> [cl\_windows\_app\_service\_plan\_deploy\_integration\_subnet](#input\_cl\_windows\_app\_service\_plan\_deploy\_integration\_subnet) | (Optional) A boolean that toggles the deployment of the vnet integration subnet. | `bool` | `true` | no |
| <a name="input_cl_windows_app_service_private_dns_zone_ids"></a> [cl\_windows\_app\_service\_private\_dns\_zone\_ids](#input\_cl\_windows\_app\_service\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_windows_app_service_public_network_access_enabled"></a> [cl\_windows\_app\_service\_public\_network\_access\_enabled](#input\_cl\_windows\_app\_service\_public\_network\_access\_enabled) | (Optional) Should public network access be enabled for the Web App. Defaults to true | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_python_version"></a> [cl\_windows\_app\_service\_python\_version](#input\_cl\_windows\_app\_service\_python\_version) | (Optional) The version of Python to use when current\_stack is set to python. Possible values include 2.7 and 3.4.0 | `string` | `"3.4.0"` | no |
| <a name="input_cl_windows_app_service_remote_debugging_enabled"></a> [cl\_windows\_app\_service\_remote\_debugging\_enabled](#input\_cl\_windows\_app\_service\_remote\_debugging\_enabled) | (Optional) Is Remote Debugging Enabled? | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_remote_debugging_version"></a> [cl\_windows\_app\_service\_remote\_debugging\_version](#input\_cl\_windows\_app\_service\_remote\_debugging\_version) | (Optional) Which version of Visual Studio should the Remote Debugger be compatible with? | `any` | `null` | no |
| <a name="input_cl_windows_app_service_rg_name"></a> [cl\_windows\_app\_service\_rg\_name](#input\_cl\_windows\_app\_service\_rg\_name) | (Required) The resource group to deploy the app service into. | `any` | n/a | yes |
| <a name="input_cl_windows_app_service_settings"></a> [cl\_windows\_app\_service\_settings](#input\_cl\_windows\_app\_service\_settings) | (Optional) Variables passed as environment variables | `map` | `{}` | no |
| <a name="input_cl_windows_app_service_support_cors_credentials"></a> [cl\_windows\_app\_service\_support\_cors\_credentials](#input\_cl\_windows\_app\_service\_support\_cors\_credentials) | (Optional) Are credentials supported?. | `bool` | `false` | no |
| <a name="input_cl_windows_app_service_use_32_bit_worker_process"></a> [cl\_windows\_app\_service\_use\_32\_bit\_worker\_process](#input\_cl\_windows\_app\_service\_use\_32\_bit\_worker\_process) | (Optional) Should the App Service run in 32 bit mode, rather than 64 bit mode? | `bool` | `true` | no |
| <a name="input_cl_windows_app_service_vnet_route_server"></a> [cl\_windows\_app\_service\_vnet\_route\_server](#input\_cl\_windows\_app\_service\_vnet\_route\_server) | (Optional) Should all outbound traffic to have Virtual Network Security Groups and User Defined Routes applied. | `number` | `1` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"


  cl_windows_app_service_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/734fea36-c123-4c5e-9e9d-b4679e9e372b/resourceGroups/rg-nprd-pr-sharedsvcs-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.us"]
    "prod-pr" = ["/subscriptions/e17b69e4-59eb-4b56-a090-d08f87c300de/resourceGroups/rg-prod-pr-shrdsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privateDnsZones/privatelink.azurewebsites.us"]
    "prod-dr" = ["/subscriptions/9ba10ba3-a3cb-4a41-8b3d-d5b8d3414558/resourceGroups/rg-prod-dr-shrdsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.us"]
  }
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_windows_app_service"></a> [cl\_windows\_app\_service](#output\_cl\_windows\_app\_service) | Outputs ********************************************************************************************** |
| <a name="output_cl_windows_app_service_plan_diagnostic_setting"></a> [cl\_windows\_app\_service\_plan\_diagnostic\_setting](#output\_cl\_windows\_app\_service\_plan\_diagnostic\_setting) | n/a |
| <a name="output_cl_windows_app_service_private_endpoint"></a> [cl\_windows\_app\_service\_private\_endpoint](#output\_cl\_windows\_app\_service\_private\_endpoint) | n/a |


## Usage

### Deploy App Service with vnet integration subnet

```terraform
module "cl_windows_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_windows_app_service_plan_app_postfix                           = var.asp_postfix
  cl_windows_app_service_plan_deploy_integration_subnet             = true
  cl_windows_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_windows_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_windows_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_windows_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_windows_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_windows_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_windows_app_service_plan_os_type                                  = var.app_service_plan_kind
  cl_windows_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_windows_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_windows_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

module "cl_windows_app_service" {
  source                                                      = "../dn-tads_tf-azure-component-library/components/cl_windows_app_service"
  env                                                         = var.env
  postfix                                                     = "crwx-a"
  location                                                    = var.location
  suffix                                                      = "gvnpa"
  cl_windows_app_service_plan_deploy_integration_subnet       = true
  cl_windows_app_service_integration_subnet_id                = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id 
  cl_windows_app_service_client_affinity_enabled              = false
  cl_windows_app_service_pe_subnet_ids                        = [data.azurerm_subnet.private_link_subnet.id]
  cl_windows_app_service_app_postfix                          = "walxar"
  cl_windows_app_service_rg_name                              = module.cl_app_service_plan.cl_app_service_plan_rg[0].name
  cl_windows_app_service_asp_id                               = module.cl_app_service_plan.cl_app_service_plan.id
  cl_windows_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  #cl_windows_app_service_diagnostics                          = var.app_service_diagnostics
  #cl_windows_app_service_settings                             = var.app_service_settings
  cl_windows_app_service_private_dns_zone_ids                 = [data.azurerm_private_dns_zone.app_service_private_dns_zone.id]
  cl_windows_app_service_cors_allowed_origins                 = [""]

  //Site_Config

  #cl_app_service_default_documents                           = var.app_service_default_documents
  #cl_app_service_use_32_bit_worker_process                   = var.app_service_use_32_bit_worker_process  
  tags                                                        = var.tags
  cl_windows_app_service_remote_debugging_enabled             = true
 }
```
### Deploy App Service for Containers with vnet integration subnet (Azure Container Registry and repository images should be already in place)
```terraform

module "cl_azure_container_registry" {
    source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
    suffix                                                      = var.suffix
    tags                                                         = var.tags
    cl_azure_container_registry_rg_name                         = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_allowed_vnet_ids                = [data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id]
    cl_azure_container_registry_content_trust_enabled           = false
    cl_azure_container_registry_admin_enabled                   = true
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
}

module "cl_windows_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_windows_app_service_plan_app_postfix                           = var.asp_postfix
  cl_windows_app_service_plan_deploy_integration_subnet             = true
  cl_windows_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_windows_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_windows_app_service_plan_integration_subnet_prefix             = var.app_service_integration_subnet_prefix
  cl_windows_app_service_plan_int_subnet_user_defined_nsg_rules     = var.app_service_nsg_rules
  cl_windows_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_windows_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_windows_app_service_plan_os_type                                  = var.app_service_plan_kind
  cl_windows_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_windows_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_windows_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

module "cl_windows_app_service" {
  source                                              = "../dn-tads_tf-azure-component-library/components/cl_windows_app_service"
  env                                                 = var.env
  postfix                                             = var.postfix
  location                                            = var.location
  suffix                                              = var.suffix
  cl_windows_app_service_plan_deploy_integration_subnet       = true
  cl_windows_app_service_integration_subnet_id                = var.cl_windows_app_service_plan_deploy_integration_subnet ? module.cl_windows_app_service_plan.cl_windows_app_service_plan_integration_subnet.id : null
  cl_windows_app_service_client_affinity_enabled              = var.app_service_client_affinity_enabled
  cl_windows_app_service_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_windows_app_service_app_postfix                          = var.app_service_app_postfix
  cl_windows_app_service_rg_name                              = module.cl_windows_app_service_plan.cl_windows_app_service_plan_rg.name
  cl_windows_app_service_asp_id                               = module.cl_windows_app_service_plan.cl_windows_app_service_plan.id
  cl_windows_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_windows_app_service_diagnostics                          = var.app_service_diagnostics
  cl_windows_app_service_settings                             = var.app_service_settings
  cl_windows_app_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.app_service_private_dns_zone.id]

  //Site_Config

  cl_windows_app_service_default_documents                    = var.app_service_default_documents
  cl_windows_app_service_use_32_bit_worker_process            = var.app_service_use_32_bit_worker_process  


  //cl_windows_app_service_acr_username can be any other user with access to pull and push images into and from ACR. Not only the admin user from ACR.
  cl_windows_app_service_is_docker        = true
  cl_windows_app_service_acr_login_server = module.cl_azure_container_registry.cl_azure_container_registry.login_server
  cl_windows_app_service_acr_username     = module.cl_azure_container_registry.cl_azure_container_registry_admin_username
  cl_windows_app_service_acr_password     = module.cl_azure_container_registry.cl_azure_container_registry_admin_password
  cl_windows_app_service_acr_image        = "myapp:latest"

    // Connection Strings in variable cl_windows_app_service_connection_strings
  cl_windows_app_service_connection_strings = {
      connection_string = {
        name      = "sa_peninsula_connection"
        type      = "Custom"
        value     = var.cl_b2c_manager_app_service_connection_string_value
      }
    }

    tags                            = var.tags
 }
```
<!-- END_TF_DOCS -->
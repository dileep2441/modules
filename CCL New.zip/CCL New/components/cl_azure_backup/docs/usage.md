## Usage
# Backups for VMs
```terraform
 // Azure Backup
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv       = true
  cl_azure_backup_enable_vm_backup = true
}
//**********************************************************************************************
```

# Backups for File Storage
```terraform
 // Azure Backup
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv                 = true
  cl_azure_backup_enable_file_storage_backup = true
}
//**********************************************************************************************
```

# Backups for Blob Storage
```terraform
 // Azure Backup
// IMPORTANT: Must assign the blob storage backup vault "Storage Account Backup Contributor" role on the blob storage account. 
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_enable_blob_storage_backup = true
}
//**********************************************************************************************
```
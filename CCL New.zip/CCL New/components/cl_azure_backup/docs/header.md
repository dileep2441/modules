# Azure Backup Component

Azure Backup Server is a backup option for both on-premises and cloud-based workloads in Azure storage. 
This resource leverages vaults (recovery service vaults and backup vaults) in order to store data such as backup copies, recovery points, and backup policies. 
This specific component deploys the Backup Service Vault, VM Backup Policy and diagnostics settings for the Azure Backup.

For more information, please visit: https://docs.microsoft.com/en-us/azure/backup/backup-overview 
<!-- BEGIN_TF_DOCS -->

# Azure Backup Component

Azure Backup Server is a backup option for both on-premises and cloud-based workloads in Azure storage. 
This resource leverages vaults (recovery service vaults and backup vaults) in order to store data such as backup copies, recovery points, and backup policies. 
This specific component deploys the Backup Service Vault, VM Backup Policy and diagnostics settings for the Azure Backup.

For more information, please visit: https://docs.microsoft.com/en-us/azure/backup/backup-overview 



## Resources

| Name | Type |
|------|------|
| [azurerm_backup_policy_file_share.cl_azure_backup_policy_fileshare](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_policy_file_share) | resource |
| [azurerm_backup_policy_vm.cl_azure_backup_policy_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_policy_vm) | resource |
| [azurerm_data_protection_backup_policy_blob_storage.cl_azure_backup_blob_sa_backup_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_policy_blob_storage) | resource |
| [azurerm_data_protection_backup_vault.cl_azure_backup_blob_sa_backup_vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_vault) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_backup_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_recovery_services_vault.cl_azure_backup_sv](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/recovery_services_vault) | resource |
| [azurerm_resource_group.cl_azure_backup_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_backup_deploy_rsv"></a> [cl\_azure\_backup\_deploy\_rsv](#input\_cl\_azure\_backup\_deploy\_rsv) | If true, deploy rsv. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_diagnostics"></a> [cl\_azure\_backup\_diagnostics](#input\_cl\_azure\_backup\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "AzureBackupReport",<br>    "CoreAzureBackup",<br>    "AddonAzureBackupJobs",<br>    "AddonAzureBackupAlerts",<br>    "AddonAzureBackupPolicy",<br>    "AddonAzureBackupStorage",<br>    "AddonAzureBackupProtectedInstance",<br>    "AzureSiteRecoveryJobs",<br>    "AzureSiteRecoveryEvents",<br>    "AzureSiteRecoveryReplicatedItems",<br>    "AzureSiteRecoveryReplicationStats",<br>    "AzureSiteRecoveryRecoveryPoints",<br>    "AzureSiteRecoveryReplicationDataUploadRate",<br>    "AzureSiteRecoveryProtectedDiskDataChurn"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_azure_backup_enable_blob_storage_backup"></a> [cl\_azure\_backup\_enable\_blob\_storage\_backup](#input\_cl\_azure\_backup\_enable\_blob\_storage\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_enable_file_storage_backup"></a> [cl\_azure\_backup\_enable\_file\_storage\_backup](#input\_cl\_azure\_backup\_enable\_file\_storage\_backup) | (Optional) Toggle the file storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_enable_vm_backup"></a> [cl\_azure\_backup\_enable\_vm\_backup](#input\_cl\_azure\_backup\_enable\_vm\_backup) | (Optional) Toggle the vm backup feature. | `bool` | `false` | no |
| <a name="input_cl_azure_backup_log_analytics_workspace_id"></a> [cl\_azure\_backup\_log\_analytics\_workspace\_id](#input\_cl\_azure\_backup\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_backup_public_network_access"></a> [cl\_azure\_backup\_public\_network\_access](#input\_cl\_azure\_backup\_public\_network\_access) | (Optional) It enabled to access the vault from public networks | `bool` | `false` | no |
| <a name="input_cl_azure_backup_retention_daily_count"></a> [cl\_azure\_backup\_retention\_daily\_count](#input\_cl\_azure\_backup\_retention\_daily\_count) | (Optional) The number of days Azure Recovery Services will retain the backup for. | `number` | `10` | no |
| <a name="input_cl_azure_backup_soft_delete_enabled"></a> [cl\_azure\_backup\_soft\_delete\_enabled](#input\_cl\_azure\_backup\_soft\_delete\_enabled) | (Optional) soft delete enable for this Vault | `bool` | `true` | no |
| <a name="input_cl_azure_backup_storage_type"></a> [cl\_azure\_backup\_storage\_type](#input\_cl\_azure\_backup\_storage\_type) | (Optional) The storage type of the Recovery Services Vault. Possible values are GeoRedundant, LocallyRedundant and ZoneRedundant | `string` | `"GeoRedundant"` | no |
| <a name="input_cl_azure_backup_time"></a> [cl\_azure\_backup\_time](#input\_cl\_azure\_backup\_time) | (Optional) The time of day to perform the backup in 24hour format. | `string` | `"23:00"` | no |
| <a name="input_cl_azure_backup_timezone"></a> [cl\_azure\_backup\_timezone](#input\_cl\_azure\_backup\_timezone) | Specifies the timezone for VM backup schedules. Defaults to `UTC`. | `string` | `"UTC"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_backup_blob_sa_backup_policy"></a> [cl\_azure\_backup\_blob\_sa\_backup\_policy](#output\_cl\_azure\_backup\_blob\_sa\_backup\_policy) | n/a |
| <a name="output_cl_azure_backup_blob_sa_backup_vault"></a> [cl\_azure\_backup\_blob\_sa\_backup\_vault](#output\_cl\_azure\_backup\_blob\_sa\_backup\_vault) | n/a |
| <a name="output_cl_azure_backup_diagnostic_setting"></a> [cl\_azure\_backup\_diagnostic\_setting](#output\_cl\_azure\_backup\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_backup_policy_fileshare"></a> [cl\_azure\_backup\_policy\_fileshare](#output\_cl\_azure\_backup\_policy\_fileshare) | n/a |
| <a name="output_cl_azure_backup_policy_vm"></a> [cl\_azure\_backup\_policy\_vm](#output\_cl\_azure\_backup\_policy\_vm) | n/a |
| <a name="output_cl_azure_backup_rg"></a> [cl\_azure\_backup\_rg](#output\_cl\_azure\_backup\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_backup_sv"></a> [cl\_azure\_backup\_sv](#output\_cl\_azure\_backup\_sv) | n/a |

## Usage
# Backups for VMs
```terraform
 // Azure Backup
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv       = true
  cl_azure_backup_enable_vm_backup = true
}
//**********************************************************************************************
```

# Backups for File Storage
```terraform
 // Azure Backup
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv                 = true
  cl_azure_backup_enable_file_storage_backup = true
}
//**********************************************************************************************
```

# Backups for Blob Storage
```terraform
 // Azure Backup
// IMPORTANT: Must assign the blob storage backup vault "Storage Account Backup Contributor" role on the blob storage account. 
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../dn-tads_tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_enable_blob_storage_backup = true
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
## Usage
```terraform
module "cl_azure_signalr" {
  source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_signalr"
  env                                                  = var.env
  postfix                                              = var.postfix
  suffix                                               = var.suffix
  location                                             = var.location
  cl_azure_signalr_postfix                             = var.cl_azure_signalr_postfix
  cl_azure_signalr_resource_group_name                 = var.cl_azure_signalr_resource_group_name
  cl_azure_signalr_service_mode                        = var.cl_azure_signalr_service_mode
  cl_azure_signalr_sku_name                            = var.cl_azure_signalr_sku_name
  cl_azure_signalr_sku_capacity                        = var.cl_azure_signalr_sku_capacity
  cl_azure_signalr_upstream_endpoint                   = {
    upstream1 = {
            category_pattern  = ["connections", "messages"]
            event_pattern     = ["*"]
            hub_pattern       = ["hub1"]
            url_template      = "http://foo.com"
    },
    upstream2 = {
            category_pattern  = ["connections", "messages"]
            event_pattern     = ["*"]
            hub_pattern       = ["hub2"]
            url_template      = "http://foo2.com"
    } 
  }
  cl_azure_signalr_allowed_origins                     = ["http://www.example.com"]
#   ## For the Newest Version of tf.
#   cl_azure_signalr_category_pattern                    = ["connections", "messages"]
#   cl_azure_signalr_event_pattern                       = ["*"]
#   cl_azure_signalr_hub_pattern                         = ["hub1"]
#   cl_azure_signalr_url_template                        = "http://foo.com"
  cl_azure_signalr_log_analytics_workspace_id          = var.cl_azure_signalr_log_analytics_workspace_id
  cl_azure_signalr_pe_subnet_ids                       = var.cl_azure_signalr_pe_subnet_ids
  cl_azure_signalr_private_dns_zone_id                 = var.cl_azure_signalr_private_dns_zone_id
  tags = var.tags
}
```
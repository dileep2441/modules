
## Usage with Private Endpoints (file share backup enabled)

```terraform

module "cl_datalake" {
    source                                 = "../dn-tads_tf-azure-component-library/components/cl_datalake_gov"
    env                                    = var.env
    postfix                                = var.postfix
    location                               = var.location
    suffix                                 = var.suffix
    tags                                         = var.tags
    cl_datalake_resource_group_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
    cl_datalake_allowed_pe_subnet_ids      = [azurerm_subnet.test_subnet.id]
    cl_datalake_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_datalake_file_share_enabled              = true
    cl_datalake_sa_file_shares                  = var.cl_datalake_sa_file_shares
    cl_datalake_sa_file_enable_backup           = true
    cl_datalake_sa_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_datalake_sa_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_datalake_sa_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
    cl_datalake_sa_backup_depends_on            = module.cl_azure_backup.cl_azure_backup_private_endpoint[0]
}
```


## Usage

### Deploy Web Jobs with VNet integration subnet
```terraform
//**********************************************************************************************
// Create the private link subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "private_link_subnet" {
    name                                            =  "${var.env}-${var.postfix}-private-link-sn"
    resource_group_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
    virtual_network_name                            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
    address_prefixes                                = ["10.0.75.0/27"]
    enforce_private_link_endpoint_network_policies  = true
    service_endpoints                               = ["Microsoft.ServiceBus","Microsoft.Storage","Microsoft.KeyVault","Microsoft.AzureActiveDirectory","Microsoft.AzureCosmosDB","Microsoft.Web"]
}
//********************************************************************************************** 

//********************************************************************************************** 
// Deploys Storage Account for webjobs
//**********************************************************************************************
module "cl_storage_account" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_storage_account_gov"
  env                                             = var.env
  postfix                                         = "${var.postfix}"
  location                                        = var.location
  suffix                                          = var.suffix
  tags                                            = var.tags
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.private_link_subnet.id]
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows KPMG addresses. need this for terraform to refresh current state
 }
//**********************************************************************************************


//**********************************************************************************************
// Create Service Plan for App Service
//**********************************************************************************************
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_app_service_plan_gov"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  tags                                                      = var.tags
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = ["10.0.75.64/26"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_app_service_plan_app_postfix                           = "ale" 
  cl_app_service_plan_os_type                               = "Windows"
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_storage_account_nsg_flow_log_id       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
}
//**********************************************************************************************

//**********************************************************************************************
// Create Web Jobs
//**********************************************************************************************
module "cl_web_jobs" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_web_jobs_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  suffix                                           = var.suffix
  tags                                             = var.tags
  cl_web_jobs_app_postfix                          = "web-jobs" 
  cl_web_jobs_integration_subnet_id                = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  cl_web_jobs_rg_name                              = module.cl_app_service_plan.cl_app_service_plan_rg.name
  cl_web_jobs_asp_id                               = module.cl_app_service_plan.cl_app_service_plan.id
  cl_web_jobs_sa_rg_name                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_web_jobs_sa_primary_key                       = module.cl_storage_account.cl_storage_account.primary_access_key
  cl_web_jobs_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_web_jobs_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_web_jobs_settings                             = {
    WEBSITE_DNS_SERVER            = "168.63.129.16"
    WEBSITE_VNET_ROUTE_ALL        = "1"
  }  
 }
//**********************************************************************************************
```
## Local values

```terraform
locals {
  timeout_duration                         = "2h"
  cl_storage_account_name_no_dash          = replace("${var.env}${var.postfix}${var.suffix}", "-", "")        
  cl_storage_account_blob_properties       = (var.cl_storage_account_kind == "FileStorage" || var.cl_storage_account_blob_enable_backup ? false : true)
  cl_storage_account_infra_encryption_enabled = (var.cl_storage_account_kind == "StorageV2" || (var.cl_storage_account_kind == "BlockBlobStorage" && var.cl_storage_account_tier == "Premium") ? true : false)
  cl_storage_account_replication_type      = (var.cl_storage_account_tier != "Premium" ? "GRS" : "LRS")
  cl_storage_account_queue_enabled         = (var.cl_storage_account_tier == "Standard" && var.cl_storage_account_kind != "BlobStorage" && var.cl_storage_account_queue_enabled ? true : false)
  cl_storage_account_table_enabled         = (var.cl_storage_account_tier == "Standard" && var.cl_storage_account_kind != "BlobStorage" && var.cl_storage_account_table_enabled ? true : false)
  cl_storage_account_replication_to_LRS    = (var.cl_storage_account_replication_override_LRS || var.env == "nprd-pr"  ? true : false ) 
  cl_storage_account_queue_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.usgovcloudapi.net"]
  }
  cl_storage_account_blob_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
  }
  cl_storage_account_file_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
  }
  cl_storage_account_table_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.usgovcloudapi.net"]
  }
  cl_storage_account_name = {
        "sbox-pr" = "sboxpr"
        "nprd-pr" = "nprdpr"
        "nprd-dr" = "nprddr"
        "prod-pr" = "prodpr"
        "prod-dr" = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```


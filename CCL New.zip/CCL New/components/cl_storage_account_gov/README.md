<!-- BEGIN_TF_DOCS -->

# Azure Storage Acccount Component

This is the Storage Account component. It will deploy Storage Account, Storage Files, Storage Queues, Monitor and Private Endpoint for Storage Account.

The following table describes the types of storage accounts, the services they support, and the supported deployment models for each account type:

Storage account type	                Supported services	                                    Supported performance tiers

General-purpose V2	                  Blob, File, Queue, Table, Disk, and Data Lake Gen22	    Standard, Premium

General-purpose V1	                  Blob, File, Queue, Table, and Disk	                    Standard, Premium

BlockBlobStorage                      Blob (block blobs and append blobs only)	              Premium 

FileStorage	                          File only	                                              Premium

BlobStorage	                          Blob (block blobs and append blobs only)	              Standard


Variables for enabled or disabled queue and file share creations into Storage account:

cl_storage_account_queue_enabled = true // Variable in true/false to enable or diabled queue creation

cl_storage_account_queue_monitor_enabled = false // Variable in true/false to enable or diabled monitor queue creation

cl_storage_account_share_enabled = true  // Variable in true/false to enable or diabled File share creation

For more information, please visit: https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.cl_advanced_threat_protection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_backup_container_storage_account.cl_storage_account_protection_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_container_storage_account) | resource |
| [azurerm_backup_protected_file_share.cl_storage_account_protected_fileshare](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_file_share) | resource |
| [azurerm_data_protection_backup_instance_blob_storage.cl_storage_account_protected_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_instance_blob_storage) | resource |
| [azurerm_monitor_diagnostic_setting.cl_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_storage_account_queue_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_storage_account_table_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_storage_account_file_share_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_storage_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_storage_account_queue_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_storage_account_table_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.cl_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.cl_storage_account_network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_storage_queue.cl_storage_account_queues](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_queue) | resource |
| [azurerm_storage_share.cl_storage_account_files](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_share) | resource |
| [azurerm_storage_table.cl_storage_account_tables](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_table) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_storage_account_access_tier"></a> [cl\_storage\_account\_access\_tier](#input\_cl\_storage\_account\_access\_tier) | (Optional) Defines the access tier for BlobStorage, FileStorage and StorageV2 accounts. Valid options are Hot and Cool | `any` | `null` | no |
| <a name="input_cl_storage_account_allow_nested_items_public_access"></a> [cl\_storage\_account\_allow\_nested\_items\_public\_access](#input\_cl\_storage\_account\_allow\_nested\_items\_public\_access) | (Optional) Allow or disallow nested items within this Account to opt into being public. | `bool` | `false` | no |
| <a name="input_cl_storage_account_allowed_ips"></a> [cl\_storage\_account\_allowed\_ips](#input\_cl\_storage\_account\_allowed\_ips) | (Optional) A list of Ip addresses that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_storage_account_allowed_pe_subnet_ids"></a> [cl\_storage\_account\_allowed\_pe\_subnet\_ids](#input\_cl\_storage\_account\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_storage_account_allowed_vnet_subnet_ids"></a> [cl\_storage\_account\_allowed\_vnet\_subnet\_ids](#input\_cl\_storage\_account\_allowed\_vnet\_subnet\_ids) | (Required) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_storage_account_backup_policy_fileshare_id"></a> [cl\_storage\_account\_backup\_policy\_fileshare\_id](#input\_cl\_storage\_account\_backup\_policy\_fileshare\_id) | (Optional) The azure file share backup policy from the recovery service vault. | `any` | `null` | no |
| <a name="input_cl_storage_account_blob_backup_policy_id"></a> [cl\_storage\_account\_blob\_backup\_policy\_id](#input\_cl\_storage\_account\_blob\_backup\_policy\_id) | The azure blob storage backup policy id from the backup vault. | `any` | `null` | no |
| <a name="input_cl_storage_account_blob_backup_vault"></a> [cl\_storage\_account\_blob\_backup\_vault](#input\_cl\_storage\_account\_blob\_backup\_vault) | The blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_storage_account_blob_backup_vault_id"></a> [cl\_storage\_account\_blob\_backup\_vault\_id](#input\_cl\_storage\_account\_blob\_backup\_vault\_id) | The id of blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_storage_account_blob_define_private_dns_zone_ids"></a> [cl\_storage\_account\_blob\_define\_private\_dns\_zone\_ids](#input\_cl\_storage\_account\_blob\_define\_private\_dns\_zone\_ids) | If local var centralized private dns zone is not available, pass in the dns zone id of what you'd like to use | `any` | `null` | no |
| <a name="input_cl_storage_account_blob_enable_backup"></a> [cl\_storage\_account\_blob\_enable\_backup](#input\_cl\_storage\_account\_blob\_enable\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_storage_account_blob_private_dns_zone_ids_exists"></a> [cl\_storage\_account\_blob\_private\_dns\_zone\_ids\_exists](#input\_cl\_storage\_account\_blob\_private\_dns\_zone\_ids\_exists) | Set to true if centralized private dns zone ids are available for use for blob SA | `bool` | `true` | no |
| <a name="input_cl_storage_account_blob_retention_days"></a> [cl\_storage\_account\_blob\_retention\_days](#input\_cl\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_storage_account_change_feed_enabled"></a> [cl\_storage\_account\_change\_feed\_enabled](#input\_cl\_storage\_account\_change\_feed\_enabled) | (Optional) Is the blob service properties for change feed events enabled? Default to false. | `bool` | `false` | no |
| <a name="input_cl_storage_account_default_action"></a> [cl\_storage\_account\_default\_action](#input\_cl\_storage\_account\_default\_action) | (Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow. | `string` | `"Deny"` | no |
| <a name="input_cl_storage_account_defender_enabled"></a> [cl\_storage\_account\_defender\_enabled](#input\_cl\_storage\_account\_defender\_enabled) | (Optional) If set to true, defender for storage is enabled. | `bool` | `false` | no |
| <a name="input_cl_storage_account_diagnostics"></a> [cl\_storage\_account\_diagnostics](#input\_cl\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_storage_account_diagnostics_queues"></a> [cl\_storage\_account\_diagnostics\_queues](#input\_cl\_storage\_account\_diagnostics\_queues) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "StorageRead",<br>    "StorageWrite",<br>    "StorageDelete"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_storage_account_diagnostics_tables"></a> [cl\_storage\_account\_diagnostics\_tables](#input\_cl\_storage\_account\_diagnostics\_tables) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "StorageRead",<br>    "StorageWrite",<br>    "StorageDelete"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_storage_account_enable_pe"></a> [cl\_storage\_account\_enable\_pe](#input\_cl\_storage\_account\_enable\_pe) | If set to true, enable private endpoints on storage account | `bool` | `true` | no |
| <a name="input_cl_storage_account_enable_sn_access"></a> [cl\_storage\_account\_enable\_sn\_access](#input\_cl\_storage\_account\_enable\_sn\_access) | If set to true, only allows specific subnets to access the storage account | `bool` | `true` | no |
| <a name="input_cl_storage_account_file_backup_depends_on"></a> [cl\_storage\_account\_file\_backup\_depends\_on](#input\_cl\_storage\_account\_file\_backup\_depends\_on) | (Optional) RSV private endpoint must be created first before file SA can have backup protection. This variabe should point to the RSV private endpoint | `any` | `null` | no |
| <a name="input_cl_storage_account_file_define_private_dns_zone_ids"></a> [cl\_storage\_account\_file\_define\_private\_dns\_zone\_ids](#input\_cl\_storage\_account\_file\_define\_private\_dns\_zone\_ids) | If local var centralized private dns zone is not available, pass in the dns zone id of what you'd like to use | `any` | `null` | no |
| <a name="input_cl_storage_account_file_enable_backup"></a> [cl\_storage\_account\_file\_enable\_backup](#input\_cl\_storage\_account\_file\_enable\_backup) | If set to true, enable file storage backup. | `bool` | `false` | no |
| <a name="input_cl_storage_account_file_private_dns_zone_ids_exists"></a> [cl\_storage\_account\_file\_private\_dns\_zone\_ids\_exists](#input\_cl\_storage\_account\_file\_private\_dns\_zone\_ids\_exists) | Set to true if centralized private dns zone ids are available for use for file SA | `bool` | `true` | no |
| <a name="input_cl_storage_account_file_share_access_tier"></a> [cl\_storage\_account\_file\_share\_access\_tier](#input\_cl\_storage\_account\_file\_share\_access\_tier) | (Optional) The access tier for the fileshare storage account. | `any` | `null` | no |
| <a name="input_cl_storage_account_file_shares"></a> [cl\_storage\_account\_file\_shares](#input\_cl\_storage\_account\_file\_shares) | (Optional) Array for the creation of multiple file shares. | <pre>map(object({<br>    name  = string<br>    quota  = number<br>  }))</pre> | `{}` | no |
| <a name="input_cl_storage_account_fileshare_ad_auth"></a> [cl\_storage\_account\_fileshare\_ad\_auth](#input\_cl\_storage\_account\_fileshare\_ad\_auth) | (Optional) Array for fileshare Active Directory Authentication | <pre>list(object({<br>    directory_type   = string<br>    active_directory = list(object({<br>      domain_guid  = string<br>      domain_name  = string<br>      domain_sid   = string<br>      forest_name  = string<br>      netbios_domain_name  = string<br>      storage_sid          = string<br>    }))<br>  }))</pre> | `[]` | no |
| <a name="input_cl_storage_account_kind"></a> [cl\_storage\_account\_kind](#input\_cl\_storage\_account\_kind) | (Optional)  Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. | `string` | `"StorageV2"` | no |
| <a name="input_cl_storage_account_large_file_share"></a> [cl\_storage\_account\_large\_file\_share](#input\_cl\_storage\_account\_large\_file\_share) | Is Large File Share Enabled? | `bool` | `false` | no |
| <a name="input_cl_storage_account_log_analytics_workspace_id"></a> [cl\_storage\_account\_log\_analytics\_workspace\_id](#input\_cl\_storage\_account\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_storage_account_malware_scanning_on_upload_cap_gb_per_month"></a> [cl\_storage\_account\_malware\_scanning\_on\_upload\_cap\_gb\_per\_month](#input\_cl\_storage\_account\_malware\_scanning\_on\_upload\_cap\_gb\_per\_month) | (Optional) The max GB to be scanned per Month. | `number` | `-1` | no |
| <a name="input_cl_storage_account_malware_scanning_on_upload_enabled"></a> [cl\_storage\_account\_malware\_scanning\_on\_upload\_enabled](#input\_cl\_storage\_account\_malware\_scanning\_on\_upload\_enabled) | (Optional) Whether On Upload malware scanning should be enabled. | `bool` | `false` | no |
| <a name="input_cl_storage_account_override_subscription_settings_enabled"></a> [cl\_storage\_account\_override\_subscription\_settings\_enabled](#input\_cl\_storage\_account\_override\_subscription\_settings\_enabled) | (Optional) Whether the settings defined for this storage account should override the settings defined for the subscription. | `bool` | `false` | no |
| <a name="input_cl_storage_account_postfix"></a> [cl\_storage\_account\_postfix](#input\_cl\_storage\_account\_postfix) | (Optional) A unique identifier for the storage account. Part of the naming scheme. | `string` | `""` | no |
| <a name="input_cl_storage_account_private_link_access"></a> [cl\_storage\_account\_private\_link\_access](#input\_cl\_storage\_account\_private\_link\_access) | (Optional) Array for private link access | <pre>list(object({<br>    endpoint_resource_id   = string<br>    endpoint_tenant_id     = string<br>  }))</pre> | `[]` | no |
| <a name="input_cl_storage_account_private_link_access_enabled"></a> [cl\_storage\_account\_private\_link\_access\_enabled](#input\_cl\_storage\_account\_private\_link\_access\_enabled) | set to true to enable private link access | `bool` | `false` | no |
| <a name="input_cl_storage_account_queue_define_private_dns_zone_ids"></a> [cl\_storage\_account\_queue\_define\_private\_dns\_zone\_ids](#input\_cl\_storage\_account\_queue\_define\_private\_dns\_zone\_ids) | If local var centralized private dns zone is not available, pass in the dns zone id of what you'd like to use | `any` | `null` | no |
| <a name="input_cl_storage_account_queue_enabled"></a> [cl\_storage\_account\_queue\_enabled](#input\_cl\_storage\_account\_queue\_enabled) | (Optional) If set to true, create queues | `bool` | `false` | no |
| <a name="input_cl_storage_account_queue_monitor_enabled"></a> [cl\_storage\_account\_queue\_monitor\_enabled](#input\_cl\_storage\_account\_queue\_monitor\_enabled) | (Optional) If set to true, create monitor queues | `bool` | `false` | no |
| <a name="input_cl_storage_account_queue_private_dns_zone_ids_exists"></a> [cl\_storage\_account\_queue\_private\_dns\_zone\_ids\_exists](#input\_cl\_storage\_account\_queue\_private\_dns\_zone\_ids\_exists) | Set to true if centralized private dns zone ids are available for use for queue SA | `bool` | `true` | no |
| <a name="input_cl_storage_account_queues"></a> [cl\_storage\_account\_queues](#input\_cl\_storage\_account\_queues) | List of storages queue names. | `list(string)` | <pre>[<br>  "queue",<br>  "queue1"<br>]</pre> | no |
| <a name="input_cl_storage_account_recovery_vault_name"></a> [cl\_storage\_account\_recovery\_vault\_name](#input\_cl\_storage\_account\_recovery\_vault\_name) | (Optional) The name of backup recovery service vault. | `any` | `null` | no |
| <a name="input_cl_storage_account_replication_override_LRS"></a> [cl\_storage\_account\_replication\_override\_LRS](#input\_cl\_storage\_account\_replication\_override\_LRS) | If set to true, it overrides the replication to LRS | `bool` | `false` | no |
| <a name="input_cl_storage_account_resource_group_name"></a> [cl\_storage\_account\_resource\_group\_name](#input\_cl\_storage\_account\_resource\_group\_name) | (Required) The name of the resource group where the storage account will be deployed to. | `any` | n/a | yes |
| <a name="input_cl_storage_account_rg_backup_name"></a> [cl\_storage\_account\_rg\_backup\_name](#input\_cl\_storage\_account\_rg\_backup\_name) | (Optional) The RG destination of the azure file share backup. | `any` | `null` | no |
| <a name="input_cl_storage_account_sensitive_data_discovery_enabled"></a> [cl\_storage\_account\_sensitive\_data\_discovery\_enabled](#input\_cl\_storage\_account\_sensitive\_data\_discovery\_enabled) | (Optional) Whether Sensitive Data Discovery should be enabled. | `bool` | `false` | no |
| <a name="input_cl_storage_account_share_ad_auth_enabled"></a> [cl\_storage\_account\_share\_ad\_auth\_enabled](#input\_cl\_storage\_account\_share\_ad\_auth\_enabled) | If set to true, enable file share AD configuration | `bool` | `false` | no |
| <a name="input_cl_storage_account_share_enabled"></a> [cl\_storage\_account\_share\_enabled](#input\_cl\_storage\_account\_share\_enabled) | If set to true, enable file shares | `bool` | `false` | no |
| <a name="input_cl_storage_account_table_define_private_dns_zone_ids"></a> [cl\_storage\_account\_table\_define\_private\_dns\_zone\_ids](#input\_cl\_storage\_account\_table\_define\_private\_dns\_zone\_ids) | If local var centralized private dns zone is not available, pass in the dns zone id of what you'd like to use | `any` | `null` | no |
| <a name="input_cl_storage_account_table_enabled"></a> [cl\_storage\_account\_table\_enabled](#input\_cl\_storage\_account\_table\_enabled) | (Optional) If set to true, create tables | `bool` | `false` | no |
| <a name="input_cl_storage_account_table_monitor_enabled"></a> [cl\_storage\_account\_table\_monitor\_enabled](#input\_cl\_storage\_account\_table\_monitor\_enabled) | (Optional) If set to true, create monitor tables | `bool` | `false` | no |
| <a name="input_cl_storage_account_table_private_dns_zone_ids_exists"></a> [cl\_storage\_account\_table\_private\_dns\_zone\_ids\_exists](#input\_cl\_storage\_account\_table\_private\_dns\_zone\_ids\_exists) | Set to true if centralized private dns zone ids are available for use for table SA | `bool` | `true` | no |
| <a name="input_cl_storage_account_tables"></a> [cl\_storage\_account\_tables](#input\_cl\_storage\_account\_tables) | List of storages table names. | `list(string)` | `[]` | no |
| <a name="input_cl_storage_account_tier"></a> [cl\_storage\_account\_tier](#input\_cl\_storage\_account\_tier) | (Optional) The pricing tier for the storage account. | `string` | `"Standard"` | no |
| <a name="input_cl_storage_account_tls_version"></a> [cl\_storage\_account\_tls\_version](#input\_cl\_storage\_account\_tls\_version) | (Optional) The minimum supported TLS version for the storage account. Possible values are TLS1\_0, TLS1\_1, and TLS1\_2. | `string` | `"TLS1_2"` | no |
| <a name="input_cl_storage_account_versioning_enabled"></a> [cl\_storage\_account\_versioning\_enabled](#input\_cl\_storage\_account\_versioning\_enabled) | (Optional) Is versioning enabled? Default to false. | `bool` | `false` | no |
| <a name="input_cors_rule"></a> [cors\_rule](#input\_cors\_rule) | CORS rules for queue storage account. | <pre>list(object({<br>	    allowed_origins    = list(string),<br>	    allowed_methods    = list(string),<br>	    allowed_headers    = list(string),<br>	    exposed_headers    = list(string),<br>	    max_age_in_seconds = string<br>	  }))</pre> | `[]` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration                         = "2h"
  cl_storage_account_name_no_dash          = replace("${var.env}${var.postfix}${var.suffix}", "-", "")        
  cl_storage_account_blob_properties       = (var.cl_storage_account_kind == "FileStorage" || var.cl_storage_account_blob_enable_backup ? false : true)
  cl_storage_account_infra_encryption_enabled = (var.cl_storage_account_kind == "StorageV2" || (var.cl_storage_account_kind == "BlockBlobStorage" && var.cl_storage_account_tier == "Premium") ? true : false)
  cl_storage_account_replication_type      = (var.cl_storage_account_tier != "Premium" ? "GRS" : "LRS")
  cl_storage_account_queue_enabled         = (var.cl_storage_account_tier == "Standard" && var.cl_storage_account_kind != "BlobStorage" && var.cl_storage_account_queue_enabled ? true : false)
  cl_storage_account_table_enabled         = (var.cl_storage_account_tier == "Standard" && var.cl_storage_account_kind != "BlobStorage" && var.cl_storage_account_table_enabled ? true : false)
  cl_storage_account_replication_to_LRS    = (var.cl_storage_account_replication_override_LRS || var.env == "nprd-pr"  ? true : false ) 
  cl_storage_account_queue_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.queue.core.usgovcloudapi.net"]
  }
  cl_storage_account_blob_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.usgovcloudapi.net"]
  }
  cl_storage_account_file_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.file.core.usgovcloudapi.net"]
  }
  cl_storage_account_table_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.table.core.usgovcloudapi.net"]
  }
  cl_storage_account_name = {
        "sbox-pr" = "sboxpr"
        "nprd-pr" = "nprdpr"
        "nprd-dr" = "nprddr"
        "prod-pr" = "prodpr"
        "prod-dr" = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_advanced_threat_protection"></a> [cl\_advanced\_threat\_protection](#output\_cl\_advanced\_threat\_protection) | n/a |
| <a name="output_cl_storage_account"></a> [cl\_storage\_account](#output\_cl\_storage\_account) | Outputs ********************************************************************************************** |
| <a name="output_cl_storage_account_diagnostic_setting"></a> [cl\_storage\_account\_diagnostic\_setting](#output\_cl\_storage\_account\_diagnostic\_setting) | n/a |
| <a name="output_cl_storage_account_file_share_private_endpoint"></a> [cl\_storage\_account\_file\_share\_private\_endpoint](#output\_cl\_storage\_account\_file\_share\_private\_endpoint) | n/a |
| <a name="output_cl_storage_account_files"></a> [cl\_storage\_account\_files](#output\_cl\_storage\_account\_files) | n/a |
| <a name="output_cl_storage_account_id"></a> [cl\_storage\_account\_id](#output\_cl\_storage\_account\_id) | n/a |
| <a name="output_cl_storage_account_network_rules"></a> [cl\_storage\_account\_network\_rules](#output\_cl\_storage\_account\_network\_rules) | n/a |
| <a name="output_cl_storage_account_private_endpoint"></a> [cl\_storage\_account\_private\_endpoint](#output\_cl\_storage\_account\_private\_endpoint) | n/a |
| <a name="output_cl_storage_account_protected_blob"></a> [cl\_storage\_account\_protected\_blob](#output\_cl\_storage\_account\_protected\_blob) | n/a |
| <a name="output_cl_storage_account_protected_fileshare"></a> [cl\_storage\_account\_protected\_fileshare](#output\_cl\_storage\_account\_protected\_fileshare) | n/a |
| <a name="output_cl_storage_account_protection_container"></a> [cl\_storage\_account\_protection\_container](#output\_cl\_storage\_account\_protection\_container) | n/a |
| <a name="output_cl_storage_account_queue_diagnostic_setting"></a> [cl\_storage\_account\_queue\_diagnostic\_setting](#output\_cl\_storage\_account\_queue\_diagnostic\_setting) | n/a |
| <a name="output_cl_storage_account_queue_private_endpoint"></a> [cl\_storage\_account\_queue\_private\_endpoint](#output\_cl\_storage\_account\_queue\_private\_endpoint) | n/a |
| <a name="output_cl_storage_account_queues"></a> [cl\_storage\_account\_queues](#output\_cl\_storage\_account\_queues) | n/a |


## Usage
#### Normal Usage (Blob Storage Backup Enabled)
```terraform
//**********************************************************************************************
// IMPORTANT: Must assign the blob storage backup vault "Storage Account Backup Contributor" role on the blob storage account. 
// https://docs.microsoft.com/en-us/azure/backup/blob-backup-configure-manage#grant-permissions-to-the-backup-vault-on-storage-accounts 

// NOTE: Please ensure spoke vnet peering to identity vnet, and spoke reader and private dns zone contributor role over identity subscription (to leverage private dns zones)
//**********************************************************************************************
module "cl_storage_account" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_storage_account_gov"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  suffix                                          = var.suffix
  tags                                            = var.tags
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.web_subnet.id]
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]  
  cl_storage_account_blob_enable_backup           = true
  cl_storage_account_blob_backup_vault_id         = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_storage_account_blob_backup_vault            = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_storage_account_blob_backup_policy_id        = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  }
```

#### For File Share (File Storage Backup Enabled)
```terraform
module "cl_storage_account" {
    source                                          = "../dn-tads_tf-azure-component-library/components/cl_storage_account_gov"
    env                                             = var.env
    postfix                                         = var.postfix
    location                                        = var.location
    suffix                                          = var.suffix
    tags                                            = var.tags
    cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name 
    cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.web_subnet.id]
    cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]
    cl_storage_account_share_enabled                = true
    cl_storage_account_file_shares                  = var.cl_storage_account_file_shares
    cl_storage_account_file_enable_backup           = true
    cl_storage_account_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_storage_account_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_storage_account_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
    cl_storage_account_file_backup_depends_on       = module.cl_azure_backup.cl_azure_backup_private_endpoint[0]
    cl_storage_account_large_file_share             = true
    cl_storage_account_tier                         = "Premium"
    cl_storage_account_kind                         = "FileStorage"
}
```
#### For Azure Queue Storage
```terraform
module "cl_storage_account" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_storage_account_gov"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  suffix                                          = var.suffix
  tags                                            = var.tags
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]  
  cl_storage_account_queue_enabled                = true
  cl_storage_account_queue_monitor_enabled        = false
}
```
#### For Azure Queue Storage and File Share (File Storage Backup Enabled)
```terraform
module "cl_storage_account" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_storage_account_gov"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  suffix                                          = var.suffix
  tags                                            = var.tags
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
  cl_storage_account_share_enabled                = true
  cl_storage_account_file_shares                  = var.cl_storage_account_file_shares
  cl_storage_account_file_enable_backup           = true
  cl_storage_account_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_storage_account_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_storage_account_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
  cl_storage_account_tier                         = "Standard"
  cl_storage_account_kind                         = "StorageV2"
  cl_storage_account_queue_enabled                = true
  cl_storage_account_queue_monitor_enabled        = true
  }
```
<!-- END_TF_DOCS -->
## Usage

```terraform

// ADI code starts from here *********************************************************************

// Azure Application Insights
//**********************************************************************************************
module "cl_app_insights" {
  source                              = "../dn-tads_tf-azure-component-library/components/cl_app_insights"
  env                                 = var.env
  postfix                             = var.postfix
  location                            = var.location
  cl_app_insights_resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_app_insights_application_type    = "web"
  cl_app_insights_content                      = "requests //simple example query"
  cl_app_insights_scope                        = "shared"
  cl_app_insights_type                         = "query"
  cl_app_insights_web_test_kind                = "ping"
  cl_app_insights_web_test            = {
    web_test = {
     frequency                    = 300
      timeout                     = 60
      enabled                     = true
      geo_locations               = ["us-tx-sn1-azr", "us-il-ch1-azr"]
      test_method = "GET"
      test_url = "http://xxxxxxxx"
      test_response_code = 200
    }
  }
 }
//************************************************************************************************************************
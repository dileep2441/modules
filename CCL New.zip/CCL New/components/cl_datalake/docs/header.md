# Azure Data Lake Component

Azure Data Lake Storage is an enterprise-wide hyper-scale repository for big data analytic workloads. 
It enables you to capture data of any size, type, and ingestion speed in one single place for operational and exploratory analytics.
This component will deploy a ADLS, private endpoint, azure diagnostics, and configures the storage account with Azure Defender.

For more information, please visit: https://docs.microsoft.com/en-us/azure/data-lake-store/data-lake-store-overview 

# Azure Kubernetes service Component

Azure Kubernetes Service (AKS) simplifies deploying a managed Kubernetes cluster in Azure by offloading the operational overhead to Azure. 
As a hosted Kubernetes service, Azure handles critical tasks, like health monitoring and maintenance. 
Since Kubernetes masters are managed by Azure, you only manage and maintain the agent nodes. 
Thus, AKS is free; you only pay for the agent nodes within your clusters, not for the masters.

For more information, please visit: https://docs.microsoft.com/en-us/azure/aks/intro-kubernetes 

```terraform
1. Azure Kubernetes Cluster Egress Traffic UDR Prerequisites:

* Create the following firewall rules with source vnet aks node pool - Restrict egress traffic in Azure Kubernetes Service (AKS) - https://docs.microsoft.com/en-us/azure/aks/limit-egress-traffic

   * *:123 or ntp.ubuntu.com:123 - Required for Network Time Protocol (NTP) time synchronization on Linux nodes.
   * CustomDNSIP:53 - If you're using custom DNS servers, you must ensure they're accessible by the cluster nodes.
   * *.hcp.<location>.azmk8s.io: HTTPS 443 - Required for Node <-> API server communication. Replace <location> with the region where your AKS cluster is deployed.
   * mcr.microsoft.com: HTTPS 443 - Required to access images in Microsoft Container Registry (MCR). This registry contains first-party images/charts (for example, coreDNS, etc.). These images are required for the correct creation and functioning of the cluster, including scale and upgrade operations.
   * *.data.mcr.microsoft.com: HTTPS 443 - Required for MCR storage backed by the Azure content delivery network (CDN).
   * management.azure.com: HTTPS 443 - Required for Kubernetes operations against the Azure API.
   * login.microsoftonline.com: HTTPS 443 - Required for Azure Active Directory authentication.
   * packages.microsoft.com: HTTPS 443 - This address is the Microsoft packages repository used for cached apt-get operations. Example packages include Moby, PowerShell, and Azure CLI.
   * acs-mirror.azureedge.net: HTTPS 443 - This address is for the repository required to download and install required binaries like kubenet and Azure CNI.
   * nvidia.github.io: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * us.download.nvidia.com: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * apt.dockerproject.org: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * ServiceTag - AzureMonitor: HTTPS 443 - This endpoint is used to send metrics data and logs to Azure Monitor and Log Analytics.
   * dc.services.visualstudio.com: HTTPS 443 - This endpoint is used for metrics and monitoring telemetry using Azure Monitor.
   * *.ods.opinsights.azure.com: HTTPS 443 - This endpoint is used by Azure Monitor for ingesting log analytics data.
   * *.oms.opinsights.azure.com: HTTPS 443 - This endpoint is used by omsagent, which is used to authenticate the log analytics service.
   * *.monitoring.azure.com:	HTTPS 443 - This endpoint is used to send metrics data to Azure Monitor.
   * data.policy.core.windows.net: HTTPS 443 - This address is used to pull the Kubernetes policies and to report cluster compliance status to policy service.
   * store.policy.core.windows.net: HTTPS 443 - This address is used to pull the Gatekeeper artifacts of built-in policies.
   * dc.services.visualstudio.com: HTTPS 443 - Azure Policy add-on that sends telemetry data to applications insights endpoint.
   * motd.ubuntu.com:  HTTPS 443 - is a package that makes a call periodically to Canonical servers to get updated news for support and informational purposes.
   * optional rule windows server node pool: HTTPS 443 - onegetcdn.azureedge.net, go.microsoft.com - To install windows-related binaries
   * optional rule windows server node pool: HTTP 80 - *.mp.microsoft.com, www.msftconnecttest.com, ctldl.windowsupdate.com - To install windows-related binaries
   * optional rules: HTTP 80 - security.ubuntu.com, azure.archive.ubuntu.com, changelogs.ubuntu.com - This address lets the Linux cluster nodes download the required security patches and updates.

2. Azure Kubernetes service Component will deploy the following resources:

* Resource Group for Azure Kubernetes Cluster - Optional resource creation
* Private Kubernetes Cluster - A private cluster uses an internal IP address to ensure that network traffic between the API server and node pools remains on a private network only.
* Resource Group Node Pool with the following components
   * Kubelet Managed Indentity
   * Ingress Application Gateway Managed Identity
   * Azure Policy Managed Identity
   * Oms Agent Managed Identity
   * Private endpoint
   * Private DNS zone
   * Kube Api server Network interface subnet node pool
   * Network security group
* Log Analytics Solution
* Monitor Diagnostic Settings - "kube-apiserver","kube-audit","kube-audit-admin","kube-controller-manager","kube-scheduler","cluster-autoscaler","guard"

3. Azure Kubernetes service Component will deploy the resources with the following Configurations:

* Private Cluster Enabled
* Egress traffic userDefinedRouting (UDR)
* Local Account Disabled
* Public fqdn Disabled
* Manage Identity SystemAssigned
* RBAC &  AAD Enabled
* Network Plugins Azure CNI
* Network Policy Azure
* Add-on ingress_application_gateway Enabled
* Add-on oms_agent Enabled 
* Add-onh http application routing Disabled
* Add-on kube_dashboard Disabled
* Default Node Pool Public Ip Disabled
* Default Node Pool only critical addons Enabled
```
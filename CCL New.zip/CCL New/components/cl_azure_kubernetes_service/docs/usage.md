## Usage Azure Kubernetes private cluster integrated with a private Azure Container Registry and add-on AGIC Application Gateway

```terraform

resource "azurerm_subnet" "cl_azure_kubernetes_nodes_subnet" {
  name                                                   = "${var.env}-${var.postfix}-aks-nodes-sn"
  resource_group_name                                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                                   = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                       = ["10.66.0.0/20"]
  enforce_private_link_endpoint_network_policies         = true
  service_endpoints                                      = ["Microsoft.ContainerRegistry","Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.KeyVault"]
}

resource "azurerm_subnet" "private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                   = ["10.66.18.0/24"]
  enforce_private_link_endpoint_network_policies     = true
  service_endpoints                                  = ["Microsoft.ContainerRegistry"]
}

module "cl_azure_container_registry" {
    source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
    cl_azure_container_registry_postfix                         = var.cl_azure_container_registry_postfix
    cl_azure_container_registry_rg_name                         = module.cl_azure_kubernetes_service.cl_kubernetes_rg[0].name
    cl_azure_container_registry_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_content_trust_enabled           = true
    cl_azure_container_registry_admin_enabled                   = false
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
    cl_azure_container_registry_allowed_vnet_ids                = [data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id]
    cl_azure_container_registry_allowed_subnets                 = [azurerm_subnet.private_endpoint_subnet.id]
    cl_azure_container_registry_public_network_access_enabled   = false
}

module "cl_app_gateway" {
  source                                      = "../dn-tads_tf-azure-component-library/components/cl_application_gateway"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  set_private_ip_listener                     = false
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["10.66.17.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
}

module "cl_azure_kubernetes_service"{
   source                                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_kubernetes_service"
   env                                                                  = var.env
   postfix                                                              = var.postfix
   location                                                             = var.location
   cl_kubernetes_deploy_rg                                              = true
   cl_kubernetes_postfix                                                = "demo"
   cl_kubernetes_kubernetes_version                                     = "1.20.9"
   cl_kubernetes_private_cluster_enabled                                = true
   cl_kubernetes_dns_prefix                                             = "${var.env}-${var.postfix}-aks-dns"
   cl_kubernetes_latam_rt                                               = true/false #true add route to LATAM and false add route to US
   cl_kubernetes_default_node_pool_node_count                           = 3
   cl_kubernetes_default_node_pool_vm_size                              = "Standard_D4ds_v4" 
   cl_kubernetes_default_node_pool_type                                 = "VirtualMachineScaleSets"
   cl_kubernetes_default_node_pool_availability_zones                   = [1]
   cl_kubernetes_default_node_pool_enable_auto_scaling                  = true
   cl_kubernetes_default_node_pool_min_count                            = 1
   cl_kubernetes_default_node_pool_max_count                            = 5
   cl_kubernetes_default_node_pool_upgrade_max_surge                    = "33%"
   cl_kubernetes_default_node_pool_vnet_subnet_id                       = azurerm_subnet.cl_azure_kubernetes_nodes_subnet.id  
   cl_kubernetes_network_profile_service_cidr                           = "10.0.0.0/16"
   cl_kubernetes_network_profile_dns_service_ip                         = "10.0.0.12"
   cl_kubernetes_network_profile_docker_bridge_cidr                     = "172.17.0.1/16"
   cl_kubernetes_logging_rg_name                                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
   cl_kubernetes_log_analytics_workspace_id                             = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_kubernetes_log_analytics_workspace_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
   cl_kubernetes_identity_type                                          = "SystemAssigned"
   cl_kubernetes_addon_profile_ingress_application_gateway_enabled      = true
   cl_kubernetes_addon_profile_ingress_application_gateway_id           = module.cl_app_gateway.cl_app_gateway.id
   cl_kubernetes_addon_profile_azure_policy_enabled                     = true
   cl_kubernetes_rbac_aad_managed                                       = true
   cl_kubernetes_route_table_subnet                                     = azurerm_subnet.cl_azure_kubernetes_nodes_subnet.id  
   cl_kubernetes_rt_resource_group_name                                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

module "cl_azure_kubernetes_service_node_pool"{
   source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_kubernetes_service_node_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_kubernetes_node_pool_name                         = "internal"
   cl_kubernetes_node_pool_kubernetes_cluster_id        =  module.cl_azure_kubernetes_service.cl_kubernetes_id
   cl_kubernetes_node_pool_vm_size                      = "Standard_B2s"
   cl_kubernetes_node_pool_availability_zones           = [1]
   cl_kubernetes_node_pool_os_disk_size_gb              = 256
   cl_kubernetes_node_pool_enable_auto_scaling          = true
   cl_kubernetes_node_pool_enable_host_encryption       = false
   cl_kubernetes_node_pool_enable_node_public_ip        = false
   cl_kubernetes_node_pool_os_disk_type                 = "Managed"
   cl_kubernetes_node_pool_os_sku                       = "Ubuntu"
   cl_kubernetes_node_pool_os_type                      = "Linux"
   cl_kubernetes_node_pool_mode                         = "User"
   cl_kubernetes_node_pool_node_count                   = 3
   cl_kubernetes_node_pool_max_count                    = 5
   cl_kubernetes_node_pool_min_count                    = 1
   cl_kubernetes_node_pool_max_pods                     = 110
   cl_kubernetes_node_pool_max_surge                    = "33%"
   cl_kubernetes_node_pool_priority                     = "Regular"
}
```
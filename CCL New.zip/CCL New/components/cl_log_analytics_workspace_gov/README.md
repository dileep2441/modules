<!-- BEGIN_TF_DOCS -->

# Azure Log Analytics

A Log Analytics workspace is a unique environment for log data from Azure Monitor and other Azure services such as Microsoft Sentinel and Microsoft Defender for Cloud. 
Each workspace has its own data repository and configuration but may combine data from multiple services.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-workspace-overview 




## Resources

| Name | Type |
|------|------|
| [azurerm_log_analytics_datasource_windows_performance_counter.cl_log_analytics_workspace_performance_counters](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_datasource_windows_performance_counter) | resource |
| [azurerm_log_analytics_workspace.cl_log_analytics_workspace](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace) | resource |
| [azurerm_monitor_diagnostic_setting.cl_log_analytics_workspace_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_subscription_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_log_analytics_internet_ingestion_enabled"></a> [cl\_log\_analytics\_internet\_ingestion\_enabled](#input\_cl\_log\_analytics\_internet\_ingestion\_enabled) | (Optional) Should the Log Analytics Workspace support ingestion over the Public Internet? Defaults to true. | `bool` | `false` | no |
| <a name="input_cl_log_analytics_internet_query_enabled"></a> [cl\_log\_analytics\_internet\_query\_enabled](#input\_cl\_log\_analytics\_internet\_query\_enabled) | (Optional) Should the Log Analytics Workspace support querying over the Public Internet? Defaults to true. | `bool` | `true` | no |
| <a name="input_cl_log_analytics_logging_rg_name"></a> [cl\_log\_analytics\_logging\_rg\_name](#input\_cl\_log\_analytics\_logging\_rg\_name) | (Required) The name of the logging resource group that log analytics workspace will be created in. | `any` | n/a | yes |
| <a name="input_cl_log_analytics_subscription_diagnostics_settings"></a> [cl\_log\_analytics\_subscription\_diagnostics\_settings](#input\_cl\_log\_analytics\_subscription\_diagnostics\_settings) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "Administrative",<br>    "Security",<br>    "ServiceHealth",<br>    "Alert",<br>    "Recommendation",<br>    "Policy",<br>    "Autoscale",<br>    "ResourceHealth"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_log_analytics_workspace_count_performance_counters"></a> [cl\_log\_analytics\_workspace\_count\_performance\_counters](#input\_cl\_log\_analytics\_workspace\_count\_performance\_counters) | n/a | `number` | `46` | no |
| <a name="input_cl_log_analytics_workspace_diagnostics_settings"></a> [cl\_log\_analytics\_workspace\_diagnostics\_settings](#input\_cl\_log\_analytics\_workspace\_diagnostics\_settings) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "Audit"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_log_analytics_workspace_performance_counters"></a> [cl\_log\_analytics\_workspace\_performance\_counters](#input\_cl\_log\_analytics\_workspace\_performance\_counters) | n/a | `list(string)` | <pre>[<br>  "\\Processor Information(_Total)\\% Processor Time",<br>  "\\System\\Processor Queue Length",<br>  "\\Memory\\% Committed Bytes In Use",<br>  "\\Memory\\Available Bytes",<br>  "\\LogicalDisk(_Total)\\Disk Transfers/sec",<br>  "\\LogicalDisk(_Total)\\Disk Reads/sec",<br>  "\\LogicalDisk(_Total)\\Disk Writes/sec",<br>  "\\LogicalDisk(_Total)\\Avg. Disk sec/Read",<br>  "\\LogicalDisk(_Total)\\Avg. Disk sec/Write",<br>  "\\LogicalDisk(_Total)\\Avg. Disk Queue Length",<br>  "\\LogicalDisk(_Total)\\% Free Space",<br>  "\\LogicalDisk(_Total)\\Free Megabytes",<br>  "\\Network Interface(*)\\Bytes Total/sec",<br>  "\\Network Interface(*)\\Bytes Sent/sec",<br>  "\\Network Interface(*)\\Bytes Received/sec",<br>  "\\Processor Information(_Total)\\% Privileged Time",<br>  "\\Processor Information(_Total)\\% User Time",<br>  "\\Processor Information(_Total)\\Processor Frequency",<br>  "\\System\\Processes",<br>  "\\Process(_Total)\\Thread Count",<br>  "\\Process(_Total)\\Handle Count",<br>  "\\System\\System Up Time",<br>  "\\System\\Context Switches/sec",<br>  "\\Memory\\Committed Bytes",<br>  "\\Memory\\Cache Bytes",<br>  "\\Memory\\Pool Paged Bytes",<br>  "\\Memory\\Pool Nonpaged Bytes",<br>  "\\Memory\\Pages/sec",<br>  "\\Memory\\Page Faults/sec",<br>  "\\Process(_Total)\\Working Set",<br>  "\\Process(_Total)\\Working Set - Private",<br>  "\\LogicalDisk(_Total)\\% Disk Time",<br>  "\\LogicalDisk(_Total)\\% Disk Read Time",<br>  "\\LogicalDisk(_Total)\\% Disk Write Time",<br>  "\\LogicalDisk(_Total)\\% Idle Time",<br>  "\\LogicalDisk(_Total)\\Disk Bytes/sec",<br>  "\\LogicalDisk(_Total)\\Disk Read Bytes/sec",<br>  "\\LogicalDisk(_Total)\\Disk Write Bytes/sec",<br>  "\\LogicalDisk(_Total)\\Avg. Disk sec/Transfer",<br>  "\\LogicalDisk(_Total)\\Avg. Disk Read Queue Length",<br>  "\\LogicalDisk(_Total)\\Avg. Disk Write Queue Length",<br>  "\\Network Interface(*)\\Packets/sec",<br>  "\\Network Interface(*)\\Packets Sent/sec",<br>  "\\Network Interface(*)\\Packets Received/sec",<br>  "\\Network Interface(*)\\Packets Outbound Errors",<br>  "\\Network Interface(*)\\Packets Received Errors"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_log_analytics_workspace"></a> [cl\_log\_analytics\_workspace](#output\_cl\_log\_analytics\_workspace) | Outputs ********************************************************************************************** |
| <a name="output_cl_log_analytics_workspace_diagnostic_settings"></a> [cl\_log\_analytics\_workspace\_diagnostic\_settings](#output\_cl\_log\_analytics\_workspace\_diagnostic\_settings) | n/a |
| <a name="output_cl_subscription_diagnostic_settings"></a> [cl\_subscription\_diagnostic\_settings](#output\_cl\_subscription\_diagnostic\_settings) | n/a |



## Usage
#### Log Analytics workspace
```terraform

#IMPORTANT - Since the AMPLS is a centralized service in shared services, its required to use a provider to access the AMPLS name (not resource ID). 
# azurerm.shs_us, local.core_sharedsvcs_us_logging_rg & local.core_sharedsvcs_us_log_analytics_private_link_scope_name are already defined in nebula framework.
resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_us
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_us_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_us_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
}

module "cl_log_analytics_workspace" {
    source                                                              = "../dn-tads_tf-azure-component-library/components/cl_log_analytics_workspace_gov"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    cl_log_analytics_logging_rg_name                                    = var.cl_log_analytics_logging_rg_name  
    tags                                                                = var.tags
}
```
<!-- END_TF_DOCS -->
# Azure Log Analytics

A Log Analytics workspace is a unique environment for log data from Azure Monitor and other Azure services such as Microsoft Sentinel and Microsoft Defender for Cloud. 
Each workspace has its own data repository and configuration but may combine data from multiple services.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-workspace-overview 


<!-- BEGIN_TF_DOCS -->

# Azure Log Analytics

A Log Analytics workspace is a unique environment for log data from Azure Monitor and other Azure services such as Microsoft Sentinel and Microsoft Defender for Cloud. 
Each workspace has its own data repository and configuration but may combine data from multiple services.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-workspace-overview 



## Resources

| Name | Type |
|------|------|
| [azurerm_log_analytics_workspace.cl_log_analytics_workspace](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace) | resource |
| [azurerm_monitor_diagnostic_setting.cl_log_analytics_workspace_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_subscription_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_log_analytics_allow_resource_only_permissions"></a> [cl\_log\_analytics\_allow\_resource\_only\_permissions](#input\_cl\_log\_analytics\_allow\_resource\_only\_permissions) | (Optional) Specifies if the log Analytics Workspace allow users accessing to data associated with resources they have permission to view, without permission to workspace. Defaults to true. | `bool` | `false` | no |
| <a name="input_cl_log_analytics_internet_ingestion_enabled"></a> [cl\_log\_analytics\_internet\_ingestion\_enabled](#input\_cl\_log\_analytics\_internet\_ingestion\_enabled) | (Optional) Should the Log Analytics Workspace support ingestion over the Public Internet? Defaults to true. | `bool` | `false` | no |
| <a name="input_cl_log_analytics_internet_query_enabled"></a> [cl\_log\_analytics\_internet\_query\_enabled](#input\_cl\_log\_analytics\_internet\_query\_enabled) | (Optional) Should the Log Analytics Workspace support querying over the Public Internet? Defaults to true. | `bool` | `true` | no |
| <a name="input_cl_log_analytics_logging_rg_name"></a> [cl\_log\_analytics\_logging\_rg\_name](#input\_cl\_log\_analytics\_logging\_rg\_name) | (Required) The name of the logging resource group that log analytics workspace will be created in. | `any` | n/a | yes |
| <a name="input_cl_log_analytics_subscription_diagnostics_settings"></a> [cl\_log\_analytics\_subscription\_diagnostics\_settings](#input\_cl\_log\_analytics\_subscription\_diagnostics\_settings) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "Administrative",<br>    "Security",<br>    "ServiceHealth",<br>    "Alert",<br>    "Recommendation",<br>    "Policy",<br>    "Autoscale",<br>    "ResourceHealth"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_log_analytics_workspace_diagnostics_settings"></a> [cl\_log\_analytics\_workspace\_diagnostics\_settings](#input\_cl\_log\_analytics\_workspace\_diagnostics\_settings) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "Audit"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_log_analytics_workspace"></a> [cl\_log\_analytics\_workspace](#output\_cl\_log\_analytics\_workspace) | Outputs ********************************************************************************************** |
| <a name="output_cl_log_analytics_workspace_diagnostic_settings"></a> [cl\_log\_analytics\_workspace\_diagnostic\_settings](#output\_cl\_log\_analytics\_workspace\_diagnostic\_settings) | n/a |
| <a name="output_cl_subscription_diagnostic_settings"></a> [cl\_subscription\_diagnostic\_settings](#output\_cl\_subscription\_diagnostic\_settings) | n/a |

## Usage
#### Log Analytics workspace
```terraform
//**********************************************************************************************
#IMPORTANT - ONLY DEPLOY "azurerm_monitor_private_link_scoped_service" IF DEPLOYING IN US (NOT LATAM).
# NOTE - Since the AMPLS is a centralized service in shared services, its required to use a provider to access the AMPLS name (not resource ID). azurerm.shs_us, local.core_sharedsvcs_us_logging_rg & local.core_sharedsvcs_us_log_analytics_private_link_scope_name are already defined in nebula framework.

resource "azurerm_monitor_private_link_scoped_service" "cl_log_analytics_link_scoped_service" {
  provider            = azurerm.shs_us
  name                = "${var.env}-${var.postfix}-logaw-pls"
  resource_group_name = lookup(local.core_sharedsvcs_us_logging_rg, var.env)
  scope_name          = lookup(local.core_sharedsvcs_us_log_analytics_private_link_scope_name, var.env)
  linked_resource_id  = module.cl_log_analytics_workspace.cl_log_analytics_workspace.id
}

module "cl_log_analytics_workspace" {
    source                                                              = "../dn-tads_tf-azure-component-library/components/cl_log_analytics_workspace"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    cl_log_analytics_logging_rg_name                                    = var.cl_log_analytics_logging_rg_name  
}
```
<!-- END_TF_DOCS -->

<!-- BEGIN_TF_DOCS -->

# Azure Route Server Component

Azure Route Server simplifies dynamic routing between your network virtual appliance (NVA) and your virtual network. It allows you to exchange routing information directly through Border Gateway Protocol (BGP) routing protocol between any NVA that supports the BGP routing protocol and the Azure Software Defined Network (SDN) in the Azure Virtual Network (VNet) without the need to manually configure or maintain route tables. Azure Route Server is a fully managed service and is configured with high availability.

For more information, please visit: https://learn.microsoft.com/en-us/azure/route-server/overview



## Resources

| Name | Type |
|------|------|
| [azurerm_public_ip.cl_azure_route_server_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_resource_group.cl_azure_route_server_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_route_server.cl_azure_route_server](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_server) | resource |
| [azurerm_route_server_bgp_connection.cl_azure_route_server_bgp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_server_bgp_connection) | resource |
| [azurerm_subnet.cl_azure_routeserver_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_route_server_availability_zone"></a> [cl\_azure\_route\_server\_availability\_zone](#input\_cl\_azure\_route\_server\_availability\_zone) | (Required) availability zone selected for this public IP. | `list(string)` | `null` | no |
| <a name="input_cl_azure_route_server_deploy_rg"></a> [cl\_azure\_route\_server\_deploy\_rg](#input\_cl\_azure\_route\_server\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the azure route server . | `bool` | `false` | no |
| <a name="input_cl_azure_route_server_rg_name"></a> [cl\_azure\_route\_server\_rg\_name](#input\_cl\_azure\_route\_server\_rg\_name) | (Optional) The name of the azure route server resource group if cl\_azure\_route\_server\_deploy\_rg = false. | `string` | `null` | no |
| <a name="input_cl_azure_route_server_subnet_id"></a> [cl\_azure\_route\_server\_subnet\_id](#input\_cl\_azure\_route\_server\_subnet\_id) | (Optional) The id of the subnet if cl\_azure\_routeserver\_deploy\_subnet = false. | `string` | `null` | no |
| <a name="input_cl_azure_routeserver_bgp_connections"></a> [cl\_azure\_routeserver\_bgp\_connections](#input\_cl\_azure\_routeserver\_bgp\_connections) | (Optional) Define bgp connections for the Azure route server. | <pre>map(object({<br>    peer_asn                 = string<br>    peer_ip                  = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_routeserver_deploy_subnet"></a> [cl\_azure\_routeserver\_deploy\_subnet](#input\_cl\_azure\_routeserver\_deploy\_subnet) | (Optional) A boolean to enable/disable the deployment of a subnet for the Azure route server. | `bool` | `false` | no |
| <a name="input_cl_azure_routeserver_subnet_prefix"></a> [cl\_azure\_routeserver\_subnet\_prefix](#input\_cl\_azure\_routeserver\_subnet\_prefix) | (Required) CIDR block / prefix used to deploy the subnet 'RouteServerSubnet'. | `list(string)` | `null` | no |
| <a name="input_cl_azure_routeserver_vnet_name"></a> [cl\_azure\_routeserver\_vnet\_name](#input\_cl\_azure\_routeserver\_vnet\_name) | (Required) name of the vnet where will be deployed the required subnet 'RouteServerSubnet'. | `string` | `null` | no |
| <a name="input_cl_azure_routeserver_vnet_rg_name"></a> [cl\_azure\_routeserver\_vnet\_rg\_name](#input\_cl\_azure\_routeserver\_vnet\_rg\_name) | (Required) resource group name where the vnet is deployed. | `string` | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration             = "2h"
  cl_azure_route_server_rg     = var.cl_azure_route_server_deploy_rg ? azurerm_resource_group.cl_azure_route_server_rg[0].name : var.cl_azure_route_server_rg_name
  cl_azure_route_server_subnet = var.cl_azure_routeserver_deploy_subnet ? azurerm_subnet.cl_azure_routeserver_subnet[0].id : var.cl_azure_route_server_subnet_id
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_route_server"></a> [cl\_azure\_route\_server](#output\_cl\_azure\_route\_server) | n/a |
| <a name="output_cl_azure_route_server_bgp"></a> [cl\_azure\_route\_server\_bgp](#output\_cl\_azure\_route\_server\_bgp) | n/a |
| <a name="output_cl_azure_route_server_pip"></a> [cl\_azure\_route\_server\_pip](#output\_cl\_azure\_route\_server\_pip) | n/a |
| <a name="output_cl_azure_route_server_rg"></a> [cl\_azure\_route\_server\_rg](#output\_cl\_azure\_route\_server\_rg) | Outputs *********************************************************** |
| <a name="output_cl_azure_route_server_subnet"></a> [cl\_azure\_route\_server\_subnet](#output\_cl\_azure\_route\_server\_subnet) | n/a |

## Usage

```terraform
// Deploy Azure Route Server
//**********************************************************************************************
  module "cl_azure_route_server" {
     source                                    = "../dn-tads_tf-azure-component-library/components/cl_azure_route_server"
     env                                       = var.env
     postfix                                   = var.postfix
     location                                  = var.location
     suffix                                    = var.suffix
     cl_azure_route_server_rg_name             = var.cl_azure_route_server_rg_name
     cl_azure_routeserver_vnet_rg_name         = var.cl_azure_routeserver_vnet_rg_name
     cl_azure_routeserver_vnet_name            = var.cl_azure_routeserver_vnet_name
     cl_azure_routeserver_subnet_prefix        = ["10.X.X.X/27"]
     cl_azure_routeserver_deploy_subnet        = true
     cl_azure_routeserver_bgp_connections      = var.cl_azure_routeserver_bgp_connections
  }
//**********************************************************************************************
```
<!-- END_TF_DOCS -->

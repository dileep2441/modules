## Usage

### Deploy single SQL Managed Instance component
```terraform
module "cl_azure_sql_mananged_instance" {
  source                                  = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_managed_instance"
  env                                                     = var.env
  postfix                                                 = var.postfix
  location                                                = var.location
  cl_azure_sql_managed_instance_sku                       = var.cl_azure_sql_managed_instance_sku
  cl_azure_sql_managed_instance_vcores                    = var.cl_azure_sql_managed_instance_vcores
  cl_azure_sql_managed_instance_storage_size              = var.cl_azure_sql_managed_instance_storage_size
  cl_azure_sql_managed_instance_storage_license_type      = var.cl_azure_sql_managed_instance_storage_license_type
  cl_azure_sql_mananged_instance_vnet_rg_name             = var.cl_azure_sql_managed_instance_vnet_rg_name
  cl_azure_sql_mananged_instance_vnet_name                = var.cl_azure_sql_managed_instance_vnet_name
  cl_azure_sql_mananged_instance_subnet_prefix            = var.cl_azure_sql_managed_instance_subnet_prefix
  cl_azure_sql_managed_instance_administrator             = var.cl_azure_sql_managed_instance_administrator
  cl_azure_sql_managed_instance_password                  = var.cl_azure_sql_managed_instance_password
  cl_azure_sql_deploy_rg                                  = true
  cl_azure_sql_mananged_deploy_subnet                     = true
  cl_azure_sql_mananged_instance_deploy_subnet_nsg        = true
  cl_azure_sql_mananged_instance_deploy_subnet_routetable = true
  cl_azure_sql_mananged_instance_workspace_id             = var.cl_azure_sql_mananged_instance_workspace_id
}
```
//**********************************************************************************************



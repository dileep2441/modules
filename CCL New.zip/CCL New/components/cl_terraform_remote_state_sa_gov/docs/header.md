# TF Remote State Storage Acccount Selected Network Access & PE

This component code is to enable selected netowrk access and PE connection on terraform remote state storage account.

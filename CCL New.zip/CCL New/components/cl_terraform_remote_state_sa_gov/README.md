<!-- BEGIN_TF_DOCS -->

# TF Remote State Storage Acccount Selected Network Access & PE

This component code is to enable selected netowrk access and PE connection on terraform remote state storage account.



## Resources

| Name | Type |
|------|------|
| [azurerm_private_endpoint.cl_tfstate_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account_network_rules.cl_tfstate_storage_account_network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_storage_account.cl_tfstate_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/storage_account) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_tfstate_core_allowed_pe_subnet_id"></a> [cl\_tfstate\_core\_allowed\_pe\_subnet\_id](#input\_cl\_tfstate\_core\_allowed\_pe\_subnet\_id) | (Required) The allowed pe subnet ids to be leveraged for pe connection on tf storage account. | `string` | `""` | no |
| <a name="input_cl_tfstate_core_module_name"></a> [cl\_tfstate\_core\_module\_name](#input\_cl\_tfstate\_core\_module\_name) | (Required) Specifies the core module name for depends on clause - needed since tf state sa vnet rules and pe connection depend on spoke vnet. | `any` | n/a | yes |
| <a name="input_cl_tfstate_core_nacl_allowed_subnets"></a> [cl\_tfstate\_core\_nacl\_allowed\_subnets](#input\_cl\_tfstate\_core\_nacl\_allowed\_subnets) | (Required) The allowed subnets to be whitelisted on tf storage account. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_cl_tfstate_core_private_dns_zone_ids"></a> [cl\_tfstate\_core\_private\_dns\_zone\_ids](#input\_cl\_tfstate\_core\_private\_dns\_zone\_ids) | (Required) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_cl_tfstate_storage_account_enable_network_rules"></a> [cl\_tfstate\_storage\_account\_enable\_network\_rules](#input\_cl\_tfstate\_storage\_account\_enable\_network\_rules) | Toggle to enable selected network access on tf storage account | `bool` | `true` | no |
| <a name="input_cl_tfstate_storage_account_enable_pe"></a> [cl\_tfstate\_storage\_account\_enable\_pe](#input\_cl\_tfstate\_storage\_account\_enable\_pe) | Toggle to enable private endpoint connection on tf storage account | `bool` | `true` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Required) Specifies the tags for resources in sub - application, environment, engagement, LOB & Owner. | `map(any)` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_tfstate_account_private_endpoint"></a> [cl\_tfstate\_account\_private\_endpoint](#output\_cl\_tfstate\_account\_private\_endpoint) | ********************************************************************************************** Outputs ********************************************************************************************** |
| <a name="output_cl_tfstate_storage_account_network_rules"></a> [cl\_tfstate\_storage\_account\_network\_rules](#output\_cl\_tfstate\_storage\_account\_network\_rules) | n/a |


#### Usage
```terraform
module "cl_tfstate_storage_account" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_terraform_remote_state_sa_gov"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  tags                                            = var.tags
  cl_tfstate_core_nacl_allowed_subnets            = var.cl_tfstate_core_nacl_allowed_subnets
  cl_tfstate_core_allowed_pe_subnet_id            = var.cl_tfstate_core_allowed_pe_subnet_id
  cl_tfstate_core_private_dns_zone_ids            = var.cl_tfstate_core_private_dns_zone_ids 
  cl_tfstate_storage_account_enable_pe            = true
  cl_tfstate_storage_account_enable_network_rules = true
  cl_tfstate_core_module_name                     = var.cl_tfstate_core_module_name # ex: module.core_us_peninsula
}
```
<!-- END_TF_DOCS -->
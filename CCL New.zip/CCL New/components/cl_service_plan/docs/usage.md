## Usage
```terraform
// App Service Plan
//**********************************************************************************************
module "cl_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_service_plan_app_postfix                           = var.asp_postfix
  cl_service_plan_deploy_integration_subnet             = true
  cl_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_service_plan_integration_subnet_prefix             = var.cl_service_plan_integration_subnet_prefix
  cl_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  } 
  cl_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_service_plan_os_type                               = var.cl_service_plan_os_type
  cl_service_plan_sku_name                              = var.cl_service_plan_sku_name
  cl_service_plan_worker_count                          = var.cl_service_plan_worker_count
  cl_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                  = var.tags
}
//**********************************************************************************************
```

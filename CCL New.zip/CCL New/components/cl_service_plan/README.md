<!-- BEGIN_TF_DOCS -->

# Azure App Service Plan Component

Azure App Service Plan is the container for hosting Web Apps, REST APIs, custom containers and Function Apps.
One or more apps can be configured to run on the same computing resources (or in the same App Service plan). 
This component will deploy an autoscalable App Service Plan and Diagnostics Settings.

https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_autoscale_setting.cl_service_plan_autoscale_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_autoscale_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_service_plan_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_service_plan_diagnostic_setting_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_service_plan_integration_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_service_plan_int_subnet_user_defined_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_resource_group.cl_service_plan_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_service_plan.cl_service_plan](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_plan) | resource |
| [azurerm_subnet.cl_service_plan_integration_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_service_plan_integration_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.cl_service_plan_rt_associate_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_service_plan_app_postfix"></a> [cl\_service\_plan\_app\_postfix](#input\_cl\_service\_plan\_app\_postfix) | (Required) The bespoke name of the app service plan you are deploying. | `any` | n/a | yes |
| <a name="input_cl_service_plan_autoscale_settings_default"></a> [cl\_service\_plan\_autoscale\_settings\_default](#input\_cl\_service\_plan\_autoscale\_settings\_default) | (Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_cl_service_plan_autoscale_settings_maximum"></a> [cl\_service\_plan\_autoscale\_settings\_maximum](#input\_cl\_service\_plan\_autoscale\_settings\_maximum) | (Optional) The maximum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `10` | no |
| <a name="input_cl_service_plan_autoscale_settings_metric_name"></a> [cl\_service\_plan\_autoscale\_settings\_metric\_name](#input\_cl\_service\_plan\_autoscale\_settings\_metric\_name) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"CpuPercentage"` | no |
| <a name="input_cl_service_plan_autoscale_settings_minimum"></a> [cl\_service\_plan\_autoscale\_settings\_minimum](#input\_cl\_service\_plan\_autoscale\_settings\_minimum) | (Optional) The minimum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_cl_service_plan_autoscale_settings_scale_in_operator"></a> [cl\_service\_plan\_autoscale\_settings\_scale\_in\_operator](#input\_cl\_service\_plan\_autoscale\_settings\_scale\_in\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"LessThan"` | no |
| <a name="input_cl_service_plan_autoscale_settings_scale_in_threshold"></a> [cl\_service\_plan\_autoscale\_settings\_scale\_in\_threshold](#input\_cl\_service\_plan\_autoscale\_settings\_scale\_in\_threshold) | (Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action. | `number` | `25` | no |
| <a name="input_cl_service_plan_autoscale_settings_scale_out_operator"></a> [cl\_service\_plan\_autoscale\_settings\_scale\_out\_operator](#input\_cl\_service\_plan\_autoscale\_settings\_scale\_out\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"GreaterThan"` | no |
| <a name="input_cl_service_plan_autoscale_settings_scale_out_threshold"></a> [cl\_service\_plan\_autoscale\_settings\_scale\_out\_threshold](#input\_cl\_service\_plan\_autoscale\_settings\_scale\_out\_threshold) | (Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action. | `number` | `75` | no |
| <a name="input_cl_service_plan_autoscale_settings_statistic"></a> [cl\_service\_plan\_autoscale\_settings\_statistic](#input\_cl\_service\_plan\_autoscale\_settings\_statistic) | (Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max. | `string` | `"Average"` | no |
| <a name="input_cl_service_plan_autoscale_settings_time_aggregation"></a> [cl\_service\_plan\_autoscale\_settings\_time\_aggregation](#input\_cl\_service\_plan\_autoscale\_settings\_time\_aggregation) | (Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total. | `string` | `"Average"` | no |
| <a name="input_cl_service_plan_autoscale_settings_time_grain"></a> [cl\_service\_plan\_autoscale\_settings\_time\_grain](#input\_cl\_service\_plan\_autoscale\_settings\_time\_grain) | (Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string. | `string` | `"PT1M"` | no |
| <a name="input_cl_service_plan_autoscale_settings_time_window"></a> [cl\_service\_plan\_autoscale\_settings\_time\_window](#input\_cl\_service\_plan\_autoscale\_settings\_time\_window) | (Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string. | `string` | `"PT5M"` | no |
| <a name="input_cl_service_plan_deploy_autoscale_settings"></a> [cl\_service\_plan\_deploy\_autoscale\_settings](#input\_cl\_service\_plan\_deploy\_autoscale\_settings) | (Optional) Choose to deploy autoscale settings or not. If the plan is serverless, this needs to be set to false | `bool` | `true` | no |
| <a name="input_cl_service_plan_deploy_integration_subnet"></a> [cl\_service\_plan\_deploy\_integration\_subnet](#input\_cl\_service\_plan\_deploy\_integration\_subnet) | (Optional) A boolean that toggles the deployment of the vnet integration subnet. | `bool` | `true` | no |
| <a name="input_cl_service_plan_deploy_rg"></a> [cl\_service\_plan\_deploy\_rg](#input\_cl\_service\_plan\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the App Service Plan. | `bool` | `true` | no |
| <a name="input_cl_service_plan_diagnostics"></a> [cl\_service\_plan\_diagnostics](#input\_cl\_service\_plan\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_service_plan_int_subnet_user_defined_nsg_rules"></a> [cl\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules](#input\_cl\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules) | (Optional) A map of NSG rules for the integration subnet. | <pre>map(object({<br>        name                          = string<br>        priority                      = number<br>        direction                     = string<br>        access                        = string<br>        protocol                      = string<br>        source_port_range             = string<br>        source_port_ranges            = list(string)<br>        destination_port_range        = string<br>        destination_port_ranges       = list(string)    <br>        source_address_prefix         = string<br>        source_address_prefixes       = list(string)<br>        destination_address_prefix    = string<br>        destination_address_prefixes  = list(string)    <br>    }))</pre> | `{}` | no |
| <a name="input_cl_service_plan_integration_subnet_prefix"></a> [cl\_service\_plan\_integration\_subnet\_prefix](#input\_cl\_service\_plan\_integration\_subnet\_prefix) | (Optional) The CIDR prefix for the app service subnet. cl\_service\_plan\_deploy\_integration\_subnet needs to be set to true. cl\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_cl_service_plan_integration_subnet_service_endpoints"></a> [cl\_service\_plan\_integration\_subnet\_service\_endpoints](#input\_cl\_service\_plan\_integration\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet. cl\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `list` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_cl_service_plan_integration_vnet_name"></a> [cl\_service\_plan\_integration\_vnet\_name](#input\_cl\_service\_plan\_integration\_vnet\_name) | (Optional) The name of the VNet where the app service subnet will be deployed into. cl\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_cl_service_plan_integration_vnet_rg_name"></a> [cl\_service\_plan\_integration\_vnet\_rg\_name](#input\_cl\_service\_plan\_integration\_vnet\_rg\_name) | (Optional) The name of the VNet resource group where the app service subnet will be deployed into. cl\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_cl_service_plan_log_analytics_workspace_id"></a> [cl\_service\_plan\_log\_analytics\_workspace\_id](#input\_cl\_service\_plan\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_service_plan_logging_rg_name"></a> [cl\_service\_plan\_logging\_rg\_name](#input\_cl\_service\_plan\_logging\_rg\_name) | (Required) The resource group for the app service plan log analytics solution. | `any` | n/a | yes |
| <a name="input_cl_service_plan_max_elastic_workers"></a> [cl\_service\_plan\_max\_elastic\_workers](#input\_cl\_service\_plan\_max\_elastic\_workers) | (Optional) The maximum number of total workers allowed for this ElasticScaleEnabled App Service Plan. | `number` | `null` | no |
| <a name="input_cl_service_plan_nsg_diagnostics"></a> [cl\_service\_plan\_nsg\_diagnostics](#input\_cl\_service\_plan\_nsg\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "NetworkSecurityGroupEvent",<br>    "NetworkSecurityGroupRuleCounter"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_service_plan_os_type"></a> [cl\_service\_plan\_os\_type](#input\_cl\_service\_plan\_os\_type) | (Optional) The O/S type for the App Services to be hosted in this plan. Possible values include Windows, Linux, and WindowsContainer. Changing this forces a new resource to be created. | `string` | `"Windows"` | no |
| <a name="input_cl_service_plan_per_site_scaling_enabled"></a> [cl\_service\_plan\_per\_site\_scaling\_enabled](#input\_cl\_service\_plan\_per\_site\_scaling\_enabled) | (Optional) Can Apps assigned to this App Service Plan be scaled independently? If set to false apps assigned to this plan will scale to all instances of the plan. | `bool` | `false` | no |
| <a name="input_cl_service_plan_rg_name"></a> [cl\_service\_plan\_rg\_name](#input\_cl\_service\_plan\_rg\_name) | (Optional) The name of the App Service Plan resource group if cl\_service\_plan\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_service_plan_route_table_id"></a> [cl\_service\_plan\_route\_table\_id](#input\_cl\_service\_plan\_route\_table\_id) | (Optional) The ID of the route table that will be associated to the subnet | `string` | `""` | no |
| <a name="input_cl_service_plan_sku_name"></a> [cl\_service\_plan\_sku\_name](#input\_cl\_service\_plan\_sku\_name) | (Optional) The SKU for the plan. Possible values include B1, B2, B3, D1, F1, I1, I2, I3, I1v2, I2v2, I3v2, I4v2, I5v2, I6v2, P1v2, P2v2, P3v2, P0v3, P1v3, P2v3, P3v3, P1mv3, P2mv3, P3mv3, P4mv3, P5mv3, S1, S2, S3, SHARED, EP1, EP2, EP3, WS1, WS2, WS3, and Y1. | `string` | `"P1v2"` | no |
| <a name="input_cl_service_plan_worker_count"></a> [cl\_service\_plan\_worker\_count](#input\_cl\_service\_plan\_worker\_count) | (Optional) The number of Workers (instances) to be allocated. | `number` | `"1"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_service_plan"></a> [cl\_service\_plan](#output\_cl\_service\_plan) | n/a |
| <a name="output_cl_service_plan_autoscale_settings"></a> [cl\_service\_plan\_autoscale\_settings](#output\_cl\_service\_plan\_autoscale\_settings) | n/a |
| <a name="output_cl_service_plan_diagnostic_setting"></a> [cl\_service\_plan\_diagnostic\_setting](#output\_cl\_service\_plan\_diagnostic\_setting) | n/a |
| <a name="output_cl_service_plan_integration_subnet"></a> [cl\_service\_plan\_integration\_subnet](#output\_cl\_service\_plan\_integration\_subnet) | n/a |
| <a name="output_cl_service_plan_integration_subnet_nsg"></a> [cl\_service\_plan\_integration\_subnet\_nsg](#output\_cl\_service\_plan\_integration\_subnet\_nsg) | n/a |
| <a name="output_cl_service_plan_rg"></a> [cl\_service\_plan\_rg](#output\_cl\_service\_plan\_rg) | Outputs ********************************************************************************************** |

## Usage
```terraform
// App Service Plan
//**********************************************************************************************
module "cl_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_service_plan_app_postfix                           = var.asp_postfix
  cl_service_plan_deploy_integration_subnet             = true
  cl_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_service_plan_integration_subnet_prefix             = var.cl_service_plan_integration_subnet_prefix
  cl_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  } 
  cl_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_service_plan_os_type                               = var.cl_service_plan_os_type
  cl_service_plan_sku_name                              = var.cl_service_plan_sku_name
  cl_service_plan_worker_count                          = var.cl_service_plan_worker_count
  cl_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                  = var.tags
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
<!-- BEGIN_TF_DOCS -->

# Azure Kubernetes services Node Pools Component

Multiple Node Pools are only supported when the Kubernetes Cluster is using Virtual Machine Scale Sets. 
The type of Default Node Pool for the Kubernetes Cluster must be VirtualMachineScaleSets to attach multiple node pools.

For more information, please visit: https://docs.microsoft.com/en-us/azure/aks/use-multiple-node-pools 

#### Note:
To add windows node pool to kubernetes cluster, it needs Terraform version 0.15 or later.
It can be specified on Jenkinsfile:
```jenkinsfile
stage("Terraform *** ") {
    agent {
        docker {
            image 'dn-cloud-docker.artifactory.us.kworld.kpmg.com/azure-terraform-0-15-4:latest'
            ...
```
Specify TF version in `pattern_backend`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```

## Resources

| Name | Type |
|------|------|
| [azurerm_kubernetes_cluster_node_pool.cl_kubernetes_cluster_node_pools](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/kubernetes_cluster_node_pool) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_kubernetes_node_pool_availability_zones"></a> [cl\_kubernetes\_node\_pool\_availability\_zones](#input\_cl\_kubernetes\_node\_pool\_availability\_zones) | (Optional) A list of Availability Zones where the Nodes in this Node Pool should be created in. Changing this forces a new resource to be created. | `list(number)` | <pre>[<br>  1,<br>  2,<br>  3<br>]</pre> | no |
| <a name="input_cl_kubernetes_node_pool_enable_auto_scaling"></a> [cl\_kubernetes\_node\_pool\_enable\_auto\_scaling](#input\_cl\_kubernetes\_node\_pool\_enable\_auto\_scaling) | (Optional) Whether to enable auto-scaler. Defaults to false. | `bool` | `false` | no |
| <a name="input_cl_kubernetes_node_pool_enable_host_encryption"></a> [cl\_kubernetes\_node\_pool\_enable\_host\_encryption](#input\_cl\_kubernetes\_node\_pool\_enable\_host\_encryption) | (Optional) Should the nodes in this Node Pool have host encryption enabled? Defaults to false. Encryption at host feature must be enabled on the subscription: https://docs.microsoft.com/azure/virtual-machines/linux/disks-enable-host-based-encryption-cli | `bool` | `false` | no |
| <a name="input_cl_kubernetes_node_pool_enable_node_public_ip"></a> [cl\_kubernetes\_node\_pool\_enable\_node\_public\_ip](#input\_cl\_kubernetes\_node\_pool\_enable\_node\_public\_ip) | (Optional) Should each node have a Public IP Address? Defaults to false. | `bool` | `false` | no |
| <a name="input_cl_kubernetes_node_pool_eviction_policy"></a> [cl\_kubernetes\_node\_pool\_eviction\_policy](#input\_cl\_kubernetes\_node\_pool\_eviction\_policy) | (Optional) The Eviction Policy which should be used for Virtual Machines within the Virtual Machine Scale Set powering this Node Pool. Possible values are Deallocate and Delete. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_fips_enabled"></a> [cl\_kubernetes\_node\_pool\_fips\_enabled](#input\_cl\_kubernetes\_node\_pool\_fips\_enabled) | (Optional) Should the nodes in this Node Pool have Federal Information Processing Standard enabled? Changing this forces a new resource to be created.FIPS support is in Public Preview | `bool` | `false` | no |
| <a name="input_cl_kubernetes_node_pool_kubelet_config"></a> [cl\_kubernetes\_node\_pool\_kubelet\_config](#input\_cl\_kubernetes\_node\_pool\_kubelet\_config) | (Optional) Customizing your node configuration allows you to configure or tune your operating system (OS) settings or the kubelet parameters to match the needs of the workloads. When you create an AKS cluster or add a node pool to your cluster, you can customize a subset of commonly used OS and kubelet settings. To configure settings beyond this subset. | <pre>map(object({<br>    allowed_unsafe_sysctls      = list(string)<br>    container_log_max_line      = number<br>    container_log_max_size_mb   = number<br>    cpu_cfs_quota_enabled       = bool<br>    cpu_cfs_quota_period        = string  <br>    cpu_manager_policy          = string<br>    image_gc_high_threshold     = number<br>    image_gc_low_threshold      = number<br>    pod_max_pid                 = number<br>    topology_manager_policy     = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_kubernetes_node_pool_kubelet_disk_type"></a> [cl\_kubernetes\_node\_pool\_kubelet\_disk\_type](#input\_cl\_kubernetes\_node\_pool\_kubelet\_disk\_type) | (Optional) The type of disk used by kubelet. At this time the only possible value is OS. | `string` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_kubernetes_cluster_id"></a> [cl\_kubernetes\_node\_pool\_kubernetes\_cluster\_id](#input\_cl\_kubernetes\_node\_pool\_kubernetes\_cluster\_id) | (Required) The ID of the Kubernetes Cluster where this Node Pool should exist. Changing this forces a new resource to be created. The type of Default Node Pool for the Kubernetes Cluster must be VirtualMachineScaleSets to attach multiple node pools. | `string` | n/a | yes |
| <a name="input_cl_kubernetes_node_pool_max_count"></a> [cl\_kubernetes\_node\_pool\_max\_count](#input\_cl\_kubernetes\_node\_pool\_max\_count) | (Required) The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min\_count. | `number` | `5` | no |
| <a name="input_cl_kubernetes_node_pool_max_pods"></a> [cl\_kubernetes\_node\_pool\_max\_pods](#input\_cl\_kubernetes\_node\_pool\_max\_pods) | (Optional) The maximum number of pods that can run on each agent. Changing this forces a new resource to be created. | `number` | `110` | no |
| <a name="input_cl_kubernetes_node_pool_max_surge"></a> [cl\_kubernetes\_node\_pool\_max\_surge](#input\_cl\_kubernetes\_node\_pool\_max\_surge) | (Optional) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade.If a percentage is provided, the number of surge nodes is calculated from the current node count on the cluster. Node surge can allow a cluster to have more nodes than max\_count during an upgrade. Ensure that your cluster has enough IP space during an upgrade. | `string` | `"33%"` | no |
| <a name="input_cl_kubernetes_node_pool_min_count"></a> [cl\_kubernetes\_node\_pool\_min\_count](#input\_cl\_kubernetes\_node\_pool\_min\_count) | (Required) The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max\_count. | `number` | `1` | no |
| <a name="input_cl_kubernetes_node_pool_mode"></a> [cl\_kubernetes\_node\_pool\_mode](#input\_cl\_kubernetes\_node\_pool\_mode) | (Optional) Should this Node Pool be used for System or User resources? Possible values are System and User. Defaults to User. | `string` | `"User"` | no |
| <a name="input_cl_kubernetes_node_pool_name"></a> [cl\_kubernetes\_node\_pool\_name](#input\_cl\_kubernetes\_node\_pool\_name) | (Required) The name of the Node Pool which should be created within the Kubernetes Cluster. Changing this forces a new resource to be created. A Windows Node Pool cannot have a name longer than 6 characters. | `string` | n/a | yes |
| <a name="input_cl_kubernetes_node_pool_node_count"></a> [cl\_kubernetes\_node\_pool\_node\_count](#input\_cl\_kubernetes\_node\_pool\_node\_count) | (Optional) The initial number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be a value in the range min\_count - max\_count. If you're specifying an initial number of nodes you may wish to use Terraform's ignore\_changes functionality to ignore changes to this field. | `number` | `3` | no |
| <a name="input_cl_kubernetes_node_pool_node_labels"></a> [cl\_kubernetes\_node\_pool\_node\_labels](#input\_cl\_kubernetes\_node\_pool\_node\_labels) | (Optional) A map of Kubernetes labels which should be applied to nodes in this Node Pool. Changing this forces a new resource to be created. | `map(string)` | `{}` | no |
| <a name="input_cl_kubernetes_node_pool_node_public_ip_prefix_id"></a> [cl\_kubernetes\_node\_pool\_node\_public\_ip\_prefix\_id](#input\_cl\_kubernetes\_node\_pool\_node\_public\_ip\_prefix\_id) | (Optional) Resource ID for the Public IP Addresses Prefix for the nodes in this Node Pool. | `string` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_node_taints"></a> [cl\_kubernetes\_node\_pool\_node\_taints](#input\_cl\_kubernetes\_node\_pool\_node\_taints) | (Optional) A list of Kubernetes taints which should be applied to nodes in the agent pool (e.g key=value:NoSchedule). Changing this forces a new resource to be created. | `list(string)` | <pre>[<br>  "key=value:NoSchedule"<br>]</pre> | no |
| <a name="input_cl_kubernetes_node_pool_orchestrator_version"></a> [cl\_kubernetes\_node\_pool\_orchestrator\_version](#input\_cl\_kubernetes\_node\_pool\_orchestrator\_version) | (Optional) Version of Kubernetes used for the Agents. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade). This version must be supported by the Kubernetes Cluster - as such the version of Kubernetes used on the Cluster/Control Plane may need to be upgraded first. | `string` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_os_disk_size_gb"></a> [cl\_kubernetes\_node\_pool\_os\_disk\_size\_gb](#input\_cl\_kubernetes\_node\_pool\_os\_disk\_size\_gb) | (Optional) The Agent Operating System disk size in GB. Changing this forces a new resource to be created. | `number` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_os_disk_type"></a> [cl\_kubernetes\_node\_pool\_os\_disk\_type](#input\_cl\_kubernetes\_node\_pool\_os\_disk\_type) | (Optional) The type of disk which should be used for the Operating System. Possible values are Ephemeral and Managed. Defaults to Managed. Changing this forces a new resource to be created. | `string` | `"Managed"` | no |
| <a name="input_cl_kubernetes_node_pool_os_sku"></a> [cl\_kubernetes\_node\_pool\_os\_sku](#input\_cl\_kubernetes\_node\_pool\_os\_sku) | (Optional) OsSKU to be used to specify Linux OSType. Not applicable to Windows OSType. Possible values include: Ubuntu, CBLMariner. Defaults to Ubuntu. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_os_type"></a> [cl\_kubernetes\_node\_pool\_os\_type](#input\_cl\_kubernetes\_node\_pool\_os\_type) | (Optional) The Operating System which should be used for this Node Pool. Changing this forces a new resource to be created. Possible values are Linux and Windows. Defaults to Linux. | `string` | `"Linux"` | no |
| <a name="input_cl_kubernetes_node_pool_pod_subnet_id"></a> [cl\_kubernetes\_node\_pool\_pod\_subnet\_id](#input\_cl\_kubernetes\_node\_pool\_pod\_subnet\_id) | (Optional) The ID of the Subnet where the pods in the default Node Pool should exist. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_priority"></a> [cl\_kubernetes\_node\_pool\_priority](#input\_cl\_kubernetes\_node\_pool\_priority) | (Optional) The Priority for Virtual Machines within the Virtual Machine Scale Set that powers this Node Pool. Possible values are Regular and Spot. Defaults to Regular. Changing this forces a new resource to be created. When setting priority to Spot - you must configure an eviction\_policy, spot\_max\_price and add the applicable node\_labels and node\_taints. | `string` | `"Regular"` | no |
| <a name="input_cl_kubernetes_node_pool_proximity_placement_group_id"></a> [cl\_kubernetes\_node\_pool\_proximity\_placement\_group\_id](#input\_cl\_kubernetes\_node\_pool\_proximity\_placement\_group\_id) | (Optional) The ID of the Proximity Placement Group where the Virtual Machine Scale Set that powers this Node Pool will be placed. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_spot_max_price"></a> [cl\_kubernetes\_node\_pool\_spot\_max\_price](#input\_cl\_kubernetes\_node\_pool\_spot\_max\_price) | (Optional) The maximum price you're willing to pay in USD per Virtual Machine. Valid values are -1 (the current on-demand price for a Virtual Machine) or a positive value with up to five decimal places. Changing this forces a new resource to be created. This field can only be configured when priority is set to Spot. | `number` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_ultra_ssd_enabled"></a> [cl\_kubernetes\_node\_pool\_ultra\_ssd\_enabled](#input\_cl\_kubernetes\_node\_pool\_ultra\_ssd\_enabled) | (Optional) Used to specify whether the UltraSSD is enabled in the Default Node Pool. Defaults to false. | `bool` | `false` | no |
| <a name="input_cl_kubernetes_node_pool_upgrade_max_surge"></a> [cl\_kubernetes\_node\_pool\_upgrade\_max\_surge](#input\_cl\_kubernetes\_node\_pool\_upgrade\_max\_surge) | (Required) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade | `number` | `null` | no |
| <a name="input_cl_kubernetes_node_pool_vm_size"></a> [cl\_kubernetes\_node\_pool\_vm\_size](#input\_cl\_kubernetes\_node\_pool\_vm\_size) | (Optional) The SKU which should be used for the Virtual Machines used in this Node Pool. Changing this forces a new resource to be created. | `string` | `"Standard_DS2_v2"` | no |
| <a name="input_cl_kubernetes_node_pool_vnet_subnet_id"></a> [cl\_kubernetes\_node\_pool\_vnet\_subnet\_id](#input\_cl\_kubernetes\_node\_pool\_vnet\_subnet\_id) | (Optional) The ID of the Subnet where this Node Pool should exist. At this time the vnet\_subnet\_id must be the same for all node pools in the cluster. A route table must be configured on this Subnet. | `string` | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to the resource. At this time there's a bug in the AKS API where Tags for a Node Pool are not stored in the correct case | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration            = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_kubernetes_cluster_node_pools"></a> [cl\_kubernetes\_cluster\_node\_pools](#output\_cl\_kubernetes\_cluster\_node\_pools) | Outputs Azure Kubernetes Services cluster node pools ********************************************************************************************** |

## Usage

### 1. Usage Add Azure Kubernetes Linux Node Pool

```terraform

module "cl_azure_kubernetes_service_node_pool"{
   source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_kubernetes_service_node_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_kubernetes_node_pool_name                         = "internal"
   cl_kubernetes_node_pool_kubernetes_cluster_id        =  module.cl_azure_kubernetes_service.cl_kubernetes_id
   cl_kubernetes_node_pool_vm_size                      = "Standard_B2s"
   cl_kubernetes_node_pool_availability_zones           = [1]
   cl_kubernetes_node_pool_os_disk_size_gb              = 256
   cl_kubernetes_node_pool_enable_auto_scaling          = true
   cl_kubernetes_node_pool_enable_host_encryption       = false
   cl_kubernetes_node_pool_enable_node_public_ip        = false
   cl_kubernetes_node_pool_os_disk_type                 = "Managed"
   cl_kubernetes_node_pool_os_sku                       = "Ubuntu"
   cl_kubernetes_node_pool_os_type                      = "Linux"
   cl_kubernetes_node_pool_mode                         = "User"
   cl_kubernetes_node_pool_node_count                   = 3
   cl_kubernetes_node_pool_max_count                    = 5
   cl_kubernetes_node_pool_min_count                    = 1
   cl_kubernetes_node_pool_max_pods                     = 110
   cl_kubernetes_node_pool_max_surge                    = "33%"
   cl_kubernetes_node_pool_priority                     = "Regular"
}
```
### 2. Usage Add Azure Kubernetes Windows Node Pool

```terraform
module "cl_azure_kubernetes_service_node_pool_windows"{
   source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_kubernetes_service_node_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_kubernetes_node_pool_name                         = "wpool"
   cl_kubernetes_node_pool_kubernetes_cluster_id        =  module.cl_azure_kubernetes_service.cl_kubernetes_id
   cl_kubernetes_node_pool_vm_size                      = "Standard_B2s"
   cl_kubernetes_node_pool_availability_zones           = [1,2]
   cl_kubernetes_node_pool_os_disk_size_gb              = 200
   cl_kubernetes_node_pool_enable_auto_scaling          = true
   cl_kubernetes_node_pool_enable_host_encryption       = false
   cl_kubernetes_node_pool_enable_node_public_ip        = false
   cl_kubernetes_node_pool_os_disk_type                 = "Managed"
   cl_kubernetes_node_pool_os_type                      = "Windows"
   cl_kubernetes_node_pool_mode                         = "User"
   cl_kubernetes_node_pool_node_count                   = 3
   cl_kubernetes_node_pool_max_pods                     = 110
   cl_kubernetes_node_pool_max_surge                    = "33%"
   cl_kubernetes_node_pool_priority                     = "Regular"
}
```
<!-- END_TF_DOCS -->
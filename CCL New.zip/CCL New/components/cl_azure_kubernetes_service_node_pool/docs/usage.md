## Usage

### 1. Usage Add Azure Kubernetes Linux Node Pool

```terraform

module "cl_azure_kubernetes_service_node_pool"{
   source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_kubernetes_service_node_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_kubernetes_node_pool_name                         = "internal"
   cl_kubernetes_node_pool_kubernetes_cluster_id        =  module.cl_azure_kubernetes_service.cl_kubernetes_id
   cl_kubernetes_node_pool_vm_size                      = "Standard_B2s"
   cl_kubernetes_node_pool_availability_zones           = [1]
   cl_kubernetes_node_pool_os_disk_size_gb              = 256
   cl_kubernetes_node_pool_enable_auto_scaling          = true
   cl_kubernetes_node_pool_enable_host_encryption       = false
   cl_kubernetes_node_pool_enable_node_public_ip        = false
   cl_kubernetes_node_pool_os_disk_type                 = "Managed"
   cl_kubernetes_node_pool_os_sku                       = "Ubuntu"
   cl_kubernetes_node_pool_os_type                      = "Linux"
   cl_kubernetes_node_pool_mode                         = "User"
   cl_kubernetes_node_pool_node_count                   = 3
   cl_kubernetes_node_pool_max_count                    = 5
   cl_kubernetes_node_pool_min_count                    = 1
   cl_kubernetes_node_pool_max_pods                     = 110
   cl_kubernetes_node_pool_max_surge                    = "33%"
   cl_kubernetes_node_pool_priority                     = "Regular"
}
```
### 2. Usage Add Azure Kubernetes Windows Node Pool

```terraform
module "cl_azure_kubernetes_service_node_pool_windows"{
   source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_kubernetes_service_node_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_kubernetes_node_pool_name                         = "wpool"
   cl_kubernetes_node_pool_kubernetes_cluster_id        =  module.cl_azure_kubernetes_service.cl_kubernetes_id
   cl_kubernetes_node_pool_vm_size                      = "Standard_B2s"
   cl_kubernetes_node_pool_availability_zones           = [1,2]
   cl_kubernetes_node_pool_os_disk_size_gb              = 200
   cl_kubernetes_node_pool_enable_auto_scaling          = true
   cl_kubernetes_node_pool_enable_host_encryption       = false
   cl_kubernetes_node_pool_enable_node_public_ip        = false
   cl_kubernetes_node_pool_os_disk_type                 = "Managed"
   cl_kubernetes_node_pool_os_type                      = "Windows"
   cl_kubernetes_node_pool_mode                         = "User"
   cl_kubernetes_node_pool_node_count                   = 3
   cl_kubernetes_node_pool_max_pods                     = 110
   cl_kubernetes_node_pool_max_surge                    = "33%"
   cl_kubernetes_node_pool_priority                     = "Regular"
}
```
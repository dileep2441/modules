# Postgresql Server Component

Azure Database for PostgreSQL Single Server is a fully managed database service. 
This server platform is designed to handle most of the database management functions such as patching, backups, high availability, security with minimal user configuration and control. 
This component will deploy Azure Postgresql Server, private endpoint and diagnostic settings for the server.

For more information, please visit: https://docs.microsoft.com/en-us/azure/postgresql/overview 

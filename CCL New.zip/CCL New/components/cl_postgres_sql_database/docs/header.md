# Postgresql Database Component

Azure Database for PostgreSQL is a relational database service based on the open-source Postgres database engine. 
It's a fully managed database-as-a-service that can handle mission-critical workloads with predictable performance, security, high availability, and dynamic scalability.
This component will deploy just the Azure Postgresql Database.

For more information, please visit: https://docs.microsoft.com/en-us/azure/postgresql/#:~:text=Azure%20Database%20for%20PostgreSQL%20is,high%20availability%2C%20and%20dynamic%20scalability


## Usage

### Deploy App Service with vnet integration subnet

```terraform
module "cl_linux_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_linux_app_service_plan_app_postfix                           = var.asp_postfix
  cl_linux_app_service_plan_deploy_integration_subnet             = true
  cl_linux_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_linux_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_linux_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_linux_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_linux_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_linux_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_linux_app_service_plan_os_type                                  = var.app_service_plan_kind
  cl_linux_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_linux_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_linux_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

module "cl_linux_app_service" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_linux_app_service"
  env                                                       = var.env
  postfix                                                   = "crwx-b"
  location                                                  = var.location
  suffix                                                    = "gvnpb"
  cl_linux_app_service_plan_deploy_integration_subnet       = true
  cl_linux_app_service_integration_subnet_id                = module.cl_linux_app_service_plan.cl_app_service_plan_integration_subnet.id 
  cl_linux_app_service_client_affinity_enabled              = false
  cl_linux_app_service_pe_subnet_ids                        = [data.azurerm_subnet.private_link_subnet.id]
  cl_linux_app_service_app_postfix                          = "walxar"
  cl_linux_app_service_rg_name                              = module.cl_linux_app_service_plan.cl_app_service_plan_rg[0].name
  cl_linux_app_service_asp_id                               = module.cl_linux_app_service_plan.cl_app_service_plan.id
  cl_linux_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  #cl_app_service_diagnostics                               = var.app_service_diagnostics
  #cl_app_service_settings                                  = var.app_service_settings
  cl_linux_app_service_private_dns_zone_ids                 = [data.azurerm_private_dns_zone.app_service_private_dns_zone.id]
  cl_linux_app_service_cors_allowed_origins                 =  [""]

  //Site_Config
  #cl_app_service_linux_fx_version                          = var.app_service_linux_fx_version
  #cl_app_service_default_documents                         = var.app_service_default_documents
  #cl_app_service_use_32_bit_worker_process                 = var.app_service_use_32_bit_worker_process  
  tags                                                      = var.tags
  cl_linux_app_service_remote_debugging_enabled             = true
  cl_linux_app_service_dotnet_version                       = "6.0"
 }
```
### Deploy App Service for Containers with vnet integration subnet (Azure Container Registry and repository images should be already in place)
```terraform

module "cl_azure_container_registry" {
    source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
    suffix                                                      = var.suffix
    tags                                                        = var.tags
    cl_azure_container_registry_rg_name                         = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_allowed_vnet_ids                = [data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id]
    cl_azure_container_registry_content_trust_enabled           = false
    cl_azure_container_registry_admin_enabled                   = true
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
}

module "cl_linux_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_linux_app_service_plan_app_postfix                           = var.asp_postfix
  cl_linux_app_service_plan_deploy_integration_subnet             = true
  cl_linux_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_linux_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_linux_app_service_plan_integration_subnet_prefix             = var.app_service_integration_subnet_prefix
  cl_linux_app_service_plan_int_subnet_user_defined_nsg_rules     = var.app_service_nsg_rules
  cl_linux_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_linux_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_linux_app_service_plan_os_type                                  = var.app_service_plan_kind
  cl_linux_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_linux_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_linux_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

module "cl_linux_app_service" {
  source                                              = "../dn-tads_tf-azure-component-library/components/cl_linux_app_service"
  env                                                 = var.env
  postfix                                             = var.postfix
  location                                            = var.location
  suffix                                              = var.suffix
  cl_linux_app_service_plan_deploy_integration_subnet       = true
  cl_linux_app_service_integration_subnet_id                = var.cl_linux_app_service_plan_deploy_integration_subnet ? module.cl_linux_app_service_plan.cl_linux_app_service_plan_integration_subnet.id : null
  cl_linux_app_service_client_affinity_enabled              = var.app_service_client_affinity_enabled
  cl_linux_app_service_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_linux_app_service_app_postfix                          = var.app_service_app_postfix
  cl_linux_app_service_rg_name                              = module.cl_linux_app_service_plan.cl_linux_app_service_plan_rg.name
  cl_linux_app_service_asp_id                               = module.cl_linux_app_service_plan.cl_linux_app_service_plan.id
  cl_linux_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_linux_app_service_diagnostics                          = var.app_service_diagnostics
  cl_linux_app_service_settings                             = var.app_service_settings
  cl_linux_app_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.app_service_private_dns_zone.id]

  //Site_Config

  cl_linux_app_service_default_documents                    = var.app_service_default_documents
  cl_linux_app_service_use_32_bit_worker_process            = var.app_service_use_32_bit_worker_process  


  //cl_linux_app_service_acr_username can be any other user with access to pull and push images into and from ACR. Not only the admin user from ACR.
  cl_linux_app_service_is_docker        = true
  cl_linux_app_service_acr_login_server = module.cl_azure_container_registry.cl_azure_container_registry.login_server
  cl_linux_app_service_acr_username     = module.cl_azure_container_registry.cl_azure_container_registry_admin_username
  cl_linux_app_service_acr_password     = module.cl_azure_container_registry.cl_azure_container_registry_admin_password
  cl_linux_app_service_acr_image        = "myapp:latest"

    // Connection Strings in variable cl_linux_app_service_connection_strings
  cl_linux_app_service_connection_strings = {
      connection_string = {
        name      = "sa_peninsula_connection"
        type      = "Custom"
        value     = var.cl_b2c_manager_app_service_connection_string_value
      }
    }

    tags                            = var.tags
 }
```

## Information
## Virtual Wan implemetation
```terraform
Azure Virtual WAN is a networking service that brings many networking, security, and routing functionalities together to provide a single operational interface. Some of the main features include:

- Branch connectivity (via connectivity automation from Virtual WAN Partner devices such as SD-WAN or VPN CPE).
- Site-to-site VPN connectivity.
- Remote user VPN connectivity (point-to-site).
- Private connectivity (ExpressRoute).
- Intra-cloud connectivity (transitive connectivity for virtual networks).
- VPN ExpressRoute inter-connectivity.
- Routing, Azure Firewall, and encryption for private connectivity.
```
## Usage
```terraform
# Creates Virtual Wan
module "cl_virtual_wan" {
  source                = "../dn-tads_tf-azure-component-library/components/cl_azure_vwan"
  env                   = var.env
  postfix               = var.postfix
  location              = var.location
  cl_azure_vwan_name    = var.cl_azure_vwan_name
  cl_azure_vwan_rg_name = var.cl_azure_vwan_rg_name

  cl_azure_vwan_disable_vpn_encryption            = var.cl_azure_vwan_disable_vpn_encryption
  cl_azure_vwan_allow_branch_to_branch_traffic    = var.cl_azure_vwan_allow_branch_to_branch_traffic
  cl_azure_vwan_office365_local_breakout_category = var.cl_azure_vwan_office365_local_breakout_category
  cl_azure_vwan_type                              = var.cl_azure_vwan_type
  cl_azure_vwan_log_analytics_workspace_id        = var.cl_azure_vwan_log_analytics_workspace_id
  tags                                            = var.tags
}

# Creates Virtual Hub
module "cl_virtual_hub" {
  source                                   = "../dn-tads_tf-azure-component-library/components/cl_azure_vwan/modules/virtualhub"
  for_each                                 = var.cl_vhub_list
  env                                      = var.env
  postfix                                  = var.postfix
  cl_azure_virtual_wan_id                  = module.cl_virtual_wan.cl_virtual_wan.id
  cl_azure_deploy_vhub_resource_group      = each.value.cl_azure_deploy_vhub_resource_group
  cl_azure_vhub_rg_name                    = each.value.cl_azure_vhub_rg_name
  location                                 = each.value.cl_vhub_location
  cl_azure_vhub_name                       = each.value.cl_vhub_name
  cl_azure_vhub_routing_preference         = each.value.cl_vhub_routing_preference
  cl_azure_vhub_address_prefix             = each.value.cl_vhub_address_prefix
  cl_azure_vhub_sku                        = each.value.cl_vhub_sku
  cl_azure_vhub_log_analytics_workspace_id = var.cl_azure_vhub_log_analytics_workspace_id
  tags                                     = var.tags
}

# Connects Spoke vNet to Virtual Hub
module "cl_virtual_hub_connection" {
   source                           = "../dn-tads_tf-azure-component-library/components/cl_azure_vwan/modules/connections"
   env                              = var.env
   postfix                          = var.postfix
   peered_virtual_networks          = var.peered_virtual_networks
   location                         = var.location
 }

# Optional Firewall deployment
 module "vhub_firewall" {
  source                                    = "../dn-tads_tf-azure-component-library/components/cl_azure_vwan/modules/firewall"
  env                                       = var.fw_env
  postfix                                   = var.postfix
  location                                  = var.location
  tags                                      = var.tags
  cl_azure_firewall_virtual_hub_name        = var.cl_azure_firewall_virtual_hub_name
  cl_azure_resource_group_name              = var.cl_azure_resource_group_name
  cl_azure_firewall_sku_tier                = var.cl_azure_firewall_sku_tier
  cl_azure_firewall_virtual_hub_id          = var.cl_azure_firewall_virtual_hub_id
  cl_azure_deploy_fw_policy                 = var.cl_azure_deploy_fw_policy
  cl_azure_firewall_availibility_zones      = var.cl_azure_firewall_availibility_zones
  cl_azure_vwan_log_analytics_workspace_id  = var.cl_azure_vwan_fw_log_analytics_workspace_id
}

# Optional Routing Intent
resource "azurerm_virtual_hub_routing_intent" "routingintent-firewall" {
  name           = "${var.fw_env}-${var.postfix}-${var.cl_azure_firewall_virtual_hub_name}-vhub-ri"
  virtual_hub_id = "/subscriptions/1392020d-7bd1-47aa-8be5-8ab82836723a/resourceGroups/prod-vwan-pr-rg/providers/Microsoft.Network/virtualHubs/prod-vwan-pr-eus-sentinel"

   routing_policy {
     name         = "InternetTrafficPolicy"
     destinations = ["Internet"]
     next_hop     = "/subscriptions/1392020d-7bd1-47aa-8be5-8ab82836723a/resourceGroups/rg-prod-vwan-palo/providers/Microsoft.Compute/virtualMachines/prod-vwan-pa-1"
   }

  routing_policy {
    name         = "PrivateTrafficPolicy"
    destinations = ["PrivateTraffic"]
    next_hop     = module.vhub_firewall.cl_azure_firewall.id
  }
  depends_on = [ module.vhub_firewall ]
}

# Example of adding rule collections. This is just an example for adding any to any rules and not suitable for production deployment. 
resource "azurerm_firewall_policy_rule_collection_group" "fwp-rcg" {
   name               = "${var.fw_env}-${var.postfix}-${var.cl_azure_firewall_virtual_hub_name}-fwprcg"
   firewall_policy_id = module.vhub_firewall.cl_azure_policy.id
   priority           = 1000
   network_rule_collection {
     name     = "network_rule_collection_allow_all"
     priority = 400
     action   = "Allow"
     rule {
       name                  = "Allow_All"
       protocols             = ["Any"]
       source_addresses      = ["*"]
       destination_addresses = ["*"]
       destination_ports     = ["*"]
     }
   }

   application_rule_collection {
     name     = "app_rule_collection_allow_all"
     priority = 500
     action   = "Allow"
     rule {
       name                  = "Allow_All"
       source_addresses      = ["*"]
       destination_addresses = ["*"]
       destination_fqdns     = ["*"]
       protocols {
         type = "Http"
         port = 80
       }
       protocols {
         type = "Https"
         port = 443
       }
       protocols {
         type = "Http"
         port = 5671
       }
       protocols {
         type = "Https"
         port = 5672
       }
     }
   }

   depends_on = [ module.vhub_firewall ]
 }
 ```
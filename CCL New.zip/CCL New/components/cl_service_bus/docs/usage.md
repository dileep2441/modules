## Usage

```terraform
resource "azurerm_private_dns_zone" "service_bus_private_dns_zone" {
  name                = "privatelink.servicebus.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "service_bus_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.service_bus_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_service_bus" {
    source = "../dn-tads_tf-azure-component-library/components/cl_service_bus"
    env                                            = var.env
    postfix                                        = var.postfix
    location                                       = var.location
    cl_service_bus_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_service_bus_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_service_bus_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_service_bus_allowed_subnets                = [azurerm_subnet.test_subnet1.id, azurerm_subnet.test_subnet2.id, azurerm_subnet.test_subnet3.id]
    cl_service_bus_private_dns_zone_ids           = [azurerm_private_dns_zone.service_bus_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "service_bus_private_dns_record" {
  name                                         = "${var.env}-${var.postfix}-app-service-int-pe-record"
  zone_name                                    = azurerm_private_dns_zone.service_bus_private_dns_zone.name
  resource_group_name                          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                                          = var.service_bus_private_record_ttl
  records                                      = module.cl_app_service.cl_service_bus_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                                         = var.tags
}
```
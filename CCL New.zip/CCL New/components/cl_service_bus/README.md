<!-- BEGIN_TF_DOCS -->

# Azure Service Bus Component

Azure Service Bus is a messaging service on cloud used to connect any applications, devices, and services running in the cloud to any other applications or services. 
As a result, it acts as a messaging backbone for applications available in the cloud or across any devices.
This component will deploy Azure Service Bus, Athoritation rules, Monitor Diagnostics, Monitor Autoscale, Network Security and Private Endpoint for allowed Subnets.

Service Bus comes in Basic, standard, and premium tiers. with the following table you can select the value of the sku variable that you require:

FEATURE				            BASIC		    STANDARD	    PREMIUM
Queues					        Available	    Available	    Available
Scheduled messages			    Available	    Available	    Available
Topics					        Not available	Available	    Available
Transactions				    Not available	Available	    Available
De-duplication				    Not available	Available	    Available
Sessions				        Not available	Available	    Available
ForwardTo/SendVia			    Not available	Available	    Available
Message Size				    256 KB		    256 KB		    1 MB
Resource isolation			    Not available	Not available	Available
Geo-Disaster Recovery (Geo-DR)	Not available	Not available	Available							
Availability Zones (AZ) support	Not available	Not available	Available

For more information, please information: https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-messaging-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_autoscale_setting.cl_service_bus_autoscale_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_autoscale_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_service_bus_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_service_bus_private_endpoint_service_bus](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_servicebus_namespace.cl_service_bus](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace) | resource |
| [azurerm_servicebus_namespace_authorization_rule.cl_service_bus_namespace_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace_authorization_rule) | resource |
| [azurerm_servicebus_namespace_network_rule_set.cl_service_bus_network_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace_network_rule_set) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_service_bus_allowed_ips"></a> [cl\_service\_bus\_allowed\_ips](#input\_cl\_service\_bus\_allowed\_ips) | (Optional) One or more IP Addresses, or CIDR Blocks which should be able to access the ServiceBus Namespace. | `list(string)` | `[]` | no |
| <a name="input_cl_service_bus_allowed_subnets"></a> [cl\_service\_bus\_allowed\_subnets](#input\_cl\_service\_bus\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this service bus. | `list(string)` | `[]` | no |
| <a name="input_cl_service_bus_autoscale_settings_default"></a> [cl\_service\_bus\_autoscale\_settings\_default](#input\_cl\_service\_bus\_autoscale\_settings\_default) | (Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 1 and 8. | `number` | `1` | no |
| <a name="input_cl_service_bus_autoscale_settings_maximum"></a> [cl\_service\_bus\_autoscale\_settings\_maximum](#input\_cl\_service\_bus\_autoscale\_settings\_maximum) | (Optional) The maximum number of instances for this resource. Valid values are between 1 and 8. | `number` | `2` | no |
| <a name="input_cl_service_bus_autoscale_settings_metric_name"></a> [cl\_service\_bus\_autoscale\_settings\_metric\_name](#input\_cl\_service\_bus\_autoscale\_settings\_metric\_name) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"NamespaceCpuUsage"` | no |
| <a name="input_cl_service_bus_autoscale_settings_metric_name_memory"></a> [cl\_service\_bus\_autoscale\_settings\_metric\_name\_memory](#input\_cl\_service\_bus\_autoscale\_settings\_metric\_name\_memory) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"NamespaceMemoryUsage"` | no |
| <a name="input_cl_service_bus_autoscale_settings_minimum"></a> [cl\_service\_bus\_autoscale\_settings\_minimum](#input\_cl\_service\_bus\_autoscale\_settings\_minimum) | (Optional) The minimum number of instances for this resource. Valid values are between 1 and 8. | `number` | `1` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_in_operator"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_in\_operator](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_in\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"LessThan"` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_in_threshold"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_in\_threshold](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_in\_threshold) | (Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action. | `number` | `25` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_out_operator"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_out\_operator](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_out\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"GreaterThan"` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_out_threshold"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_out\_threshold](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_out\_threshold) | (Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action. | `number` | `75` | no |
| <a name="input_cl_service_bus_autoscale_settings_statistic"></a> [cl\_service\_bus\_autoscale\_settings\_statistic](#input\_cl\_service\_bus\_autoscale\_settings\_statistic) | (Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max. | `string` | `"Average"` | no |
| <a name="input_cl_service_bus_autoscale_settings_time_aggregation"></a> [cl\_service\_bus\_autoscale\_settings\_time\_aggregation](#input\_cl\_service\_bus\_autoscale\_settings\_time\_aggregation) | (Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total. | `string` | `"Average"` | no |
| <a name="input_cl_service_bus_autoscale_settings_time_grain"></a> [cl\_service\_bus\_autoscale\_settings\_time\_grain](#input\_cl\_service\_bus\_autoscale\_settings\_time\_grain) | (Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string. | `string` | `"PT1M"` | no |
| <a name="input_cl_service_bus_autoscale_settings_time_window"></a> [cl\_service\_bus\_autoscale\_settings\_time\_window](#input\_cl\_service\_bus\_autoscale\_settings\_time\_window) | (Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string. | `string` | `"PT5M"` | no |
| <a name="input_cl_service_bus_diagnostics"></a> [cl\_service\_bus\_diagnostics](#input\_cl\_service\_bus\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "OperationalLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_service_bus_identity_type"></a> [cl\_service\_bus\_identity\_type](#input\_cl\_service\_bus\_identity\_type) | (Optional) Specifies the type of Managed Service Identity that should be configured on this ServiceBus Namespace. Possible values are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both). | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_service_bus_identity_type_ids"></a> [cl\_service\_bus\_identity\_type\_ids](#input\_cl\_service\_bus\_identity\_type\_ids) | (Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this ServiceBus namespace. | `list(string)` | `null` | no |
| <a name="input_cl_service_bus_log_analytics_workspace_id"></a> [cl\_service\_bus\_log\_analytics\_workspace\_id](#input\_cl\_service\_bus\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_service_bus_log_analytics_workspace_name"></a> [cl\_service\_bus\_log\_analytics\_workspace\_name](#input\_cl\_service\_bus\_log\_analytics\_workspace\_name) | (Required) The the log analytics workspace name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_service_bus_name"></a> [cl\_service\_bus\_name](#input\_cl\_service\_bus\_name) | Name of resource name | `string` | `null` | no |
| <a name="input_cl_service_bus_namespace_capacity"></a> [cl\_service\_bus\_namespace\_capacity](#input\_cl\_service\_bus\_namespace\_capacity) | Specifies the capacity. When sku is Premium, capacity can be 1, 2, 4 or 8. When sku is Basic or Standard, capacity can be 0 only | `number` | `2` | no |
| <a name="input_cl_service_bus_namespace_sku"></a> [cl\_service\_bus\_namespace\_sku](#input\_cl\_service\_bus\_namespace\_sku) | Defines which tier to use. Options are Basic, Standard or Premium | `string` | `"Premium"` | no |
| <a name="input_cl_service_bus_postfix"></a> [cl\_service\_bus\_postfix](#input\_cl\_service\_bus\_postfix) | (Required) The  name of the service bus app you are deploying. | `any` | n/a | yes |
| <a name="input_cl_service_bus_premium_messaging_partitions"></a> [cl\_service\_bus\_premium\_messaging\_partitions](#input\_cl\_service\_bus\_premium\_messaging\_partitions) | (Optional) Specifies the number messaging partitions. Only valid when sku is Premium and the minimum number is 1. Possible values include 0, 1, 2, and 4. Defaults to 0 for Standard, Basic namespace. Changing this forces a new resource to be created. | `number` | `1` | no |
| <a name="input_cl_service_bus_private_dns_zone_ids"></a> [cl\_service\_bus\_private\_dns\_zone\_ids](#input\_cl\_service\_bus\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_service_bus_rg_name"></a> [cl\_service\_bus\_rg\_name](#input\_cl\_service\_bus\_rg\_name) | Name of resource name | `string` | n/a | yes |
| <a name="input_cl_service_bus_zone_redundant"></a> [cl\_service\_bus\_zone\_redundant](#input\_cl\_service\_bus\_zone\_redundant) | Whether or not this resource is zone redundant. sku needs to be Premium. Defaults to false. | `bool` | `false` | no |
| <a name="input_env"></a> [env](#input\_env) | The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to the resource | `map(string)` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_azurerm_monitor_diagnostic_setting"></a> [azurerm\_monitor\_diagnostic\_setting](#output\_azurerm\_monitor\_diagnostic\_setting) | n/a |
| <a name="output_azurerm_private_endpoint"></a> [azurerm\_private\_endpoint](#output\_azurerm\_private\_endpoint) | n/a |
| <a name="output_cl_app_service_plan_autoscale_settings"></a> [cl\_app\_service\_plan\_autoscale\_settings](#output\_cl\_app\_service\_plan\_autoscale\_settings) | n/a |
| <a name="output_cl_service_bus"></a> [cl\_service\_bus](#output\_cl\_service\_bus) | Azure service Bus output |
| <a name="output_cl_service_bus_namespace_rule"></a> [cl\_service\_bus\_namespace\_rule](#output\_cl\_service\_bus\_namespace\_rule) | n/a |

## Usage

```terraform
resource "azurerm_private_dns_zone" "service_bus_private_dns_zone" {
  name                = "privatelink.servicebus.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "service_bus_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.service_bus_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_service_bus" {
    source = "../dn-tads_tf-azure-component-library/components/cl_service_bus"
    env                                            = var.env
    postfix                                        = var.postfix
    location                                       = var.location
    cl_service_bus_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_service_bus_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_service_bus_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_service_bus_allowed_subnets                = [azurerm_subnet.test_subnet1.id, azurerm_subnet.test_subnet2.id, azurerm_subnet.test_subnet3.id]
    cl_service_bus_private_dns_zone_ids           = [azurerm_private_dns_zone.service_bus_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "service_bus_private_dns_record" {
  name                                         = "${var.env}-${var.postfix}-app-service-int-pe-record"
  zone_name                                    = azurerm_private_dns_zone.service_bus_private_dns_zone.name
  resource_group_name                          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                                          = var.service_bus_private_record_ttl
  records                                      = module.cl_app_service.cl_service_bus_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                                         = var.tags
}
```
<!-- END_TF_DOCS -->
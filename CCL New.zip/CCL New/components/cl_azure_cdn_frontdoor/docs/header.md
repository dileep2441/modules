# Content Delivery Network (CDN)

A content delivery network (CDN) is a distributed network of servers that can efficiently deliver 	web content to users. A CDN store cached content on edge servers in point-of-presence (POP) 	locations that are close to end users, to minimize latency. 

For more information, please visit: https://learn.microsoft.com/en-us/azure/cdn/cdn-overview

# Azure Front Door (AFD)

Azure Front Door is Microsoft’s modern cloud Content Delivery Network (CDN) that provides fast, reliable, and secure access between your users and your applications’ static and dynamic web content across the globe. Azure Front Door delivers your content using Microsoft’s global edge network with hundreds of global and local points of presence (PoPs) distributed around the world close to both your enterprise and consumer end users.

For more information, please visit: https://learn.microsoft.com/en-us/azure/frontdoor/front-door-overview

```
The following cdn/frontdoor contains two different sku´s : Standard and premium
...
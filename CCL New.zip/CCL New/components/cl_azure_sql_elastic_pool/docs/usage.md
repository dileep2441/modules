 ## Usage
   ```terraform
 module "cl_azure_sql_elastic_pool" {
   source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_elastic_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_azure_sql_elastic_pool_postfix                    = "globaldb"
   cl_azure_sql_elastic_pool_enable                     = true
   cl_azure_sql_elastic_pool_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
   cl_azure_sql_elastic_pool_server_name                = module.cl_azure_sql_server.cl_azure_sql_server.name
   cl_azure_sql_elastic_pool_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
 }
  ```
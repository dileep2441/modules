# Azure Container Registry Component

Azure Container Registry (ACR) is a managed service that allows you to build, store, and manage docker container images/artifacts in a private registry for all types of container deployments. 
This component deploys Azure Container Registry with: IP rules, Content Trust option. Also Private DNS Zone, DNS Zone link for VNET's of allowed subnets, Diagnostic Settings and Private Endpoint for allowed Subnets.

For further detailed overview, please visit: https://docs.microsoft.com/en-us/azure/container-registry/ 

Important! If admin is enabled please store and maintain the user and password as secrets into a KeyVault.

Azure Defender only supported for Linux images with public and shell access:
https://docs.microsoft.com/en-us/azure/security-center/defender-for-container-registries-introduction
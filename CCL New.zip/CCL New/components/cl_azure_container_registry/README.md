<!-- BEGIN_TF_DOCS -->

# Azure Container Registry Component

Azure Container Registry (ACR) is a managed service that allows you to build, store, and manage docker container images/artifacts in a private registry for all types of container deployments. 
This component deploys Azure Container Registry with: IP rules, Content Trust option. Also Private DNS Zone, DNS Zone link for VNET's of allowed subnets, Diagnostic Settings and Private Endpoint for allowed Subnets.

For further detailed overview, please visit: https://docs.microsoft.com/en-us/azure/container-registry/ 

Important! If admin is enabled please store and maintain the user and password as secrets into a KeyVault.

Azure Defender only supported for Linux images with public and shell access:
https://docs.microsoft.com/en-us/azure/security-center/defender-for-container-registries-introduction



## Resources

| Name | Type |
|------|------|
| [azurerm_container_registry.cl_azure_container_registry](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_registry) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_container_registry_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_dns_zone.cl_azure_container_registry_private_dns_zone](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.cl_azure_container_registry_private_dns_zone_virtual_network_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_private_endpoint.cl_azure_container_registry_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_container_registry_admin_enabled"></a> [cl\_azure\_container\_registry\_admin\_enabled](#input\_cl\_azure\_container\_registry\_admin\_enabled) | (Optional) Specifies whether the admin user is enabled. | `bool` | `false` | no |
| <a name="input_cl_azure_container_registry_allowed_subnets"></a> [cl\_azure\_container\_registry\_allowed\_subnets](#input\_cl\_azure\_container\_registry\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this Container Registry. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_container_registry_allowed_vnet_ids"></a> [cl\_azure\_container\_registry\_allowed\_vnet\_ids](#input\_cl\_azure\_container\_registry\_allowed\_vnet\_ids) | (Optional) One or more VNET ID's which should be linked to the Private DNS Zone for ACR name resolution and access trough Private Endpoint. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_container_registry_content_trust_enabled"></a> [cl\_azure\_container\_registry\_content\_trust\_enabled](#input\_cl\_azure\_container\_registry\_content\_trust\_enabled) | (Optional) Enables content trust for the sign of images being pushed to the registry | `bool` | `false` | no |
| <a name="input_cl_azure_container_registry_diagnostics"></a> [cl\_azure\_container\_registry\_diagnostics](#input\_cl\_azure\_container\_registry\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ContainerRegistryRepositoryEvents",<br>    "ContainerRegistryLoginEvents"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_container_registry_dns_zone_enabled"></a> [cl\_azure\_container\_registry\_dns\_zone\_enabled](#input\_cl\_azure\_container\_registry\_dns\_zone\_enabled) | (Optional) Enabled creation of acr dns private zone. | `bool` | `false` | no |
| <a name="input_cl_azure_container_registry_dns_zone_name"></a> [cl\_azure\_container\_registry\_dns\_zone\_name](#input\_cl\_azure\_container\_registry\_dns\_zone\_name) | Is the private link to be associated with the Private DNS Zone. By default it uses recommended Private DNS Zone name | `string` | `"privatelink.azurecr.io"` | no |
| <a name="input_cl_azure_container_registry_georeplication_location"></a> [cl\_azure\_container\_registry\_georeplication\_location](#input\_cl\_azure\_container\_registry\_georeplication\_location) | (Optional) A location where the container registry should be geo-replicated. | `string` | `""` | no |
| <a name="input_cl_azure_container_registry_identity_ids"></a> [cl\_azure\_container\_registry\_identity\_ids](#input\_cl\_azure\_container\_registry\_identity\_ids) | (Optional) Specifies a list of User Assigned Managed Identity IDs to be assigned to this Container Registry | `list(string)` | `null` | no |
| <a name="input_cl_azure_container_registry_identity_type"></a> [cl\_azure\_container\_registry\_identity\_type](#input\_cl\_azure\_container\_registry\_identity\_type) | (Required) Specifies the type of Managed Service Identity that should be configured on this Container Registry. Possible values are SystemAssigned, UserAssigned, SystemAssigned, UserAssigned (to enable both). | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_azure_container_registry_ip_rule_action"></a> [cl\_azure\_container\_registry\_ip\_rule\_action](#input\_cl\_azure\_container\_registry\_ip\_rule\_action) | (Optional) The action for the IP rule. | `string` | `"Allow"` | no |
| <a name="input_cl_azure_container_registry_ip_rule_ranges"></a> [cl\_azure\_container\_registry\_ip\_rule\_ranges](#input\_cl\_azure\_container\_registry\_ip\_rule\_ranges) | (Optional) The CIDR range for the IP rule. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_container_registry_log_analytics_workspace_id"></a> [cl\_azure\_container\_registry\_log\_analytics\_workspace\_id](#input\_cl\_azure\_container\_registry\_log\_analytics\_workspace\_id) | (Required) The log analytics workspace ID required for PostgreSQL diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_container_registry_network_rule_set_default_action"></a> [cl\_azure\_container\_registry\_network\_rule\_set\_default\_action](#input\_cl\_azure\_container\_registry\_network\_rule\_set\_default\_action) | (Optional) The behaviour for requests matching no rules. Either Allow or Deny. Defaults to Deny | `string` | `"Deny"` | no |
| <a name="input_cl_azure_container_registry_postfix"></a> [cl\_azure\_container\_registry\_postfix](#input\_cl\_azure\_container\_registry\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_cl_azure_container_registry_private_dns_zone_id"></a> [cl\_azure\_container\_registry\_private\_dns\_zone\_id](#input\_cl\_azure\_container\_registry\_private\_dns\_zone\_id) | (Optional) existing Private Dns zone id | `string` | `""` | no |
| <a name="input_cl_azure_container_registry_public_network_access_enabled"></a> [cl\_azure\_container\_registry\_public\_network\_access\_enabled](#input\_cl\_azure\_container\_registry\_public\_network\_access\_enabled) | (Optional) Whether public network access is allowed for the container registry. | `bool` | `true` | no |
| <a name="input_cl_azure_container_registry_rg_name"></a> [cl\_azure\_container\_registry\_rg\_name](#input\_cl\_azure\_container\_registry\_rg\_name) | (Required) The resource group for the datafactory. | `any` | n/a | yes |
| <a name="input_cl_azure_container_registry_sku"></a> [cl\_azure\_container\_registry\_sku](#input\_cl\_azure\_container\_registry\_sku) | (Optional) Desire SKU for the Container Registry. Can be Basic, Standard or Premium. | `string` | `"Premium"` | no |
| <a name="input_cl_azure_container_registry_zone_redundancy_enabled"></a> [cl\_azure\_container\_registry\_zone\_redundancy\_enabled](#input\_cl\_azure\_container\_registry\_zone\_redundancy\_enabled) | (Optional) Whether zone redundancy is enabled for this replication location? Defaults to false. | `bool` | `false` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_container_registry"></a> [cl\_azure\_container\_registry](#output\_cl\_azure\_container\_registry) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_container_registry_admin_password"></a> [cl\_azure\_container\_registry\_admin\_password](#output\_cl\_azure\_container\_registry\_admin\_password) | n/a |
| <a name="output_cl_azure_container_registry_admin_username"></a> [cl\_azure\_container\_registry\_admin\_username](#output\_cl\_azure\_container\_registry\_admin\_username) | n/a |
| <a name="output_cl_azure_container_registry_diagnostic_setting"></a> [cl\_azure\_container\_registry\_diagnostic\_setting](#output\_cl\_azure\_container\_registry\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_container_registry_private_dns_zone"></a> [cl\_azure\_container\_registry\_private\_dns\_zone](#output\_cl\_azure\_container\_registry\_private\_dns\_zone) | n/a |
| <a name="output_cl_azure_container_registry_private_endpoint"></a> [cl\_azure\_container\_registry\_private\_endpoint](#output\_cl\_azure\_container\_registry\_private\_endpoint) | n/a |

## Usage

```terraform
module "cl_azure_container_registry" {
    source = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_azure_container_registry_rg_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_allowed_subnets            = [subnetID_1, subnetID_2, subnetID_N]
    cl_azure_container_registry_allowed_vnets              = [vnetID_1, vnetID_2, vnetID_N]
    cl_azure_container_registry_ip_rule_ranges             = ["CIDR_1", "CIDR_N"]
}
```
<!-- END_TF_DOCS -->
## Local values

```terraform
locals {
  timeout_duration = "2h" 
  cl_purview_account_resource_group_name      = var.cl_purview_account_deploy_rg ? azurerm_resource_group.cl_purview_account_rg[0].name : var.cl_purview_account_resource_group_name 
}
```

## Usage

```terraform
module "cl_datafactory" {
    source                                        = "../dn-tads_tf-azure-component-library/components/cl_datafactory_gov"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    suffix                                        = var.suffix
    tags                                         = var.tags
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_deploy_self_hosted_ir          = true/false
    cl_datafactory_deploy_azure_ir                = true/false
}
```
## Usage with VSTS/ADO Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../dn-tads_tf-azure-component-library/components/cl_datafactory_gov"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    suffix                                        = var.suffix
    tags                                         = var.tags
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_deploy_self_hosted_ir          = true/false
    cl_datafactory_deploy_azure_ir                = true/false

    cl_datafactory_repository_type                = "vsts" 
    cl_datafactory_vsts_account_name              = "organization_name"
    cl_datafactory_vsts_branch_name               = "master"
    cl_datafactory_vsts_project_name              = "migration" 
    cl_datafactory_vsts_repository_name           = "migration"
    cl_datafactory_vsts_root_folder               = "/" 
    cl_datafactory_vsts_tenant_id                 = "z567b2579-xxx-457d-a68e-764775adcb646"
}
```
## Usage with GITHUB Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../dn-tads_tf-azure-component-library/components/cl_datafactory_gov"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    suffix                                        = var.suffix
    tags                                         = var.tags
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_deploy_self_hosted_ir          = true/false
    cl_datafactory_deploy_azure_ir                = true/false

    cl_datafactory_repository_type                = "github" 
    cl_datafactory_github_account_name            = "organization_name"
    cl_datafactory_github_branch_name             = "master"
    cl_datafactory_github_git_url                 = "https://domaingithub.com/" 
    cl_datafactory_github_repository_name         = "migration"
    cl_datafactory_github_root_folder             = "/" 
}
```

## Usage

### Azure Devops Pipelines Agent Installation
Unlike Commercial deployments the TeamServicesAgent extension is not avaiable in Azure GOV tenant and there is not ETA to support the feature.  
**Do Not Use cl_windows_vm_enable_devops_agent = true** it would fail.  
The deployment group agent needs to be installed manually using the following installation and configuration guide. 
[Deployment Group Agent Installation](https://docs.microsoft.com/en-us/azure/devops/pipelines/release/deployment-groups/?view=azure-devops)


#### Useful Links
[Get started with the agent](https://docs.microsoft.com/azure/devops/pipelines/agents/agents?view=azure-devops#install).
[Azure Pipelines](https://azure.microsoft.com/en-us/services/devops/pipelines/)
[Deployment Groups](https://aka.ms/832442)
[Personal access tokens](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate)


### Deploy VM
```terraform
// Deploys Windows VM 
//***************************************************************************************************
module "cl_windows_vm_power_bi_gateway" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_windows_vm_gov"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  suffix                                          = var.suffix
  cl_windows_vm_app_name                          = var.power_bi_gateway_vm_app_name
  cl_windows_vm_computer_name                     = var.power_bi_gateway_vm_computer_name  
  cl_windows_vm_image_id                          = var.power_bi_gateway_vm_image_id
  cl_windows_vm_availability_zone                 = var.cl_windows_vm_availability_zone
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = true
  cl_windows_vm_backup_depends_on                 = module.cl_azure_backup.cl_azure_backup_private_endpoint[0]
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host         = true
  cl_windows_vm_enable_domain_join                = true
  cl_windows_vm_domain_name                       = "us.kworld.kpmg.com"
  cl_windows_vm_ou_path                           = "OU=Application,OU=Member Servers v8.0,OU=Windows 2019 Server GSv8.x,OU=AZR,OU=Public Cloud,OU=Server Policies,DC=us,DC=kworld,DC=kpmg,DC=com"
  cl_windows_vm_domain_user_upn                   = "us-svcciacadmin@us.kworld.kpmg.com"
  cl_windows_vm_domain_password                   = data.azurerm_key_vault_secret.win_domain_pass.value 
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix 
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER #Must be Servername_ADM format
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS #Must be random string generated
  tags                                            = var.tags
  cl_windows_vm_core_sa_enabled                   = true
  cl_windows_vm_storage_account_nsg_flow_log_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
  cl_windows_vm_managed_disks                     = {
                                                        data = {
                                                            storage_account_type = "StandardSSD_LRS"
                                                            disk_size            = "80"
                                                            lun                  = "1"
                                                            caching              = "None"
                                                        }
                                                    } 
}
//***************************************************************************************************
```

<!-- BEGIN_TF_DOCS -->

# Azure Windows VM Component

Windows virtual machine is a computer within a computer that provides the user the same experience they would have on the host operating system itself. 
Each virtual machine provides its own virtual hardware including CPUs, memory, hard drives, network interfaces, and other devices.
This Windows VM component will deploy a new resource group, Vnet, Subnet, Public IP, NIC Interface, Windows VM, Recovery Services Vault, Backup policy and a Backup Protected VM.

For more information, please visit: https://docs.microsoft.com/en-us/azure/virtual-machines/windows/overview 



## Resources

| Name | Type |
|------|------|
| [azurerm_availability_set.cl_windows_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_backup_protected_vm.cl_windows_vm_protected_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_vm) | resource |
| [azurerm_managed_disk.cl_windows_vm_managed_disk](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_network_interface.cl_windows_vm_nic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.cl_windows_vm_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.cl_windows_vm_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_windows_vm_azure_bastion_nsgrule_22](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_windows_vm_azure_bastion_nsgrule_3389](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_windows_vm_user_defined_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_watcher_flow_log.cl_windows_vm_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_resource_group.cl_windows_vm_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subnet.cl_windows_vm_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_windows_vm_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.cl_windows_vm_route_table_associate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_machine_data_disk_attachment.cl_windows_vm_managed_disk_attachment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |
| [azurerm_virtual_machine_extension.cl_windows_antimalware_protection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.cl_windows_log_analytics_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.cl_windows_vm_domain_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.cl_windows_vm_guest_config](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_windows_virtual_machine.cl_windows_vm_machine](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_virtual_machine) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_windows_availability_set_id"></a> [cl\_windows\_availability\_set\_id](#input\_cl\_windows\_availability\_set\_id) | (Required) Specifies an already existing Availability set ID in which this Windows Virtual Machine should be located. | `string` | `""` | no |
| <a name="input_cl_windows_deploy_availability_set"></a> [cl\_windows\_deploy\_availability\_set](#input\_cl\_windows\_deploy\_availability\_set) | n/a | `bool` | `false` | no |
| <a name="input_cl_windows_vm_admin_pass"></a> [cl\_windows\_vm\_admin\_pass](#input\_cl\_windows\_vm\_admin\_pass) | (Required) The password of the windows OS admin. Must be random string generated value. Cannot be stored in plaintext code. | `string` | n/a | yes |
| <a name="input_cl_windows_vm_admin_user"></a> [cl\_windows\_vm\_admin\_user](#input\_cl\_windows\_vm\_admin\_user) | (Required) The name of the windows OS admin. Must be Severname\_ADM format. | `string` | n/a | yes |
| <a name="input_cl_windows_vm_app_name"></a> [cl\_windows\_vm\_app\_name](#input\_cl\_windows\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_availability_zone"></a> [cl\_windows\_vm\_availability\_zone](#input\_cl\_windows\_vm\_availability\_zone) | (Required) Specifies the Availability Zone in which this Windows Virtual Machine should be located. | `string` | `""` | no |
| <a name="input_cl_windows_vm_azurerm_subnet_service_enpoints"></a> [cl\_windows\_vm\_azurerm\_subnet\_service\_enpoints](#input\_cl\_windows\_vm\_azurerm\_subnet\_service\_enpoints) | (Optional) The Size of the windows vm. | `list (string)` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_cl_windows_vm_backup_depends_on"></a> [cl\_windows\_vm\_backup\_depends\_on](#input\_cl\_windows\_vm\_backup\_depends\_on) | (Optional) RSV private endpoint must be created first before VM can have backup protection. This variabe should point to the RSV private endpoint | `any` | `null` | no |
| <a name="input_cl_windows_vm_backup_policy_vm_id"></a> [cl\_windows\_vm\_backup\_policy\_vm\_id](#input\_cl\_windows\_vm\_backup\_policy\_vm\_id) | (Optional) The backup policy from the backup vault. | `any` | `null` | no |
| <a name="input_cl_windows_vm_bastion_enable"></a> [cl\_windows\_vm\_bastion\_enable](#input\_cl\_windows\_vm\_bastion\_enable) | (Optional) Enable te creation for azure bastion | `bool` | `false` | no |
| <a name="input_cl_windows_vm_bastion_subnet_prefix"></a> [cl\_windows\_vm\_bastion\_subnet\_prefix](#input\_cl\_windows\_vm\_bastion\_subnet\_prefix) | (Required) The subnet prefix for the bastion. | `any` | `null` | no |
| <a name="input_cl_windows_vm_boot_diagnostics_enabled"></a> [cl\_windows\_vm\_boot\_diagnostics\_enabled](#input\_cl\_windows\_vm\_boot\_diagnostics\_enabled) | (Optional) Enable boot diagnostics for VM | `bool` | `false` | no |
| <a name="input_cl_windows_vm_boot_diagnostics_storage_uri"></a> [cl\_windows\_vm\_boot\_diagnostics\_storage\_uri](#input\_cl\_windows\_vm\_boot\_diagnostics\_storage\_uri) | (Optional) The Primary/Secondary Endpoint for the Azure Storage Account which should be used to store Boot Diagnostics, including Console Output and Screenshots from the Hypervisor. | `string` | `null` | no |
| <a name="input_cl_windows_vm_computer_name"></a> [cl\_windows\_vm\_computer\_name](#input\_cl\_windows\_vm\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | n/a | yes |
| <a name="input_cl_windows_vm_core_sa_enabled"></a> [cl\_windows\_vm\_core\_sa\_enabled](#input\_cl\_windows\_vm\_core\_sa\_enabled) | (Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_deploy_rg"></a> [cl\_windows\_vm\_deploy\_rg](#input\_cl\_windows\_vm\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_deploy_subnet"></a> [cl\_windows\_vm\_deploy\_subnet](#input\_cl\_windows\_vm\_deploy\_subnet) | (Optional) A boolean to enable/disable the deployment of a subnet for the VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_deploy_subnet_nsg"></a> [cl\_windows\_vm\_deploy\_subnet\_nsg](#input\_cl\_windows\_vm\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_domain_name"></a> [cl\_windows\_vm\_domain\_name](#input\_cl\_windows\_vm\_domain\_name) | (Optional) Name of the domain to join | `string` | `""` | no |
| <a name="input_cl_windows_vm_domain_password"></a> [cl\_windows\_vm\_domain\_password](#input\_cl\_windows\_vm\_domain\_password) | (Optional) Password of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_cl_windows_vm_domain_user_upn"></a> [cl\_windows\_vm\_domain\_user\_upn](#input\_cl\_windows\_vm\_domain\_user\_upn) | (Optional) UPN of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_cl_windows_vm_enable_antimalware_protection"></a> [cl\_windows\_vm\_enable\_antimalware\_protection](#input\_cl\_windows\_vm\_enable\_antimalware\_protection) | (Optional) Toggle the antimalware protection extension feature. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_enable_automatic_updates"></a> [cl\_windows\_vm\_enable\_automatic\_updates](#input\_cl\_windows\_vm\_enable\_automatic\_updates) | (Optional) Boolean to enable automatic updates. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_enable_backup"></a> [cl\_windows\_vm\_enable\_backup](#input\_cl\_windows\_vm\_enable\_backup) | (Optional) Toggle the backup feature. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_enable_domain_join"></a> [cl\_windows\_vm\_enable\_domain\_join](#input\_cl\_windows\_vm\_enable\_domain\_join) | (Optional) Toggle the domain join feature. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_enable_encryption_at_host"></a> [cl\_windows\_vm\_enable\_encryption\_at\_host](#input\_cl\_windows\_vm\_enable\_encryption\_at\_host) | (Optional) Boolean to enable encryption\_at\_host. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_enable_guest_config"></a> [cl\_windows\_vm\_enable\_guest\_config](#input\_cl\_windows\_vm\_enable\_guest\_config) | (Optional) Toggle the guest config extension feature. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_enable_log_analytics_settings"></a> [cl\_windows\_vm\_enable\_log\_analytics\_settings](#input\_cl\_windows\_vm\_enable\_log\_analytics\_settings) | (Optional) Toggle the log analytics extension on or off. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_enable_managed_disk_availability_zone"></a> [cl\_windows\_vm\_enable\_managed\_disk\_availability\_zone](#input\_cl\_windows\_vm\_enable\_managed\_disk\_availability\_zone) | (Optional) If set to true enable avail zone for managed disk | `bool` | `true` | no |
| <a name="input_cl_windows_vm_identity_ids"></a> [cl\_windows\_vm\_identity\_ids](#input\_cl\_windows\_vm\_identity\_ids) | (Optional) A list of User Managed Identity ID's which should be assigned to the Windows Virtual Machine | `list(string)` | `[]` | no |
| <a name="input_cl_windows_vm_identity_type"></a> [cl\_windows\_vm\_identity\_type](#input\_cl\_windows\_vm\_identity\_type) | (Optional) Managed identity type for VM | `string` | `null` | no |
| <a name="input_cl_windows_vm_image_id"></a> [cl\_windows\_vm\_image\_id](#input\_cl\_windows\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_license_type"></a> [cl\_windows\_vm\_license\_type](#input\_cl\_windows\_vm\_license\_type) | (Optional) Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows\_Client and Windows\_Server. | `string` | `"Windows_Server"` | no |
| <a name="input_cl_windows_vm_log_analytics_primary_shared_key"></a> [cl\_windows\_vm\_log\_analytics\_primary\_shared\_key](#input\_cl\_windows\_vm\_log\_analytics\_primary\_shared\_key) | (Required) The log analytics workspace primary shared key. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_log_analytics_workspace_id"></a> [cl\_windows\_vm\_log\_analytics\_workspace\_id](#input\_cl\_windows\_vm\_log\_analytics\_workspace\_id) | (Required) The log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_machine_postfix_enable"></a> [cl\_windows\_vm\_machine\_postfix\_enable](#input\_cl\_windows\_vm\_machine\_postfix\_enable) | (Optional) Enable if a dedicated postfix name needs to be enabled for VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_managed_disks"></a> [cl\_windows\_vm\_managed\_disks](#input\_cl\_windows\_vm\_managed\_disks) | (Optional) Map containing the managed disks attributes | <pre>map(object({<br>    storage_account_type = string<br>    disk_size            = string<br>    lun                  = string<br>    caching              = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_windows_vm_nsg_sa_allowed_pe_subnet_ids"></a> [cl\_windows\_vm\_nsg\_sa\_allowed\_pe\_subnet\_ids](#input\_cl\_windows\_vm\_nsg\_sa\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_windows_vm_nsg_sa_allowed_vnet_subnet_ids"></a> [cl\_windows\_vm\_nsg\_sa\_allowed\_vnet\_subnet\_ids](#input\_cl\_windows\_vm\_nsg\_sa\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_windows_vm_os_disk_caching"></a> [cl\_windows\_vm\_os\_disk\_caching](#input\_cl\_windows\_vm\_os\_disk\_caching) | (Optional) The caching for the os disk of the windows vm. | `string` | `"ReadWrite"` | no |
| <a name="input_cl_windows_vm_os_disk_disk_size_gb"></a> [cl\_windows\_vm\_os\_disk\_disk\_size\_gb](#input\_cl\_windows\_vm\_os\_disk\_disk\_size\_gb) | (Optional) The disk size gb for the os disk of the windows vm. | `string` | `"128"` | no |
| <a name="input_cl_windows_vm_os_disk_storage_account_type"></a> [cl\_windows\_vm\_os\_disk\_storage\_account\_type](#input\_cl\_windows\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"Standard_LRS"` | no |
| <a name="input_cl_windows_vm_os_disk_write_accelerator_enabled"></a> [cl\_windows\_vm\_os\_disk\_write\_accelerator\_enabled](#input\_cl\_windows\_vm\_os\_disk\_write\_accelerator\_enabled) | (Optional) Boolean to enable write accelerator enabled. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_os_ultra_ssd_enabled"></a> [cl\_windows\_vm\_os\_ultra\_ssd\_enabled](#input\_cl\_windows\_vm\_os\_ultra\_ssd\_enabled) | (Optional) Boolean to enable ultra ssd enabled. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_ou_path"></a> [cl\_windows\_vm\_ou\_path](#input\_cl\_windows\_vm\_ou\_path) | (Optional) OU path to us during domain join | `string` | `""` | no |
| <a name="input_cl_windows_vm_postfix"></a> [cl\_windows\_vm\_postfix](#input\_cl\_windows\_vm\_postfix) | (Optional) Unique postfix name for VM. | `string` | `""` | no |
| <a name="input_cl_windows_vm_private_ip_address"></a> [cl\_windows\_vm\_private\_ip\_address](#input\_cl\_windows\_vm\_private\_ip\_address) | (Optional) Private IP of VM defined by end user if allocation = static | `string` | `""` | no |
| <a name="input_cl_windows_vm_private_ip_address_allocation"></a> [cl\_windows\_vm\_private\_ip\_address\_allocation](#input\_cl\_windows\_vm\_private\_ip\_address\_allocation) | (Required) The allocation method used for the Private IP Address. Possible values are Dynamic and Static. | `string` | `"Dynamic"` | no |
| <a name="input_cl_windows_vm_provision_vm_agent"></a> [cl\_windows\_vm\_provision\_vm\_agent](#input\_cl\_windows\_vm\_provision\_vm\_agent) | (Optional) Boolean to enable provision vm agent. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_recovery_vault_name"></a> [cl\_windows\_vm\_recovery\_vault\_name](#input\_cl\_windows\_vm\_recovery\_vault\_name) | (Optional) The name of recovery backup vault. | `any` | `null` | no |
| <a name="input_cl_windows_vm_rg_backup_name"></a> [cl\_windows\_vm\_rg\_backup\_name](#input\_cl\_windows\_vm\_rg\_backup\_name) | (Optional) The RG destination of the windows vm backup. | `any` | `null` | no |
| <a name="input_cl_windows_vm_rg_name"></a> [cl\_windows\_vm\_rg\_name](#input\_cl\_windows\_vm\_rg\_name) | (Optional) The name of the windows VM resource group if cl\_windows\_vm\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_windows_vm_route_table_id"></a> [cl\_windows\_vm\_route\_table\_id](#input\_cl\_windows\_vm\_route\_table\_id) | (Conditionally Required) if deploying subnet. | `any` | `null` | no |
| <a name="input_cl_windows_vm_sa_log_analytics_workspace_id"></a> [cl\_windows\_vm\_sa\_log\_analytics\_workspace\_id](#input\_cl\_windows\_vm\_sa\_log\_analytics\_workspace\_id) | (Required) The reosurce ID of log analytics workspace for NSG flow logs storage acct. Not just the workspace ID for VM extensions | `string` | `null` | no |
| <a name="input_cl_windows_vm_size"></a> [cl\_windows\_vm\_size](#input\_cl\_windows\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_DS1_v2"` | no |
| <a name="input_cl_windows_vm_storage_account_nsg_flow_log_id"></a> [cl\_windows\_vm\_storage\_account\_nsg\_flow\_log\_id](#input\_cl\_windows\_vm\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_cl_windows_vm_subnet_id"></a> [cl\_windows\_vm\_subnet\_id](#input\_cl\_windows\_vm\_subnet\_id) | (Optional) The subnet ID where the Windows VM will be deployed to. Use this only if cl\_windows\_vm\_deploy\_subnet = false. | `any` | `null` | no |
| <a name="input_cl_windows_vm_subnet_prefix"></a> [cl\_windows\_vm\_subnet\_prefix](#input\_cl\_windows\_vm\_subnet\_prefix) | (Optional) The prefix of the windows vm subnet. | `any` | `null` | no |
| <a name="input_cl_windows_vm_timezone"></a> [cl\_windows\_vm\_timezone](#input\_cl\_windows\_vm\_timezone) | (Optional) The timezone of the windows vm. | `any` | `null` | no |
| <a name="input_cl_windows_vm_user_defined_nsg_rules"></a> [cl\_windows\_vm\_user\_defined\_nsg\_rules](#input\_cl\_windows\_vm\_user\_defined\_nsg\_rules) | (Optional) Define additional NSG rules | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)<br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_cl_windows_vm_vnet_name"></a> [cl\_windows\_vm\_vnet\_name](#input\_cl\_windows\_vm\_vnet\_name) | (Required) The name of the core vnet required for the windows vm subnet. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_vnet_rg_name"></a> [cl\_windows\_vm\_vnet\_rg\_name](#input\_cl\_windows\_vm\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in. | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration     = "2h"
  cl_windows_vm_rg     = var.cl_windows_vm_deploy_rg ? azurerm_resource_group.cl_windows_vm_rg[0].name : var.cl_windows_vm_rg_name
  cl_windows_availability_set_id     = var.cl_windows_deploy_availability_set ? azurerm_availability_set.cl_windows_availability_set[0].name : var.cl_windows_availability_set_id
  cl_windows_vm_subnet = var.cl_windows_vm_deploy_subnet ? azurerm_subnet.cl_windows_vm_subnet[0] : null
  cl_windows_vm_nsg    = var.cl_windows_vm_deploy_subnet_nsg ? azurerm_network_security_group.cl_windows_vm_nsg[0] : null
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_windows_log_analytics_settings"></a> [cl\_windows\_log\_analytics\_settings](#output\_cl\_windows\_log\_analytics\_settings) | n/a |
| <a name="output_cl_windows_vm_admin_username"></a> [cl\_windows\_vm\_admin\_username](#output\_cl\_windows\_vm\_admin\_username) | n/a |
| <a name="output_cl_windows_vm_domain_join"></a> [cl\_windows\_vm\_domain\_join](#output\_cl\_windows\_vm\_domain\_join) | n/a |
| <a name="output_cl_windows_vm_machine"></a> [cl\_windows\_vm\_machine](#output\_cl\_windows\_vm\_machine) | n/a |
| <a name="output_cl_windows_vm_managed_disk"></a> [cl\_windows\_vm\_managed\_disk](#output\_cl\_windows\_vm\_managed\_disk) | n/a |
| <a name="output_cl_windows_vm_nic"></a> [cl\_windows\_vm\_nic](#output\_cl\_windows\_vm\_nic) | n/a |
| <a name="output_cl_windows_vm_nsg"></a> [cl\_windows\_vm\_nsg](#output\_cl\_windows\_vm\_nsg) | n/a |
| <a name="output_cl_windows_vm_protected_vm"></a> [cl\_windows\_vm\_protected\_vm](#output\_cl\_windows\_vm\_protected\_vm) | n/a |
| <a name="output_cl_windows_vm_rg"></a> [cl\_windows\_vm\_rg](#output\_cl\_windows\_vm\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_windows_vm_subnet"></a> [cl\_windows\_vm\_subnet](#output\_cl\_windows\_vm\_subnet) | n/a |
| <a name="output_cl_windows_vm_user_defined_nsg_rules"></a> [cl\_windows\_vm\_user\_defined\_nsg\_rules](#output\_cl\_windows\_vm\_user\_defined\_nsg\_rules) | n/a |


## Usage

### Azure Devops Pipelines Agent Installation
Unlike Commercial deployments the TeamServicesAgent extension is not avaiable in Azure GOV tenant and there is not ETA to support the feature.  
**Do Not Use cl_windows_vm_enable_devops_agent = true** it would fail.  
The deployment group agent needs to be installed manually using the following installation and configuration guide. 
[Deployment Group Agent Installation](https://docs.microsoft.com/en-us/azure/devops/pipelines/release/deployment-groups/?view=azure-devops)


#### Useful Links
[Get started with the agent](https://docs.microsoft.com/azure/devops/pipelines/agents/agents?view=azure-devops#install).
[Azure Pipelines](https://azure.microsoft.com/en-us/services/devops/pipelines/)
[Deployment Groups](https://aka.ms/832442)
[Personal access tokens](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate)


### Deploy VM
```terraform
// Deploys Windows VM 
//***************************************************************************************************
module "cl_windows_vm_power_bi_gateway" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_windows_vm_gov"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  suffix                                          = var.suffix
  cl_windows_vm_app_name                          = var.power_bi_gateway_vm_app_name
  cl_windows_vm_computer_name                     = var.power_bi_gateway_vm_computer_name  
  cl_windows_vm_image_id                          = var.power_bi_gateway_vm_image_id
  cl_windows_vm_availability_zone                 = var.cl_windows_vm_availability_zone
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = true
  cl_windows_vm_backup_depends_on                 = module.cl_azure_backup.cl_azure_backup_private_endpoint[0]
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host         = true
  cl_windows_vm_enable_domain_join                = true
  cl_windows_vm_domain_name                       = "us.kworld.kpmg.com"
  cl_windows_vm_ou_path                           = "OU=Application,OU=Member Servers v8.0,OU=Windows 2019 Server GSv8.x,OU=AZR,OU=Public Cloud,OU=Server Policies,DC=us,DC=kworld,DC=kpmg,DC=com"
  cl_windows_vm_domain_user_upn                   = "us-svcciacadmin@us.kworld.kpmg.com"
  cl_windows_vm_domain_password                   = data.azurerm_key_vault_secret.win_domain_pass.value 
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix 
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER #Must be Servername_ADM format
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS #Must be random string generated
  tags                                            = var.tags
  cl_windows_vm_core_sa_enabled                   = true
  cl_windows_vm_storage_account_nsg_flow_log_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
  cl_windows_vm_managed_disks                     = {
                                                        data = {
                                                            storage_account_type = "StandardSSD_LRS"
                                                            disk_size            = "80"
                                                            lun                  = "1"
                                                            caching              = "None"
                                                        }
                                                    } 
}
//***************************************************************************************************
```
<!-- END_TF_DOCS -->
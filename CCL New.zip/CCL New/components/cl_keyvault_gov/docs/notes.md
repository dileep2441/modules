#### Note:
```terraform
#Peering must be established between shared svcs and spoke, identity and spoke
#A centralized KV private dns zone record set must be present in identity subscription
#Self hosted runner subnet needs to be whitelisted on the KV vnet rules
#KeyVault Adminstrator role needs to be granted to SPN on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
#KeyVault Secrets user/crypto user/certificates officer role needs to be granted to source comp Managed Identitity on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
```
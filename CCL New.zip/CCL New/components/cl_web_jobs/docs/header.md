# Azure Web Jobs Component

WebJobs is a feature of Azure App Service that enables you to run a program or script in the same instance as a web app, API app, or mobile app.
There are two types of web jobs: continuous and triggered. Continuous starts immediately, runs in all instances of the web app and supports remote debugging.
Triggered web jobs start manually, runs on a single instance and does not support remote debugging.
This component will deploy Web Jobs app service, private endpoint, diagnostics Settings and binds the app service to the integration subnet.

For more information, please visit: https://docs.microsoft.com/en-us/azure/app-service/webjobs-create 

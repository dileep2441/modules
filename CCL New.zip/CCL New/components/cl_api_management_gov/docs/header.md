# Azure API Management Component

Azure API Management is a fully managed service that enables customers to publish, secure, transform, maintain, and monitor APIs.
It can be leveraged as a "front-door" through which external and internal applications can access data or business logic that is running in Azure or on-premises.
This component will create an Azure API Management service and deploy the following resources for it: Subnet, route table, NSG, Inbound and Outbound NSG rules, custom domain & diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/api-management/api-management-key-concepts
<!-- BEGIN_TF_DOCS -->

# Azure API Management Component

Azure API Management is a fully managed service that enables customers to publish, secure, transform, maintain, and monitor APIs.
It can be leveraged as a "front-door" through which external and internal applications can access data or business logic that is running in Azure or on-premises.
This component will create an Azure API Management service and deploy the following resources for it: Subnet, route table, NSG, Inbound and Outbound NSG rules, custom domain & diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/api-management/api-management-key-concepts



## Resources

| Name | Type |
|------|------|
| [azurerm_api_management.cl_api_mgmt](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management) | resource |
| [azurerm_api_management_custom_domain.cl_api_mgmt_custom_domain](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management_custom_domain) | resource |
| [azurerm_monitor_diagnostic_setting.cl_api_mgmt_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_api_mgmt_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-api-mgmt-3443-inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-api-mgmt-3443-newinbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-ad-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-cloud-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-eventhub-5671-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-eventhub-https-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-files-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-kv-newoutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-monitor-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-smtp-25-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-smtp-25028-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-smtp-587-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-sql-newoutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-sql-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-azure-storage-outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-https-inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-lb-6390-newinbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-redis-6381-inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-redis-6382-inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_api_mgmt_subnet_nsgrule_allow-redis-6383-inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_watcher_flow_log.cl_api_management_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_subnet.cl_api_mgmt_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_api_mgmt_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.rt_associate_api_mgmt_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_api_mgmt_core_sa_enabled"></a> [cl\_api\_mgmt\_core\_sa\_enabled](#input\_cl\_api\_mgmt\_core\_sa\_enabled) | (Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs. | `bool` | `true` | no |
| <a name="input_cl_api_mgmt_deploy_custom_domain"></a> [cl\_api\_mgmt\_deploy\_custom\_domain](#input\_cl\_api\_mgmt\_deploy\_custom\_domain) | (Optional) Specifies if custom domain for API management should be deployed or not. | `bool` | `false` | no |
| <a name="input_cl_api_mgmt_developer_portals"></a> [cl\_api\_mgmt\_developer\_portals](#input\_cl\_api\_mgmt\_developer\_portals) | (Optional) Array for API management developer portal deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_api_mgmt_diagnostic"></a> [cl\_api\_mgmt\_diagnostic](#input\_cl\_api\_mgmt\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_api_mgmt_identity_identity_ids"></a> [cl\_api\_mgmt\_identity\_identity\_ids](#input\_cl\_api\_mgmt\_identity\_identity\_ids) | (Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned. | `list(string)` | `null` | no |
| <a name="input_cl_api_mgmt_identity_type"></a> [cl\_api\_mgmt\_identity\_type](#input\_cl\_api\_mgmt\_identity\_type) | (Optional) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_api_mgmt_inbound_cidrs"></a> [cl\_api\_mgmt\_inbound\_cidrs](#input\_cl\_api\_mgmt\_inbound\_cidrs) | (Required) A list of CIDRs to allow to communicate with API Management. | `list(string)` | n/a | yes |
| <a name="input_cl_api_mgmt_log_analytics_workspace_id"></a> [cl\_api\_mgmt\_log\_analytics\_workspace\_id](#input\_cl\_api\_mgmt\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_api_mgmt_managements"></a> [cl\_api\_mgmt\_managements](#input\_cl\_api\_mgmt\_managements) | (Optional) Array for API management managements deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_api_mgmt_nsg_flow_log_postfix"></a> [cl\_api\_mgmt\_nsg\_flow\_log\_postfix](#input\_cl\_api\_mgmt\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | n/a | yes |
| <a name="input_cl_api_mgmt_nsg_sa_allowed_pe_subnet_ids"></a> [cl\_api\_mgmt\_nsg\_sa\_allowed\_pe\_subnet\_ids](#input\_cl\_api\_mgmt\_nsg\_sa\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_api_mgmt_nsg_sa_allowed_vnet_subnet_ids"></a> [cl\_api\_mgmt\_nsg\_sa\_allowed\_vnet\_subnet\_ids](#input\_cl\_api\_mgmt\_nsg\_sa\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_api_mgmt_nsg_sa_private_dns_zone_ids"></a> [cl\_api\_mgmt\_nsg\_sa\_private\_dns\_zone\_ids](#input\_cl\_api\_mgmt\_nsg\_sa\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_api_mgmt_portals"></a> [cl\_api\_mgmt\_portals](#input\_cl\_api\_mgmt\_portals) | (Optional) Array for API management portals deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_api_mgmt_proxies"></a> [cl\_api\_mgmt\_proxies](#input\_cl\_api\_mgmt\_proxies) | (Optional) Array for API management proxy deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    default_ssl_binding           = bool<br>    key_vault_id                  = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_api_mgmt_publisher_email"></a> [cl\_api\_mgmt\_publisher\_email](#input\_cl\_api\_mgmt\_publisher\_email) | (Required) The email of publisher/company. | `string` | n/a | yes |
| <a name="input_cl_api_mgmt_publisher_name"></a> [cl\_api\_mgmt\_publisher\_name](#input\_cl\_api\_mgmt\_publisher\_name) | (Required) The name of publisher/company. | `string` | n/a | yes |
| <a name="input_cl_api_mgmt_rg_name"></a> [cl\_api\_mgmt\_rg\_name](#input\_cl\_api\_mgmt\_rg\_name) | (Required) The name of the resource group where the api management will be deployed to. | `any` | n/a | yes |
| <a name="input_cl_api_mgmt_route_table"></a> [cl\_api\_mgmt\_route\_table](#input\_cl\_api\_mgmt\_route\_table) | (Required) The route\_table id allowed to connect to this API Mgmt. | `string` | n/a | yes |
| <a name="input_cl_api_mgmt_scms"></a> [cl\_api\_mgmt\_scms](#input\_cl\_api\_mgmt\_scms) | (Optional) Array for API management SCM deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_api_mgmt_sku_name"></a> [cl\_api\_mgmt\_sku\_name](#input\_cl\_api\_mgmt\_sku\_name) | (Optional) sku\_name is a string consisting of two parts separated by an underscore(\_) | `string` | `"Premium_1"` | no |
| <a name="input_cl_api_mgmt_storage_account_nsg_flow_log_id"></a> [cl\_api\_mgmt\_storage\_account\_nsg\_flow\_log\_id](#input\_cl\_api\_mgmt\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_cl_api_mgmt_subnet_prefix"></a> [cl\_api\_mgmt\_subnet\_prefix](#input\_cl\_api\_mgmt\_subnet\_prefix) | (Required) The prefix of the api mgmt subnet. | `any` | n/a | yes |
| <a name="input_cl_api_mgmt_subnet_service_enpoints"></a> [cl\_api\_mgmt\_subnet\_service\_enpoints](#input\_cl\_api\_mgmt\_subnet\_service\_enpoints) | (Optional) The service endpoints for the api mgmt subnet. | `list(string)` | <pre>[<br>  "Microsoft.Sql",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_cl_api_mgmt_subnet_vnet_name"></a> [cl\_api\_mgmt\_subnet\_vnet\_name](#input\_cl\_api\_mgmt\_subnet\_vnet\_name) | (Required) The name of the core vnet required for the Api mgmt subnet. | `any` | n/a | yes |
| <a name="input_cl_api_mgmt_subnet_vnet_rg_name"></a> [cl\_api\_mgmt\_subnet\_vnet\_rg\_name](#input\_cl\_api\_mgmt\_subnet\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_api_mgmt"></a> [cl\_api\_mgmt](#output\_cl\_api\_mgmt) | Outputs ********************************************************************************************** |
| <a name="output_cl_api_mgmt_diagnostic_setting"></a> [cl\_api\_mgmt\_diagnostic\_setting](#output\_cl\_api\_mgmt\_diagnostic\_setting) | n/a |
| <a name="output_cl_api_mgmt_subnet"></a> [cl\_api\_mgmt\_subnet](#output\_cl\_api\_mgmt\_subnet) | n/a |
| <a name="output_cl_api_mgmt_subnet_nsg"></a> [cl\_api\_mgmt\_subnet\_nsg](#output\_cl\_api\_mgmt\_subnet\_nsg) | n/a |


## Usage

```terraform
// Azure API Management
//**********************************************************************************************
 module "cl_api_mgmt" {
  source                                    = "../dn-tads_tf-azure-component-library/components/cl_api_mgmt_gov"
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  tags                                         = var.tags
  cl_api_mgmt_rg_name                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_api_mgmt_log_analytics_workspace_id    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_api_mgmt_route_table                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_api_mgmt_subnet_vnet_rg_name           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_api_mgmt_subnet_vnet_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_api_mgmt_core_sa_enabled               = true
  cl_api_mgmt_storage_account_nsg_flow_log_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
  cl_api_mgmt_nsg_flow_log_postfix          = var.cl_api_mgmt_nsg_flow_log_postfix   
  cl_api_mgmt_subnet_prefix                 = ["55.0.3.0/24"]
  cl_api_mgmt_publisher_name                = "My-Company-KPMG"
  cl_api_mgmt_publisher_email               = "company@terraform.io"
  cl_api_mgmt_inbound_cidrs                 = ["199.206.0.0/15"]
  cl_api_mgmt_proxies                       = {
    api_mgmt_proxy = {
      host_name                     = "api.ati.kpmg.com.br"
      certificate                   = var.APP_GW_TLS_CERT_PFX_BASE64
      certificate_password          = var.APP_GW_TLS_CERT_PASS
      negotiate_client_certificate  = false
      default_ssl_binding           = false
      key_vault_id                  = null
    }
  }
  cl_api_mgmt_developer_portals             = {
    api_mgmt_proxy = {
      host_name                     = "portal.ati.kpmg.com.br"
      certificate                   = var.APP_GW_TLS_CERT_PFX_BASE64
      certificate_password          = var.APP_GW_TLS_CERT_PASS
      negotiate_client_certificate  = false
      key_vault_id                  = null
    }
  }  
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
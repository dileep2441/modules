<!-- BEGIN_TF_DOCS -->

# Azure SignalR Component
Azure SignalR Service simplifies the process of adding real-time web functionality to applications over HTTP. This real-time functionality allows the service to push content updates to connected clients, such as a single page web or mobile application. As a result, clients are updated without the need to poll the server, or submit new HTTP requests for updates.



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_azure_signalr_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_azure_signalr_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_signalr_service.cl_azure_signalr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/signalr_service) | resource |
| [azurerm_signalr_service_network_acl.cl_azure_signalr_network_acl](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/signalr_service_network_acl) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_signalr_allowed_origins"></a> [cl\_azure\_signalr\_allowed\_origins](#input\_cl\_azure\_signalr\_allowed\_origins) | (Optional) A list of origins which should be able to make cross-origin calls. * can be used to allow all calls. | `list(string)` | <pre>[<br>  "*"<br>]</pre> | no |
| <a name="input_cl_azure_signalr_category_pattern"></a> [cl\_azure\_signalr\_category\_pattern](#input\_cl\_azure\_signalr\_category\_pattern) | (Optional) The categories to match on, or * for all. | `list(string)` | <pre>[<br>  "*"<br>]</pre> | no |
| <a name="input_cl_azure_signalr_diagnostics"></a> [cl\_azure\_signalr\_diagnostics](#input\_cl\_azure\_signalr\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AllLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_signalr_event_pattern"></a> [cl\_azure\_signalr\_event\_pattern](#input\_cl\_azure\_signalr\_event\_pattern) | (Optional)  The events to match on, or * for all. | `list(string)` | <pre>[<br>  "*"<br>]</pre> | no |
| <a name="input_cl_azure_signalr_hub_pattern"></a> [cl\_azure\_signalr\_hub\_pattern](#input\_cl\_azure\_signalr\_hub\_pattern) | (Optional) The hubs to match on, or * for all. | `list(string)` | <pre>[<br>  "*"<br>]</pre> | no |
| <a name="input_cl_azure_signalr_log_analytics_workspace_id"></a> [cl\_azure\_signalr\_log\_analytics\_workspace\_id](#input\_cl\_azure\_signalr\_log\_analytics\_workspace\_id) | (Required) The id of the synapse workspace. | `string` | n/a | yes |
| <a name="input_cl_azure_signalr_pe_subnet_ids"></a> [cl\_azure\_signalr\_pe\_subnet\_ids](#input\_cl\_azure\_signalr\_pe\_subnet\_ids) | (Required) The id of the SignalR Private Endpoint subnet id. | `list(string)` | n/a | yes |
| <a name="input_cl_azure_signalr_postfix"></a> [cl\_azure\_signalr\_postfix](#input\_cl\_azure\_signalr\_postfix) | (Required) The id of the synapse keyvault id. | `string` | n/a | yes |
| <a name="input_cl_azure_signalr_private_allowed_request_types"></a> [cl\_azure\_signalr\_private\_allowed\_request\_types](#input\_cl\_azure\_signalr\_private\_allowed\_request\_types) | (Optional) The allowed request types for the Private Endpoint Connection. Possible values are ClientConnection, ServerConnection, RESTAPI and Trace | `list(string)` | <pre>[<br>  "ClientConnection",<br>  "ServerConnection",<br>  "RESTAPI",<br>  "Trace"<br>]</pre> | no |
| <a name="input_cl_azure_signalr_private_dns_zone_id"></a> [cl\_azure\_signalr\_private\_dns\_zone\_id](#input\_cl\_azure\_signalr\_private\_dns\_zone\_id) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_signalr_public_allowed_request_types"></a> [cl\_azure\_signalr\_public\_allowed\_request\_types](#input\_cl\_azure\_signalr\_public\_allowed\_request\_types) | (Optional) The allowed request types for the public network. Possible values are ClientConnection, ServerConnection, RESTAPI and Trace. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_signalr_resource_group_name"></a> [cl\_azure\_signalr\_resource\_group\_name](#input\_cl\_azure\_signalr\_resource\_group\_name) | (Required) The name of the resource group where the synapse resources will be deployed to. | `string` | n/a | yes |
| <a name="input_cl_azure_signalr_service_mode"></a> [cl\_azure\_signalr\_service\_mode](#input\_cl\_azure\_signalr\_service\_mode) | (Optional) Specifies the service mode. Possible values are Classic, Default and Serverless. Defaults to Default | `string` | `"Serverless"` | no |
| <a name="input_cl_azure_signalr_sku_capacity"></a> [cl\_azure\_signalr\_sku\_capacity](#input\_cl\_azure\_signalr\_sku\_capacity) | (Required) Specifies the number of units associated with this SignalR service. Valid values are 1, 2, 5, 10, 20, 50 and 100 | `number` | `1` | no |
| <a name="input_cl_azure_signalr_sku_name"></a> [cl\_azure\_signalr\_sku\_name](#input\_cl\_azure\_signalr\_sku\_name) | (Required) Specifies which tier to use. Valid values are Free\_F1, Standard\_S1, Premium\_P1 is not supported for 2.99.0 provider version | `string` | `"Standard_S1"` | no |
| <a name="input_cl_azure_signalr_upstream_endpoint"></a> [cl\_azure\_signalr\_upstream\_endpoint](#input\_cl\_azure\_signalr\_upstream\_endpoint) | (Optional) The allowed request types for the Private Endpoint Connection. Possible values are ClientConnection, ServerConnection, RESTAPI and Trace | <pre>map(object({<br>    category_pattern  = list(string)<br>    event_pattern     = list(string)<br>    hub_pattern       = list(string)<br>    url_template      = string<br>  }))</pre> | n/a | yes |
| <a name="input_cl_azure_signalr_url_template"></a> [cl\_azure\_signalr\_url\_template](#input\_cl\_azure\_signalr\_url\_template) | (Optional) The upstream URL Template. This can be a url or a template such as http://host.com/{hub}/api/{category}/{event}. | `string` | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h" 
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_signalr"></a> [cl\_azure\_signalr](#output\_cl\_azure\_signalr) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_signalr_diagnostic_setting"></a> [cl\_azure\_signalr\_diagnostic\_setting](#output\_cl\_azure\_signalr\_diagnostic\_setting) | n/a |
| <a name="output_cl_azure_signalr_network_acl"></a> [cl\_azure\_signalr\_network\_acl](#output\_cl\_azure\_signalr\_network\_acl) | n/a |
| <a name="output_cl_azure_signalr_private_endpoint"></a> [cl\_azure\_signalr\_private\_endpoint](#output\_cl\_azure\_signalr\_private\_endpoint) | n/a |

## Usage
```terraform
module "cl_azure_signalr" {
  source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_signalr"
  env                                                  = var.env
  postfix                                              = var.postfix
  location                                             = var.location
  cl_azure_signalr_postfix                             = var.cl_azure_signalr_postfix
  cl_azure_signalr_resource_group_name                 = var.cl_azure_signalr_resource_group_name
  cl_azure_signalr_service_mode                        = var.cl_azure_signalr_service_mode
  cl_azure_signalr_sku_name                            = var.cl_azure_signalr_sku_name
  cl_azure_signalr_sku_capacity                        = var.cl_azure_signalr_sku_capacity
  cl_azure_signalr_upstream_endpoint                   = {
    upstream1 = {
            category_pattern  = ["connections", "messages"]
            event_pattern     = ["*"]
            hub_pattern       = ["hub1"]
            url_template      = "http://foo.com"
    },
    upstream2 = {
            category_pattern  = ["connections", "messages"]
            event_pattern     = ["*"]
            hub_pattern       = ["hub2"]
            url_template      = "http://foo2.com"
    } 
  }
  cl_azure_signalr_allowed_origins                     = ["http://www.example.com"]
#   ## For the Newest Version of tf.
#   cl_azure_signalr_category_pattern                    = ["connections", "messages"]
#   cl_azure_signalr_event_pattern                       = ["*"]
#   cl_azure_signalr_hub_pattern                         = ["hub1"]
#   cl_azure_signalr_url_template                        = "http://foo.com"
  cl_azure_signalr_log_analytics_workspace_id          = var.cl_azure_signalr_log_analytics_workspace_id
  cl_azure_signalr_pe_subnet_ids                       = var.cl_azure_signalr_pe_subnet_ids
  cl_azure_signalr_private_dns_zone_id                 = var.cl_azure_signalr_private_dns_zone_id
  tags = var.tags
}
```
<!-- END_TF_DOCS -->
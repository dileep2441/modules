<!-- BEGIN_TF_DOCS -->

# Azure Redis Cache Component

The Azure Redis Cache is a high-performance caching service that provides in-memory data store for faster retrieval of data.
It ensures low latency and high throughput by reducing the need to perform slow I/O operations.

This component will deploy Azure Redis Cache and make itself available inside of a subnet.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-cache-for-redis/cache-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_redis_cache_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_redis_enterprise_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_redis_cache_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_redis_cache_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Allow20226Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Allow8433Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowALB10221to10231Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowALB13000to13999Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowALB15000to15999Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowALB16001Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowAzureDnsServersOutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowAzureLoadBalancer6379and6380Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowAzureLoadBalancer8500Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowAzureMonitorOutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowInt10221to10231Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowInt13000to13999Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowInt15000to15999Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowInt6379and6380Inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowKeyVaultOutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_AllowStorageInternetOutbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Internal10221to10231Outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Internal13000to13999Outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Internal15000to15999Outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Internal20226Outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Internal6379to6380Outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_redis_cache_subnet_nsgrule_Internal8443Outbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_private_endpoint.cl_redis_enterprise_cluster_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_redis_cache.cl_redis_cache](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/redis_cache) | resource |
| [azurerm_redis_enterprise_cluster.cl_redis_enterprise_cluster](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/redis_enterprise_cluster) | resource |
| [azurerm_redis_enterprise_database.cl_redis_enterprise_database](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/redis_enterprise_database) | resource |
| [azurerm_subnet.cl_redis_cache_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_redis_cache_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.cl_redis_cache_route_table_associate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_redis_cache_capacity"></a> [cl\_redis\_cache\_capacity](#input\_cl\_redis\_cache\_capacity) | (Optional) The size of the Redis cache to deploy. Valid values for a SKU family of C (Basic/Standard) are 0, 1, 2, 3, 4, 5, 6, and for P (Premium) family are 1, 2, 3, 4. | `number` | `1` | no |
| <a name="input_cl_redis_cache_configuration_maxfragmentationmemory_reserved"></a> [cl\_redis\_cache\_configuration\_maxfragmentationmemory\_reserved](#input\_cl\_redis\_cache\_configuration\_maxfragmentationmemory\_reserved) | (Optional) lue in megabytes reserved to accommodate for memory fragmentation. | `number` | `50` | no |
| <a name="input_cl_redis_cache_configuration_maxmemory_delta"></a> [cl\_redis\_cache\_configuration\_maxmemory\_delta](#input\_cl\_redis\_cache\_configuration\_maxmemory\_delta) | (Optional) The max-memory delta for this Redis instance. | `number` | `50` | no |
| <a name="input_cl_redis_cache_configuration_maxmemory_policy"></a> [cl\_redis\_cache\_configuration\_maxmemory\_policy](#input\_cl\_redis\_cache\_configuration\_maxmemory\_policy) | (Optional) How Redis will select what to remove when maxmemory is reached. | `string` | `"volatile-lru"` | no |
| <a name="input_cl_redis_cache_configuration_maxmemory_reserved"></a> [cl\_redis\_cache\_configuration\_maxmemory\_reserved](#input\_cl\_redis\_cache\_configuration\_maxmemory\_reserved) | (Optional) Value in megabytes reserved for non-cache usage e.g. failover. | `number` | `50` | no |
| <a name="input_cl_redis_cache_diagnostic"></a> [cl\_redis\_cache\_diagnostic](#input\_cl\_redis\_cache\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_redis_cache_enable"></a> [cl\_redis\_cache\_enable](#input\_cl\_redis\_cache\_enable) | Enable/disabled creation module Redis Cache | `bool` | `true` | no |
| <a name="input_cl_redis_cache_enable_non_ssl_port"></a> [cl\_redis\_cache\_enable\_non\_ssl\_port](#input\_cl\_redis\_cache\_enable\_non\_ssl\_port) | (Optional) Enable the non ssl port for redis cache. | `bool` | `false` | no |
| <a name="input_cl_redis_cache_family"></a> [cl\_redis\_cache\_family](#input\_cl\_redis\_cache\_family) | (Optional) The SKU family/pricing group to use. Valid values are C (for Basic/Standard SKU family) and P (for Premium). | `string` | `"P"` | no |
| <a name="input_cl_redis_cache_identity_ids"></a> [cl\_redis\_cache\_identity\_ids](#input\_cl\_redis\_cache\_identity\_ids) | (Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned. | `list(string)` | `null` | no |
| <a name="input_cl_redis_cache_identity_type"></a> [cl\_redis\_cache\_identity\_type](#input\_cl\_redis\_cache\_identity\_type) | (Optional) Specifies the identity type of Redis Cache. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_redis_cache_log_analytics_workspace_id"></a> [cl\_redis\_cache\_log\_analytics\_workspace\_id](#input\_cl\_redis\_cache\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `string` | `""` | no |
| <a name="input_cl_redis_cache_minimum_tls_version"></a> [cl\_redis\_cache\_minimum\_tls\_version](#input\_cl\_redis\_cache\_minimum\_tls\_version) | (Optional) The minimum TLS version. | `string` | `"1.2"` | no |
| <a name="input_cl_redis_cache_nsg_rules"></a> [cl\_redis\_cache\_nsg\_rules](#input\_cl\_redis\_cache\_nsg\_rules) | (Optional) Define additional NSG rules for redis subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_cl_redis_cache_postfix"></a> [cl\_redis\_cache\_postfix](#input\_cl\_redis\_cache\_postfix) | (Required) The postfix for the redis cache. Use this to make the name globally unique. | `string` | `""` | no |
| <a name="input_cl_redis_cache_public_network_access_enabled"></a> [cl\_redis\_cache\_public\_network\_access\_enabled](#input\_cl\_redis\_cache\_public\_network\_access\_enabled) | (Optional) Enable public network access for Redis cache. | `bool` | `false` | no |
| <a name="input_cl_redis_cache_rdb_backup_enabled"></a> [cl\_redis\_cache\_rdb\_backup\_enabled](#input\_cl\_redis\_cache\_rdb\_backup\_enabled) | (Optional) Is Backup Enabled? Only supported on Premium SKU's | `bool` | `false` | no |
| <a name="input_cl_redis_cache_rdb_backup_frequency"></a> [cl\_redis\_cache\_rdb\_backup\_frequency](#input\_cl\_redis\_cache\_rdb\_backup\_frequency) | (Optional) The Backup Frequency in Minutes. Only supported on Premium SKU's | `number` | `360` | no |
| <a name="input_cl_redis_cache_rdb_backup_max_snapshot_count"></a> [cl\_redis\_cache\_rdb\_backup\_max\_snapshot\_count](#input\_cl\_redis\_cache\_rdb\_backup\_max\_snapshot\_count) | (Optional) The maximum number of snapshots to create as a backup. Only supported for Premium SKU's | `number` | `1` | no |
| <a name="input_cl_redis_cache_rdb_backup_storage_account_endpoint"></a> [cl\_redis\_cache\_rdb\_backup\_storage\_account\_endpoint](#input\_cl\_redis\_cache\_rdb\_backup\_storage\_account\_endpoint) | (Optional) Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_cl_redis_cache_rdb_backup_storage_account_key"></a> [cl\_redis\_cache\_rdb\_backup\_storage\_account\_key](#input\_cl\_redis\_cache\_rdb\_backup\_storage\_account\_key) | (Optional) storage account key. Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_cl_redis_cache_rdb_backup_storage_account_name"></a> [cl\_redis\_cache\_rdb\_backup\_storage\_account\_name](#input\_cl\_redis\_cache\_rdb\_backup\_storage\_account\_name) | (Optional) Name of backup storage account name. Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_cl_redis_cache_resource_group_name"></a> [cl\_redis\_cache\_resource\_group\_name](#input\_cl\_redis\_cache\_resource\_group\_name) | (Required) The name of the resource group where the redis cache will be deployed to. | `string` | `""` | no |
| <a name="input_cl_redis_cache_route_table_id"></a> [cl\_redis\_cache\_route\_table\_id](#input\_cl\_redis\_cache\_route\_table\_id) | (Required) The route table to associate the redis cache subnet with. | `string` | `""` | no |
| <a name="input_cl_redis_cache_sku_name"></a> [cl\_redis\_cache\_sku\_name](#input\_cl\_redis\_cache\_sku\_name) | (Optional) The SKU of Redis to use. Possible values are Basic, Standard and Premium. | `string` | `"Premium"` | no |
| <a name="input_cl_redis_cache_subnet_prefix"></a> [cl\_redis\_cache\_subnet\_prefix](#input\_cl\_redis\_cache\_subnet\_prefix) | (Required) The prefix of the redis cache subnet. | `string` | `""` | no |
| <a name="input_cl_redis_cache_subnet_service_enpoints"></a> [cl\_redis\_cache\_subnet\_service\_enpoints](#input\_cl\_redis\_cache\_subnet\_service\_enpoints) | (Optional) The service endpoints for the redis cache subnet. | `list (string)` | <pre>[<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_cl_redis_cache_vnet_name"></a> [cl\_redis\_cache\_vnet\_name](#input\_cl\_redis\_cache\_vnet\_name) | (Required) The name of the core vnet required for the redis cache subnet. | `string` | `""` | no |
| <a name="input_cl_redis_cache_vnet_rg_name"></a> [cl\_redis\_cache\_vnet\_rg\_name](#input\_cl\_redis\_cache\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in. | `string` | `""` | no |
| <a name="input_cl_redis_enterprise_cluster_diagnostic"></a> [cl\_redis\_enterprise\_cluster\_diagnostic](#input\_cl\_redis\_enterprise\_cluster\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_redis_enterprise_cluster_enable"></a> [cl\_redis\_enterprise\_cluster\_enable](#input\_cl\_redis\_enterprise\_cluster\_enable) | Enable/disabled creation module Redis Cache | `bool` | `false` | no |
| <a name="input_cl_redis_enterprise_cluster_minimum_tls_version"></a> [cl\_redis\_enterprise\_cluster\_minimum\_tls\_version](#input\_cl\_redis\_enterprise\_cluster\_minimum\_tls\_version) | (Optional) The minimum TLS version. Possible values are 1.0, 1.1 and 1.2. Defaults to 1.2. | `string` | `"1.2"` | no |
| <a name="input_cl_redis_enterprise_cluster_private_dns_zone_ids"></a> [cl\_redis\_enterprise\_cluster\_private\_dns\_zone\_ids](#input\_cl\_redis\_enterprise\_cluster\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_cl_redis_enterprise_cluster_resource_group_name"></a> [cl\_redis\_enterprise\_cluster\_resource\_group\_name](#input\_cl\_redis\_enterprise\_cluster\_resource\_group\_name) | (Optional) The name of the Resource Group where the Redis Enterprise Cluster should exist. Changing this forces a new Redis Enterprise Cluster to be created. | `any` | `null` | no |
| <a name="input_cl_redis_enterprise_cluster_sku_name"></a> [cl\_redis\_enterprise\_cluster\_sku\_name](#input\_cl\_redis\_enterprise\_cluster\_sku\_name) | (Required) The sku\_name is comprised of two segments separated by a hyphen (e.g. Enterprise\_E10-2). | `string` | `""` | no |
| <a name="input_cl_redis_enterprise_cluster_subnet"></a> [cl\_redis\_enterprise\_cluster\_subnet](#input\_cl\_redis\_enterprise\_cluster\_subnet) | (Required) The name of subnet which should be used for the Redis cluster private endpoint | `string` | `""` | no |
| <a name="input_cl_redis_enterprise_database_client_protocol"></a> [cl\_redis\_enterprise\_database\_client\_protocol](#input\_cl\_redis\_enterprise\_database\_client\_protocol) | (Optional) Specifies whether redis clients can connect using TLS-encrypted or plaintext redis protocols. Default is TLS-encrypted. Possible values are Encrypted and Plaintext. Defaults to Encrypted. | `string` | `"Encrypted"` | no |
| <a name="input_cl_redis_enterprise_database_clustering_policy"></a> [cl\_redis\_enterprise\_database\_clustering\_policy](#input\_cl\_redis\_enterprise\_database\_clustering\_policy) | (Optional) Clustering policy - default is OSSCluster. Specified at create time. Possible values are EnterpriseCluster and OSSCluster. Defaults to OSSCluster. | `string` | `"OSSCluster"` | no |
| <a name="input_cl_redis_enterprise_database_eviction_policy"></a> [cl\_redis\_enterprise\_database\_eviction\_policy](#input\_cl\_redis\_enterprise\_database\_eviction\_policy) | (Optional) Redis eviction policy - default is VolatileLRU. Possible values are AllKeysLFU, AllKeysLRU, AllKeysRandom, VolatileLRU, VolatileLFU, VolatileTTL, VolatileRandom and NoEviction. | `string` | `"VolatileLRU"` | no |
| <a name="input_cl_redis_enterprise_database_linked_database_group_nickname"></a> [cl\_redis\_enterprise\_database\_linked\_database\_group\_nickname](#input\_cl\_redis\_enterprise\_database\_linked\_database\_group\_nickname) | (Optional) Nickname of the group of linked databases. Changing this force a new Redis Enterprise Geo Database to be created. | `string` | `""` | no |
| <a name="input_cl_redis_enterprise_database_linked_database_id"></a> [cl\_redis\_enterprise\_database\_linked\_database\_id](#input\_cl\_redis\_enterprise\_database\_linked\_database\_id) | (Optional) A list of database resources to link with this database with a maximum of 5. | `list(string)` | `[]` | no |
| <a name="input_cl_redis_enterprise_database_module_name"></a> [cl\_redis\_enterprise\_database\_module\_name](#input\_cl\_redis\_enterprise\_database\_module\_name) | (Required) The name which should be used for this module. Possible values are RedisBloom, RedisTimeSeries, RediSearch and RedisJSON | `string` | `null` | no |
| <a name="input_cl_redis_enterprise_database_port"></a> [cl\_redis\_enterprise\_database\_port](#input\_cl\_redis\_enterprise\_database\_port) | (Optional) TCP port of the database endpoint. Specified at create time. Defaults to an available port. Changing this forces a new Redis Enterprise Database to be created. Defaults to 10000. | `number` | `10000` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_redis_cache"></a> [cl\_redis\_cache](#output\_cl\_redis\_cache) | n/a |
| <a name="output_cl_redis_cache_diagnostic_setting"></a> [cl\_redis\_cache\_diagnostic\_setting](#output\_cl\_redis\_cache\_diagnostic\_setting) | n/a |
| <a name="output_cl_redis_cache_route_table_associate"></a> [cl\_redis\_cache\_route\_table\_associate](#output\_cl\_redis\_cache\_route\_table\_associate) | n/a |
| <a name="output_cl_redis_cache_subnet"></a> [cl\_redis\_cache\_subnet](#output\_cl\_redis\_cache\_subnet) | Outputs ********************************************************************************************** |
| <a name="output_cl_redis_cache_subnet_association"></a> [cl\_redis\_cache\_subnet\_association](#output\_cl\_redis\_cache\_subnet\_association) | n/a |
| <a name="output_cl_redis_cache_subnet_nsg"></a> [cl\_redis\_cache\_subnet\_nsg](#output\_cl\_redis\_cache\_subnet\_nsg) | n/a |

## Usage

```terraform
// Azure Redis Cache
//**********************************************************************************************
 module "cl_redis_cache" {
  source                                    = "../dn-tads_tf-azure-component-library/components/cl_redis_cache"
  cl_redis_cache_enable                     = true/false
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  cl_redis_cache_vnet_rg_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_redis_cache_vnet_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_redis_cache_subnet_prefix              = ["55.0.3.0/24"]
  cl_redis_cache_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_redis_cache_postfix                    = "app1"
  cl_redis_cache_route_table_id             = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_redis_cache_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_redis_cache_nsg_rules                  = {
    allow_redis_6379_6380 = {
      name                        = "Allow6379and6380Inbound"
      priority                    = 1013
      direction                   = "Inbound"
      access                      = "Allow"
      protocol                    = "Tcp"
      source_port_range           = "*"
      source_port_ranges          = null
      destination_port_range      = null
      destination_port_ranges     = ["6379", "6380"]
      source_address_prefix       = "10.69.22.78/27"
      source_address_prefixes     = null
      destination_address_prefix  = "10.69.22.89/27"  
      destination_address_prefixes  = null  
    }
  }
}
//***************************************************************************************************
```
<!-- END_TF_DOCS -->
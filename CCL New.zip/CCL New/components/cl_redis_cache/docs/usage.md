## Usage

```terraform
// Azure Redis Cache
//**********************************************************************************************
 module "cl_redis_cache" {
  source                                    = "../dn-tads_tf-azure-component-library/components/cl_redis_cache"
  cl_redis_cache_enable                     = true/false
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  cl_redis_cache_vnet_rg_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_redis_cache_vnet_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_redis_cache_subnet_prefix              = ["55.0.3.0/24"]
  cl_redis_cache_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_redis_cache_postfix                    = "app1"
  cl_redis_cache_route_table_id             = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_redis_cache_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_redis_cache_nsg_rules                  = {
    allow_redis_6379_6380 = {
      name                        = "Allow6379and6380Inbound"
      priority                    = 1013
      direction                   = "Inbound"
      access                      = "Allow"
      protocol                    = "Tcp"
      source_port_range           = "*"
      source_port_ranges          = null
      destination_port_range      = null
      destination_port_ranges     = ["6379", "6380"]
      source_address_prefix       = "10.69.22.78/27"
      source_address_prefixes     = null
      destination_address_prefix  = "10.69.22.89/27"  
      destination_address_prefixes  = null  
    }
  }
}
//***************************************************************************************************
```
# Azure Redis Cache Component

The Azure Redis Cache is a high-performance caching service that provides in-memory data store for faster retrieval of data.
It ensures low latency and high throughput by reducing the need to perform slow I/O operations.

This component will deploy Azure Redis Cache and make itself available inside of a subnet.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-cache-for-redis/cache-overview

<!-- BEGIN_TF_DOCS -->

# Azure App Insights Component

Azure Application Insights is a Application Performance Management (APM) service that is used to monitor live applications. 
This service provides insights on app availability, performance, failures and usage.
This component will deploy Azure Application insights and make itself available for App/Web monitoring.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-monitor/app/app-insights-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_application_insights.cl_app_insights](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights) | resource |
| [azurerm_application_insights_api_key.cl_app_insights_authenticate_sdk_control_channel](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights_api_key) | resource |
| [azurerm_application_insights_api_key.cl_app_insights_full_permissions](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights_api_key) | resource |
| [azurerm_application_insights_api_key.cl_app_insights_read_telemetry](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights_api_key) | resource |
| [azurerm_application_insights_api_key.cl_app_insights_write_annotations](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights_api_key) | resource |
| [azurerm_application_insights_web_test.cl_app_insights_web_test](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights_web_test) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_app_insights_application_type"></a> [cl\_app\_insights\_application\_type](#input\_cl\_app\_insights\_application\_type) | (Required) Specifies the type of Application Insights to create. | `string` | n/a | yes |
| <a name="input_cl_app_insights_read_permissions"></a> [cl\_app\_insights\_read\_permissions](#input\_cl\_app\_insights\_read\_permissions) | (Optional) Specifies the list of read permissions granted to the API key. | `list(string)` | <pre>[<br>  "agentconfig",<br>  "aggregate",<br>  "api",<br>  "draft",<br>  "extendqueries",<br>  "search"<br>]</pre> | no |
| <a name="input_cl_app_insights_resource_group_name"></a> [cl\_app\_insights\_resource\_group\_name](#input\_cl\_app\_insights\_resource\_group\_name) | (Required) The name of the resource group in which to create the Application Insights component. | `any` | n/a | yes |
| <a name="input_cl_app_insights_web_test"></a> [cl\_app\_insights\_web\_test](#input\_cl\_app\_insights\_web\_test) | (Optional) Define additional NSG rules | <pre>map(object({<br>    frequency           = number<br>    timeout             = number<br>    enabled             = string<br>    geo_locations       = list(string)<br>    test_method         = string<br>    test_url            = string<br>    test_response_code  = number<br>  }))</pre> | `{}` | no |
| <a name="input_cl_app_insights_web_test_kind"></a> [cl\_app\_insights\_web\_test\_kind](#input\_cl\_app\_insights\_web\_test\_kind) | (Required) The kind of web test that this web test watches. | `string` | n/a | yes |
| <a name="input_cl_app_insights_write_permissions"></a> [cl\_app\_insights\_write\_permissions](#input\_cl\_app\_insights\_write\_permissions) | (Optional) Specifies the list of write permissions granted to the API key. | `list(string)` | <pre>[<br>  "annotations"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_sdk_control_channel_read_permission"></a> [sdk\_control\_channel\_read\_permission](#input\_sdk\_control\_channel\_read\_permission) | (Optional) Specifies the list of read permissions granted to the API key. | `list(string)` | <pre>[<br>  "agentconfig"<br>]</pre> | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_app_insights"></a> [cl\_app\_insights](#output\_cl\_app\_insights) | n/a |
| <a name="output_cl_app_insights_authenticate_sdk_control_channel"></a> [cl\_app\_insights\_authenticate\_sdk\_control\_channel](#output\_cl\_app\_insights\_authenticate\_sdk\_control\_channel) | n/a |
| <a name="output_cl_app_insights_full_permissions_api_key"></a> [cl\_app\_insights\_full\_permissions\_api\_key](#output\_cl\_app\_insights\_full\_permissions\_api\_key) | n/a |
| <a name="output_cl_app_insights_read_telemetry_api_key"></a> [cl\_app\_insights\_read\_telemetry\_api\_key](#output\_cl\_app\_insights\_read\_telemetry\_api\_key) | n/a |
| <a name="output_cl_app_insights_web_test"></a> [cl\_app\_insights\_web\_test](#output\_cl\_app\_insights\_web\_test) | n/a |
| <a name="output_cl_app_insights_write_annotations_api_key"></a> [cl\_app\_insights\_write\_annotations\_api\_key](#output\_cl\_app\_insights\_write\_annotations\_api\_key) | n/a |
| <a name="output_instrumentation_key"></a> [instrumentation\_key](#output\_instrumentation\_key) | // Outputs //********************************************************************************************** |


## Usage

```terraform

// ADI code starts from here *********************************************************************

// Azure Application Insights
//**********************************************************************************************
module "cl_app_insights" {
  source                              = "../dn-tads_tf-azure-component-library/components/cl_app_insights_gov"
  env                                 = var.env
  postfix                             = var.postfix
  location                            = var.location
  tags                                = var.tags
  cl_app_insights_resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_app_insights_application_type    = "web"
  cl_app_insights_content             = "requests //simple example query"
  cl_app_insights_scope               = "shared"
  cl_app_insights_type                = "query"
  cl_app_insights_web_test_kind       = "ping"
  cl_app_insights_web_test = {
    web_test = {
      frequency     = 300
      timeout       = 60
      enabled       = true
      geo_locations = ["us-tx-sn1-azr", "us-il-ch1-azr"]
    }
  }
}
//************************************************************************************************************************
```
<!-- END_TF_DOCS -->
<!-- BEGIN_TF_DOCS -->

# Azure App Service Plan Component

Azure App Service Plan is the container for hosting Web Apps, REST APIs, custom containers and Function Apps.
One or more apps can be configured to run on the same computing resources (or in the same App Service plan). 
This component will deploy an autoscalable App Service Plan and Diagnostics Settings.

https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans

#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified in a Github Action Task:
```Githubaction task
    - name: Setup Terraform
      uses: hashicorp/setup-terraform@v1
      with:
        terraform_version: ${{ env.TF_VERSION }}   
```
Specify TF version in `pattern_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_autoscale_setting.cl_app_service_plan_autoscale_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_autoscale_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_app_service_plan_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_app_service_plan_nsg_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_app_service_plan_integration_subnet_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_app_service_plan_int_subnet_user_defined_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_watcher_flow_log.cl_app_service_plan_network_watcher_flow_log](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_watcher_flow_log) | resource |
| [azurerm_resource_group.cl_app_service_plan_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_service_plan.cl_app_service_plan](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_plan) | resource |
| [azurerm_subnet.cl_app_service_plan_integration_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_app_service_plan_integration_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.cl_app_service_plan_rt_associate_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_app_service_plan_app_postfix"></a> [cl\_app\_service\_plan\_app\_postfix](#input\_cl\_app\_service\_plan\_app\_postfix) | (Required) The bespoke name of the app service plan you are deploying. | `any` | n/a | yes |
| <a name="input_cl_app_service_plan_autoscale_settings_default"></a> [cl\_app\_service\_plan\_autoscale\_settings\_default](#input\_cl\_app\_service\_plan\_autoscale\_settings\_default) | (Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_maximum"></a> [cl\_app\_service\_plan\_autoscale\_settings\_maximum](#input\_cl\_app\_service\_plan\_autoscale\_settings\_maximum) | (Optional) The maximum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `10` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_metric_name"></a> [cl\_app\_service\_plan\_autoscale\_settings\_metric\_name](#input\_cl\_app\_service\_plan\_autoscale\_settings\_metric\_name) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"CpuPercentage"` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_minimum"></a> [cl\_app\_service\_plan\_autoscale\_settings\_minimum](#input\_cl\_app\_service\_plan\_autoscale\_settings\_minimum) | (Optional) The minimum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_scale_in_operator"></a> [cl\_app\_service\_plan\_autoscale\_settings\_scale\_in\_operator](#input\_cl\_app\_service\_plan\_autoscale\_settings\_scale\_in\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"LessThan"` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_scale_in_threshold"></a> [cl\_app\_service\_plan\_autoscale\_settings\_scale\_in\_threshold](#input\_cl\_app\_service\_plan\_autoscale\_settings\_scale\_in\_threshold) | (Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action. | `number` | `25` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_scale_out_operator"></a> [cl\_app\_service\_plan\_autoscale\_settings\_scale\_out\_operator](#input\_cl\_app\_service\_plan\_autoscale\_settings\_scale\_out\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"GreaterThan"` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_scale_out_threshold"></a> [cl\_app\_service\_plan\_autoscale\_settings\_scale\_out\_threshold](#input\_cl\_app\_service\_plan\_autoscale\_settings\_scale\_out\_threshold) | (Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action. | `number` | `75` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_statistic"></a> [cl\_app\_service\_plan\_autoscale\_settings\_statistic](#input\_cl\_app\_service\_plan\_autoscale\_settings\_statistic) | (Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max. | `string` | `"Average"` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_time_aggregation"></a> [cl\_app\_service\_plan\_autoscale\_settings\_time\_aggregation](#input\_cl\_app\_service\_plan\_autoscale\_settings\_time\_aggregation) | (Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total. | `string` | `"Average"` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_time_grain"></a> [cl\_app\_service\_plan\_autoscale\_settings\_time\_grain](#input\_cl\_app\_service\_plan\_autoscale\_settings\_time\_grain) | (Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string. | `string` | `"PT1M"` | no |
| <a name="input_cl_app_service_plan_autoscale_settings_time_window"></a> [cl\_app\_service\_plan\_autoscale\_settings\_time\_window](#input\_cl\_app\_service\_plan\_autoscale\_settings\_time\_window) | (Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string. | `string` | `"PT5M"` | no |
| <a name="input_cl_app_service_plan_core_sa_enabled"></a> [cl\_app\_service\_plan\_core\_sa\_enabled](#input\_cl\_app\_service\_plan\_core\_sa\_enabled) | (Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs. | `bool` | `true` | no |
| <a name="input_cl_app_service_plan_deploy_autoscale_settings"></a> [cl\_app\_service\_plan\_deploy\_autoscale\_settings](#input\_cl\_app\_service\_plan\_deploy\_autoscale\_settings) | (Optional) Choose to deploy autoscale settings or not. If the plan is serverless, this needs to be set to false | `bool` | `true` | no |
| <a name="input_cl_app_service_plan_deploy_integration_subnet"></a> [cl\_app\_service\_plan\_deploy\_integration\_subnet](#input\_cl\_app\_service\_plan\_deploy\_integration\_subnet) | (Optional) A boolean that toggles the deployment of the vnet integration subnet. | `bool` | `true` | no |
| <a name="input_cl_app_service_plan_deploy_rg"></a> [cl\_app\_service\_plan\_deploy\_rg](#input\_cl\_app\_service\_plan\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the App Service Plan. | `bool` | `true` | no |
| <a name="input_cl_app_service_plan_diagnostics"></a> [cl\_app\_service\_plan\_diagnostics](#input\_cl\_app\_service\_plan\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_app_service_plan_int_subnet_user_defined_nsg_rules"></a> [cl\_app\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules](#input\_cl\_app\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules) | (Optional) A map of NSG rules for the integration subnet. | <pre>map(object({<br>        name                          = string<br>        priority                      = number<br>        direction                     = string<br>        access                        = string<br>        protocol                      = string<br>        source_port_range             = string<br>        source_port_ranges            = list(string)<br>        destination_port_range        = string<br>        destination_port_ranges       = list(string)    <br>        source_address_prefix         = string<br>        source_address_prefixes       = list(string)<br>        destination_address_prefix    = string<br>        destination_address_prefixes  = list(string)    <br>    }))</pre> | `{}` | no |
| <a name="input_cl_app_service_plan_integration_subnet_prefix"></a> [cl\_app\_service\_plan\_integration\_subnet\_prefix](#input\_cl\_app\_service\_plan\_integration\_subnet\_prefix) | (Optional) The CIDR prefix for the app service subnet. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_cl_app_service_plan_integration_subnet_service_endpoints"></a> [cl\_app\_service\_plan\_integration\_subnet\_service\_endpoints](#input\_cl\_app\_service\_plan\_integration\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `list` | `[]` | no |
| <a name="input_cl_app_service_plan_integration_vnet_name"></a> [cl\_app\_service\_plan\_integration\_vnet\_name](#input\_cl\_app\_service\_plan\_integration\_vnet\_name) | (Optional) The name of the VNet where the app service subnet will be deployed into. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_cl_app_service_plan_integration_vnet_rg_name"></a> [cl\_app\_service\_plan\_integration\_vnet\_rg\_name](#input\_cl\_app\_service\_plan\_integration\_vnet\_rg\_name) | (Optional) The name of the VNet resource group where the app service subnet will be deployed into. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_cl_app_service_plan_log_analytics_workspace_id"></a> [cl\_app\_service\_plan\_log\_analytics\_workspace\_id](#input\_cl\_app\_service\_plan\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_app_service_plan_max_elastic_workers"></a> [cl\_app\_service\_plan\_max\_elastic\_workers](#input\_cl\_app\_service\_plan\_max\_elastic\_workers) | (Optional) The maximum number of total workers allowed for this ElasticScaleEnabled App Service Plan. | `number` | `null` | no |
| <a name="input_cl_app_service_plan_nsg_diagnostics"></a> [cl\_app\_service\_plan\_nsg\_diagnostics](#input\_cl\_app\_service\_plan\_nsg\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "NetworkSecurityGroupRuleCounter",<br>    "NetworkSecurityGroupEvent"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_app_service_plan_nsg_sa_allowed_pe_subnet_ids"></a> [cl\_app\_service\_plan\_nsg\_sa\_allowed\_pe\_subnet\_ids](#input\_cl\_app\_service\_plan\_nsg\_sa\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_app_service_plan_nsg_sa_allowed_vnet_subnet_ids"></a> [cl\_app\_service\_plan\_nsg\_sa\_allowed\_vnet\_subnet\_ids](#input\_cl\_app\_service\_plan\_nsg\_sa\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_app_service_plan_nsg_sa_private_dns_zone_ids"></a> [cl\_app\_service\_plan\_nsg\_sa\_private\_dns\_zone\_ids](#input\_cl\_app\_service\_plan\_nsg\_sa\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_app_service_plan_os_type"></a> [cl\_app\_service\_plan\_os\_type](#input\_cl\_app\_service\_plan\_os\_type) | (Optional) The os type of the App Service Plan to create. Possible values are Windows (also available as App), Linux, elastic (for Premium Consumption) and FunctionApp (for a Consumption Plan). Defaults to Windows. Changing this forces a new resource to be created. | `string` | `"Windows"` | no |
| <a name="input_cl_app_service_plan_per_site_scaling"></a> [cl\_app\_service\_plan\_per\_site\_scaling](#input\_cl\_app\_service\_plan\_per\_site\_scaling) | (Optional) Can Apps assigned to this App Service Plan be scaled independently? If set to false apps assigned to this plan will scale to all instances of the plan. | `bool` | `false` | no |
| <a name="input_cl_app_service_plan_rg_name"></a> [cl\_app\_service\_plan\_rg\_name](#input\_cl\_app\_service\_plan\_rg\_name) | (Optional) The name of the App Service Plan resource group if cl\_app\_service\_plan\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_app_service_plan_route_table_id"></a> [cl\_app\_service\_plan\_route\_table\_id](#input\_cl\_app\_service\_plan\_route\_table\_id) | (Optional) The ID of the route table that will be associated to the subnet | `string` | `""` | no |
| <a name="input_cl_app_service_plan_sku_name"></a> [cl\_app\_service\_plan\_sku\_name](#input\_cl\_app\_service\_plan\_sku\_name) | (Optional) Specifies the plan's instance size. | `string` | `"P1v2"` | no |
| <a name="input_cl_app_service_plan_storage_account_nsg_flow_log_id"></a> [cl\_app\_service\_plan\_storage\_account\_nsg\_flow\_log\_id](#input\_cl\_app\_service\_plan\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
    cl_app_service_plan_rg     = var.cl_app_service_plan_deploy_rg ? azurerm_resource_group.cl_app_service_plan_rg[0].name : var.cl_app_service_plan_rg_name
    cl_app_service_plan_integration_subnet = var.cl_app_service_plan_deploy_integration_subnet ? azurerm_subnet.cl_app_service_plan_integration_subnet[0] : null
    cl_app_service_plan_integration_subnet_nsg = var.cl_app_service_plan_deploy_integration_subnet ? azurerm_network_security_group.cl_app_service_plan_integration_subnet_nsg[0] : null
    cl_app_service_plan_integration_subnet_association = var.cl_app_service_plan_deploy_integration_subnet ? azurerm_subnet_network_security_group_association.cl_app_service_plan_integration_subnet_association[0] : null
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_app_service_plan"></a> [cl\_app\_service\_plan](#output\_cl\_app\_service\_plan) | n/a |
| <a name="output_cl_app_service_plan_autoscale_settings"></a> [cl\_app\_service\_plan\_autoscale\_settings](#output\_cl\_app\_service\_plan\_autoscale\_settings) | n/a |
| <a name="output_cl_app_service_plan_diagnostic_setting"></a> [cl\_app\_service\_plan\_diagnostic\_setting](#output\_cl\_app\_service\_plan\_diagnostic\_setting) | n/a |
| <a name="output_cl_app_service_plan_integration_subnet"></a> [cl\_app\_service\_plan\_integration\_subnet](#output\_cl\_app\_service\_plan\_integration\_subnet) | n/a |
| <a name="output_cl_app_service_plan_integration_subnet_nsg"></a> [cl\_app\_service\_plan\_integration\_subnet\_nsg](#output\_cl\_app\_service\_plan\_integration\_subnet\_nsg) | n/a |
| <a name="output_cl_app_service_plan_rg"></a> [cl\_app\_service\_plan\_rg](#output\_cl\_app\_service\_plan\_rg) | Outputs ********************************************************************************************** |

## Usage
```terraform
// App Service Plan
//**********************************************************************************************
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_app_service_plan_gov"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  } 
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_app_service_plan_os_type                               = var.cl_app_service_plan_os_type
  #cl_app_service_plan_logging_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_app_service_plan_core_sa_enabled                       = true
  cl_app_service_plan_storage_account_nsg_flow_log_id       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
  tags                                                      = var.tags
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
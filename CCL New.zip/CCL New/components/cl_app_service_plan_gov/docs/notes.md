#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified in a Github Action Task:
```Githubaction task
    - name: Setup Terraform
      uses: hashicorp/setup-terraform@v1
      with:
        terraform_version: ${{ env.TF_VERSION }}   
```
Specify TF version in `pattern_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
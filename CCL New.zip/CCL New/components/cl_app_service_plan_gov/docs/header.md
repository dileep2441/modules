# Azure App Service Plan Component

Azure App Service Plan is the container for hosting Web Apps, REST APIs, custom containers and Function Apps.
One or more apps can be configured to run on the same computing resources (or in the same App Service plan). 
This component will deploy an autoscalable App Service Plan and Diagnostics Settings.

https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans

## Usage
```terraform
// App Service Plan
//**********************************************************************************************
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_app_service_plan_gov"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  } 
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
  cl_app_service_plan_os_type                               = var.cl_app_service_plan_os_type
  #cl_app_service_plan_logging_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_app_service_plan_core_sa_enabled                       = true
  cl_app_service_plan_storage_account_nsg_flow_log_id       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_storage_account[0].cl_storage_account.id
  tags                                                      = var.tags
}
//**********************************************************************************************
```

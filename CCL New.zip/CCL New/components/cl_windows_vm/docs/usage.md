## Usage

### Azure Devops Pipelines Agent Installation
Azure Pipelines Agent extension can be installed to deploy software using Azure DevOps Services to the virtual machines hosted in Microsoft Azure. When installed, the extension automatically downloads the Azure Pipelines Agent MSI, installs it, and registers the agent with the specified Deployment Group within your Azure DevOps Organization Project.

For the agent installation, the parameters below should be defined on VM module:

```terraform
  cl_windows_vm_enable_devops_agent               = true
  cl_windows_vm_devops_agent_org_url              = "https://dev.azure.com/<organization>"
  cl_windows_vm_devops_agent_pat                  = "<PERSONAL ACCESS TOKEN>"
  cl_windows_vm_devops_agent_team_project         = "<TEAM PROJECT NAME>"
  cl_windows_vm_devops_agent_deployment_group     = "<DEPLOYMENT GROUPS NAME>"
```

#### Useful Links
[Get started with the agent](https://docs.microsoft.com/azure/devops/pipelines/agents/agents?view=azure-devops#install).
[Azure Pipelines](https://azure.microsoft.com/en-us/services/devops/pipelines/)
[Deployment Groups](https://aka.ms/832442)
[Personal access tokens](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate)

#### Deploy VM With Azure Devops Agent
```terraform
// Deploys Windows VM with the Azure Devops Agent installed
//**********************************************************************************************
module "cl_windows_vm" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_windows_vm"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_windows_vm_app_name                          = var.windows_vm_app_name
  cl_windows_vm_computer_name                     = var.windows_vm_computer_name  
  cl_windows_vm_image_id                          = var.windows_vm_image_id
  cl_windows_vm_availability_set_id               = var.availability_set_id
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = true
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host_enabled = false
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS
# cl_windows_vm_user_defined_nsg_rules            = {
#     allow_6379_6380 = {
#       name                        = "Allow6379and6380Inbound"
#       priority                    = 1013
#       direction                   = "Inbound"
#       access                      = "Allow"
#       protocol                    = "Tcp"
#       source_port_range           = "*"
#       source_port_ranges          = null
#       destination_port_range      = null
#       destination_port_ranges     = ["6379", "6380"]
#       source_address_prefix       = "10.69.22.78/27"
#       source_address_prefixes     = null
#       destination_address_prefix  = "10.69.22.89/27"  
#       destination_address_prefixes  = null  
#     }
}
  
  // DevOps Configs
  cl_windows_vm_enable_devops_agent               = true
  cl_windows_vm_devops_agent_org_url              = "https://dev.azure.com/contoso"
  cl_windows_vm_devops_agent_pat                  = "xmtvguqak3k2lxi5gu633c6pgzjbjznczxwlvxmp2glluot4dkftfqx"
  cl_windows_vm_devops_agent_team_project         = "CONTOSO"
  cl_windows_vm_devops_agent_deployment_group     = "CONTOSO-SBOX"
}
//**********************************************************************************************
```
#### Deploy VM Without Azure Devops Agent
```terraform
// Deploys Windows VM without the Azure Devops Agent installed
//***************************************************************************************************
module "cl_windows_vm_power_bi_gateway" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_windows_vm"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_windows_vm_app_name                          = var.power_bi_gateway_vm_app_name
  cl_windows_vm_computer_name                     = var.power_bi_gateway_vm_computer_name  
  cl_windows_vm_image_id                          = var.power_bi_gateway_vm_image_id
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = false
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host_enabled = false
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix 
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS
  cl_windows_vm_managed_disks                     = {
                                                        data = {
                                                            storage_account_type = "StandardSSD_LRS"
                                                            disk_size            = "80"
                                                            lun                  = "1"
                                                            caching              = "None"
                                                        }
                                                    } 
}
//***************************************************************************************************
```
<!-- BEGIN_TF_DOCS -->

# Azure Windows VM Component

Windows virtual machine is a computer within a computer that provides the user the same experience they would have on the host operating system itself. 
Each virtual machine provides its own virtual hardware including CPUs, memory, hard drives, network interfaces, and other devices.
This Windows VM component will deploy a new resource group, Vnet, Subnet, Public IP, NIC Interface, Windows VM, Recovery Services Vault, Backup policy and a Backup Protected VM.

For more information, please visit: https://docs.microsoft.com/en-us/azure/virtual-machines/windows/overview 



## Resources

| Name | Type |
|------|------|
| [azurerm_availability_set.cl_windows_vm_availability_set](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/availability_set) | resource |
| [azurerm_backup_protected_vm.cl_windows_vm_protected_vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_protected_vm) | resource |
| [azurerm_managed_disk.cl_windows_vm_managed_disk](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_monitor_data_collection_rule_association.cl_data_collection_rule_assoc](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_data_collection_rule_association) | resource |
| [azurerm_monitor_data_collection_rule_association.cl_data_collection_rule_endpoint_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_data_collection_rule_association) | resource |
| [azurerm_network_interface.cl_windows_vm_nic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.cl_windows_vm_nic_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_network_security_group.cl_windows_vm_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_windows_vm_azure_bastion_nsgrule_22](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_windows_vm_azure_bastion_nsgrule_3389](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_windows_vm_user_defined_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_resource_group.cl_windows_vm_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subnet.cl_windows_vm_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_windows_vm_subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.cl_windows_vm_route_table_associate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_machine_data_disk_attachment.cl_windows_vm_managed_disk_attachment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |
| [azurerm_virtual_machine_extension.cl_windows_log_analytics_ama_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.cl_windows_log_analytics_mma_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.cl_windows_vm_devops_agent](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.cl_windows_vm_domain_join](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.cl_windows_vm_guest_configuration](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_virtual_machine_extension.core_dns_forwarder_vm_antimalware_extension](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_extension) | resource |
| [azurerm_windows_virtual_machine.cl_windows_vm_machine](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_virtual_machine) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_windows_vm_admin_pass"></a> [cl\_windows\_vm\_admin\_pass](#input\_cl\_windows\_vm\_admin\_pass) | (Required) The password of the windows OS admin. | `string` | n/a | yes |
| <a name="input_cl_windows_vm_admin_user"></a> [cl\_windows\_vm\_admin\_user](#input\_cl\_windows\_vm\_admin\_user) | (Required) The name of the windows OS admin. | `string` | n/a | yes |
| <a name="input_cl_windows_vm_app_name"></a> [cl\_windows\_vm\_app\_name](#input\_cl\_windows\_vm\_app\_name) | (Required) A string that is appended to the end of the VM name to identify it. | `string` | `""` | no |
| <a name="input_cl_windows_vm_availability_set_id"></a> [cl\_windows\_vm\_availability\_set\_id](#input\_cl\_windows\_vm\_availability\_set\_id) | (Required) The ID of the availability set for the VM. Required for the VM provisioning. | `any` | `null` | no |
| <a name="input_cl_windows_vm_azurerm_monitor_data_collection_rule"></a> [cl\_windows\_vm\_azurerm\_monitor\_data\_collection\_rule](#input\_cl\_windows\_vm\_azurerm\_monitor\_data\_collection\_rule) | (Required) DCR ID that is provisioned with spoke LAW. | `string` | `""` | no |
| <a name="input_cl_windows_vm_azurerm_monitor_data_collection_rule_id"></a> [cl\_windows\_vm\_azurerm\_monitor\_data\_collection\_rule\_id](#input\_cl\_windows\_vm\_azurerm\_monitor\_data\_collection\_rule\_id) | (Optional) The ID of the Data Collection Rule which will be associated to the target resource. | `any` | `null` | no |
| <a name="input_cl_windows_vm_azurerm_subnet_service_enpoints"></a> [cl\_windows\_vm\_azurerm\_subnet\_service\_enpoints](#input\_cl\_windows\_vm\_azurerm\_subnet\_service\_enpoints) | (Optional) The Size of the windows vm. | `list(string)` | <pre>[<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_cl_windows_vm_backup_policy_vm_id"></a> [cl\_windows\_vm\_backup\_policy\_vm\_id](#input\_cl\_windows\_vm\_backup\_policy\_vm\_id) | (Optional) The backup policy from the backup vault. | `any` | `null` | no |
| <a name="input_cl_windows_vm_bastion_enable"></a> [cl\_windows\_vm\_bastion\_enable](#input\_cl\_windows\_vm\_bastion\_enable) | (Optional) Enable te creation for azure bastion | `bool` | `false` | no |
| <a name="input_cl_windows_vm_bastion_subnet_prefix"></a> [cl\_windows\_vm\_bastion\_subnet\_prefix](#input\_cl\_windows\_vm\_bastion\_subnet\_prefix) | (Required) The subnet prefix for the bastion. | `any` | `null` | no |
| <a name="input_cl_windows_vm_computer_name"></a> [cl\_windows\_vm\_computer\_name](#input\_cl\_windows\_vm\_computer\_name) | (Required) Specifies the Hostname which should be used for this Virtual Machine. | `string` | n/a | yes |
| <a name="input_cl_windows_vm_data_collection_rule_assoc"></a> [cl\_windows\_vm\_data\_collection\_rule\_assoc](#input\_cl\_windows\_vm\_data\_collection\_rule\_assoc) | (Required) conditinal for enabling DCR association on VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_data_collection_rule_endpoint_windows"></a> [cl\_windows\_vm\_data\_collection\_rule\_endpoint\_windows](#input\_cl\_windows\_vm\_data\_collection\_rule\_endpoint\_windows) | (Required) Endpoint ID that is provisioned with spoke LAW. | `string` | `""` | no |
| <a name="input_cl_windows_vm_deploy_availability_set"></a> [cl\_windows\_vm\_deploy\_availability\_set](#input\_cl\_windows\_vm\_deploy\_availability\_set) | (Optional) A boolean to enable/disable the deployment of Availability set for the VM. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_deploy_rg"></a> [cl\_windows\_vm\_deploy\_rg](#input\_cl\_windows\_vm\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_deploy_subnet"></a> [cl\_windows\_vm\_deploy\_subnet](#input\_cl\_windows\_vm\_deploy\_subnet) | (Optional) A boolean to enable/disable the deployment of a subnet for the VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_deploy_subnet_nsg"></a> [cl\_windows\_vm\_deploy\_subnet\_nsg](#input\_cl\_windows\_vm\_deploy\_subnet\_nsg) | (Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_devops_agent_deployment_group"></a> [cl\_windows\_vm\_devops\_agent\_deployment\_group](#input\_cl\_windows\_vm\_devops\_agent\_deployment\_group) | (Optional) Deployment Group of Azure DevOps | `string` | `""` | no |
| <a name="input_cl_windows_vm_devops_agent_org_url"></a> [cl\_windows\_vm\_devops\_agent\_org\_url](#input\_cl\_windows\_vm\_devops\_agent\_org\_url) | (Optional) Organization of Azure DevOps | `string` | `""` | no |
| <a name="input_cl_windows_vm_devops_agent_pat"></a> [cl\_windows\_vm\_devops\_agent\_pat](#input\_cl\_windows\_vm\_devops\_agent\_pat) | (Optional) A Personal Access Token (PAT) is used as an alternate password to authenticate into Azure DevOps. | `string` | `""` | no |
| <a name="input_cl_windows_vm_devops_agent_team_project"></a> [cl\_windows\_vm\_devops\_agent\_team\_project](#input\_cl\_windows\_vm\_devops\_agent\_team\_project) | (Optional) Team Project of Azure DevOps | `string` | `""` | no |
| <a name="input_cl_windows_vm_domain_name"></a> [cl\_windows\_vm\_domain\_name](#input\_cl\_windows\_vm\_domain\_name) | (Optional) Name of the domain to join | `string` | `""` | no |
| <a name="input_cl_windows_vm_domain_password"></a> [cl\_windows\_vm\_domain\_password](#input\_cl\_windows\_vm\_domain\_password) | (Optional) Password of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_cl_windows_vm_domain_user_upn"></a> [cl\_windows\_vm\_domain\_user\_upn](#input\_cl\_windows\_vm\_domain\_user\_upn) | (Optional) UPN of the user to authenticate with the domain | `string` | `""` | no |
| <a name="input_cl_windows_vm_enable_ama_log_analytics_settings"></a> [cl\_windows\_vm\_enable\_ama\_log\_analytics\_settings](#input\_cl\_windows\_vm\_enable\_ama\_log\_analytics\_settings) | (Optional) Toggle the log analytics ama extension on or off. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_enable_automatic_updates"></a> [cl\_windows\_vm\_enable\_automatic\_updates](#input\_cl\_windows\_vm\_enable\_automatic\_updates) | (Optional) Boolean to enable automatic updates. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_enable_backup"></a> [cl\_windows\_vm\_enable\_backup](#input\_cl\_windows\_vm\_enable\_backup) | (Optional) Toggle the backup feature. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_enable_devops_agent"></a> [cl\_windows\_vm\_enable\_devops\_agent](#input\_cl\_windows\_vm\_enable\_devops\_agent) | (Optional) A boolean variable indicating if devops agent should be installed or not. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_enable_domain_join"></a> [cl\_windows\_vm\_enable\_domain\_join](#input\_cl\_windows\_vm\_enable\_domain\_join) | (Optional) Toggle the domain join feature. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_enable_encryption_at_host_enabled"></a> [cl\_windows\_vm\_enable\_encryption\_at\_host\_enabled](#input\_cl\_windows\_vm\_enable\_encryption\_at\_host\_enabled) | (Optional) Boolean to enable encryption\_at\_host\_enabled. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_enable_mma_log_analytics_settings"></a> [cl\_windows\_vm\_enable\_mma\_log\_analytics\_settings](#input\_cl\_windows\_vm\_enable\_mma\_log\_analytics\_settings) | (Optional) Toggle the log analytics mma extension on or off. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_identity_ids"></a> [cl\_windows\_vm\_identity\_ids](#input\_cl\_windows\_vm\_identity\_ids) | (Optional) A list of User Managed Identity ID's which should be assigned to the Windows Virtual Machine | `list(string)` | `[]` | no |
| <a name="input_cl_windows_vm_identity_type"></a> [cl\_windows\_vm\_identity\_type](#input\_cl\_windows\_vm\_identity\_type) | (Optional) Managed identity type for VM | `string` | `null` | no |
| <a name="input_cl_windows_vm_image_id"></a> [cl\_windows\_vm\_image\_id](#input\_cl\_windows\_vm\_image\_id) | (Required) The Windows image id to be used for the vm creation module. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_license_type"></a> [cl\_windows\_vm\_license\_type](#input\_cl\_windows\_vm\_license\_type) | (Optional) Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows\_Client and Windows\_Server. | `string` | `"Windows_Server"` | no |
| <a name="input_cl_windows_vm_log_analytics_primary_sentinel_shared_key"></a> [cl\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key](#input\_cl\_windows\_vm\_log\_analytics\_primary\_sentinel\_shared\_key) | (Required) The log analytics workspace primary shared key. | `any` | `null` | no |
| <a name="input_cl_windows_vm_log_analytics_primary_shared_key"></a> [cl\_windows\_vm\_log\_analytics\_primary\_shared\_key](#input\_cl\_windows\_vm\_log\_analytics\_primary\_shared\_key) | (Required) The log analytics workspace primary shared key. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_log_analytics_workspace_id"></a> [cl\_windows\_vm\_log\_analytics\_workspace\_id](#input\_cl\_windows\_vm\_log\_analytics\_workspace\_id) | (Required) The log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_log_analytics_workspace_sentinel_id"></a> [cl\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id](#input\_cl\_windows\_vm\_log\_analytics\_workspace\_sentinel\_id) | (Required) The log analytics workspace ID for diagnostics. | `any` | `null` | no |
| <a name="input_cl_windows_vm_managed_disks"></a> [cl\_windows\_vm\_managed\_disks](#input\_cl\_windows\_vm\_managed\_disks) | (Optional) Map containing the managed disks attributes | <pre>map(object({<br>    storage_account_type = string<br>    disk_size            = string<br>    lun                  = string<br>    caching              = string<br>  }))</pre> | `{}` | no |
| <a name="input_cl_windows_vm_os_disk_caching"></a> [cl\_windows\_vm\_os\_disk\_caching](#input\_cl\_windows\_vm\_os\_disk\_caching) | (Optional) The caching for the os disk of the windows vm. | `string` | `"ReadWrite"` | no |
| <a name="input_cl_windows_vm_os_disk_disk_size_gb"></a> [cl\_windows\_vm\_os\_disk\_disk\_size\_gb](#input\_cl\_windows\_vm\_os\_disk\_disk\_size\_gb) | (Optional) The disk size gb for the os disk of the windows vm. | `string` | `"128"` | no |
| <a name="input_cl_windows_vm_os_disk_storage_account_type"></a> [cl\_windows\_vm\_os\_disk\_storage\_account\_type](#input\_cl\_windows\_vm\_os\_disk\_storage\_account\_type) | (Optional) The storage account type for the os disk of the windows vm. | `string` | `"Standard_LRS"` | no |
| <a name="input_cl_windows_vm_os_disk_write_accelerator_enabled"></a> [cl\_windows\_vm\_os\_disk\_write\_accelerator\_enabled](#input\_cl\_windows\_vm\_os\_disk\_write\_accelerator\_enabled) | (Optional) Boolean to enable write accelerator enabled. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_os_ultra_ssd_enabled"></a> [cl\_windows\_vm\_os\_ultra\_ssd\_enabled](#input\_cl\_windows\_vm\_os\_ultra\_ssd\_enabled) | (Optional) Boolean to enable ultra ssd enabled. | `bool` | `false` | no |
| <a name="input_cl_windows_vm_ou_path"></a> [cl\_windows\_vm\_ou\_path](#input\_cl\_windows\_vm\_ou\_path) | (Optional) OU path to us during domain join | `string` | `""` | no |
| <a name="input_cl_windows_vm_platform_fault_domain_count"></a> [cl\_windows\_vm\_platform\_fault\_domain\_count](#input\_cl\_windows\_vm\_platform\_fault\_domain\_count) | (Optional) Specifies the number of fault domains that are used. Defaults to 3. Changing this forces a new resource to be created. | `number` | `3` | no |
| <a name="input_cl_windows_vm_post_provisioning_tag"></a> [cl\_windows\_vm\_post\_provisioning\_tag](#input\_cl\_windows\_vm\_post\_provisioning\_tag) | tag to enable post provisioning | `map` | <pre>{<br>  "EnablePrivateNetworkGC": "TRUE"<br>}</pre> | no |
| <a name="input_cl_windows_vm_private_ip_address"></a> [cl\_windows\_vm\_private\_ip\_address](#input\_cl\_windows\_vm\_private\_ip\_address) | (Optional) Private IP of VM defined by end user if allocation = static | `string` | `""` | no |
| <a name="input_cl_windows_vm_private_ip_address_allocation"></a> [cl\_windows\_vm\_private\_ip\_address\_allocation](#input\_cl\_windows\_vm\_private\_ip\_address\_allocation) | (Required) The allocation method used for the Private IP Address. Possible values are Dynamic and Static. | `string` | `"Dynamic"` | no |
| <a name="input_cl_windows_vm_provision_vm_agent"></a> [cl\_windows\_vm\_provision\_vm\_agent](#input\_cl\_windows\_vm\_provision\_vm\_agent) | (Optional) Boolean to enable provision vm agent. | `bool` | `true` | no |
| <a name="input_cl_windows_vm_recovery_vault_name"></a> [cl\_windows\_vm\_recovery\_vault\_name](#input\_cl\_windows\_vm\_recovery\_vault\_name) | (Optional) The name of recovery backup vault. | `any` | `null` | no |
| <a name="input_cl_windows_vm_rg_backup_name"></a> [cl\_windows\_vm\_rg\_backup\_name](#input\_cl\_windows\_vm\_rg\_backup\_name) | (Optional) The RG destination of the windows vm backup. | `any` | `null` | no |
| <a name="input_cl_windows_vm_rg_name"></a> [cl\_windows\_vm\_rg\_name](#input\_cl\_windows\_vm\_rg\_name) | (Optional) The name of the windows VM resource group if cl\_windows\_vm\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_windows_vm_route_table_id"></a> [cl\_windows\_vm\_route\_table\_id](#input\_cl\_windows\_vm\_route\_table\_id) | (Required) The ID of the route table from Core. required for subnet association. | `any` | `null` | no |
| <a name="input_cl_windows_vm_size"></a> [cl\_windows\_vm\_size](#input\_cl\_windows\_vm\_size) | (Optional) The Size of the windows vm. | `string` | `"Standard_DS1_v2"` | no |
| <a name="input_cl_windows_vm_subnet_id"></a> [cl\_windows\_vm\_subnet\_id](#input\_cl\_windows\_vm\_subnet\_id) | (Optional) The subnet ID where the Windows VM will be deployed to. Use this only if cl\_windows\_vm\_deploy\_subnet = false. | `any` | `null` | no |
| <a name="input_cl_windows_vm_subnet_prefix"></a> [cl\_windows\_vm\_subnet\_prefix](#input\_cl\_windows\_vm\_subnet\_prefix) | (Optional) The prefix of the windows vm subnet. | `any` | `null` | no |
| <a name="input_cl_windows_vm_timezone"></a> [cl\_windows\_vm\_timezone](#input\_cl\_windows\_vm\_timezone) | (Optional) The timezone of the windows vm. | `any` | `null` | no |
| <a name="input_cl_windows_vm_user_defined_nsg_rules"></a> [cl\_windows\_vm\_user\_defined\_nsg\_rules](#input\_cl\_windows\_vm\_user\_defined\_nsg\_rules) | (Optional) Define additional NSG rules | <pre>map(object({<br>    name                         = string<br>    priority                     = number<br>    direction                    = string<br>    access                       = string<br>    protocol                     = string<br>    source_port_range            = string<br>    source_port_ranges           = list(string)<br>    destination_port_range       = string<br>    destination_port_ranges      = list(string)<br>    source_address_prefix        = string<br>    source_address_prefixes      = list(string)<br>    destination_address_prefix   = string<br>    destination_address_prefixes = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_cl_windows_vm_vnet_name"></a> [cl\_windows\_vm\_vnet\_name](#input\_cl\_windows\_vm\_vnet\_name) | (Required) The name of the core vnet required for the windows vm subnet. | `any` | n/a | yes |
| <a name="input_cl_windows_vm_vnet_rg_name"></a> [cl\_windows\_vm\_vnet\_rg\_name](#input\_cl\_windows\_vm\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in. | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_windows_log_analytics_ama_settings"></a> [cl\_windows\_log\_analytics\_ama\_settings](#output\_cl\_windows\_log\_analytics\_ama\_settings) | n/a |
| <a name="output_cl_windows_log_analytics_mma_settings"></a> [cl\_windows\_log\_analytics\_mma\_settings](#output\_cl\_windows\_log\_analytics\_mma\_settings) | n/a |
| <a name="output_cl_windows_vm_availability_set"></a> [cl\_windows\_vm\_availability\_set](#output\_cl\_windows\_vm\_availability\_set) | n/a |
| <a name="output_cl_windows_vm_domain_join"></a> [cl\_windows\_vm\_domain\_join](#output\_cl\_windows\_vm\_domain\_join) | n/a |
| <a name="output_cl_windows_vm_machine"></a> [cl\_windows\_vm\_machine](#output\_cl\_windows\_vm\_machine) | n/a |
| <a name="output_cl_windows_vm_managed_disk"></a> [cl\_windows\_vm\_managed\_disk](#output\_cl\_windows\_vm\_managed\_disk) | n/a |
| <a name="output_cl_windows_vm_nic"></a> [cl\_windows\_vm\_nic](#output\_cl\_windows\_vm\_nic) | n/a |
| <a name="output_cl_windows_vm_nsg"></a> [cl\_windows\_vm\_nsg](#output\_cl\_windows\_vm\_nsg) | n/a |
| <a name="output_cl_windows_vm_protected_vm"></a> [cl\_windows\_vm\_protected\_vm](#output\_cl\_windows\_vm\_protected\_vm) | n/a |
| <a name="output_cl_windows_vm_rg"></a> [cl\_windows\_vm\_rg](#output\_cl\_windows\_vm\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_windows_vm_subnet"></a> [cl\_windows\_vm\_subnet](#output\_cl\_windows\_vm\_subnet) | n/a |
| <a name="output_cl_windows_vm_user_defined_nsg_rules"></a> [cl\_windows\_vm\_user\_defined\_nsg\_rules](#output\_cl\_windows\_vm\_user\_defined\_nsg\_rules) | n/a |

## Usage

### Azure Devops Pipelines Agent Installation
Azure Pipelines Agent extension can be installed to deploy software using Azure DevOps Services to the virtual machines hosted in Microsoft Azure. When installed, the extension automatically downloads the Azure Pipelines Agent MSI, installs it, and registers the agent with the specified Deployment Group within your Azure DevOps Organization Project.

For the agent installation, the parameters below should be defined on VM module:

```terraform
  cl_windows_vm_enable_devops_agent               = true
  cl_windows_vm_devops_agent_org_url              = "https://dev.azure.com/<organization>"
  cl_windows_vm_devops_agent_pat                  = "<PERSONAL ACCESS TOKEN>"
  cl_windows_vm_devops_agent_team_project         = "<TEAM PROJECT NAME>"
  cl_windows_vm_devops_agent_deployment_group     = "<DEPLOYMENT GROUPS NAME>"
```

#### Useful Links
[Get started with the agent](https://docs.microsoft.com/azure/devops/pipelines/agents/agents?view=azure-devops#install).
[Azure Pipelines](https://azure.microsoft.com/en-us/services/devops/pipelines/)
[Deployment Groups](https://aka.ms/832442)
[Personal access tokens](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate)

#### Deploy VM With Azure Devops Agent
```terraform
// Deploys Windows VM with the Azure Devops Agent installed
//**********************************************************************************************
module "cl_windows_vm" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_windows_vm"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_windows_vm_app_name                          = var.windows_vm_app_name
  cl_windows_vm_computer_name                     = var.windows_vm_computer_name  
  cl_windows_vm_image_id                          = var.windows_vm_image_id
  cl_windows_vm_availability_set_id               = var.availability_set_id
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = true
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host_enabled = false
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS
# cl_windows_vm_user_defined_nsg_rules            = {
#     allow_6379_6380 = {
#       name                        = "Allow6379and6380Inbound"
#       priority                    = 1013
#       direction                   = "Inbound"
#       access                      = "Allow"
#       protocol                    = "Tcp"
#       source_port_range           = "*"
#       source_port_ranges          = null
#       destination_port_range      = null
#       destination_port_ranges     = ["6379", "6380"]
#       source_address_prefix       = "10.69.22.78/27"
#       source_address_prefixes     = null
#       destination_address_prefix  = "10.69.22.89/27"  
#       destination_address_prefixes  = null  
#     }
}
  
  // DevOps Configs
  cl_windows_vm_enable_devops_agent               = true
  cl_windows_vm_devops_agent_org_url              = "https://dev.azure.com/contoso"
  cl_windows_vm_devops_agent_pat                  = "xmtvguqak3k2lxi5gu633c6pgzjbjznczxwlvxmp2glluot4dkftfqx"
  cl_windows_vm_devops_agent_team_project         = "CONTOSO"
  cl_windows_vm_devops_agent_deployment_group     = "CONTOSO-SBOX"
}
//**********************************************************************************************
```
#### Deploy VM Without Azure Devops Agent
```terraform
// Deploys Windows VM without the Azure Devops Agent installed
//***************************************************************************************************
module "cl_windows_vm_power_bi_gateway" {
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_windows_vm"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_windows_vm_app_name                          = var.power_bi_gateway_vm_app_name
  cl_windows_vm_computer_name                     = var.power_bi_gateway_vm_computer_name  
  cl_windows_vm_image_id                          = var.power_bi_gateway_vm_image_id
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = false
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host_enabled = false
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix 
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS
  cl_windows_vm_managed_disks                     = {
                                                        data = {
                                                            storage_account_type = "StandardSSD_LRS"
                                                            disk_size            = "80"
                                                            lun                  = "1"
                                                            caching              = "None"
                                                        }
                                                    } 
}
//***************************************************************************************************
```
<!-- END_TF_DOCS -->
# Azure Bastion Component

Azure Bastion allows to RDP/SSH into a virtual machine without the need for a public IP on the VM (thus enforces secure access). 
This component will create an Azure Bastion and deploy the following for that resource: NSG, NSG inbound & outbound rules, additional security rules and diagnostic settings.

For more information, please visit:  https://docs.microsoft.com/en-us/azure/bastion/bastion-overview
## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_azure_bastion_sku = var.cl_azure_bastion_centralized_enable ? "Standard" : "Basic" 
  az_bastion_public_ip_diagnotics_settingss = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
```
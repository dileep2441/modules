<!-- BEGIN_TF_DOCS -->

# Azure Service Bus Component

Azure Service Bus is a messaging service on cloud used to connect any applications, devices, and services running in the cloud to any other applications or services. 
As a result, it acts as a messaging backbone for applications available in the cloud or across any devices.
This component will deploy Azure Service Bus, Athoritation rules, Monitor Diagnostics, Monitor Autoscale, Network Security and Private Endpoint for allowed Subnets.

Service Bus comes in Basic, standard, and premium tiers. with the following table you can select the value of the sku variable that you require:

FEATURE				            BASIC		    STANDARD	    PREMIUM
Queues					        Available	    Available	    Available
Scheduled messages			    Available	    Available	    Available
Topics					        Not available	Available	    Available
Transactions				    Not available	Available	    Available
De-duplication				    Not available	Available	    Available
Sessions				        Not available	Available	    Available
ForwardTo/SendVia			    Not available	Available	    Available
Message Size				    256 KB		    256 KB		    1 MB
Resource isolation			    Not available	Not available	Available
Geo-Disaster Recovery (Geo-DR)	Not available	Not available	Available							
Availability Zones (AZ) support	Not available	Not available	Available

For more information, please information: https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-messaging-overview




## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_autoscale_setting.cl_service_bus_autoscale_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_autoscale_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_service_bus_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_service_bus_private_endpoint_service_bus](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_servicebus_namespace.cl_service_bus](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace) | resource |
| [azurerm_servicebus_namespace_authorization_rule.cl_service_bus_namespace_rule](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace_authorization_rule) | resource |
| [azurerm_servicebus_namespace_network_rule_set.cl_service_bus_network_rule_default](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace_network_rule_set) | resource |
| [azurerm_servicebus_namespace_network_rule_set.cl_service_bus_network_rule_selected_network_access](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/servicebus_namespace_network_rule_set) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_service_bus_allowed_ips"></a> [cl\_service\_bus\_allowed\_ips](#input\_cl\_service\_bus\_allowed\_ips) | (Optional) One or more IP Addresses, or CIDR Blocks which should be able to access the ServiceBus Namespace. var.cl\_service\_bus\_public\_network\_access\_enabled must be set to true. | `list(string)` | `[]` | no |
| <a name="input_cl_service_bus_allowed_subnets"></a> [cl\_service\_bus\_allowed\_subnets](#input\_cl\_service\_bus\_allowed\_subnets) | (Required) One or more Subnet ID's which should be able to access this service bus. var.cl\_service\_bus\_public\_network\_access\_enabled must be set to true. | `list(string)` | `[]` | no |
| <a name="input_cl_service_bus_autoscale_settings_default"></a> [cl\_service\_bus\_autoscale\_settings\_default](#input\_cl\_service\_bus\_autoscale\_settings\_default) | (Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 1 and 8. | `number` | `1` | no |
| <a name="input_cl_service_bus_autoscale_settings_maximum"></a> [cl\_service\_bus\_autoscale\_settings\_maximum](#input\_cl\_service\_bus\_autoscale\_settings\_maximum) | (Optional) The maximum number of instances for this resource. Valid values are between 1 and 8. | `number` | `2` | no |
| <a name="input_cl_service_bus_autoscale_settings_metric_name"></a> [cl\_service\_bus\_autoscale\_settings\_metric\_name](#input\_cl\_service\_bus\_autoscale\_settings\_metric\_name) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"NamespaceCpuUsage"` | no |
| <a name="input_cl_service_bus_autoscale_settings_metric_name_memory"></a> [cl\_service\_bus\_autoscale\_settings\_metric\_name\_memory](#input\_cl\_service\_bus\_autoscale\_settings\_metric\_name\_memory) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"NamespaceMemoryUsage"` | no |
| <a name="input_cl_service_bus_autoscale_settings_minimum"></a> [cl\_service\_bus\_autoscale\_settings\_minimum](#input\_cl\_service\_bus\_autoscale\_settings\_minimum) | (Optional) The minimum number of instances for this resource. Valid values are between 1 and 8. | `number` | `1` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_in_operator"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_in\_operator](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_in\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"LessThan"` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_in_threshold"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_in\_threshold](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_in\_threshold) | (Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action. | `number` | `25` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_out_operator"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_out\_operator](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_out\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"GreaterThan"` | no |
| <a name="input_cl_service_bus_autoscale_settings_scale_out_threshold"></a> [cl\_service\_bus\_autoscale\_settings\_scale\_out\_threshold](#input\_cl\_service\_bus\_autoscale\_settings\_scale\_out\_threshold) | (Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action. | `number` | `75` | no |
| <a name="input_cl_service_bus_autoscale_settings_statistic"></a> [cl\_service\_bus\_autoscale\_settings\_statistic](#input\_cl\_service\_bus\_autoscale\_settings\_statistic) | (Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max. | `string` | `"Average"` | no |
| <a name="input_cl_service_bus_autoscale_settings_time_aggregation"></a> [cl\_service\_bus\_autoscale\_settings\_time\_aggregation](#input\_cl\_service\_bus\_autoscale\_settings\_time\_aggregation) | (Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total. | `string` | `"Average"` | no |
| <a name="input_cl_service_bus_autoscale_settings_time_grain"></a> [cl\_service\_bus\_autoscale\_settings\_time\_grain](#input\_cl\_service\_bus\_autoscale\_settings\_time\_grain) | (Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string. | `string` | `"PT1M"` | no |
| <a name="input_cl_service_bus_autoscale_settings_time_window"></a> [cl\_service\_bus\_autoscale\_settings\_time\_window](#input\_cl\_service\_bus\_autoscale\_settings\_time\_window) | (Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string. | `string` | `"PT5M"` | no |
| <a name="input_cl_service_bus_diagnostics"></a> [cl\_service\_bus\_diagnostics](#input\_cl\_service\_bus\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "OperationalLogs",<br>    "VNetAndIPFilteringLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_service_bus_log_analytics_workspace_id"></a> [cl\_service\_bus\_log\_analytics\_workspace\_id](#input\_cl\_service\_bus\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_service_bus_log_analytics_workspace_name"></a> [cl\_service\_bus\_log\_analytics\_workspace\_name](#input\_cl\_service\_bus\_log\_analytics\_workspace\_name) | (Required) The the log analytics workspace name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_service_bus_namespace_capacity"></a> [cl\_service\_bus\_namespace\_capacity](#input\_cl\_service\_bus\_namespace\_capacity) | Specifies the capacity. When sku is Premium, capacity can be 1, 2, 4 or 8. When sku is Basic or Standard, capacity can be 0 only | `number` | `2` | no |
| <a name="input_cl_service_bus_namespace_sku"></a> [cl\_service\_bus\_namespace\_sku](#input\_cl\_service\_bus\_namespace\_sku) | Defines which tier to use. Options are Basic, Standard or Premium | `string` | `"Premium"` | no |
| <a name="input_cl_service_bus_public_network_access_enabled"></a> [cl\_service\_bus\_public\_network\_access\_enabled](#input\_cl\_service\_bus\_public\_network\_access\_enabled) | (Optional) Whether to allow traffic over public network. Possible values are true and false | `bool` | `false` | no |
| <a name="input_cl_service_bus_rg_name"></a> [cl\_service\_bus\_rg\_name](#input\_cl\_service\_bus\_rg\_name) | Name of resource name | `string` | n/a | yes |
| <a name="input_cl_service_bus_trusted_services_allowed"></a> [cl\_service\_bus\_trusted\_services\_allowed](#input\_cl\_service\_bus\_trusted\_services\_allowed) | (Optional) If True, then Azure Services that are known and trusted for this resource type are allowed to bypass firewall configuration. | `bool` | `false` | no |
| <a name="input_cl_service_bus_zone_redundant"></a> [cl\_service\_bus\_zone\_redundant](#input\_cl\_service\_bus\_zone\_redundant) | Whether or not this resource is zone redundant. sku needs to be Premium. Defaults to false. | `bool` | `false` | no |
| <a name="input_env"></a> [env](#input\_env) | The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to the resource | `map(string)` | `{}` | no |

## Local values

```terraform
locals {
    cl_service_bus_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.servicebus.usgovcloudapi.net"]
    }
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_service_bus"></a> [cl\_service\_bus](#output\_cl\_service\_bus) | Outputs Azure Service Bus ********************************************************************************************** |
| <a name="output_cl_service_bus_autoscale_settings"></a> [cl\_service\_bus\_autoscale\_settings](#output\_cl\_service\_bus\_autoscale\_settings) | n/a |
| <a name="output_cl_service_bus_diagnostic_setting"></a> [cl\_service\_bus\_diagnostic\_setting](#output\_cl\_service\_bus\_diagnostic\_setting) | n/a |
| <a name="output_cl_service_bus_namespace_rule"></a> [cl\_service\_bus\_namespace\_rule](#output\_cl\_service\_bus\_namespace\_rule) | n/a |
| <a name="output_cl_service_bus_private_endpoint_service_bus"></a> [cl\_service\_bus\_private\_endpoint\_service\_bus](#output\_cl\_service\_bus\_private\_endpoint\_service\_bus) | n/a |

## Usage

```terraform
# // Azure Service Bus
# //**********************************************************************************************
module "cl_service_bus" {
    source                                         = "../dn-tads_tf-azure-component-library/components/cl_service_bus_gov"
    env                                            = var.env
    postfix                                        = var.postfix
    location                                       = var.location
    suffix                                         = var.suffix
    cl_service_bus_rg_name                         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
    cl_service_bus_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_service_bus_log_analytics_workspace_name    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
    cl_service_bus_allowed_subnets                 = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
    tags                                           = var.tags
}
# //**********************************************************************************************
```
<!-- END_TF_DOCS -->
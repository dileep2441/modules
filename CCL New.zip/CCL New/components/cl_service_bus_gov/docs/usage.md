## Usage

```terraform
# // Azure Service Bus
# //**********************************************************************************************
module "cl_service_bus" {
    source                                         = "../dn-tads_tf-azure-component-library/components/cl_service_bus_gov"
    env                                            = var.env
    postfix                                        = var.postfix
    location                                       = var.location
    suffix                                         = var.suffix
    cl_service_bus_rg_name                         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
    cl_service_bus_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_service_bus_log_analytics_workspace_name    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
    cl_service_bus_allowed_subnets                 = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
    tags                                           = var.tags
}
# //**********************************************************************************************
```

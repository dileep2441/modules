# Azure Service Bus Component

Azure Service Bus is a messaging service on cloud used to connect any applications, devices, and services running in the cloud to any other applications or services. 
As a result, it acts as a messaging backbone for applications available in the cloud or across any devices.
This component will deploy Azure Service Bus, Athoritation rules, Monitor Diagnostics, Monitor Autoscale, Network Security and Private Endpoint for allowed Subnets.

Service Bus comes in Basic, standard, and premium tiers. with the following table you can select the value of the sku variable that you require:

FEATURE				            BASIC		    STANDARD	    PREMIUM
Queues					        Available	    Available	    Available
Scheduled messages			    Available	    Available	    Available
Topics					        Not available	Available	    Available
Transactions				    Not available	Available	    Available
De-duplication				    Not available	Available	    Available
Sessions				        Not available	Available	    Available
ForwardTo/SendVia			    Not available	Available	    Available
Message Size				    256 KB		    256 KB		    1 MB
Resource isolation			    Not available	Not available	Available
Geo-Disaster Recovery (Geo-DR)	Not available	Not available	Available							
Availability Zones (AZ) support	Not available	Not available	Available

For more information, please information: https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-messaging-overview


# Azure CosmosDB Component

Azure Cosmos DB is Microsoft’s fully managed, globally distributed and horizontally scalable cloud service. 
It’s a multi-model NoSQL database that provides independent scaling across all the Azure regions. It can support many use cases such as document, key value, relational, and graph models. 
This component will deploy Azure CosmosDB, a private endpoint and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/cosmos-db/introduction 
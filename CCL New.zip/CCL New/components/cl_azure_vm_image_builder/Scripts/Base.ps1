if (-Not (Test-Path -Path C:\BuildLog)) {
    $null = New-Item -Path C:\BuildLog -ItemType Directory -Force
}
Start-Transcript -Path "C:\BuildLog\$(Get-Date -Format yyyyMMdd).log" -Append -Force  -Confirm:$false
Write-Output "Starting Base.ps1"

Write-Output "Configuring Windows to hide last logged in user name and server manager"
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'DontDisplayLastUserName' -Value 0 -Type DWORD -Force
Disable-ScheduledTask -TaskName "ServerManager" -TaskPath "Microsoft\Windows\Server Manager" | Out-Null

# Local Admins
$Groups = @(
    'S-1-5-21-1232934697-1086943095-315576832-1028002', # US-SG-Techops-TSO
    'S-1-5-21-1232934697-1086943095-315576832-1039212', # US-SG Techops SVCAccounts
    'S-1-5-21-1232934697-1086943095-315576832-1025068', # US-SG TechOps SAG Windows
    'S-1-5-21-1232934697-1086943095-315576832-1025603', # US-SG TechOps NOC All EMP USC
    'S-1-5-21-1232934697-1086943095-315576832-1025072', # US-SG TechOps LCM Admin
    'S-1-5-21-1232934697-1086943095-315576832-1027968', # US-SG TechOps Build Admin
    'S-1-5-21-1232934697-1086943095-315576832-1025617', # US-SG TechOps Backup Ops
    'S-1-5-21-1232934697-1086943095-315576832-1025590', # US-SG TechOps Automation EMP USC
    'S-1-5-21-1232934697-1086943095-315576832-1226263', # US-SG SDL Build
    'S-1-5-21-1232934697-1086943095-315576832-869495'   # us-svcscomaap
)

Write-Output "Adding domain groups to local administrators group"
$LocalGroup = 'Administrators'
foreach ($Group in $Groups) {
    $Adsi = [ADSI]"WinNT://$env:COMPUTERNAME"
    $LocalGroupObject = $Adsi.psbase.Children.find($LocalGroup)
    try {
        $LocalGroupObject.Add("WinNT://$Group")
    } catch {

    }
}

# Local Groups
Write-Output "Creating local groups used by GPOs"
$LocalGroups = @(
    'GO-SG AllowLocalLogon',
    'GO-SG DenyBatchLogon',
    'GO-SG DenyNetLogon',
    'GO-SG DenyTS',
    'GO-SG ManageSecurityLogs',
    'GO-SG PowerUsers',
    'GO-SG ProcessSettings',
    'GO-SG System'
)
foreach ($LocalGroup in $LocalGroups) {
    $Adsi = [ADSI]"WinNT://$env:COMPUTERNAME"
    $Group = $Adsi.Create("Group", $LocalGroup)
    $Group.SetInfo()
    $Group.Description = "Needed for GPO"
    $Group.SetInfo()
}

# Power Scheme
Write-Output "Setting power scheme to high performance"
$TargetScheme = 'High performance'
$PowerCfgOutput = powercfg -list
$SchemeNamePattern = '\((?<SchemeName>[\w\s]+)\)'
$SchemeGuidPattern = '(?<guid>\w+\-\w+\-\w+\-\w+\-\w+)'
$Results = @{}
foreach ($Line in $PowerCfgOutput)
{
    if ($Line -match $SchemeNamePattern)
    {
        $Name = $Matches['SchemeName']
        if ($Line -match $SchemeGuidPattern)
        {
            $Results[$Name] = $Matches['guid']
        }
    }
}
powercfg -setactive $Results[$TargetScheme]

Write-Output "Disabling SMB1 protocol"
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name SMB1 -Value 0 -Type DWORD -Force
if (Get-Command -Name Disable-WindowsOptionalFeature -ErrorAction SilentlyContinue) {
    if (Get-WindowsOptionalFeature -Online -FeatureName smb1protocol -ErrorAction SilentlyContinue) {
        Disable-WindowsOptionalFeature -Online -FeatureName smb1protocol -NoRestart
    }
}
if ((sc.exe qc lanmanworkstation) -match 'MRxSmb10') {
    sc.exe config lanmanworkstation depend= mrxsmb20/nsi
    sc.exe config mrxsmb10 start= disabled
}

Write-Output "Disabling Windows firewall"
# Hardening
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 0 -Type DWORD -Force
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name 'UserAuthentication' -Value 1 -Type DWORD -Force
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name 'SecurityLayer' -Value 2 -Type DWORD -Force
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -Name 'MinEncryptionLevel' -Value 3 -Type DWORD -Force

Write-Output "Disabling older SSL/TLS protocols"
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Force
$Protocol.SetValue('Enabled', 1)
$Protocol.SetValue('DisabledByDefault', 0)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Force
$Protocol.SetValue('Enabled', 1)
$Protocol.SetValue('DisabledByDefault', 0)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)
$Protocol = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Force
$Protocol.SetValue('Enabled', 0)
$Protocol.SetValue('DisabledByDefault', 1)

Write-Output "Enabling Key Exchange Algorithms"
$KeyExchangeAlgorithm = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman' -Force
$KeyExchangeAlgorithm.SetValue('Enabled', 4294967295)
$KeyExchangeAlgorithm = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\ECDH' -Force
$KeyExchangeAlgorithm.SetValue('Enabled', 4294967295)
$KeyExchangeAlgorithm = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\PKCS' -Force
$KeyExchangeAlgorithm.SetValue('Enabled', 4294967295)

Write-Output "Enabling common and secure hashes"
$Hash = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -Force
$Hash.SetValue('Enabled', 4294967295)
$Hash = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA' -Force
$Hash.SetValue('Enabled', 4294967295)
$Hash = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA256' -Force
$Hash.SetValue('Enabled', 4294967295)
$Hash = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA384' -Force
$Hash.SetValue('Enabled', 4294967295)
$Hash = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA512' -Force
$Hash.SetValue('Enabled', 4294967295)

Write-Output "Disabling insecure ciphers"
$Ciphers = New-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers' -Force
$InsecureCiphers = @(
    "DES 56/56",
    "NULL",
    "RC2 128/128",
    "RC2 40/128",
    "RC2 56/128",
    "RC4 40/128",
    "RC4 56/128",
    "RC4 64/128",
    "RC4 128/128",
    "Triple DES 168",
    "Triple DES 168/168"
)

foreach ($InsecureCipher in $InsecureCiphers) {
    $Cipher = $Ciphers.CreateSubKey($InsecureCipher)
    $Cipher.SetValue('Enabled', 0)
}

Write-Output "Enabling secure ciphers"
$SecureCiphers = @(
    "AES 128/128",
    "AES 256/256"
)
foreach ($SecureCipher in $SecureCiphers) {
    $Cipher = $Ciphers.CreateSubKey($SecureCipher)
    $Cipher.SetValue('Enabled', 0xffffffff)
}

Write-Output "Disabling IPv6 and configuring crash dump"
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' -Name 'DisabledComponents' -Value 4294967295 -Type DWORD -Force
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'CrashDumpEnabled' -Value 3 -Type DWORD -Force

# Disable UAC
Write-Output "Disable UAC for builtin Administrator"
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name FilterAdministratorToken -Value 0 -Type DWORD -Force

# set reposerver permanently
[System.Environment]::SetEnvironmentVariable('REPOSERVER', '\\winrepo-mdc-sh.us.kworld.kpmg.com\Repo', 'PROCESS')
[System.Environment]::SetEnvironmentVariable('REPOSERVER', '\\winrepo-mdc-sh.us.kworld.kpmg.com\Repo', 'MACHINE')

Write-Output "Finished Base.ps1"
Stop-Transcript

exit 0
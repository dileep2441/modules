# Azure App Service Slot Component

App Service Slot is an additional feature to Azure App Service. It allows to perform blue-green deployments for the App Service, eliminating downtime on deployments or even allow to run separate versions of the Application on the same Azure App Service.
This component will deploy an app service slot in the target app service (hence on the same App Service Plan), bind the app service slot to the integration subnet,
configure a private endpoint, custom domain and diagnostics for the app service.

For more information, please visit: https://docs.microsoft.com/en-us/azure/app-service/deploy-staging-slots
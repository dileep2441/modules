# Azure Container Registry Component

This is the Azure Container Registry component. It will deploy Azure Container Registry with: IP rules, Content Trust option. Also Private DNS Zone, DNS Zone link for VNET's of allowed subnets, Diagnostic Settings and Private Endpoint for allowed Subnets.

Important! If admin is enabled please store and maintain the user and password as secrets into a KeyVault.

Azure Defender only supported for Linux images with public and shell access:
https://docs.microsoft.com/en-us/azure/security-center/defender-for-container-registries-introduction
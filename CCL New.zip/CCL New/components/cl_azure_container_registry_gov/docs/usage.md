## Usage

```terraform
module "cl_azure_container_registry" {
    source                                                 = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry_gov"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    tags                                                   = var.tags
    suffix                                                 = var.suffix
    cl_azure_container_registry_rg_name                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
    cl_azure_container_registry_allowed_subnets            = [subnetID_1, subnetID_2, subnetID_N]
    cl_azure_container_registry_allowed_vnets              = [vnetID_1, vnetID_2, vnetID_N]
    cl_azure_container_registry_ip_rule_ranges              = ["CIDR_1", "CIDR_N"]
}
```
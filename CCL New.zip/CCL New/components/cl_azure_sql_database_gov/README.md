<!-- BEGIN_TF_DOCS -->

# Azure SQL Database Component

Azure SQL Database is a fully managed platform as a service (PaaS) database engine that handles most of the database management functions such as upgrading, patching, backups, and monitoring without user involvement. 
This component will deploy an Azure SQL Database, audit policy and a diagnostic settings for the Azure SQL Database.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview


#### Note:
To get this code to work, it needs Terraform version 0.15 or later.
It can be specified in a Github Action Task:
```Githubaction task
    - name: Setup Terraform
      uses: hashicorp/setup-terraform@v1
      with:
        terraform_version: ${{ env.TF_VERSION }}   
```
Specify TF version in `pattern_backend.tf`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```

## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_azure_sql_database_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_mssql_database.cl_azure_sql_database](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_database) | resource |
| [azurerm_mssql_database_extended_auditing_policy.cl_azure_sql_database_audit_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_database_extended_auditing_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_sql_database_LTR_monthly_retention"></a> [cl\_azure\_sql\_database\_LTR\_monthly\_retention](#input\_cl\_azure\_sql\_database\_LTR\_monthly\_retention) | (Optional) The monthly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D. | `string` | `"P1M"` | no |
| <a name="input_cl_azure_sql_database_LTR_week_of_year"></a> [cl\_azure\_sql\_database\_LTR\_week\_of\_year](#input\_cl\_azure\_sql\_database\_LTR\_week\_of\_year) | (Required) The week of year to take the yearly backup. Value has to be between 1 and 52. | `number` | `1` | no |
| <a name="input_cl_azure_sql_database_LTR_weekly_retention"></a> [cl\_azure\_sql\_database\_LTR\_weekly\_retention](#input\_cl\_azure\_sql\_database\_LTR\_weekly\_retention) | (Optional) The weekly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 520 weeks. e.g. P1Y, P1M, P1W or P7D. | `string` | `"P1W"` | no |
| <a name="input_cl_azure_sql_database_LTR_yearly_retention"></a> [cl\_azure\_sql\_database\_LTR\_yearly\_retention](#input\_cl\_azure\_sql\_database\_LTR\_yearly\_retention) | (Optional) The yearly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 10 years. e.g. P1Y, P12M, P52W or P365D. | `string` | `"P1Y"` | no |
| <a name="input_cl_azure_sql_database_STR_retention"></a> [cl\_azure\_sql\_database\_STR\_retention](#input\_cl\_azure\_sql\_database\_STR\_retention) | (Required) Point In Time Restore configuration. Value has to be between 7 and 35. | `number` | `35` | no |
| <a name="input_cl_azure_sql_database_audit_enabled"></a> [cl\_azure\_sql\_database\_audit\_enabled](#input\_cl\_azure\_sql\_database\_audit\_enabled) | (Optional) Boolean to enable sql db extended auditing policy resource creation | `bool` | `false` | no |
| <a name="input_cl_azure_sql_database_audit_retention_days"></a> [cl\_azure\_sql\_database\_audit\_retention\_days](#input\_cl\_azure\_sql\_database\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `180` | no |
| <a name="input_cl_azure_sql_database_collation"></a> [cl\_azure\_sql\_database\_collation](#input\_cl\_azure\_sql\_database\_collation) | (Optional) Specifies the collation of the database. Changing this forces a new resource to be created. | `string` | `"SQL_Latin1_General_CP1_CI_AS"` | no |
| <a name="input_cl_azure_sql_database_create_mode"></a> [cl\_azure\_sql\_database\_create\_mode](#input\_cl\_azure\_sql\_database\_create\_mode) | (Optional) The create mode of the database. Possible values are Copy, Default, OnlineSecondary, PointInTimeRestore, Recovery, Restore, RestoreExternalBackup, RestoreExternalBackupSecondary, RestoreLongTermRetentionBackup and Secondary. | `string` | `"Default"` | no |
| <a name="input_cl_azure_sql_database_diagnostics"></a> [cl\_azure\_sql\_database\_diagnostics](#input\_cl\_azure\_sql\_database\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "SQLInsights",<br>    "AutomaticTuning",<br>    "QueryStoreRuntimeStatistics",<br>    "QueryStoreWaitStatistics",<br>    "Errors",<br>    "DatabaseWaitStatistics",<br>    "Timeouts",<br>    "Blocks",<br>    "Deadlocks"<br>  ],<br>  "metrics": [<br>    "Basic",<br>    "InstanceAndAppAdvanced",<br>    "WorkloadManagement"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_sql_database_disabled_alerts"></a> [cl\_azure\_sql\_database\_disabled\_alerts](#input\_cl\_azure\_sql\_database\_disabled\_alerts) | (Optional) Specifies a list of alerts which should be disabled. Possible values include Access\_Anomaly, Sql\_Injection and Sql\_Injection\_Vulnerability. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_database_elastic_pool_id"></a> [cl\_azure\_sql\_database\_elastic\_pool\_id](#input\_cl\_azure\_sql\_database\_elastic\_pool\_id) | (Optional) The Elastic Pool id to Integrate the DB with one azure sql elastic pool. | `string` | `null` | no |
| <a name="input_cl_azure_sql_database_license"></a> [cl\_azure\_sql\_database\_license](#input\_cl\_azure\_sql\_database\_license) | (Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_cl_azure_sql_database_postfix"></a> [cl\_azure\_sql\_database\_postfix](#input\_cl\_azure\_sql\_database\_postfix) | (Required) A string that is appended to the end of the database name to identify it. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_database_read"></a> [cl\_azure\_sql\_database\_read](#input\_cl\_azure\_sql\_database\_read) | (Optional) If enabled, connections that have application intent set to readonly in their connection string may be routed to a readonly secondary replica. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_database_redudant"></a> [cl\_azure\_sql\_database\_redudant](#input\_cl\_azure\_sql\_database\_redudant) | (Optional) Whether or not this database is zone redundant, which means the replicas of this database will be spread across multiple availability zones. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_cl_azure_sql_database_replica_count"></a> [cl\_azure\_sql\_database\_replica\_count](#input\_cl\_azure\_sql\_database\_replica\_count) | (Optional) The number of readonly secondary replicas associated with the database to which readonly application intent connections may be routed. This property is only settable for Hyperscale edition databases. | `number` | `null` | no |
| <a name="input_cl_azure_sql_database_sample_name"></a> [cl\_azure\_sql\_database\_sample\_name](#input\_cl\_azure\_sql\_database\_sample\_name) | (Optional) Sample eschema to be loaded into. | `string` | `null` | no |
| <a name="input_cl_azure_sql_database_size"></a> [cl\_azure\_sql\_database\_size](#input\_cl\_azure\_sql\_database\_size) | (Optional) The max size of the database in gigabytes. | `number` | `1` | no |
| <a name="input_cl_azure_sql_database_sku"></a> [cl\_azure\_sql\_database\_sku](#input\_cl\_azure\_sql\_database\_sku) | (Optional) Specifies the name of the sku used by the database. Changing this forces a new resource to be created. Single Database default value: BC\_Gen5\_2. If the database require be include in Elastic Pool group, in variable sku default value: ElasticPool. | `string` | `"BC_Gen5_2"` | no |
| <a name="input_cl_azure_sql_database_threat_email_admins"></a> [cl\_azure\_sql\_database\_threat\_email\_admins](#input\_cl\_azure\_sql\_database\_threat\_email\_admins) | (Optional) Should the account administrators be emailed when this alert is triggered? | `string` | `"Disabled"` | no |
| <a name="input_cl_azure_sql_database_threat_emails"></a> [cl\_azure\_sql\_database\_threat\_emails](#input\_cl\_azure\_sql\_database\_threat\_emails) | (Optional) A list of email addresses which alerts should be sent to. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_sql_database_threat_logs_retention"></a> [cl\_azure\_sql\_database\_threat\_logs\_retention](#input\_cl\_azure\_sql\_database\_threat\_logs\_retention) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_cl_azure_sql_database_threat_policy_state"></a> [cl\_azure\_sql\_database\_threat\_policy\_state](#input\_cl\_azure\_sql\_database\_threat\_policy\_state) | (Optional) The State of the Policy. Possible values are Enabled, Disabled or New. | `string` | `"Enabled"` | no |
| <a name="input_cl_azure_sql_database_workspace_id"></a> [cl\_azure\_sql\_database\_workspace\_id](#input\_cl\_azure\_sql\_database\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_sql_server_id"></a> [cl\_azure\_sql\_server\_id](#input\_cl\_azure\_sql\_server\_id) | (Required) The id of the Ms SQL Server on which to create the database. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_cl_azure_storage_account_access_key"></a> [cl\_azure\_storage\_account\_access\_key](#input\_cl\_azure\_storage\_account\_access\_key) | (Required) Specifies the access key to use for the auditing storage account. | `any` | n/a | yes |
| <a name="input_cl_azure_storage_account_endpoint"></a> [cl\_azure\_storage\_account\_endpoint](#input\_cl\_azure\_storage\_account\_endpoint) | (Required) Specifies the blob storage endpoint. | `any` | n/a | yes |
| <a name="input_cl_azure_storage_account_secondary_access_key"></a> [cl\_azure\_storage\_account\_secondary\_access\_key](#input\_cl\_azure\_storage\_account\_secondary\_access\_key) | (Optional) Specifies whether cl\_azure\_storage\_account\_access\_key value is the storage's secondary key. | `bool` | `false` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_sql_database"></a> [cl\_azure\_sql\_database](#output\_cl\_azure\_sql\_database) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_sql_database_diagnostic_settings"></a> [cl\_azure\_sql\_database\_diagnostic\_settings](#output\_cl\_azure\_sql\_database\_diagnostic\_settings) | n/a |


## Usage
### Deploy single SQL Database
```terraform
module "cl_azure_sql_server" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_server_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  suffix                                           = var.suffix
  tags                                             = var.tags
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
    }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_sa_private_dns_zone_ids      = var.cl_azure_sql_server_sa_private_dns_zone_ids
  cl_azure_sql_server_private_dns_zone_ids         = var.cl_azure_sql_server_private_dns_zone_ids
  cl_azure_sql_server_sa_enable_backup                    = true
  cl_azure_sql_server_sa_backup_vault_id                  = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_azure_sql_server_sa_backup_vault                     = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_azure_sql_server_sa_backup_policy_id                 = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_azure_sql_server_login_username                      = "wtamayo@kpmgnp.onmicrosoft.us"
  cl_azure_sql_server_object_id                           = "f3f17b13-24d1-4e1b-ad44-44a748688393"
  cl_azure_sql_server_sa_allowed_vnet_subnet_ids          = var.cl_azure_sql_server_sa_allowed_vnet_subnet_ids 
  cl_azure_sql_server_sa_allowed_pe_subnet_ids            = var.cl_azure_sql_server_sa_allowed_pe_subnet_ids
}

module "cl_azure_sql_database" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_database_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  tags                                                    = var.tags
  cl_azure_sql_database_postfix                    = "globaldb"
  cl_azure_sql_server_id                           = module.cl_azure_sql_server.cl_azure_sql_server.id
  cl_azure_storage_account_endpoint                = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_blob_endpoint
  cl_azure_storage_account_access_key              = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_access_key
  cl_azure_sql_database_workspace_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id 
}
```

### Deploy SQL Database with SQL Elastic Pool
```terraform
module "cl_azure_sql_elastic_pool" {
   source                                               = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_elastic_pool_gov"
   cl_azure_sql_elastic_pool_enable                     = true
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   tags                                                    = var.tags
   cl_azure_sql_elastic_pool_postfix                    = "globaldb"
   cl_azure_sql_elastic_pool_resource_group_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
   cl_azure_sql_elastic_pool_server_name                = module.cl_azure_sql_server.cl_azure_sql_server.name
   cl_azure_sql_elastic_pool_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
}

module "cl_azure_sql_server" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_server_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  tags                                                    = var.tags
  suffix                                           = var.suffix
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_sa_private_dns_zone_ids      = var.cl_azure_sql_server_sa_private_dns_zone_ids
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
    }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids         = var.cl_azure_sql_server_private_dns_zone_ids
  cl_azure_sql_server_sa_enable_backup                    = true
  cl_azure_sql_server_sa_backup_vault_id                  = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_azure_sql_server_sa_backup_vault                     = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_azure_sql_server_sa_backup_policy_id                 = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_azure_sql_server_login_username                      = "wtamayo@kpmgnp.onmicrosoft.us"
  cl_azure_sql_server_object_id                           = "f3f17b13-24d1-4e1b-ad44-44a748688393"
  cl_azure_sql_server_sa_allowed_vnet_subnet_ids          = var.cl_azure_sql_server_sa_allowed_vnet_subnet_ids 
  cl_azure_sql_server_sa_allowed_pe_subnet_ids            = var.cl_azure_sql_server_sa_allowed_pe_subnet_ids
}

module "cl_azure_sql_database" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_database_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  tags                                                    = var.tags
  cl_azure_sql_database_postfix                    = "globaldb"
  cl_azure_sql_database_sku                        = "ElasticPool"
  cl_azure_sql_server_id                           = module.cl_azure_sql_server.cl_azure_sql_server.id
  cl_azure_storage_account_endpoint                = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_blob_endpoint
  cl_azure_storage_account_access_key              = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_access_key
  cl_azure_sql_database_workspace_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_azure_sql_database_license                    = "LicenseIncluded"
  cl_azure_sql_database_elastic_pool_id            = module.cl_azure_sql_elastic_pool.cl_azure_sql_elastic_pool[0].id
}
```
<!-- END_TF_DOCS -->
## Local values

```terraform
locals {
  cl_azure_databricks_sa_no_dash       = replace("${var.env}${var.postfix}${var.suffix}", "-", "") 
  timeout_duration = "2h"
}
```


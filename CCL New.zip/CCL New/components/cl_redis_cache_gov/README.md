<!-- BEGIN_TF_DOCS -->

# Azure Redis Cache Component

The Azure Redis Cache is a high-performance caching service that provides in-memory data store for faster retrieval of data.
It ensures low latency and high throughput by reducing the need to perform slow I/O operations.

This component will deploy Azure Redis Cache and make itself available inside of a subnet.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-cache-for-redis/cache-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_monitor_diagnostic_setting.cl_redis_cache_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_redis_cache_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_redis_cache.cl_redis_cache](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/redis_cache) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_redis_cache_allowed_subnets"></a> [cl\_redis\_cache\_allowed\_subnets](#input\_cl\_redis\_cache\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this redis cache. | `list(string)` | `[]` | no |
| <a name="input_cl_redis_cache_capacity"></a> [cl\_redis\_cache\_capacity](#input\_cl\_redis\_cache\_capacity) | (Optional) The size of the Redis cache to deploy. Valid values for a SKU family of C (Basic/Standard) are 0, 1, 2, 3, 4, 5, 6, and for P (Premium) family are 1, 2, 3, 4. | `number` | `1` | no |
| <a name="input_cl_redis_cache_configuration_maxfragmentationmemory_reserved"></a> [cl\_redis\_cache\_configuration\_maxfragmentationmemory\_reserved](#input\_cl\_redis\_cache\_configuration\_maxfragmentationmemory\_reserved) | (Optional) lue in megabytes reserved to accommodate for memory fragmentation. | `number` | `50` | no |
| <a name="input_cl_redis_cache_configuration_maxmemory_delta"></a> [cl\_redis\_cache\_configuration\_maxmemory\_delta](#input\_cl\_redis\_cache\_configuration\_maxmemory\_delta) | (Optional) The max-memory delta for this Redis instance. | `number` | `50` | no |
| <a name="input_cl_redis_cache_configuration_maxmemory_policy"></a> [cl\_redis\_cache\_configuration\_maxmemory\_policy](#input\_cl\_redis\_cache\_configuration\_maxmemory\_policy) | (Optional) How Redis will select what to remove when maxmemory is reached. | `string` | `"volatile-lru"` | no |
| <a name="input_cl_redis_cache_configuration_maxmemory_reserved"></a> [cl\_redis\_cache\_configuration\_maxmemory\_reserved](#input\_cl\_redis\_cache\_configuration\_maxmemory\_reserved) | (Optional) Value in megabytes reserved for non-cache usage e.g. failover. | `number` | `50` | no |
| <a name="input_cl_redis_cache_diagnostic"></a> [cl\_redis\_cache\_diagnostic](#input\_cl\_redis\_cache\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ConnectedClientList"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_redis_cache_enable"></a> [cl\_redis\_cache\_enable](#input\_cl\_redis\_cache\_enable) | Enable/disabled creation module Redis Cache | `bool` | `true` | no |
| <a name="input_cl_redis_cache_enable_non_ssl_port"></a> [cl\_redis\_cache\_enable\_non\_ssl\_port](#input\_cl\_redis\_cache\_enable\_non\_ssl\_port) | (Optional) Enable the non ssl port for redis cache. | `bool` | `false` | no |
| <a name="input_cl_redis_cache_family"></a> [cl\_redis\_cache\_family](#input\_cl\_redis\_cache\_family) | (Optional) The SKU family/pricing group to use. Valid values are C (for Basic/Standard SKU family) and P (for Premium). | `string` | `"P"` | no |
| <a name="input_cl_redis_cache_log_analytics_workspace_id"></a> [cl\_redis\_cache\_log\_analytics\_workspace\_id](#input\_cl\_redis\_cache\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_redis_cache_minimum_tls_version"></a> [cl\_redis\_cache\_minimum\_tls\_version](#input\_cl\_redis\_cache\_minimum\_tls\_version) | (Optional) The minimum TLS version. | `string` | `"1.2"` | no |
| <a name="input_cl_redis_cache_postfix"></a> [cl\_redis\_cache\_postfix](#input\_cl\_redis\_cache\_postfix) | (Required) The postfix for the redis cache. Use this to make the name globally unique. | `any` | n/a | yes |
| <a name="input_cl_redis_cache_public_network_access_enabled"></a> [cl\_redis\_cache\_public\_network\_access\_enabled](#input\_cl\_redis\_cache\_public\_network\_access\_enabled) | (Optional) Enable public network access for Redis cache. | `bool` | `false` | no |
| <a name="input_cl_redis_cache_rdb_backup_enabled"></a> [cl\_redis\_cache\_rdb\_backup\_enabled](#input\_cl\_redis\_cache\_rdb\_backup\_enabled) | (Optional) Is Backup Enabled? Only supported on Premium SKU's | `bool` | `false` | no |
| <a name="input_cl_redis_cache_rdb_backup_frequency"></a> [cl\_redis\_cache\_rdb\_backup\_frequency](#input\_cl\_redis\_cache\_rdb\_backup\_frequency) | (Optional) The Backup Frequency in Minutes. Only supported on Premium SKU's | `number` | `360` | no |
| <a name="input_cl_redis_cache_rdb_backup_max_snapshot_count"></a> [cl\_redis\_cache\_rdb\_backup\_max\_snapshot\_count](#input\_cl\_redis\_cache\_rdb\_backup\_max\_snapshot\_count) | (Optional) The maximum number of snapshots to create as a backup. Only supported for Premium SKU's | `number` | `1` | no |
| <a name="input_cl_redis_cache_rdb_backup_storage_account_endpoint"></a> [cl\_redis\_cache\_rdb\_backup\_storage\_account\_endpoint](#input\_cl\_redis\_cache\_rdb\_backup\_storage\_account\_endpoint) | (Optional) Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_cl_redis_cache_rdb_backup_storage_account_key"></a> [cl\_redis\_cache\_rdb\_backup\_storage\_account\_key](#input\_cl\_redis\_cache\_rdb\_backup\_storage\_account\_key) | (Optional) storage account key. Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_cl_redis_cache_rdb_backup_storage_account_name"></a> [cl\_redis\_cache\_rdb\_backup\_storage\_account\_name](#input\_cl\_redis\_cache\_rdb\_backup\_storage\_account\_name) | (Optional) Name of backup storage account name. Only supported for Premium SKU's | `any` | `null` | no |
| <a name="input_cl_redis_cache_resource_group_name"></a> [cl\_redis\_cache\_resource\_group\_name](#input\_cl\_redis\_cache\_resource\_group\_name) | (Required) The name of the resource group where the redis cache will be deployed to. | `any` | n/a | yes |
| <a name="input_cl_redis_cache_sku_name"></a> [cl\_redis\_cache\_sku\_name](#input\_cl\_redis\_cache\_sku\_name) | (Optional) The SKU of Redis to use. Possible values are Basic, Standard and Premium. | `string` | `"Premium"` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_redis_cache_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.usgovcloudapi.net"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.usgovcloudapi.net"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.redis.cache.usgovcloudapi.net"]    
  }
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_redis_cache"></a> [cl\_redis\_cache](#output\_cl\_redis\_cache) | Outputs ********************************************************************************************** |
| <a name="output_cl_redis_cache_diagnostic_setting"></a> [cl\_redis\_cache\_diagnostic\_setting](#output\_cl\_redis\_cache\_diagnostic\_setting) | n/a |
| <a name="output_cl_redis_cache_private_endpoint"></a> [cl\_redis\_cache\_private\_endpoint](#output\_cl\_redis\_cache\_private\_endpoint) | n/a |


## Usage

```terraform
// Azure Redis Cache
//**********************************************************************************************
 module "cl_redis_cache" {
  source                                    = "../dn-tads_tf-azure-component-library/components/cl_redis_cache_gov"
  cl_redis_cache_enable                     = true
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  tags                                      = var.tags
  cl_redis_cache_resource_group_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_redis_cache_postfix                    = "app1"
  cl_redis_cache_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_redis_cache_allowed_subnets            = var.cl_redis_cache_allowed_subnets
  }
//***************************************************************************************************
```
<!-- END_TF_DOCS -->
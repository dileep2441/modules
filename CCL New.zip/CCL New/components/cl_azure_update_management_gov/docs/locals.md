## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_azure_update_management_rg_name     = var.cl_azure_update_management_deploy_rg ? azurerm_resource_group.cl_azure_update_management_rg[0].name : var.cl_azure_update_management_rg_name
  cl_azure_update_management_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azure-automation.us"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azure-automation.us"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azure-automation.us"]
  }
}
```


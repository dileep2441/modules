<!-- BEGIN_TF_DOCS -->





## Resources

| Name | Type |
|------|------|
| [azurerm_automation_account.cl_azure_update_management](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/automation_account) | resource |
| [azurerm_log_analytics_linked_service.cl_azure_update_management_log_analytics_linked_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_linked_service) | resource |
| [azurerm_log_analytics_solution.cl_azure_update_management_log_analytics_solution_change_tracking](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_log_analytics_solution.cl_azure_update_management_log_analytics_solution_updates](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_solution) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_update_management_diagnostic_logs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_azure_update_management_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.cl_azure_update_management_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_update_management_allowed_subnets"></a> [cl\_azure\_update\_management\_allowed\_subnets](#input\_cl\_azure\_update\_management\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure Update Management. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_update_management_deploy_rg"></a> [cl\_azure\_update\_management\_deploy\_rg](#input\_cl\_azure\_update\_management\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the Azure Automation Account. | `bool` | `true` | no |
| <a name="input_cl_azure_update_management_diagnostics"></a> [cl\_azure\_update\_management\_diagnostics](#input\_cl\_azure\_update\_management\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "JobLogs",<br>    "JobStreams",<br>    "DscNodeStatus"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_azure_update_management_identity_ids"></a> [cl\_azure\_update\_management\_identity\_ids](#input\_cl\_azure\_update\_management\_identity\_ids) | UserAssigned Identities ID to add to Cognitive services. Mandatory if type is UserAssigned | `list(string)` | `null` | no |
| <a name="input_cl_azure_update_management_identity_type"></a> [cl\_azure\_update\_management\_identity\_type](#input\_cl\_azure\_update\_management\_identity\_type) | Add an Identity (MSI) to the Automation Account. Possible values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_azure_update_management_log_analytics_workspace_id"></a> [cl\_azure\_update\_management\_log\_analytics\_workspace\_id](#input\_cl\_azure\_update\_management\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_update_management_log_analytics_workspace_name"></a> [cl\_azure\_update\_management\_log\_analytics\_workspace\_name](#input\_cl\_azure\_update\_management\_log\_analytics\_workspace\_name) | (Required) The the log analytics workspace Name for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_update_management_logging_rg_name"></a> [cl\_azure\_update\_management\_logging\_rg\_name](#input\_cl\_azure\_update\_management\_logging\_rg\_name) | (Required) Core logging name. | `string` | n/a | yes |
| <a name="input_cl_azure_update_management_private_dns_zone_ids"></a> [cl\_azure\_update\_management\_private\_dns\_zone\_ids](#input\_cl\_azure\_update\_management\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_update_management_public_network_access_enabled"></a> [cl\_azure\_update\_management\_public\_network\_access\_enabled](#input\_cl\_azure\_update\_management\_public\_network\_access\_enabled) | (Optional) Public endpoints allow access to this automation account through the internet using a public IP address. | `bool` | `false` | no |
| <a name="input_cl_azure_update_management_rg_name"></a> [cl\_azure\_update\_management\_rg\_name](#input\_cl\_azure\_update\_management\_rg\_name) | (Optional) The name of the resource group in which to create the Azure Automation Account. | `any` | `null` | no |
| <a name="input_cl_azure_update_management_sku_name"></a> [cl\_azure\_update\_management\_sku\_name](#input\_cl\_azure\_update\_management\_sku\_name) | (Required) The name of the SKU to use | `string` | `"Basic"` | no |
| <a name="input_cl_private_endpoint_subresource_names"></a> [cl\_private\_endpoint\_subresource\_names](#input\_cl\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "DSCAndHybridWorker"<br>]</pre> | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_azure_update_management_rg_name     = var.cl_azure_update_management_deploy_rg ? azurerm_resource_group.cl_azure_update_management_rg[0].name : var.cl_azure_update_management_rg_name
  cl_azure_update_management_private_dns_zone_ids = {
    "nprd-pr" = ["/subscriptions/b5103e4e-3712-4196-a92c-f7f5200b586f/resourceGroups/rg-nprd-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azure-automation.us"]
    "prod-pr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azure-automation.us"]
    "prod-dr" = ["/subscriptions/c0cca293-0f8f-4013-9cfd-6d5bd8be8cc8/resourceGroups/rg-prod-pr-gov-idt-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azure-automation.us"]
  }
}
```


## Outputs

No outputs.


<!-- END_TF_DOCS -->
## Usage
```terraform

resource "azurerm_private_dns_zone" "sqldb_private_dns_zone" {
  name                = "privatelink.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sqldb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-sqldb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.sqldb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                   = var.tags
}

module "cl_azure_sql_server" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_server"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_azuread_login_username       = confirm the ADD group with the sql admins for the project
  cl_azure_sql_server_azuread_object_id            = confirme the group admin sql object id created for variable cl_azure_sql_server_azuread_login_username
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids         = [azurerm_private_dns_zone.sqldb_private_dns_zone.id]
  cl_azure_sql_server_sa_enable_backup             = true
  cl_azure_sql_server_sa_backup_vault_id           = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_azure_sql_server_sa_backup_vault              = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_azure_sql_server_sa_backup_policy_id          = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_azure_sql_server_storage_account_bypass       = ["AzureServices"]
  cl_azure_sql_server_storage_account_ip_rules     = ["199.206.0.0/15"] //Jenkins IP
}
```

## Deploying the SQL Server's storage account with private endpoints

```terraform

resource "azurerm_private_dns_zone" "sqldb_private_dns_zone" {
  name                = "privatelink.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sqldb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-sqldb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.sqldb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  tags                   = var.tags
}

resource "azurerm_private_dns_zone" "blob_private_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "blob_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-blob-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.blob_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  tags                   = var.tags
}

module "cl_azure_sql_server" {
  source                                                   = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_server"
  env                                                      = var.env
  postfix                                                  = var.postfix
  location                                                 = var.location
  cl_azure_sql_server_postfix                              = "global"
  cl_azure_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                        = "sqladmin"
  cl_azure_sql_server_password                             = "Portal123456!"
  cl_azure_sql_server_azuread_login_username               = confirm the ADD group with the sql admins for the project
  cl_azure_sql_server_azuread_object_id                    = confirme the group admin sql object id created for variab
  cl_azure_sql_server_logging_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets                 = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_azure_sql_server_vnet_rules                           = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.sqldb_private_dns_zone.id]
  cl_azure_sql_server_storage_account_private_dns_zone_ids = [azurerm_private_dns_zone.blob_private_dns_zone.id]
  cl_azure_sql_server_storage_account_pe_subnet_ids        = [azurerm_subnet.pe_subnet.id]
  cl_azure_sql_server_storage_account_bypass               = ["AzureServices"]
  cl_azure_sql_server_storage_account_ip_rules             = ["199.206.0.0/15"] //Jenkins IP
}
```
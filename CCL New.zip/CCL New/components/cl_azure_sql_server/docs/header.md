# Azure SQL Server Component

SQL Server on Azure Virtual Machines enables users to use full versions of SQL Server in the cloud without having to manage any on-premises hardware. 
SQL Server virtual machines (VMs) also simplify licensing costs when you pay as you go.
This component will deploy a new Azure SQL Server, storage account for audit & security logging, diagnostic settings for the storage account, storage container, SQL Server audit policy, SQL Server security alert policy, Azure SQL Server security assessment, a private endpoint for Azure SQL Server, firewall rules, vnet rules and logs solutions for Azure SQL Server.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview 

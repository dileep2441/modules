<!-- BEGIN_TF_DOCS -->

# Azure Lighthouse 

Azure Lighthouse enables multi-tenant management with scalability, higher automation, and enhanced governance across resources.

Enterprise organizations managing resources across multiple tenants can use Azure Lighthouse to streamline management tasks.

Cross-tenant management experiences let you work more efficiently with Azure services such as Azure Policy, Microsoft Sentinel, Azure Arc, and many more. Users can see what changes were made and by whom in the activity log, which is stored in the customer's tenant and can be viewed by users in the managing tenant.

For more information, please visit: https://learn.microsoft.com/en-us/azure/lighthouse/overview



## Resources

| Name | Type |
|------|------|
| [azurerm_lighthouse_assignment.cl_azure_lighthouse_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lighthouse_assignment) | resource |
| [azurerm_lighthouse_definition.cl_azure_lighthouse_definition](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/lighthouse_definition) | resource |
| [azurerm_role_definition.builtin_role](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/role_definition) | data source |
| [azurerm_role_definition.builtin_role_delegated](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/role_definition) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_lighthouse_assignment_scopes"></a> [cl\_azure\_lighthouse\_assignment\_scopes](#input\_cl\_azure\_lighthouse\_assignment\_scopes) | (Required) Map of 'name => Scope IDs' to associate the Lighthouse definition (Subscription ID or Resource Group ID). | `map(string)` | n/a | yes |
| <a name="input_cl_azure_lighthouse_definition_authorizations"></a> [cl\_azure\_lighthouse\_definition\_authorizations](#input\_cl\_azure\_lighthouse\_definition\_authorizations) | (Required) List of Authorization objects. | <pre>list(object({<br>    principal_id         = string<br>    principal_name       = string<br>    role_name            = string<br>    delegated_role_names = optional(list(string))<br>  }))</pre> | n/a | yes |
| <a name="input_cl_azure_lighthouse_definition_description"></a> [cl\_azure\_lighthouse\_definition\_description](#input\_cl\_azure\_lighthouse\_definition\_description) | (Required) A description of the Lighthouse Definition. | `string` | `null` | no |
| <a name="input_cl_azure_lighthouse_definition_managed_subscription_id"></a> [cl\_azure\_lighthouse\_definition\_managed\_subscription\_id](#input\_cl\_azure\_lighthouse\_definition\_managed\_subscription\_id) | (Required) The ID of the managed Subscription that will contains the Lighthouse Definition. (Recommended to use Management or Shared-Services Subscription in a Landing Zone context.) | `string` | n/a | yes |
| <a name="input_cl_azure_lighthouse_definition_managing_tenant_id"></a> [cl\_azure\_lighthouse\_definition\_managing\_tenant\_id](#input\_cl\_azure\_lighthouse\_definition\_managing\_tenant\_id) | (Required) The ID of the managing Tenant. | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_lighthouse_definition_id"></a> [cl\_azure\_lighthouse\_definition\_id](#output\_cl\_azure\_lighthouse\_definition\_id) | Lighthouse definition ID |

## Usage

### Deploy Azure Lighthouse

```terraform
// Azure Lighthouse
//**********************************************************************************************************
module "cl_azure_lighthouse" {
  env                                                    = var.env
  postfix                                                = var.postfix
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_azure_lighthouse"
  cl_azure_lighthouse_definition_description             = var.cl_azure_lighthouse_definition_description
  cl_azure_lighthouse_definition_managing_tenant_id      = var.cl_azure_lighthouse_definition_managing_tenant_id
  cl_azure_lighthouse_definition_managed_subscription_id = var.cl_azure_lighthouse_definition_managed_subscription_id
  cl_azure_lighthouse_definition_authorizations          = var.cl_azure_lighthouse_definition_authorizations
  cl_azure_lighthouse_assignment_scopes                  = var.cl_azure_lighthouse_assignment_scopes
}
//**********************************************************************************************************
```
<!-- END_TF_DOCS -->
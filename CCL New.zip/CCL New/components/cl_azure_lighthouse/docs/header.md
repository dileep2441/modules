# Azure Lighthouse 

Azure Lighthouse enables multi-tenant management with scalability, higher automation, and enhanced governance across resources.

Enterprise organizations managing resources across multiple tenants can use Azure Lighthouse to streamline management tasks.

Cross-tenant management experiences let you work more efficiently with Azure services such as Azure Policy, Microsoft Sentinel, Azure Arc, and many more. Users can see what changes were made and by whom in the activity log, which is stored in the customer's tenant and can be viewed by users in the managing tenant.

For more information, please visit: https://learn.microsoft.com/en-us/azure/lighthouse/overview
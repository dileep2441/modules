## Usage

### Deploy Azure Lighthouse

```terraform
// Azure Lighthouse
//**********************************************************************************************************
module "cl_azure_lighthouse" {
  env                                                    = var.env
  postfix                                                = var.postfix
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_azure_lighthouse"
  cl_azure_lighthouse_definition_description             = var.cl_azure_lighthouse_definition_description
  cl_azure_lighthouse_definition_managing_tenant_id      = var.cl_azure_lighthouse_definition_managing_tenant_id
  cl_azure_lighthouse_definition_managed_subscription_id = var.cl_azure_lighthouse_definition_managed_subscription_id
  cl_azure_lighthouse_definition_authorizations          = var.cl_azure_lighthouse_definition_authorizations
  cl_azure_lighthouse_assignment_scopes                  = var.cl_azure_lighthouse_assignment_scopes
}
//**********************************************************************************************************
```
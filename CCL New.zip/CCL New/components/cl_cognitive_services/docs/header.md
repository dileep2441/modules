# Cognitive Services

Azure Cognitive Services are cloud-based services with REST APIs and client library SDKs available to help you build cognitive intelligence into your applications. You can add cognitive features to your applications without having artificial intelligence (AI) or data science skills. Azure Cognitive Services comprise various AI services that enable you to build cognitive solutions that can see, hear, speak, understand, and even make decisions. Cognitive services provides cognitive understanding are categorized into five main pillars:

-Vision:   Computer Vision, Custom Vision Service, Face

-Speech:   Speech service

-Language: QnA Maker, Text Analytics, Translator

-Decision: Anomaly Detector, Content Moderator, Personalizer

-Search:   Bing News Search, Bing Video Search, Bing Web Search, Bing Autosuggest, Bing Custom Search, Bing Entity Search, Bing Image Search, Bing Visual Search, Bing Local Business Search, Bing Spell Check.

For more information, please visit: -https://docs.microsoft.com/en-us/azure/cognitive-services/what-are-cognitive-services 

# Important Note:

LUIS will be retired on October 1st 2025 and starting April 1st 2023 you will not be able to create new LUIS resources. 
Microsoft We recommend migrating your LUIS applications to conversational language understanding (CLU) to benefit from continued product support and multilingual capabilities.
https://learn.microsoft.com/en-us/azure/ai-services/luis/what-is-luis

# Currently CLU (conversational language understanding) is not supported by Terraform

```
The following table contains the different sku´s for Cognitive Services:

ResourceType          tier Name                   kind Vision
accounts               F0,S1                      ComputerVision
accounts               F0,S0,S1                   Face
accounts               F0,S0                      FormRecognizer

ResourceType          tier Name                   kind Language
accounts               F0,S0                      QnAMaker
accounts               F0,S1,S2,S3,S4,C2,C3,C4,D3 TextTranslation
accounts               F,S                        TextAnalytics

ResourceType          tier Name                   kind Speech
accounts               F0,S0                      Bing.Speech
accounts               F0,S1,S2,S3,S4             SpeechTranslation

ResourceType          tier Name                   kind Search
accounts               S1,S2,S3,S4,S5,S6.S7,S8    Bing.Search.v7
accounts               S1                         Bing.Autosuggest.v7
accounts               S1                         Bing.CustomSearch
accounts               S1                         Bing.SpellCheck.v7
accounts               F0,S1                      Bing.EntitySearch

ResourceType          tier Name                   kind Decision
accounts               F0,S0                      ContentModerator

ResourceType          tier Name                   kind OpenAI
accounts               S0                         OpenAI
```

In those usages we are deep in the following cognitive services:

*Natural language processing (NLP)* is used for tasks such as sentiment analysis, topic detection, language detection, key phrase extraction, and document categorization. NLP can be use to classify documents, such as labeling documents as sensitive or spam.

1. QNA MAKER: QnA Maker is a cloud-based Natural Language Processing (NLP) service that allows you to create a natural conversational layer over your data. It is used to find the most appropriate answer for any input from your custom knowledge base (KB) of information. QnA Maker imports your content into a knowledge base of question and answer pairs. The import process extracts information about the relationship between the parts of your structured and semi-structured content to imply relationships between the question and answer pairs. You can edit these question and answer pairs or add new pairs.

2. Text Anayltic: The Text Analytics API is a cloud-based service that provides Natural Language Processing (NLP) features for text mining and text analysis, including: sentiment analysis, opinion mining, key phrase extraction, language detection, and named entity recognition. The API is a part of Azure Cognitive Services, a collection of machine learning and AI algorithms in the cloud for your development projects. You can use these features with the REST API version 3.0 or version 3.1-preview, or the client library.

*Optical character recognition (OCR)* allows you to extract printed or handwritten text from images, such as photos of street signs and products, as well as from documents—invoices, bills, financial reports, articles, and more. Microsoft's OCR technologies support extracting printed text in several languages.

1. Computer Vision: The Computer Vision service provides developers with access to advanced algorithms for processing images and returning information. Computer Vision algorithms analyze the content of an image in different ways, depending on the visual features you're interested in.You can use Computer Vision in your application to: Analyze images for insight, Extract text, from images and Generate thumbnails.

2. Form Recognizer: Form Recognizer is a Cognitive Service that lets you identify and extract text, key/value pairs, and table data from documents. With Form Recognizer you can train custom models to extract structured data from your forms and documents.

*Azure OpenAI Service* provides REST API access to OpenAI's powerful language models including the GPT-3, Codex and Embeddings model series. These models can be easily adapted to your specific task including but not limited to content generation, summarization, semantic search, and natural language to code translation. Users can access the service through REST APIs, Python SDK, or our web-based interface in the Azure OpenAI Studio.
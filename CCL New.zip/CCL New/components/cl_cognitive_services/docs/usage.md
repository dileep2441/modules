## Usage

1. To create a Cognitive Services please send in the following variables the kind required for the cognitive services and the sku for that cognitive services selectecd in the kind variable.

   For example:

   cl_cognitive_services_kind                             = "OpenAI"

   cl_cognitive_services_sku_name                         = "S0"
   

2. If you required to use the same resource group for all your cognitive services is necesary to send the variable cl_cognitive_services_deploy_rg in false and confirm the value for the varaible cl_cognitive_services_rg_name, in you need each cognitive service in a different resource group you don´t need to send an additional variable, only confirm the variable cl_cognitive_services_deploy_rg in true.

```terraform
//********************************************************************************************
//Create a single Cognitive Services
//********************************************************************************************
resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_OpenAI" {
   source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp"
   cl_cognitive_services_deploy_rg                        = true
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "OpenAI"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                = "privatelink.cognitiveservices.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************
//Create NLP Cognitive Servies: 1.) QNA MAKER 2.)  Text Anayltics
//********************************************************************************************
resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                                   = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                                   = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                       = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies         = true
  service_endpoints                                      = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_CLU" {
   source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp"
   cl_cognitive_services_deploy_rg                        = true
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "CLU"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]  
}

module "cl_cognitive_services_QNA_MAKER" {
   source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp-qna"
   cl_cognitive_services_deploy_rg                        = false
   cl_cognitive_services_rg_name                          = module.cl_cognitive_services_CLU.cl_cognitive_services_rg[0].name
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "QnAMaker"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
   cl_cognitive_services_qna_runtime_endpoint             = "https://docs.microsoft.com/rest/api/cognitiveservices/qnamaker/knowledgebase"
}

module "cl_cognitive_services_TextAnalytics" {
   source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "nlp-ta"
   cl_cognitive_services_deploy_rg                        = false
   cl_cognitive_services_rg_name                          = module.cl_cognitive_services_CLU.cl_cognitive_services_rg[0].name
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "TextAnalytics"
   cl_cognitive_services_sku_name                         = "S"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                   = "privatelink.cognitiveservices.azure.com"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************

//********************************************************************************************
//Vision API/OCR Cognitive Services: 1.) Computer Vision 2.) Form Recognizer   
//********************************************************************************************
resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_ComputerVision" {
   source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "cvision"
   cl_cognitive_services_deploy_rg                        = true
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "ComputerVision"
   cl_cognitive_services_sku_name                         = "S1"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_Form_Recognizer" {
   source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
   env                                                    = var.env
   postfix                                                = var.postfix
   location                                               = var.location
   cl_cognitive_services_postfix                          = "frzer"
   cl_cognitive_services_deploy_rg                        = false
   cl_cognitive_services_rg_name                          = module.cl_cognitive_services_ComputerVision.cl_cognitive_services_rg[0].name
   cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_cognitive_services_kind                             = "FormRecognizer"
   cl_cognitive_services_sku_name                         = "S0"
   cl_cognitive_services_identity_type                    = "SystemAssigned"
   cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
   cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
   cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
   cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                   = "privatelink.cognitiveservices.azure.com"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************

//********************************************************************************************************
//Deploy Cognitive Services: 1.) Speech Service 2.) Anomaly Detector 3.) TextAnalytics 4.) TextTranslation   
//********************************************************************************************************

resource "azurerm_subnet" "cl_cognitive_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}

module "cl_cognitive_services_Speech_service" {
    source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "cnsnlp-sp"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "SpeechServices"
    cl_cognitive_services_sku_name                         = "S0"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_Speech_service_Anomaly_Detector" {
    source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "cnsnlp-ad"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "AnomalyDetector"
    cl_cognitive_services_sku_name                         = "S0"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_TextAnalytics" {
    source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "nlp-ta"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "TextAnalytics"
    cl_cognitive_services_sku_name                         = "S"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

module "cl_cognitive_services_TextTranslation" {
    source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_cognitive_services_postfix                          = "nlp-ta"
    cl_cognitive_services_deploy_rg                        = true
    cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_cognitive_services_kind                             = "TextTranslation"
    cl_cognitive_services_sku_name                         = "S1"
    cl_cognitive_services_identity_type                    = "SystemAssigned"
    cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.cl_cognitive_private_subnet.id
    cl_cognitive_services_nacl_allowed_subnets             = [azurerm_subnet.cl_cognitive_private_subnet.id]
    cl_cognitive_services_resource_group_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}

resource "azurerm_private_dns_zone" "cns_private_dns_zone" {
  name                   = "privatelink.cognitiveservices.azure.com"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "cns_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-cns-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.cns_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//********************************************************************************************
```

3. OpenAI

Note: OpenAI is a "kind" of Azure Cognitive services account that is available for AzureRM for TF provider version 3.40.0

```terraform
//********************************************************************************************
module "cl_cognitive_services" {
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_cognitive_services"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  tags                                                   = var.tags
  cl_cognitive_services_postfix                          = var.cognitive_services_postfix
  cl_cognitive_services_log_analytics_workspace_id       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_cognitive_services_resource_group_name              = azurerm_resource_group.cognitive_services.name
  cl_cognitive_services_rg_name                          = azurerm_resource_group.cognitive_services.name
  cl_cognitive_services_deploy_rg                        = true
  cl_cognitive_services_kind                             = "OpenAI"
  cl_cognitive_services_sku_name                         = "S0"  # at the moment (2023/03) this is the only SKU available for OpenAI
  cl_cognitive_services_nacls_default_action             = "Allow"
  cl_cognitive_services_nacls_virtual_network_subnet_ids = azurerm_subnet.private_subnet_vm.id
  cl_cognitive_services_nacl_allowed_subnets             = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet.id]
  cl_cognitive_services_private_dns_zone_ids             = [azurerm_private_dns_zone.cns_private_dns_zone.id]
}
//********************************************************************************************
```

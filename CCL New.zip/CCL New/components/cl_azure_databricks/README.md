<!-- BEGIN_TF_DOCS -->

# Azure Data Bricks Component

Azure Databricks is a cloud-based data engineering tool used for processing and transforming massive quantities of data and exploring the data through machine learning models. 
This component creates an Azure DataBricks workspace and deploys the following for that resource: resource group, virtual network, public & priavte [subnets, NSGs, additional security rules] & diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/databricks/scenarios/what-is-azure-databricks



## Resources

| Name | Type |
|------|------|
| [azurerm_databricks_workspace.cl_azure_databricks](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/databricks_workspace) | resource |
| [azurerm_monitor_diagnostic_setting.cl_azure_databricks_diagnostic_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_azure_databricks_private_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_group.cl_azure_databricks_public_nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.cl_azure_databricks_private_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.cl_azure_databricks_public_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_resource_group.cl_azure_databricks_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subnet.cl_azure_databricks_private_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet.cl_azure_databricks_public_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.cl_azure_databricks_private_nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_network_security_group_association.cl_azure_databricks_public_nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_virtual_network.cl_azure_databricks_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_databricks_diagnostics"></a> [cl\_azure\_databricks\_diagnostics](#input\_cl\_azure\_databricks\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "dbfs",<br>    "clusters",<br>    "accounts",<br>    "jobs",<br>    "notebook",<br>    "ssh",<br>    "workspace",<br>    "secrets",<br>    "sqlPermissions",<br>    "instancePools"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_cl_azure_databricks_log_analytics_workspace_id"></a> [cl\_azure\_databricks\_log\_analytics\_workspace\_id](#input\_cl\_azure\_databricks\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_azure_databricks_managed_rg"></a> [cl\_azure\_databricks\_managed\_rg](#input\_cl\_azure\_databricks\_managed\_rg) | (Optional) The name of the resource group where Azure should place the managed Databricks resources. Changing this forces a new resource to be created. If this is not set Azure will create a new RG where all the managed resources will be deployed. | `string` | `null` | no |
| <a name="input_cl_azure_databricks_private_nsg_rules"></a> [cl\_azure\_databricks\_private\_nsg\_rules](#input\_cl\_azure\_databricks\_private\_nsg\_rules) | (Optional) Define additional NSG rules for private subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_databricks_private_subnet"></a> [cl\_azure\_databricks\_private\_subnet](#input\_cl\_azure\_databricks\_private\_subnet) | (Optional) The name of the Private Subnet within the Virtual Network. Required if cl\_azure\_databricks\_vnet\_id is set. | `string` | `null` | no |
| <a name="input_cl_azure_databricks_public_ip"></a> [cl\_azure\_databricks\_public\_ip](#input\_cl\_azure\_databricks\_public\_ip) | (Optional) Are public IP Addresses not allowed? | `bool` | `true` | no |
| <a name="input_cl_azure_databricks_public_nsg_rules"></a> [cl\_azure\_databricks\_public\_nsg\_rules](#input\_cl\_azure\_databricks\_public\_nsg\_rules) | (Optional) Define additional NSG rules for public subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_cl_azure_databricks_public_subnet"></a> [cl\_azure\_databricks\_public\_subnet](#input\_cl\_azure\_databricks\_public\_subnet) | (Optional) The name of the Public Subnet within the Virtual Network. Required if cl\_azure\_databricks\_vnet\_id is set. | `string` | `null` | no |
| <a name="input_cl_azure_databricks_sku"></a> [cl\_azure\_databricks\_sku](#input\_cl\_azure\_databricks\_sku) | (Optional) The sku to use for the Databricks Workspace. Possible values are standard, premium, or trial. Changing this can force a new resource to be created in some circumstances. | `string` | `"premium"` | no |
| <a name="input_cl_azure_databricks_subnet_private_address_prefixes"></a> [cl\_azure\_databricks\_subnet\_private\_address\_prefixes](#input\_cl\_azure\_databricks\_subnet\_private\_address\_prefixes) | (Required) The address prefixes for the private subnet of data bricks. | `any` | n/a | yes |
| <a name="input_cl_azure_databricks_subnet_private_service_endpoints"></a> [cl\_azure\_databricks\_subnet\_private\_service\_endpoints](#input\_cl\_azure\_databricks\_subnet\_private\_service\_endpoints) | (Optional) The list of Service endpoints to associate with the private subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage and Microsoft.Web. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_databricks_subnet_public_address_prefixes"></a> [cl\_azure\_databricks\_subnet\_public\_address\_prefixes](#input\_cl\_azure\_databricks\_subnet\_public\_address\_prefixes) | (Required) The address prefixes for the public subnet of data bricks. | `any` | n/a | yes |
| <a name="input_cl_azure_databricks_subnet_public_service_endpoints"></a> [cl\_azure\_databricks\_subnet\_public\_service\_endpoints](#input\_cl\_azure\_databricks\_subnet\_public\_service\_endpoints) | (Optional) The list of Service endpoints to associate with the public subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage and Microsoft.Web. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_databricks_vnet_address_space"></a> [cl\_azure\_databricks\_vnet\_address\_space](#input\_cl\_azure\_databricks\_vnet\_address\_space) | (Required) The address space for virtual network of data bricks. | `any` | n/a | yes |
| <a name="input_cl_azure_databricks_vnet_dns_servers"></a> [cl\_azure\_databricks\_vnet\_dns\_servers](#input\_cl\_azure\_databricks\_vnet\_dns\_servers) | (Optional) Custom list of dns to be included in the vnet. | `list(string)` | `[]` | no |
| <a name="input_cl_azure_databricks_vnet_id"></a> [cl\_azure\_databricks\_vnet\_id](#input\_cl\_azure\_databricks\_vnet\_id) | (Optional) The ID of a Virtual Network where this Databricks Cluster should be created. | `string` | `null` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_databricks"></a> [cl\_azure\_databricks](#output\_cl\_azure\_databricks) | n/a |
| <a name="output_cl_azure_databricks_private_nsg"></a> [cl\_azure\_databricks\_private\_nsg](#output\_cl\_azure\_databricks\_private\_nsg) | n/a |
| <a name="output_cl_azure_databricks_private_nsg_rules"></a> [cl\_azure\_databricks\_private\_nsg\_rules](#output\_cl\_azure\_databricks\_private\_nsg\_rules) | n/a |
| <a name="output_cl_azure_databricks_private_subnet"></a> [cl\_azure\_databricks\_private\_subnet](#output\_cl\_azure\_databricks\_private\_subnet) | n/a |
| <a name="output_cl_azure_databricks_public_nsg"></a> [cl\_azure\_databricks\_public\_nsg](#output\_cl\_azure\_databricks\_public\_nsg) | n/a |
| <a name="output_cl_azure_databricks_public_nsg_rules"></a> [cl\_azure\_databricks\_public\_nsg\_rules](#output\_cl\_azure\_databricks\_public\_nsg\_rules) | n/a |
| <a name="output_cl_azure_databricks_public_subnet"></a> [cl\_azure\_databricks\_public\_subnet](#output\_cl\_azure\_databricks\_public\_subnet) | n/a |
| <a name="output_cl_azure_databricks_rg"></a> [cl\_azure\_databricks\_rg](#output\_cl\_azure\_databricks\_rg) | Outputs ********************************************************************************************** |
| <a name="output_cl_azure_databricks_vnet"></a> [cl\_azure\_databricks\_vnet](#output\_cl\_azure\_databricks\_vnet) | n/a |

## Usage

```terraform
// Azure Data Bricks
//**********************************************************************************************
module "cl_azure_databricks" {
  source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_databricks"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  cl_azure_databricks_vnet_address_space                      = ["70.0.0.0/16"]
  cl_azure_databricks_subnet_public_address_prefixes          = ["70.0.1.0/24"]
  cl_azure_databricks_subnet_private_address_prefixes         = ["70.0.64.0/24"]
  cl_azure_databricks_log_analytics_workspace_id              = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id //only for premium plan
  cl_azure_databricks_public_nsg_rules = {  
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_azure_databricks_private_nsg_rules = {  
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
# Azure Data Bricks Component

Azure Databricks is a cloud-based data engineering tool used for processing and transforming massive quantities of data and exploring the data through machine learning models. 
This component creates an Azure DataBricks workspace and deploys the following for that resource: resource group, virtual network, public & priavte [subnets, NSGs, additional security rules] & diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/databricks/scenarios/what-is-azure-databricks
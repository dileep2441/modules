## Usage

``` hcl
 module "cl_api_mgmt" {
  source                                    = "../dn-tads_tf-azure-component-library/components/cl_api_management"
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  cl_api_mgmt_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_api_mgmt_log_analytics_workspace_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_api_mgmt_route_table                   = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_api_mgmt_subnet_vnet_rg_name           = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
  cl_api_mgmt_subnet_vnet_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_api_mgmt_subnet_prefix                 = ["55.0.3.0/24"]
  cl_api_mgmt_publisher_name                = "My-Company-KPMG"
  cl_api_mgmt_publisher_email               = "company@terraform.io"
  cl_api_mgmt_inbound_cidrs                 = ["199.206.0.0/15"]
  cl_api_mgmt_proxies                       = {
    api_mgmt_proxy = {
      host_name                     = "api.ati.kpmg.com.br"
      certificate                   = var.APP_GW_TLS_CERT_PFX_BASE64
      certificate_password          = var.APP_GW_TLS_CERT_PASS
      negotiate_client_certificate  = false
      default_ssl_binding           = false
      key_vault_id                  = null 
    }
  }
  cl_api_mgmt_developer_portals             = {
    api_mgmt_proxy = {
      host_name                     = "portal.ati.kpmg.com.br"
      certificate                   = var.APP_GW_TLS_CERT_PFX_BASE64
      certificate_password          = var.APP_GW_TLS_CERT_PASS
      negotiate_client_certificate  = false
      key_vault_id                  = null 
    }
  }  
}
```
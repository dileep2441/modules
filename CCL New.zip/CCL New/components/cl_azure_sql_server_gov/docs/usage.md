
## Usage

```terraform

module "cl_azure_sql_server" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_azure_sql_server_gov"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  suffix                                           = var.suffix
  tags                                             = var.tags
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_sa_private_dns_zone_ids      var.cl_azure_sql_server_sa_private_dns_zone_ids
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
    }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids         = var.cl_azure_sql_server_private_dns_zone_ids
  cl_azure_sql_server_sa_enable_backup                    = true
  cl_azure_sql_server_sa_backup_vault_id                  = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_azure_sql_server_sa_backup_vault                     = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_azure_sql_server_sa_backup_policy_id                 = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_azure_sql_server_login_username                      = "wtamayo@kpmgnp.onmicrosoft.us"
  cl_azure_sql_server_object_id                           = "f3f17b13-24d1-4e1b-ad44-44a748688393"
  cl_azure_sql_server_sa_allowed_vnet_subnet_ids          = var.cl_azure_sql_server_sa_allowed_vnet_subnet_ids 
  cl_azure_sql_server_sa_allowed_pe_subnet_ids            = var.cl_azure_sql_server_sa_allowed_pe_subnet_ids
}
```
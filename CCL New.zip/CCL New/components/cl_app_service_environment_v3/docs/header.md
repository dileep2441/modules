# Azure App Service Environment V3

An App Service Environment can host your:
•	Windows web apps
•	Linux web apps
•	Docker containers (Windows and Linux)
•	Functions
•	Logic apps (Standard)
App Service Environments are appropriate for application workloads that require:
•	High scale.
•	Isolation and secure network access.
•	High memory utilization.
•	High requests per second (RPS). You can create multiple App Service Environments in a single Azure region or across multiple Azure regions. This flexibility makes an App Service Environment ideal for horizontally scaling stateless applications with a high RPS requirement.
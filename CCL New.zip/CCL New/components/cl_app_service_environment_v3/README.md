<!-- BEGIN_TF_DOCS -->

# Azure App Service Environment V3

An App Service Environment can host your:
•	Windows web apps
•	Linux web apps
•	Docker containers (Windows and Linux)
•	Functions
•	Logic apps (Standard)
App Service Environments are appropriate for application workloads that require:
•	High scale.
•	Isolation and secure network access.
•	High memory utilization.
•	High requests per second (RPS). You can create multiple App Service Environments in a single Azure region or across multiple Azure regions. This flexibility makes an App Service Environment ideal for horizontally scaling stateless applications with a high RPS requirement.



## Resources

| Name | Type |
|------|------|
| [azurerm_app_service_environment_v3.cl_app_service_env_v3](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service_environment_v3) | resource |
| [azurerm_monitor_diagnostic_setting.cl_app_service_plan_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_network_security_group.cl_ase_v3_nsg_allow_inbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.AppInbound](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_network_security_rule.custom_nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_resource_group.cl_ase_v3_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_service_plan.cl_app_service_plan_v3](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_plan) | resource |
| [azurerm_subnet.cl_subnet_ase_v3](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.subnet_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_ase_v3_additional_nsg_rules"></a> [cl\_ase\_v3\_additional\_nsg\_rules](#input\_cl\_ase\_v3\_additional\_nsg\_rules) | (Optional) Define additional NSG rules | <pre>map(object({<br>    name                         = string<br>    priority                     = number<br>    direction                    = string<br>    access                       = string<br>    protocol                     = string<br>    source_port_range            = string<br>    source_port_ranges           = list(string)<br>    destination_port_range       = string<br>    destination_port_ranges      = list(string)<br>    source_address_prefix        = string<br>    source_address_prefixes      = list(string)<br>    destination_address_prefix   = string<br>    destination_address_prefixes = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_cl_ase_v3_allow_new_private_endpoint_connections"></a> [cl\_ase\_v3\_allow\_new\_private\_endpoint\_connections](#input\_cl\_ase\_v3\_allow\_new\_private\_endpoint\_connections) | (Optional) Should new Private Endpoint Connections be allowed | `bool` | `true` | no |
| <a name="input_cl_ase_v3_app_service_diagnostics"></a> [cl\_ase\_v3\_app\_service\_diagnostics](#input\_cl\_ase\_v3\_app\_service\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AppServiceEnvironmentPlatformLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_ase_v3_app_service_plans"></a> [cl\_ase\_v3\_app\_service\_plans](#input\_cl\_ase\_v3\_app\_service\_plans) | A map of App Service plan to create | <pre>map(object({<br>    name     = string<br>    os_type  = string<br>    sku_name = string<br>  }))</pre> | `null` | no |
| <a name="input_cl_ase_v3_core_vnet_address_space"></a> [cl\_ase\_v3\_core\_vnet\_address\_space](#input\_cl\_ase\_v3\_core\_vnet\_address\_space) | (Required) The core vnet address space of where the ASE subnet should be created | `string` | `null` | no |
| <a name="input_cl_ase_v3_core_vnet_name"></a> [cl\_ase\_v3\_core\_vnet\_name](#input\_cl\_ase\_v3\_core\_vnet\_name) | (Required) The name of the core vnet to which the App Service Environment should be connected to | `string` | `null` | no |
| <a name="input_cl_ase_v3_core_vnet_resource_group_name"></a> [cl\_ase\_v3\_core\_vnet\_resource\_group\_name](#input\_cl\_ase\_v3\_core\_vnet\_resource\_group\_name) | (Required) The resource group of the core vnet which the App Service Environment should be connected to | `string` | `null` | no |
| <a name="input_cl_ase_v3_dedicated_host_count"></a> [cl\_ase\_v3\_dedicated\_host\_count](#input\_cl\_ase\_v3\_dedicated\_host\_count) | (Optional) This ASEv3 should use dedicated Hosts | `number` | `0` | no |
| <a name="input_cl_ase_v3_log_analytics_workspace_id"></a> [cl\_ase\_v3\_log\_analytics\_workspace\_id](#input\_cl\_ase\_v3\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `string` | `null` | no |
| <a name="input_cl_ase_v3_name"></a> [cl\_ase\_v3\_name](#input\_cl\_ase\_v3\_name) | (Required) The spoke name of the app you are deploying. | `string` | `null` | no |
| <a name="input_cl_ase_v3_subnet_prefix"></a> [cl\_ase\_v3\_subnet\_prefix](#input\_cl\_ase\_v3\_subnet\_prefix) | (Required) The prefix of the Subnet which the App Service Environment should be connected to | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_cl_ase_v3_zone_redundant"></a> [cl\_ase\_v3\_zone\_redundant](#input\_cl\_ase\_v3\_zone\_redundant) | (Optional) deploy the ASEv3 with availability zones | `bool` | `false` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_app_service_env_v3"></a> [cl\_app\_service\_env\_v3](#output\_cl\_app\_service\_env\_v3) | Outputs ********************************************************************************************** |
| <a name="output_cl_app_service_plan_v3"></a> [cl\_app\_service\_plan\_v3](#output\_cl\_app\_service\_plan\_v3) | n/a |

## Usage

```terraform
module "component_ase_v3" {
  source                                  = "../dn-tads_tf-azure-component-library/components/cl_app_service_environment_v3"
  env                                     = var.env
  postfix                                 = var.postfix
  location                                = var.location
  cl_ase_v3_core_vnet_resource_group_name = var.cl_core_vnet_resource_group_name
  cl_ase_v3_core_vnet_name                = var.cl_core_vnet_name
  cl_ase_v3_core_vnet_id                  = var.cl_core_vnet_id
  cl_ase_v3_subnet_prefix                 = var.cl_ase_v3_subnet_prefix
  cl_ase_v3_name                          = var.cl_ase_v3_name
  cl_ase_v3_app_service_plans             = var.cl_ase_v3_app_service_plans
  cl_ase_v3_log_analytics_workspace_id    = var.cl_ase_v3_log_analytics_workspace_id
  tags                                    = var.tags
}
```
<!-- END_TF_DOCS -->
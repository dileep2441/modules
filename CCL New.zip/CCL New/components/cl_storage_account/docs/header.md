# Azure Storage Acccount Component

This is the Storage Account component. It will deploy Storage Account, Storage Files, Storage Queues, Monitor and Private Endpoint for Storage Account.

The following table describes the types of storage accounts, the services they support, and the supported deployment models for each account type:

Storage account type	                Supported services	                                    Supported performance tiers

General-purpose V2	                  Blob, File, Queue, Table, Disk, and Data Lake Gen22	    Standard, Premium

General-purpose V1	                  Blob, File, Queue, Table, and Disk	                    Standard, Premium

BlockBlobStorage                      Blob (block blobs and append blobs only)	              Premium 

FileStorage	                          File only	                                              Premium

BlobStorage	                          Blob (block blobs and append blobs only)	              Standard


Variables for enabled or disabled queue and file share creations into Storage account:

cl_storage_account_queue_enabled = true // Variable in true/false to enable or diabled queue creation

cl_storage_account_queue_monitor_enabled = false // Variable in true/false to enable or diabled monitor queue creation

cl_storage_account_share_enabled = true  // Variable in true/false to enable or diabled File share creation

For more information, please visit: https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview
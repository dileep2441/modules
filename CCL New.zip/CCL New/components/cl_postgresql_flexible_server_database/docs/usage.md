## Usage

```terraform
// Deploy PostgreSQL - Flexible Server
//**********************************************************************************************
module "cl_postgresql_flexible_server" {
  source                                                   = "../dn-tads_tf-azure-component-library/components/cl_postgresql_flexible_server"
  env                                                      = var.env
  postfix                                                  = var.postfix
  location                                                 = var.location
  cl_postgresql_flexible_server_postfix                    = var.cl_postgresql_flexible_server_postfix
  cl_postgresql_flexible_server_resource_group_name        = var.cl_postgresql_flexible_server_resource_group_name
  cl_postgresql_flexible_server_vnet_rg_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.resource_group_name
  cl_postgresql_flexible_server_vnet_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_postgresql_flexible_server_subnet_prefix              = ["x.x.xx.x/27"]
  cl_postgresql_flexible_server_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_postgresql_flexible_server_private_dns_zone_id        = [var.cl_postgresql_flexible_server_private_dns_zone_id]
}
//**********************************************************************************************

// Deploy Azure Database for PostgreSQL - Flexible Server
//**********************************************************************************************
module "cl_postgresql_flexible_server_database" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_postgresql_flexible_server_database"
  env                                              = var.env
  postfix                                          = var.postfix
  cl_postgresql_flexible_server_db_postfix         = "db"
  cl_postgresql_flexible_server_database_server_id = module.cl_postgresql_flexible_server.cl_postgresql_flexible_server.id
}
//**********************************************************************************************
```
# Azure Database for PostgreSQL - Flexible Server

Azure Database for PostgreSQL flexible server is a relational database service in the Microsoft cloud based on the PostgreSQL open source relational database. 

For more information, please visit: https://learn.microsoft.com/en-us/azure/postgresql/flexible-server/service-overview


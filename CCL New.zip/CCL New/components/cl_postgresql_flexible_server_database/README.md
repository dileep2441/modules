<!-- BEGIN_TF_DOCS -->

# Azure Database for PostgreSQL - Flexible Server

Azure Database for PostgreSQL flexible server is a relational database service in the Microsoft cloud based on the PostgreSQL open source relational database. 

For more information, please visit: https://learn.microsoft.com/en-us/azure/postgresql/flexible-server/service-overview




## Resources

| Name | Type |
|------|------|
| [azurerm_postgresql_flexible_server_database.cl_postgresql_flexible_server_database](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/postgresql_flexible_server_database) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_postgresql_flexible_server_database_charset"></a> [cl\_postgresql\_flexible\_server\_database\_charset](#input\_cl\_postgresql\_flexible\_server\_database\_charset) | (Optional) Specifies the Charset for the Azure PostgreSQL Flexible Server Database, which needs to be a valid PostgreSQL Charset. Defaults to UTF8. Changing this forces a new Azure PostgreSQL Flexible Server Database to be created. | `string` | `"utf8"` | no |
| <a name="input_cl_postgresql_flexible_server_database_collation"></a> [cl\_postgresql\_flexible\_server\_database\_collation](#input\_cl\_postgresql\_flexible\_server\_database\_collation) | (Optional) Specifies the Collation for the Azure PostgreSQL Flexible Server Database, which needs to be a valid PostgreSQL Collation. Defaults to en\_US.utf8. Changing this forces a new Azure PostgreSQL Flexible Server Database to be created. | `string` | `"en_US.utf8"` | no |
| <a name="input_cl_postgresql_flexible_server_database_server_id"></a> [cl\_postgresql\_flexible\_server\_database\_server\_id](#input\_cl\_postgresql\_flexible\_server\_database\_server\_id) | (Required) The ID of the Azure PostgreSQL Flexible Server from which to create this PostgreSQL Flexible Server Database. Changing this forces a new Azure PostgreSQL Flexible Server Database to be created. | `string` | n/a | yes |
| <a name="input_cl_postgresql_flexible_server_db_postfix"></a> [cl\_postgresql\_flexible\_server\_db\_postfix](#input\_cl\_postgresql\_flexible\_server\_db\_postfix) | (Required) The name which should be used for this Azure PostgreSQL Flexible Server Database. Changing this forces a new Azure PostgreSQL Flexible Server Database to be created. | `string` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |

## Local values

```terraform

```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_postgresql_flexible_server_database"></a> [cl\_postgresql\_flexible\_server\_database](#output\_cl\_postgresql\_flexible\_server\_database) | Outputs ********************************************************************************************** |

## Usage

```terraform
// Deploy PostgreSQL - Flexible Server
//**********************************************************************************************
module "cl_postgresql_flexible_server" {
  source                                                   = "../dn-tads_tf-azure-component-library/components/cl_postgresql_flexible_server"
  env                                                      = var.env
  postfix                                                  = var.postfix
  location                                                 = var.location
  cl_postgresql_flexible_server_postfix                    = var.cl_postgresql_flexible_server_postfix
  cl_postgresql_flexible_server_resource_group_name        = var.cl_postgresql_flexible_server_resource_group_name
  cl_postgresql_flexible_server_vnet_rg_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.resource_group_name
  cl_postgresql_flexible_server_vnet_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_postgresql_flexible_server_subnet_prefix              = ["x.x.xx.x/27"]
  cl_postgresql_flexible_server_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_postgresql_flexible_server_private_dns_zone_id        = [var.cl_postgresql_flexible_server_private_dns_zone_id]
}
//**********************************************************************************************

// Deploy Azure Database for PostgreSQL - Flexible Server
//**********************************************************************************************
module "cl_postgresql_flexible_server_database" {
  source                                           = "../dn-tads_tf-azure-component-library/components/cl_postgresql_flexible_server_database"
  env                                              = var.env
  postfix                                          = var.postfix
  cl_postgresql_flexible_server_db_postfix         = "db"
  cl_postgresql_flexible_server_database_server_id = module.cl_postgresql_flexible_server.cl_postgresql_flexible_server.id
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
<!-- BEGIN_TF_DOCS -->

# Azure logic App Component

(Azure Logic App is a serverless workflow service that enables the user to run event-triggered code without having to provision or manage infrastructure.)
This component will deploy an Azure Logic App. It will also deploy a storage account, private endpoints, and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/logic-apps/logic-apps-overview



## Resources

| Name | Type |
|------|------|
| [azurerm_advanced_threat_protection.cl_logic_app_sa_atp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection) | resource |
| [azurerm_app_service_virtual_network_swift_connection.cl_logic_app_network_connection_integration_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service_virtual_network_swift_connection) | resource |
| [azurerm_data_protection_backup_instance_blob_storage.cl_logic_app_storage_account_protected_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/data_protection_backup_instance_blob_storage) | resource |
| [azurerm_logic_app_standard.cl_logic_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/logic_app_standard) | resource |
| [azurerm_monitor_diagnostic_setting.cl_logic_app_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_monitor_diagnostic_setting.cl_logic_app_storage_account_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_logic_app_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.cl_logic_app_storage_account_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.cl_logic_app_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.cl_logic_app_sa_network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_logic_app_always_on"></a> [cl\_logic\_app\_always\_on](#input\_cl\_logic\_app\_always\_on) | (Optional) Should the app be loaded at all times? | `bool` | `false` | no |
| <a name="input_cl_logic_app_app_settings"></a> [cl\_logic\_app\_app\_settings](#input\_cl\_logic\_app\_app\_settings) | (Optional) A map of key-value pairs for App Settings and custom values. | `map` | `{}` | no |
| <a name="input_cl_logic_app_asp_id"></a> [cl\_logic\_app\_asp\_id](#input\_cl\_logic\_app\_asp\_id) | (Required) App Service Plan ID used by the logic app. | `any` | n/a | yes |
| <a name="input_cl_logic_app_auth_settings_enabled"></a> [cl\_logic\_app\_auth\_settings\_enabled](#input\_cl\_logic\_app\_auth\_settings\_enabled) | (Optional) Enable or disable Authentication Settings | `string` | `"true"` | no |
| <a name="input_cl_logic_app_diagnostics"></a> [cl\_logic\_app\_diagnostics](#input\_cl\_logic\_app\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "FunctionAppLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_logic_app_elastic_instance_minimum"></a> [cl\_logic\_app\_elastic\_instance\_minimum](#input\_cl\_logic\_app\_elastic\_instance\_minimum) | (Optional) The number of minimum instances for this function app. Only affects apps on the Premium plan. | `string` | `null` | no |
| <a name="input_cl_logic_app_ftps_state"></a> [cl\_logic\_app\_ftps\_state](#input\_cl\_logic\_app\_ftps\_state) | (Optional) State of FTP / FTPS service for this logic app. Possible values include: AllAllowed, FtpsOnly and Disabled. | `string` | `"Disabled"` | no |
| <a name="input_cl_logic_app_http2_enabled"></a> [cl\_logic\_app\_http2\_enabled](#input\_cl\_logic\_app\_http2\_enabled) | (Optional) Is HTTP2 Enabled on this logic app? | `bool` | `false` | no |
| <a name="input_cl_logic_app_https_only"></a> [cl\_logic\_app\_https\_only](#input\_cl\_logic\_app\_https\_only) | (Optional) Booolean to toggle if the logic app can only be accessed via HTTPS. | `bool` | `true` | no |
| <a name="input_cl_logic_app_identity_ids"></a> [cl\_logic\_app\_identity\_ids](#input\_cl\_logic\_app\_identity\_ids) | UserAssigned Identities ID to add to logic App. Mandatory if type is UserAssigned | `list(string)` | `null` | no |
| <a name="input_cl_logic_app_identity_type"></a> [cl\_logic\_app\_identity\_type](#input\_cl\_logic\_app\_identity\_type) | Add an Identity (MSI) to the logic app. Possible values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_logic_app_integration_subnet_id"></a> [cl\_logic\_app\_integration\_subnet\_id](#input\_cl\_logic\_app\_integration\_subnet\_id) | (Required) The ID of the integration subnet the logic app will be associated to (the subnet must have a service\_delegation configured for Microsoft.Web/serverFarms). | `any` | n/a | yes |
| <a name="input_cl_logic_app_log_analytics_workspace_id"></a> [cl\_logic\_app\_log\_analytics\_workspace\_id](#input\_cl\_logic\_app\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_logic_app_min_tls_version"></a> [cl\_logic\_app\_min\_tls\_version](#input\_cl\_logic\_app\_min\_tls\_version) | (Optional) The minimum supported TLS version for the logic app. | `string` | `"1.2"` | no |
| <a name="input_cl_logic_app_os_type"></a> [cl\_logic\_app\_os\_type](#input\_cl\_logic\_app\_os\_type) | (Optional) The logic app os type. Enter 'linux' for Linux and leave null for Windows. For linux, you will need to set cl\_app\_service\_plan\_reserved to true and cl\_app\_service\_plan\_kind to logicApp in the app service plan component. | `string` | `null` | no |
| <a name="input_cl_logic_app_pe_subnet_ids"></a> [cl\_logic\_app\_pe\_subnet\_ids](#input\_cl\_logic\_app\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_cl_logic_app_postfix"></a> [cl\_logic\_app\_postfix](#input\_cl\_logic\_app\_postfix) | (Required) The bespoke name of the app you are deploying. | `any` | n/a | yes |
| <a name="input_cl_logic_app_pre_warmed_instance_count"></a> [cl\_logic\_app\_pre\_warmed\_instance\_count](#input\_cl\_logic\_app\_pre\_warmed\_instance\_count) | (Optional) The number of pre-warmed instances for this function app. Only affects apps on the Premium plan. | `string` | `null` | no |
| <a name="input_cl_logic_app_private_dns_zone_ids"></a> [cl\_logic\_app\_private\_dns\_zone\_ids](#input\_cl\_logic\_app\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_logic_app_rg_name"></a> [cl\_logic\_app\_rg\_name](#input\_cl\_logic\_app\_rg\_name) | (Required) The resource group to deploy the logic app into. | `any` | n/a | yes |
| <a name="input_cl_logic_app_sa_allowed_ips"></a> [cl\_logic\_app\_sa\_allowed\_ips](#input\_cl\_logic\_app\_sa\_allowed\_ips) | (Optional) A list of Ip addresses that can access the fcn app storage account. It is recommended that you add your automation tool's IP range here. | `list` | `[]` | no |
| <a name="input_cl_logic_app_sa_allowed_vnet_subnet_ids"></a> [cl\_logic\_app\_sa\_allowed\_vnet\_subnet\_ids](#input\_cl\_logic\_app\_sa\_allowed\_vnet\_subnet\_ids) | (Optional) A list of Subnets of the vnet that can access the fcn app storage account. | `list(string)` | `[]` | no |
| <a name="input_cl_logic_app_settings"></a> [cl\_logic\_app\_settings](#input\_cl\_logic\_app\_settings) | (Optional) Variables passed as environment variables | `map` | `{}` | no |
| <a name="input_cl_logic_app_storage_account_backup_policy_id"></a> [cl\_logic\_app\_storage\_account\_backup\_policy\_id](#input\_cl\_logic\_app\_storage\_account\_backup\_policy\_id) | The azure blob storage backup policy id from the backup vault. | `any` | `null` | no |
| <a name="input_cl_logic_app_storage_account_backup_vault"></a> [cl\_logic\_app\_storage\_account\_backup\_vault](#input\_cl\_logic\_app\_storage\_account\_backup\_vault) | The blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_logic_app_storage_account_backup_vault_id"></a> [cl\_logic\_app\_storage\_account\_backup\_vault\_id](#input\_cl\_logic\_app\_storage\_account\_backup\_vault\_id) | The id of blob storage backup vault. | `any` | `null` | no |
| <a name="input_cl_logic_app_storage_account_blob_retention_days"></a> [cl\_logic\_app\_storage\_account\_blob\_retention\_days](#input\_cl\_logic\_app\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `7` | no |
| <a name="input_cl_logic_app_storage_account_container_retention_days"></a> [cl\_logic\_app\_storage\_account\_container\_retention\_days](#input\_cl\_logic\_app\_storage\_account\_container\_retention\_days) | Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7` | `number` | `7` | no |
| <a name="input_cl_logic_app_storage_account_diagnostics"></a> [cl\_logic\_app\_storage\_account\_diagnostics](#input\_cl\_logic\_app\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_logic_app_storage_account_enable_backup"></a> [cl\_logic\_app\_storage\_account\_enable\_backup](#input\_cl\_logic\_app\_storage\_account\_enable\_backup) | (Optional) Toggle the blob storage backup feature. | `bool` | `false` | no |
| <a name="input_cl_logic_app_storage_account_kind"></a> [cl\_logic\_app\_storage\_account\_kind](#input\_cl\_logic\_app\_storage\_account\_kind) | (Optional)  Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2. | `string` | `"StorageV2"` | no |
| <a name="input_cl_logic_app_storage_account_pe_subnet_ids"></a> [cl\_logic\_app\_storage\_account\_pe\_subnet\_ids](#input\_cl\_logic\_app\_storage\_account\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_cl_logic_app_storage_account_private_dns_zone_ids"></a> [cl\_logic\_app\_storage\_account\_private\_dns\_zone\_ids](#input\_cl\_logic\_app\_storage\_account\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_cl_logic_app_storage_account_replication_type"></a> [cl\_logic\_app\_storage\_account\_replication\_type](#input\_cl\_logic\_app\_storage\_account\_replication\_type) | (Optional) Defines the type of replication to use for the storage account for the logic app audit and security logging. | `string` | `"LRS"` | no |
| <a name="input_cl_logic_app_storage_account_rg_name"></a> [cl\_logic\_app\_storage\_account\_rg\_name](#input\_cl\_logic\_app\_storage\_account\_rg\_name) | (Required) The resource group to deploy the storage account needed for the logic app. | `any` | n/a | yes |
| <a name="input_cl_logic_app_storage_account_tier"></a> [cl\_logic\_app\_storage\_account\_tier](#input\_cl\_logic\_app\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for the logic app audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_cl_logic_app_storage_account_tls_version"></a> [cl\_logic\_app\_storage\_account\_tls\_version](#input\_cl\_logic\_app\_storage\_account\_tls\_version) | (Optional) Defines the minimum TLS version to use for the data lake storage account. | `string` | `"TLS1_2"` | no |
| <a name="input_cl_logic_app_use_32_bit_worker_process"></a> [cl\_logic\_app\_use\_32\_bit\_worker\_process](#input\_cl\_logic\_app\_use\_32\_bit\_worker\_process) | (Optional) Should the logic app run in 32 bit mode, rather than 64 bit mode? | `bool` | `true` | no |
| <a name="input_cl_logic_app_version"></a> [cl\_logic\_app\_version](#input\_cl\_logic\_app\_version) | (Optional) The runtime version associated with the logic App. Defaults to ~1 | `string` | `"~1"` | no |
| <a name="input_cl_logic_app_vnet_route_all_enabled"></a> [cl\_logic\_app\_vnet\_route\_all\_enabled](#input\_cl\_logic\_app\_vnet\_route\_all\_enabled) | (Optional) Should all outbound traffic to have NAT Gateways, Network Security Groups and User Defined Routes applied? . | `bool` | `true` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

## Local values

```terraform
locals {
    timeout_duration = "2h"
    cl_storage_account_blob_properties           = (var.cl_logic_app_storage_account_enable_backup ? false : true)
    cl_logic_app_storage_account_infra_encryption_enabled = (var.cl_logic_app_storage_account_kind == "StorageV2" || var.cl_logic_app_storage_account_kind == "BlockBlobStorage" && var.cl_logic_app_storage_account_tier == "Premium" ? true : false)
    cl_logic_app_storage_account_modify_name = {
        "sbox-pr" = "sboxpr"
        "nprd-pr" = "nprdpr"
        "nprd-dr" = "nprddr"
        "prod-pr" = "prodpr"
        "prod-dr" = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_logic_app"></a> [cl\_logic\_app](#output\_cl\_logic\_app) | n/a |
| <a name="output_cl_logic_app_private_endpoint"></a> [cl\_logic\_app\_private\_endpoint](#output\_cl\_logic\_app\_private\_endpoint) | n/a |
| <a name="output_cl_logic_app_storage_account"></a> [cl\_logic\_app\_storage\_account](#output\_cl\_logic\_app\_storage\_account) | Outputs ********************************************************************************************** |
| <a name="output_cl_logic_app_storage_account_protected_blob"></a> [cl\_logic\_app\_storage\_account\_protected\_blob](#output\_cl\_logic\_app\_storage\_account\_protected\_blob) | n/a |

## Usage
#### Linux logic App (logic app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_deploy_rg                             = false
  cl_app_service_plan_rg_name                               = azurerm_resource_group.cl_logic_app_rg.name
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.0/27"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_sku_size                              = var.app_service_plan_sku_size
  cl_app_service_plan_sku_tier                              = var.app_service_plan_sku_tier
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "logic_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "logic_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.logic_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_logic_app" {
  depends_on                                      = [module.cl_app_service_plan, azurerm_resource_group.cl_logic_app_rg]
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_logic_app"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_logic_app_postfix                            = "lgcapp"
  cl_logic_app_rg_name                            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_storage_account_rg_name            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_asp_id                             = module.cl_app_service_plan.cl_app_service_plan.id
  cl_logic_app_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_logic_app_os_type                            = "linux"
  cl_logic_app_version                            = "~3"
  cl_logic_app_pe_subnet_ids                      = [azurerm_subnet.test_subnet.id]
  #cl_app_service_private_dns_zone_ids            = azurerm_private_dns_zone.logic_app_private_dns_zone.id
  cl_logic_app_integration_subnet_id              = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  # cl_logic_app_allowed_vnet_subnet_ids          = var.cl_logic_app_allowed_vnet_subnet_ids
  # cl_logic_app_allowed_ips                      = var.cl_logic_app_allowed_ips
  cl_logic_app_sa_allowed_vnet_subnet_ids         = [module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id]
  cl_logic_app_storage_account_enable_backup      = false
  cl_logic_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_logic_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_logic_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```
#### Windows logic App (logic app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-gov_component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "logic_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "logic_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.logic_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_logic_app" {
  depends_on                                      = [module.cl_app_service_plan, azurerm_resource_group.cl_logic_app_rg]
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_logic_app"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_logic_app_postfix                            = "lgcapp"
  cl_logic_app_rg_name                            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_storage_account_rg_name            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_asp_id                             = module.cl_app_service_plan.cl_app_service_plan.id
  cl_logic_app_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_logic_app_pe_subnet_ids                      = [azurerm_subnet.test_subnet.id]
  #cl_app_service_private_dns_zone_ids            = azurerm_private_dns_zone.logic_app_private_dns_zone.id
  cl_logic_app_integration_subnet_id              = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  # cl_logic_app_allowed_vnet_subnet_ids          = var.cl_logic_app_allowed_vnet_subnet_ids
  # cl_logic_app_allowed_ips                      = var.cl_logic_app_allowed_ips
  cl_logic_app_sa_allowed_vnet_subnet_ids         = [module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id]
  cl_logic_app_storage_account_enable_backup      = false
  cl_logic_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_logic_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_logic_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```
<!-- END_TF_DOCS -->

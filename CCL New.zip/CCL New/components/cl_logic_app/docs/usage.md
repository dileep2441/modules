## Usage
#### Linux logic App (logic app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_deploy_rg                             = false
  cl_app_service_plan_rg_name                               = azurerm_resource_group.cl_logic_app_rg.name
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.0/27"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_sku_size                              = var.app_service_plan_sku_size
  cl_app_service_plan_sku_tier                              = var.app_service_plan_sku_tier
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "logic_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "logic_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.logic_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_logic_app" {
  depends_on                                      = [module.cl_app_service_plan, azurerm_resource_group.cl_logic_app_rg]
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_logic_app"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_logic_app_postfix                            = "lgcapp"
  cl_logic_app_rg_name                            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_storage_account_rg_name            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_asp_id                             = module.cl_app_service_plan.cl_app_service_plan.id
  cl_logic_app_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_logic_app_os_type                            = "linux"
  cl_logic_app_version                            = "~3"
  cl_logic_app_pe_subnet_ids                      = [azurerm_subnet.test_subnet.id]
  #cl_app_service_private_dns_zone_ids            = azurerm_private_dns_zone.logic_app_private_dns_zone.id
  cl_logic_app_integration_subnet_id              = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  # cl_logic_app_allowed_vnet_subnet_ids          = var.cl_logic_app_allowed_vnet_subnet_ids
  # cl_logic_app_allowed_ips                      = var.cl_logic_app_allowed_ips
  cl_logic_app_sa_allowed_vnet_subnet_ids         = [module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id]
  cl_logic_app_storage_account_enable_backup      = false
  cl_logic_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_logic_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_logic_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```
#### Windows logic App (logic app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-gov_component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_kpmg_inbound = {
      name                          = "allow-kpmg-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "logic_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "logic_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.logic_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_logic_app" {
  depends_on                                      = [module.cl_app_service_plan, azurerm_resource_group.cl_logic_app_rg]
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_logic_app"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_logic_app_postfix                            = "lgcapp"
  cl_logic_app_rg_name                            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_storage_account_rg_name            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_asp_id                             = module.cl_app_service_plan.cl_app_service_plan.id
  cl_logic_app_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_logic_app_pe_subnet_ids                      = [azurerm_subnet.test_subnet.id]
  #cl_app_service_private_dns_zone_ids            = azurerm_private_dns_zone.logic_app_private_dns_zone.id
  cl_logic_app_integration_subnet_id              = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  # cl_logic_app_allowed_vnet_subnet_ids          = var.cl_logic_app_allowed_vnet_subnet_ids
  # cl_logic_app_allowed_ips                      = var.cl_logic_app_allowed_ips
  cl_logic_app_sa_allowed_vnet_subnet_ids         = [module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id]
  cl_logic_app_storage_account_enable_backup      = false
  cl_logic_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_logic_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_logic_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```
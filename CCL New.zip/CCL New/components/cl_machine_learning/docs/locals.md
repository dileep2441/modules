## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_machine_learning_private_dns_zone_ids = [
    var.cl_machine_learning_privatelink_api_azureml_ms_id,
    var.cl_machine_learning_privatelink_notebooks_azure_net_id
  ]
}
```

#### Note:
For Machine Learning component, it needs AzureRM provider for Terraform version 3.40.0 or later.
It can be specified on Jenkinsfile:
```terraform
terraform {
  required_version = ">= 1.0"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">= 3.40.0"
    }
  }
}
```

Please, confirm that these two Private DNS Zone entries exists in the respective Shared Subscription.
[Azure Private Endpoint DNS configuration](https://learn.microsoft.com/en-us/azure/private-link/private-endpoint-dns#azure-services-dns-zone-configuration)

- `privatelink.api.azureml.ms`
- `privatelink.notebooks.azure.net`


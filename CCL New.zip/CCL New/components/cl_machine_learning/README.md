<!-- BEGIN_TF_DOCS -->

# Azure Machine Learning workspace

**Azure Machine Learning** is a cloud service for accelerating and managing the machine learning project lifecycle. Machine learning professionals, data scientists, and engineers can use it in their day-to-day workflows: Train and deploy models, and manage MLOps.

You can create a model in Azure Machine Learning or use a model built from an open-source platform, such as Pytorch, TensorFlow, or scikit-learn. MLOps tools help you monitor, retrain, and redeploy models.

**Workspaces** are places to collaborate with colleagues and group related work. For example, experiments, jobs, datasets, components, and inference endpoints.

We recommend creating a workspace per project. While a workspace can be used for multiple projects, limiting it to one project per workspace allows for cost reporting accrued to a project level. It also allows you to manage configurations like datastores in the scope of each project.

## Working with a workspace
Machine learning tasks read and/or write artifacts to your workspace.

- Run an experiment to train a model - writes job run results to the workspace.
- Use automated ML to train a model - writes training results to the workspace.
- Register a model in the workspace.
- Deploy a model - uses the registered model to create a deployment.
- Create and run reusable workflows.
- View machine learning artifacts such as jobs, pipelines, models, deployments.
- Track and monitor models.
- You can share assets between workspaces using Azure Machine Learning registries (preview).




#### Note:
For Machine Learning component, it needs AzureRM provider for Terraform version 3.40.0 or later.
It can be specified on Jenkinsfile:
```terraform
terraform {
  required_version = ">= 1.0"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">= 3.40.0"
    }
  }
}
```

Please, confirm that these two Private DNS Zone entries exists in the respective Shared Subscription.
[Azure Private Endpoint DNS configuration](https://learn.microsoft.com/en-us/azure/private-link/private-endpoint-dns#azure-services-dns-zone-configuration)

- `privatelink.api.azureml.ms`
- `privatelink.notebooks.azure.net`


## Resources

| Name | Type |
|------|------|
| [azurerm_machine_learning_workspace.cl_machine_learning](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/machine_learning_workspace) | resource |
| [azurerm_monitor_diagnostic_setting.cl_machine_learning_diagnostic_setting](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.cl_machine_learning_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_resource_group.cl_machine_learning_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_machine_learning_app_insights_id"></a> [cl\_machine\_learning\_app\_insights\_id](#input\_cl\_machine\_learning\_app\_insights\_id) | (Required) The ID of the Application Insights associated with this Machine Learning Workspace. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_cl_machine_learning_deploy_rg"></a> [cl\_machine\_learning\_deploy\_rg](#input\_cl\_machine\_learning\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the Azure Machine Learning workspace. | `bool` | `true` | no |
| <a name="input_cl_machine_learning_diagnostic"></a> [cl\_machine\_learning\_diagnostic](#input\_cl\_machine\_learning\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AmlComputeClusterEvent",<br>    "AmlComputeJobEvent",<br>    "AmlComputeCpuGpuUtilization",<br>    "AmlRunStatusChangedEvent",<br>    "ModelsChangeEvent",<br>    "ModelsReadEvent",<br>    "ModelsActionEvent",<br>    "DeploymentReadEvent",<br>    "DeploymentEventACI",<br>    "DeploymentEventAKS",<br>    "InferencingOperationAKS",<br>    "InferencingOperationACI",<br>    "EnvironmentChangeEvent",<br>    "EnvironmentReadEvent",<br>    "DataLabelChangeEvent",<br>    "DataLabelReadEvent",<br>    "ComputeInstanceEvent",<br>    "DataStoreChangeEvent",<br>    "DataStoreReadEvent",<br>    "DataSetChangeEvent",<br>    "DataSetReadEvent",<br>    "PipelineChangeEvent",<br>    "PipelineReadEvent",<br>    "RunEvent",<br>    "RunReadEvent"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_cl_machine_learning_identity_type"></a> [cl\_machine\_learning\_identity\_type](#input\_cl\_machine\_learning\_identity\_type) | (Optional) Specifies the identity type of the Machine Learning workspace. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_cl_machine_learning_keyvault_id"></a> [cl\_machine\_learning\_keyvault\_id](#input\_cl\_machine\_learning\_keyvault\_id) | (Required) The ID of key vault associated with this Machine Learning Workspace. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_cl_machine_learning_log_analytics_workspace_id"></a> [cl\_machine\_learning\_log\_analytics\_workspace\_id](#input\_cl\_machine\_learning\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `any` | n/a | yes |
| <a name="input_cl_machine_learning_nacl_allowed_subnets"></a> [cl\_machine\_learning\_nacl\_allowed\_subnets](#input\_cl\_machine\_learning\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure Machine Learning Workspace. | `list(string)` | `[]` | no |
| <a name="input_cl_machine_learning_postfix"></a> [cl\_machine\_learning\_postfix](#input\_cl\_machine\_learning\_postfix) | (Required) The bespoke name of the machine learning workspace you are deploying. | `any` | n/a | yes |
| <a name="input_cl_machine_learning_private_endpoint_subresource_names"></a> [cl\_machine\_learning\_private\_endpoint\_subresource\_names](#input\_cl\_machine\_learning\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "amlworkspace"<br>]</pre> | no |
| <a name="input_cl_machine_learning_privatelink_api_azureml_ms_id"></a> [cl\_machine\_learning\_privatelink\_api\_azureml\_ms\_id](#input\_cl\_machine\_learning\_privatelink\_api\_azureml\_ms\_id) | (Required) Azure Resource Id of Private DNS Zone for privatelink.api.azureml.ms | `string` | n/a | yes |
| <a name="input_cl_machine_learning_privatelink_notebooks_azure_net_id"></a> [cl\_machine\_learning\_privatelink\_notebooks\_azure\_net\_id](#input\_cl\_machine\_learning\_privatelink\_notebooks\_azure\_net\_id) | (Required) Azure Resource Id of Private DNS Zone for privatelink.notebooks.azure.net | `string` | n/a | yes |
| <a name="input_cl_machine_learning_rg_name"></a> [cl\_machine\_learning\_rg\_name](#input\_cl\_machine\_learning\_rg\_name) | (Optional) The name of the Machine Learning workspace resource group if cl\_machine\_learning\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_cl_machine_learning_storage_account_id"></a> [cl\_machine\_learning\_storage\_account\_id](#input\_cl\_machine\_learning\_storage\_account\_id) | (Required) The ID of the Storage Account associated with this Machine Learning Workspace. Changing this forces a new resource to be created. | `any` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map(any)` | `{}` | no |

## Local values

```terraform
locals {
  timeout_duration = "2h"
  cl_machine_learning_private_dns_zone_ids = [
    var.cl_machine_learning_privatelink_api_azureml_ms_id,
    var.cl_machine_learning_privatelink_notebooks_azure_net_id
  ]
}
```

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_machine_learning"></a> [cl\_machine\_learning](#output\_cl\_machine\_learning) | Machine Learning workspace |
| <a name="output_cl_machine_learning_diagnostic_setting"></a> [cl\_machine\_learning\_diagnostic\_setting](#output\_cl\_machine\_learning\_diagnostic\_setting) | Monitor Diagnostic |
| <a name="output_cl_machine_learning_private_endpoint"></a> [cl\_machine\_learning\_private\_endpoint](#output\_cl\_machine\_learning\_private\_endpoint) | Machine Learning workspace private endpoint |
| <a name="output_cl_machine_learning_rg"></a> [cl\_machine\_learning\_rg](#output\_cl\_machine\_learning\_rg) | Resource Group for Machine Learning |

## Usage 

```terraform
// Azure Resource Group
//**********************************************************************************************
resource "azurerm_resource_group" "machine_learning" {
  name     = "rg-${var.env}-${var.postfix}-mlws-${var.machine_learning_postfix}"
  location = var.location
  tags     = var.tags
}
//**********************************************************************************************

// Azure Application Insights
//**********************************************************************************************
module "cl_app_insights" {
  source                              = "../dn-tads_tf-azure-component-library/components/cl_app_insights"
  env                                 = var.env
  postfix                             = var.postfix
  location                            = var.location
  cl_app_insights_resource_group_name = azurerm_resource_group.machine_learning.name
  cl_app_insights_application_type    = "web"
  cl_app_insights_content             = "requests //simple example query"
  cl_app_insights_scope               = "shared"
  cl_app_insights_type                = "query"
  cl_app_insights_web_test_kind       = "ping"
 }
//**********************************************************************************************

// Azure Storage account
//**********************************************************************************************
module "cl_storage_account" {
  source                                        = "../dn-tads_tf-azure-component-library/components/cl_storage_account"
  env                                           = var.env
  postfix                                       = var.postfix
  location                                      = var.location
  cl_storage_account_resource_group_name        = azurerm_resource_group.machine_learning.name
  cl_storage_account_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_storage_account_allowed_ips                = ["199.206.0.0/15"] //allows KPMG addresses
  cl_storage_account_allowed_pe_subnet_ids      = var.cl_storage_account_allowed_pe_subnet_ids
  cl_storage_account_allowed_vnet_subnet_ids    = var.cl_storage_account_allowed_vnet_subnet_ids
  cl_storage_account_private_dns_zone_ids       = var.sa_private_dns_zone_id
}
//**********************************************************************************************

// Azure Machine Learning Workspace
//**********************************************************************************************
module "cl_machine_learning" {
  source                                                 = "../dn-tads_tf-azure-component-library/components/cl_machine_learning"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  cl_machine_learning_postfix                            = var.machine_learning_postfix
  cl_machine_learning_deploy_rg                          = false
  cl_machine_learning_rg_name                            = azurerm_resource_group.machine_learning.name
  cl_machine_learning_app_insights_id                    = module.cl_app_insights.cl_app_insights.id
  cl_machine_learning_storage_account_id                 = module.cl_storage_account.cl_storage_account.id
  cl_machine_learning_keyvault_id                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_keyvault[0].cl_keyvault.id
  cl_machine_learning_nacl_allowed_subnets               = [
      data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet.id
  ]
  cl_machine_learning_privatelink_api_azureml_ms_id      = var.privatelink_api_azureml_ms
  cl_machine_learning_privatelink_notebooks_azure_net_id = var.privatelink_notebooks_azure_net
  cl_machine_learning_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  tags                                                   = var.tags
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
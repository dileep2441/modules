# Azure Web Jobs Component

WebJobs is a feature of Azure App Service that enables you to run a program or script in the same instance as a web app, API app, or mobile app.
There are two types of web jobs: continuous and triggered. Continuous starts immediately, runs in all instances of the web app and supports remote debugging.
Triggered web jobs start manually, runs on a single instance and does not support remote debugging.
This component will deploy Web Jobs app service, private endpoint, diagnostics Settings and binds the app service to the integration subnet.

For more information, please visit: https://docs.microsoft.com/en-us/azure/app-service/webjobs-create 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_web_jobs_app_postfix" {
    description = "(Required) The bespoke name of the app you are deploying."
}
variable "cl_web_jobs_rg_name" {
    description = "(Required) The resource group to deploy the Web Jobs into."
}
variable "cl_web_jobs_asp_id" {
    description = "(Required) The resource id of the web jobs plan."
}
variable "cl_web_jobs_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_web_jobs_integration_subnet_id" {
    description = "(Optional) The ID of the integration subnet the web jobs will be associated to (the subnet must have a service_delegation configured for Microsoft.Web/serverFarms)."
    default     = null
}
variable "cl_app_service_plan_deploy_integration_subnet" {
    description = "(Optional) A boolean that toggles the deployment of the vnet integration subnet."
    default     = true
}
variable "cl_web_jobs_https_only" {
    description = "(Optional) Booolean to toggle if the web jobs can only be accessed via HTTPS."
    default     = true
}
variable "cl_web_jobs_client_affinity_enabled" {
    description = "(Optional) Should the web jobs send session affinity cookies, which route client requests in the same session to the same instance?"
    default     = false
}
variable "cl_web_jobs_ftps_state" {
    description = "(Optional) State of FTP / FTPS service for this web jobs. Possible values include: AllAllowed, FtpsOnly and Disabled."
    default     = "Disabled"
}
variable "cl_web_jobs_linux_fx_version" {
    description = "(Optional) Linux App Framework and version for the web jobs."
    default     = null
}
variable "cl_web_jobs_always_on" {
    description = "(Optional) Should the app be loaded at all times?"
    default     = false
}
variable "cl_web_jobs_min_tls_version" {
    description = "(Optional) The minimum supported TLS version for the web jobs"
    default     = "1.2"
}
variable "cl_web_jobs_http2_enabled" {
    description = "(Optional) Is HTTP2 Enabled on this web jobs?"
    default     = false
}
variable "cl_web_jobs_use_32_bit_worker_process" {
    description = "(Optional) Should the web jobs run in 32 bit mode, rather than 64 bit mode?"
    default     = true
}
variable "cl_web_jobs_number_of_workers" {
    description = "(Optional) The scaled number of workers (for per site scaling) of this web jobs."
    default     = 1
}
variable "cl_web_jobs_default_documents" {
    description = "(Optional) The ordering of default documents to load, if an address isn't specified."
    default     = []
}
variable "cl_web_jobs_remote_debugging_enabled" {
    description = "(Optional) Is Remote Debugging Enabled?"
    default     = false
}
variable "cl_web_jobs_dotnet_framework_version" {
    type = string
    default = "v5.0"
    description = "(Optional) The version of the .net framework's CLR used in this web jobs."
}
variable "cl_web_jobs_remote_debugging_version" {
    description = "(Optional) Which version of Visual Studio should the Remote Debugger be compatible with?"
    default     = null
}
variable "cl_web_jobs_auth_settings_enabled" {
    description = "(Optional) Enable or disable Authentication Settings"
    default     = false
}
variable "cl_web_jobs_auth_settings_default_provider"{
    description = "(Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter."
    default     = null
}
variable "cl_web_jobs_auth_settings_unauthenticated_client_action" {
    description = " (Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage."
    default     = null
}
variable "cl_web_jobs_identity_type" {
    description = "(Optional) Specifies the identity type of the web jobs. Values are SystemAssigned or UserAssigned"
    default     = "SystemAssigned"
}
variable "cl_web_jobs_identity_identity_ids" {
    description = "(Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned."
    default     = null
}
variable "cl_web_jobs_settings" {
    description = "(Optional) Variables passed as environment variables"
    type        = map
    default     = {}
}
variable "cl_web_jobs_pe_subnet_ids" {
    description = "(Optional) A list of subnet IDs the web jobs will create a private endpoint in."
    default     = []
}
variable "cl_web_jobs_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
variable "cl_web_jobs_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default = {
        logs    = ["AppServiceAntivirusScanAuditLogs", "AppServiceHTTPLogs", "AppServiceConsoleLogs", "AppServiceAppLogs", "AppServiceFileAuditLogs", "AppServiceAuditLogs", "AppServiceIPSecAuditLogs", "AppServicePlatformLogs"]
        metrics = ["AllMetrics"]
    }
}
variable "cl_web_jobs_scm_type" { 
    type = string
    default = "None"
    description = "Type of the source control enabled for this web jobs. Defaults to None"
}
variable "cl_web_jobs_health_check_path" {
    type = string
    default = null
    description = "The health check path to be pinged by web jobs"
}
variable "cl_web_jobs_connection_strings" {
  type = map(object({
    name                  = string
    type                  = string
    value                 = string
  }))
  description = "(Optional) Connection strings for web jobs."
  default     = {}
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
    timeout_duration = "2h"
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_web_jobs" {
    value = azurerm_app_service.cl_web_jobs
}
output "cl_web_jobs_private_endpoint" {
    value = azurerm_private_endpoint.cl_web_jobs_private_endpoint
}
output "cl_web_jobs_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_web_jobs_diagnostic_setting
}
//**********************************************************************************************
```


## Usage

### Deploy Web Jobs with VNet integration subnet
```terraform

// Create the private link subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "private_link_subnet" {
    name                                            =  "${var.env}-${var.postfix}-private-link-sn"
    resource_group_name                             = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
    virtual_network_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
    address_prefixes                                = ["10.0.75.0/27"]
    enforce_private_link_endpoint_network_policies  = true
    service_endpoints                               = ["Microsoft.ServiceBus","Microsoft.Storage","Microsoft.KeyVault","Microsoft.AzureCosmosDB","Microsoft.Web"]
}
//********************************************************************************************** 
 
 // Create Private DNS Zone for Azure Storage Account
//**********************************************************************************************
resource "azurerm_private_dns_zone" "storage_account_private_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}
//**********************************************************************************************


// Link the Private Zone with the VNet for App Service
//**********************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "storage_account_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.storage_account_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//**********************************************************************************************


//********************************************************************************************** 
 // Deploys Storage Account for webjobs
//**********************************************************************************************
module "cl_storage_account" {
  source                                          = "../caf-tf-modules/cl_storage_account"
  env                                             = var.env
  postfix                                         = "${var.postfix}"
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.private_link_subnet.id]
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows xoriant addresses. need this for terraform to refresh current state
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.storage_account_private_dns_zone.id]
 }
//**********************************************************************************************


//**********************************************************************************************
// Create Service Plan for App Service
//**********************************************************************************************
module "cl_app_service_plan" {
  source                                                    = "../tf-azure-component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             =["10.0.75.64/26"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_app_postfix                           = "ale" 
  cl_app_service_plan_kind                                  = "Windows"
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.Storage", "Microsoft.Web"]
}
//**********************************************************************************************


// Create Private DNS Zone for Azure Web Apps
//**********************************************************************************************
resource "azurerm_private_dns_zone" "app_service_private_dns_zone" {
  name                = "privatelink.azurewebsites.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}
//**********************************************************************************************


// Link the Private Zone with the VNet for App Service
//**********************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "app_service_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.app_service_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//**********************************************************************************************


//**********************************************************************************************
// Create Web Jobs
//**********************************************************************************************
module "cl_web_jobs" {
  source                                           = "../tf-azure-component-library/components/cl_web_jobs"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_web_jobs_app_postfix                          = "web-jobs" 
  cl_web_jobs_integration_subnet_id                = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  cl_web_jobs_rg_name                              = module.cl_app_service_plan.cl_app_service_plan_rg.name
  cl_web_jobs_asp_id                               = module.cl_app_service_plan.cl_app_service_plan.id
  cl_web_jobs_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_web_jobs_private_dns_zone_ids                 = [azurerm_private_dns_zone.app_service_private_dns_zone.id]
  cl_web_jobs_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_web_jobs_settings                             = {
    WEBSITE_DNS_SERVER            = "168.63.129.16"
    WEBSITE_VNET_ROUTE_ALL        = "1"
  } 

  //For vanguard subscription please don't send the variable cl_web_jobs_connection_strings and you must to create the following connection strings manually with a CloudOps, in order to avoid error for sensitive values.  
  
  cl_web_jobs_connection_strings = {
    AzureWebJobsDashboard = {
     name = "AzureWebJobsDashboard"
     type = "Custom"
     value = "DefaultEndpointsProtocol=https;AccountName=${module.cl_storage_account.cl_storage_account.name};AccountKey=${module.cl_storage_account.cl_storage_account.primary_access_key};EndpointSuffix=privatelink.blob.core.windows.net"
  }
    AzureWebJobsStorage = {
     name = "AzureWebJobsStorage"
     type = "Custom"
     value = "DefaultEndpointsProtocol=https;AccountName=${module.cl_storage_account.cl_storage_account.name};AccountKey=${module.cl_storage_account.cl_storage_account.primary_access_key};EndpointSuffix=privatelink.blob.core.windows.net"
   }
  }  
 }
//**********************************************************************************************
```
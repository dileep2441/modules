# Azure CosmosDB Component

Azure Cosmos DB is Microsoft’s fully managed, globally distributed and horizontally scalable cloud service. 
It’s a multi-model NoSQL database that provides independent scaling across all the Azure regions. It can support many use cases such as document, key value, relational, and graph models. 
This component will deploy Azure CosmosDB, a private endpoint and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/cosmos-db/introduction 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_cosmosdb_resource_group_name" {
  description = "(Required) The name of the resource group where the cosmos db will be deployed to."
}

variable "cl_cosmosdb_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_cosmosdb_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["CassandraRequests", "DataPlaneRequests", "GremlinRequests", "MongoRequests", "QueryRuntimeStatistics", "PartitionKeyStatistics", "PartitionKeyRUConsumption", "ControlPlaneRequests"]
    metrics = ["Requests"]
  }
} 

variable "cl_cosmosdb_failover_location" {
    description = "(Required) The cloud region where resources will be deployed into."
    type        = string
    default     = null
}

variable "cl_cosmosdb_offer_type" {
    description = "(Required) The cloud region where resources will be deployed into."
    type        = string
    default     = "Standard"
}

variable "cl_cosmosdb_kind" {
    description = "(Required) The cloud region where resources will be deployed into."
    type        = string
    default     = "MongoDB"
}

variable "cl_cosmosdb_enable_multiple_write_locations {
    description = "(Optional) Enable multi-master support for this CosmosDB account"
    default     = false
}

variable "cl_cosmosdb_capabilities" {
  type        = list(string)
  description = "(Optional) The capabilities which should be enabled for Cosmos DB account."
  default     = ["EnableMongo"]
}

variable "cl_cosmosdb_consistency_policy_level" {
    description = "(Required) Consistency_policy_level will be deployed into."
    type        = string
    default     = "BoundedStaleness"
}

variable "cl_cosmosdb_consistency_max_interval" {
  description = "(Optional) A mapping of random_integer value to assign to all resources."
  type = number
  default = 350
}

variable "cl_cosmosdb_consistency_max_staleness_prefix" {
  description = "(Optional) A mapping of random_integer value to assign to all resources."
  type = number
  default = 200000
}

variable "cl_cosmosdb_virtual_network_filter_enabled" {
  type        = bool
  description = "(Optional) Enable/Disable network filtering"
  default     = true
}

variable "cl_cosmosdb_allowed_ips" {
  type        = string
  description = "(Optional) The list of ips allowed to connect to your CosmosDB database over the internet."
  default     = ""
}

variable "cl_cosmosdb_allowed_subnet" {
  type        = string
  description = "(Optional) The subnet id allowed to connect to this CosmosDB instance."
  default     = ""
}

variable "cl_private_endpoint_subresource_names" {
  type        = list(string)
  description = "(Optional) A list of subresources to be included in the private endpoint"
  default     = ["MongoDB"]
}

variable "cl_cosmosdb_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}

variable "cl_cosmosdb_zone_redundant" {
    description = "(Optional) Should zone redundancy be enabled for this region?"
    default     = false
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_cosmosdb" {
  value = azurerm_cosmosdb_account.cl_cosmosdb
}
output "cl_cosmosdb_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_cosmosdb_diagnostic_setting
}
output "cl_cosmosdb_private_endpoint" {
  value = azurerm_private_endpoint.cl_cosmosdb_private_endpoint
}
//**********************************************************************************************
```


## Usage

```terraform
## Deploy Azure Cosmos DB API for MongoDB
resource "azurerm_private_dns_zone" "cosmosdb_private_dns_zone" {
  name                = "privatelink.mongo.cosmos.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "cosmosdb_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-cosmosdb-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_cosmosdb" {
  source   = "../caf-tf-modules/cl_cosmosdb"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_cosmosdb_resource_group_name         = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_cosmosdb_log_analytics_workspace_id  = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_cosmosdb_allowed_subnet = azurerm_subnet.test_subnet.id
  cl_cosmosdb_private_dns_zone_ids = [azurerm_private_dns_zone.cosmosdb_private_dns_zone.id]
  cl_cosmosdb_failover_location    = var.cosmosdb_failover_location
}
```
```terraform
## Deploy Azure Cosmos DB's core
resource "azurerm_private_dns_zone" "cosmosdb_private_dns_zone" {
  name                = "privatelink.documents.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "cosmosdb_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-cosmosdb-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cosmosdb_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_cosmosdb" {
  source                                 = "../tf-azure-component-library/components/cl_cosmosdb"
  env                                    = var.env
  postfix                                = var.postfix
  location                               = var.location
  cl_cosmosdb_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_cosmosdb_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_cosmosdb_allowed_subnet             = azurerm_subnet.private_link_subnet.id
  cl_cosmosdb_private_dns_zone_ids       = var.cosmosdb_private_dns_zone_ids
  cl_cosmosdb_kind                       = "GlobalDocumentDB"
  cl_cosmosdb_capabilities               = ["EnableServerless"]
  tags                                   = var.tags
}
```
# Azure DataFactory Component

Azure Data Factory is the cloud-based ETL and data integration service that allows you to create data-driven workflows for orchestrating data movement and transforming data at scale. 
With Azure Data Factory, users can create and schedule data-driven workflows (pipelines) that can ingest data from multiple data stores. 
It allows to build complex ETL processes that transform data visually with data flows or by using compute services such as Azure HDInsight Hadoop, Azure Databricks, and Azure SQL Database.

This component will deploy DataFactory, Self-Hosted IR, Monitor Diagnostics, Log Analytics and Private Endpoint for allowed Subnets.

For more information, please visit: https://docs.microsoft.com/en-us/azure/data-factory/introduction

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_datafactory_rg_name" {
    description = "(Required) The resource group for the datafactory."
}
variable "cl_datafactory_logging_rg_name" {
    description = "(Required) The resource group for the datafactory log analytics solution."
}
variable "cl_datafactory_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
variable "cl_datafactory_log_analytics_workspace_name" {
    description = "(Required) The the log analytics workspace name for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}

variable "cl_datafactory_public_network_enabled" {
    description = "(Optional) Is the datafactory visible to the public network?"
    default     = false
}

variable "cl_datafactory_managed_virtual_network_enabled" {
    description = "(Optional) Is Managed Virtual Network enabled?"
    default     = false
}

variable "cl_datafactory_nacl_allowed_subnets" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access this datafactory."
    default     = []
}

variable "cl_datafactory_deploy_self_hosted_ir" {
    description = "(Optional) Deploy the self-hosted integration runtime?."
    default     = true
}

variable "cl_datafactory_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}

variable "cl_datafactory_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["ActivityRuns","PipelineRuns","TriggerRuns","SSISPackageEventMessages","SSISPackageExecutableStatistics","SSISPackageEventMessageContext","SSISPackageExecutionComponentPhases","SSISPackageExecutionDataStatistics","SSISIntegrationRuntimeLogs"]
    metrics = ["AllMetrics"]
  }
}

variable "cl_datafactory_log_analytics_solutions" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    datafactoryAnalytics = {
      publisher = "Microsoft"
      product   = "OMSGallery/AzureDataFactoryAnalytics"
    }
  }
}
//Configure Repository
//**********************************************************************************************
variable "cl_datafactory_repository_type" {
  type = string
  description = "(Optional) The Repository Type (vsts, github)"
  default     = ""
}
//GitHub
//**********************************************************************************************
variable "cl_datafactory_github_account_name" {
    description = "(Required) Specifies the GitHub account name"
    default     = "" 
}
variable "cl_datafactory_github_branch_name" {
    description = "(Required) Specifies the branch of the repository to get code from"
    default     = "" 
}
variable "cl_datafactory_github_git_url" {
    description = "(Required) Specifies the GitHub Enterprise host name. For example: https://github.mydomain.com. Use https://github.com for open source repositories"
    default     = "" 
}
variable "cl_datafactory_github_repository_name" {
    description = "(Required) Specifies the name of the git repository"
    default     = "" 
}
variable "cl_datafactory_github_root_folder" {
    description = "(Required) Specifies the root folder within the repository. Set to / for the top level"
    default     = "/"
}

//Vsts
//**********************************************************************************************
variable "cl_datafactory_vsts_account_name" {
    description = "(Required) Specifies the VSTS account name"
    default     = "" 
}
variable "cl_datafactory_vsts_branch_name" {
    description = "(Required) Specifies the branch of the repository to get code from"
    default     = "" 
}
variable "cl_datafactory_vsts_project_name" {
    description = "(Required) Specifies the name of the VSTS project"
    default     = "" 
}
variable "cl_datafactory_vsts_repository_name" {
    description = "(Required) Specifies the name of the git repository"
    default     = "" 
}
variable "cl_datafactory_vsts_root_folder" {
    description = "(Required) Specifies the root folder within the repository. Set to / for the top level."
    default     = "/"
}
variable "cl_datafactory_vsts_tenant_id" {
    description = "(Required) Specifies the Tenant ID associated with the VSTS account"
    default     = "" 
}
//**********************************************************************************************
```

## Outputs

```terraform
output "azure_data_factory" {
    value = azurerm_data_factory.cl_datafactory
}

output "azurerm_data_factory_integration_runtime_self_hosted" {
    value = azurerm_data_factory_integration_runtime_self_hosted.cl_datafactory_integration_runtime
}

output "azurerm_monitor_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_datafactory_diagnostic_setting
}

output "azurerm_log_analytics_solution" {
    value = azurerm_log_analytics_solution.cl_datafactory_log_analytics_solution
}

output "azurerm_private_endpoint_datafactory_dataFactory" {
    value = azurerm_private_endpoint.cl_datafactory_private_endpoint_dataFactory
}

output "azurerm_private_endpoint_datafactory_portal" {
    value = azurerm_private_endpoint.cl_datafactory_private_endpoint_portal
}
```

## Usage

```terraform
resource "azurerm_private_dns_zone" "data_factory_private_dns_zone" {
  name                = var.datafactory_private_dns_zone_name
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "data_factory_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-adf-private-dns-vnet-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.data_factory_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_datafactory" {
    source                                        = "../tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]
}
```
## Usage with VSTS/ADO Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../caf-tf-modules/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]    

    cl_datafactory_repository_type                = "vsts" 
    cl_datafactory_vsts_account_name              = "organization_name"
    cl_datafactory_vsts_branch_name               = "master"
    cl_datafactory_vsts_project_name              = "migration" 
    cl_datafactory_vsts_repository_name           = "migration"
    cl_datafactory_vsts_root_folder               = "/" 
    cl_datafactory_vsts_tenant_id                 = "z567b2579-xxx-457d-a68e-764775adcb646"
}
```
## Usage with GITHUB Repository 
```terraform
module "cl_datafactory" {
    source                                        = "../tf-azure-component-library/components/cl_datafactory"
    env                                           = var.env
    postfix                                       = var.postfix
    location                                      = var.location
    cl_datafactory_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datafactory_logging_rg_name                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
    cl_datafactory_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datafactory_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_datafactory_nacl_allowed_subnets           = [azurerm_subnet.snet1.id, azurerm_subnet.snet2.id, azurerm_subnet.snetN.id]
    cl_datafactory_private_dns_zone_ids           = [azurerm_private_dns_zone.data_factory_private_dns_zone.id]

    cl_datafactory_repository_type                = "github" 
    cl_datafactory_github_account_name            = "organization_name"
    cl_datafactory_github_branch_name             = "master"
    cl_datafactory_github_git_url                 = "https://domaingithub.com/" 
    cl_datafactory_github_repository_name         = "migration"
    cl_datafactory_github_root_folder             = "/" 
}

resource "azurerm_private_dns_a_record" "data_factory_private_dns_record" {
  name                = "${var.env}-${var.postfix}-adf-pe-record"
  zone_name           = azurerm_private_dns_zone.data_factory_private_dns_zone.name
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                 = var.datafactory_private_record_ttl
  records             = module.cl_datafactory.azurerm_private_endpoint_datafactory_dataFactory[*].private_service_connection[0].private_ip_address
  tags                = var.tags
}
```
# Azure Data Bricks Component

Azure Databricks is a cloud-based data engineering tool used for processing and transforming massive quantities of data and exploring the data through machine learning models. 
This component creates an Azure DataBricks workspace and deploys the following for that resource: resource group, virtual network, public & priavte [subnets, NSGs, additional security rules] & diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/databricks/scenarios/what-is-azure-databricks

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_azure_databricks_vnet_rg_name" {
    description = "(Required) The resource group name for networking components of data bricks."
}

variable "cl_azure_databricks_vnet_address_space" {
    description = "(Required) The address space for virtual network of data bricks."
}

variable "cl_azure_databricks_subnet_public_address_prefixes" {
    description = "(Required) The address prefixes for the public subnet of data bricks."
}

variable "cl_azure_databricks_subnet_private_address_prefixes" {
    description = "(Required) The address prefixes for the private subnet of data bricks."
}

variable "cl_azure_databricks_subnet_ssh_source_ip_range" {
    description = "(Required) The source IP range enabled for ssh on public and private subnet."
}

variable "cl_azure_databricks_subnet_proxy_source_ip_range" {
    description = "(Required) The source IP range enabled for proxy on public and private subnet."
}

variable "cl_azure_databricks_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}

variable "cl_azure_databricks_sku" {
    description = "(Optional) The sku to use for the Databricks Workspace. Possible values are standard, premium, or trial. Changing this can force a new resource to be created in some circumstances."
    type = string
    default = "premium"
}

variable "cl_azure_databricks_subnet_public_enforce_network_policies" {
    description = "(Optional) Enable or Disable network policies for the private link endpoint on the public subnet. Conflicts with enforce_private_link_service_network_policies."
    type        = bool
    default     = false    
}

variable "cl_azure_databricks_subnet_public_service_endpoints" {
    description = "(Optional) The list of Service endpoints to associate with the public subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage and Microsoft.Web."
    type        = list(string)
    default     = []    
}

variable "cl_azure_databricks_subnet_private_enforce_network_policies" {
    description = "(Optional) Enable or Disable network policies for the private link endpoint on the private subnet. Conflicts with enforce_private_link_service_network_policies."
    type        = bool
    default     = false    
}

variable "cl_azure_databricks_subnet_private_service_endpoints" {
    description = "(Optional) The list of Service endpoints to associate with the private subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage and Microsoft.Web."
    type        = list(string)
    default     = []    
}

variable "cl_azure_databricks_public_nsg_rules" {
  type = map(object({
    name                          = string
    priority                      = number
    direction                     = string
    access                        = string
    protocol                      = string
    source_port_range             = string
    source_port_ranges            = list(string)
    destination_port_range        = string
    destination_port_ranges       = list(string)    
    source_address_prefix         = string
    source_address_prefixes       = list(string)
    destination_address_prefix    = string
    destination_address_prefixes  = list(string)    
  }))
  description = "(Optional) Define additional NSG rules for app gateway subnet."
  default     = {}
}

variable "cl_azure_databricks_private_nsg_rules" {
  type = map(object({
    name                          = string
    priority                      = number
    direction                     = string
    access                        = string
    protocol                      = string
    source_port_range             = string
    source_port_ranges            = list(string)
    destination_port_range        = string
    destination_port_ranges       = list(string)    
    source_address_prefix         = string
    source_address_prefixes       = list(string)
    destination_address_prefix    = string
    destination_address_prefixes  = list(string)    
  }))
  description = "(Optional) Define additional NSG rules for app gateway subnet."
  default     = {}
}

variable "cl_azure_databricks_managed_rg" {
    description = "(Optional) The name of the resource group where Azure should place the managed Databricks resources. Changing this forces a new resource to be created. If this is not set Azure will create a new RG where all the managed resources will be deployed."
    type        = string
    default     = null
}

variable "cl_azure_databricks_vnet_id" {
    description = "(Optional) The ID of a Virtual Network where this Databricks Cluster should be created."
    type        = string
    default     = null
}

variable "cl_azure_databricks_public_ip" {
    description = "(Optional) Are public IP Addresses not allowed?"
    type        = bool
    default     = true
}

variable "cl_azure_databricks_public_subnet" {
    description = "(Optional) The name of the Public Subnet within the Virtual Network. Required if cl_azure_databricks_vnet_id is set."
    type        = string
    default     = null
}

variable "cl_azure_databricks_private_subnet" {
    description = "(Optional) The name of the Private Subnet within the Virtual Network. Required if cl_azure_databricks_vnet_id is set."
    type        = string
    default     = null
}

variable "cl_azure_databricks_vnet_dns_servers" {
    description = "(Optional) Custom list of dns to be included in the vnet."
    type        = list(string)
    default     = []
}

variable "cl_azure_databricks_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["dbfs", "clusters", "accounts", "jobs", "notebook", "ssh", "workspace", "secrets", "sqlPermissions", "instancePools"]
    metrics = []
  }
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_azure_databricks_rg" {
    value = azurerm_resource_group.cl_azure_databricks_rg
}

output "cl_azure_databricks_vnet" {
    value = azurerm_virtual_network.cl_azure_databricks_vnet
}

output "cl_azure_databricks_public_subnet" {
    value = azurerm_subnet.cl_azure_databricks_public_subnet
}

output "cl_azure_databricks_private_subnet" {
    value = azurerm_subnet.cl_azure_databricks_private_subnet
}

output "cl_azure_databricks_public_nsg" {
    value = azurerm_network_security_group.cl_azure_databricks_public_nsg
}

output "cl_azure_databricks_private_nsg" {
    value = azurerm_network_security_group.cl_azure_databricks_private_nsg
}

output "cl_azure_databricks_public_nsg_rules" {
    value = azurerm_network_security_rule.cl_azure_databricks_public_nsg_rules
}

output "cl_azure_databricks_private_nsg_rules" {
    value = azurerm_network_security_rule.cl_azure_databricks_private_nsg_rules
}

output "cl_azure_databricks" {
    value = azurerm_databricks_workspace.cl_azure_databricks
}
//**********************************************************************************************
```


## Usage

```terraform
// Azure Data Bricks
//**********************************************************************************************
module "cl_azure_databricks" {
  source                                                      = "../caf-tf-modules/cl_azure_databricks"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  cl_azure_databricks_vnet_address_space                      = ["70.0.0.0/16"]
  cl_azure_databricks_subnet_public_address_prefixes          = ["70.0.1.0/24"]
  cl_azure_databricks_subnet_private_address_prefixes         = ["70.0.64.0/24"]
  cl_azure_databricks_log_analytics_workspace_id              = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id //only for premium plan
  cl_azure_databricks_public_nsg_rules = {  
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_azure_databricks_private_nsg_rules = {  
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
}
//**********************************************************************************************
```
# Azure Backup Component

Azure Backup Server is a backup option for both on-premises and cloud-based workloads in Azure storage. 
This resource leverages vaults (recovery service vaults and backup vaults) in order to store data such as backup copies, recovery points, and backup policies. 
This specific component deploys the Backup Service Vault, VM Backup Policy and diagnostics settings for the Azure Backup.

For more information, please visit: https://docs.microsoft.com/en-us/azure/backup/backup-overview 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_azure_backup_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_azure_backup_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["AzureBackupReport","CoreAzureBackup","AddonAzureBackupJobs","AddonAzureBackupAlerts","AddonAzureBackupPolicy","AddonAzureBackupStorage","AddonAzureBackupProtectedInstance","AzureSiteRecoveryJobs","AzureSiteRecoveryEvents","AzureSiteRecoveryReplicatedItems","AzureSiteRecoveryReplicationStats","AzureSiteRecoveryRecoveryPoints","AzureSiteRecoveryReplicationDataUploadRate","AzureSiteRecoveryProtectedDiskDataChurn"]
    metrics = []
  }
} 
variable "cl_azure_backup_timezone" {
  description = "Specifies the timezone for VM backup schedules. Defaults to `UTC`."
  type        = string
  default     = "UTC"
}
variable "cl_azure_backup_time" {
  description = "(Optional) The time of day to perform the backup in 24hour format."
  type        = string
  default     = "23:00"
}
variable "cl_azure_backup_retention_daily_count" {
  description = "(Optional) The number of days Azure Recovery Services will retain the backup for."
  type = number
  default = 10
}
variable "cl_azure_backup_deploy_rsv" {
  description = "If true, deploy rsv."
  default     = false
}
variable "cl_azure_backup_enable_vm_backup" {
  description = "(Optional) Toggle the vm backup feature."
  default     = false
}
variable "cl_azure_backup_enable_file_storage_backup" {
  description = "(Optional) Toggle the file storage backup feature."
  default     = false
}
variable "cl_azure_backup_enable_blob_storage_backup" {
  description = "(Optional) Toggle the blob storage backup feature."
  default     = false
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_azure_backup_rg" {
  value = azurerm_resource_group.cl_azure_backup_rg
}
output "cl_azure_backup_sv" {
  value = azurerm_recovery_services_vault.cl_azure_backup_sv
}
output "cl_azure_backup_policy_vm" {
  value = azurerm_backup_policy_vm.cl_azure_backup_policy_vm
}
output "cl_azure_backup_policy_fileshare" {
  value = azurerm_backup_policy_file_share.cl_azure_backup_policy_fileshare
}
output "cl_azure_backup_blob_sa_backup_vault" {
  value = azurerm_data_protection_backup_vault.cl_azure_backup_blob_sa_backup_vault
}
output "cl_azure_backup_blob_sa_backup_policy" {
  value = azurerm_data_protection_backup_policy_blob_storage.cl_azure_backup_blob_sa_backup_policy
}
output "cl_azure_backup_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_azure_backup_diagnostic_setting
}
//**********************************************************************************************
```


## Usage
# Backups for VMs
```terraform
 // Azure Backup
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../caf-tf-modules/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv       = true
  cl_azure_backup_enable_vm_backup = true
}
//**********************************************************************************************
```

# Backups for File Storage
```terraform
 // Azure Backup
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_deploy_rsv                 = true
  cl_azure_backup_enable_file_storage_backup = true
}
//**********************************************************************************************
```

# Backups for Blob Storage
```terraform
 // Azure Backup
// IMPORTANT: Must assign the blob storage backup vault "Storage Account Backup Contributor" role on the blob storage account. 
 //**********************************************************************************************
 module "cl_azure_backup" {
  source   = "../tf-azure-component-library/components/cl_azure_backup"
  env      = var.env
  postfix  = var.postfix
  location = var.location
  cl_azure_backup_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_backup_enable_blob_storage_backup = true
}
//**********************************************************************************************
```

 
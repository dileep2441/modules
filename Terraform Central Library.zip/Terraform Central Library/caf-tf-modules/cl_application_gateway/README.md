# Azure Application Gateway Component

Azure Application Gateway is a web traffic load balancer that manages traffic to your web applications via application layer load balancing. 
This means creating routing rules for traffic based on the attributes of an HTTP request (ex: URL based routing). 
This specific component deploys an Application Gateway it's associated Public IPs, Route Table, NSGs, Log Analytics and Diagnostics Settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/application-gateway/overview

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_app_gateway_vnet_rg_name" {
  description = "(Required) Resource group where the Core VNet exists."
}
variable "cl_app_gateway_vnet_name" {
  description = "(Required) The name of the vnet which the app gateway subnet will be deployed into."
}
variable "cl_app_gateway_subnet_address_prefix" {
  description = "(Required) The address prefix of the application gateway subnet."
}
variable "cl_app_gateway_resource_group_name" {
  description = "(Required) The name of the resource group where the application gateway will be deployed to."
}
variable "cl_app_gateway_logging_rg_name" {
  description = "(Required) The resource group for the Application Gateway log analytics solution."
}
variable "cl_app_gateway_log_analytics_workspace_id" {
  description = "(Required) The log analytics workspace ID for diagnostics."
}
variable "cl_app_gateway_log_analytics_workspace_name" {
  description = "(Required) The log analytics workspace name for diagnostics."
}
variable "cl_app_gateway_firewall_policy_id" {
  description = "(Required) The ID of the Web Application Firewall Policy."
  type        = string
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}
variable "cl_app_gateway_deploy_subnet" {
  description = "(Optional) A boolean to enable/disable the deployment of a subnet for the VM."
  default     = false
}
variable "cl_app_gateway_subnet_id" {
  description = "(Optional) The subnet ID where the Windows VM will be deployed to. Use this only if cl_app_gateway_deploy_subnet = false."
  default     = null
}
variable "cl_app_gateway_subnet_prefix" {
  description = "(Optional) The address prefix of the application gateway existing subnet."
  default     = null
}
variable "cl_app_gateway_deploy_subnet_nsg" {
  description = "(Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM."
  default     = false
}
variable "cl_app_gateway_subnet_service_endpoints" {
  description = "(Optional) A list of service endpoints that is enabled in the subnet"
  default     = []
}
variable "cl_app_gateway_frontend_tls_cert" {
  description = "(Optional) The name of the ssl cert file in pfx format that exists in the same folder that TF plan/apply is executed on. The file must not be base64 encrypted."
  default     = ""
}
variable "cl_app_gateway_frontend_tls_cert_pass" {
  description = "(Optional) The password for the front end ssl cert file"
  default     = ""
}
variable "cl_app_gateway_frontend_tls_cert_keyvault_id" {
  description = "(Optional) Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in Azure KeyVault."
  default     = null
}
variable "cl_app_gateway_identity_ids" {
  type        = list(string)
  description = "(Optional) Specifies a list with a single user managed identity id to be assigned to the Application Gateway"
  default     = []
}
variable "cl_app_gateway_firewall_mode" {
  description = "(Optional) Resource group where the Core VNet exists."
  default     = "Detection"
}
variable "set_private_ip_listener" {
  description = "(Optional) A boolean variable indicating which environment the app gateway is being deployed into."
  default     = false
}
variable "cl_app_gateway_public_ip_allocation_method" {
  description = "(Optional) The allocation method for this IP address. Possible values are Static or Dynamic."
  default     = "Static"
}
variable "cl_app_gateway_public_ip_sku" {
  description = "(Optional) The SKU of the Public IP. Accepted values are Basic and Standard"
  default     = "Standard"
}
variable "cl_app_gateway_domain_name_label" {
  description = " (Optional) Label for the Domain Name. Will be used to make up the FQDN. If a domain name label is specified, an A DNS record is created for the public IP in the Microsoft Azure DNS system."
  type        = string
  default     = null
}
variable "cl_app_gateway_reverse_fqdn" {
  description = "(Optional) A fully qualified domain name that resolves to this public IP address"
  default     = null
}
variable "cl_app_gateway_min_capacity" {
  description = "(Optional) The minimum number of app gateway units for autoscaling"
  default     = 1
}
variable "cl_app_gateway_max_capacity" {
  description = "(Optional) The minimum number of app gateway units for autoscaling"
  default     = 5
}
variable "cl_app_gateway_backend_address" {
  description = "(Optional) The backend ip or fqdns address from the address pool"
  type        = list
  default     = null
}
variable "cl_app_gateway_pick_host_name" {
  description = "(Optional) True/false to pick a host from backend pool or overwrite the host name."
  type        = bool
  default     = true
}
variable "cl_app_gateway_pick_host_backend" {
  description = "(Optional) True/false to pick the host from the backend configuration"
  type        = bool
  default     = true
}
variable "cl_app_gateway_backend_host_name" {
  description = "(Optional) Host header to be sent to the backend servers. Cannot be set if pick_host_name_from_backend_address is set to true"
  default     = null
}
variable "cl_app_gateway_subnet_hostnum" {
  description = "(Optional) The hostnumber from the subnet prefix for the private IP."
  default     = 15
}
//SSL Policy
variable "cl_app_gateway_ssl_policy_type" {
  description = "(Optional) The Type from SSL Policy"
  default     = "Predefined"
}
variable "cl_app_gateway_ssl_policy_name" {
  description = "(Optional) The Name from SSL Policy"
  default     = "AppGwSslPolicy20170401S"
}
variable "cl_app_gateway_ssl_policy_protocol_version" {
  description = "(Optional) The Minimun Protocol Version from SSL Policy"
  default     = "TLSv1_2"
}
variable "cl_app_gateway_probe_name" {
  description = "(Optional) The probe name from Health probes"
  default     = "https-probe"
}
variable "cl_app_gateway_probe_host" {
  description = "(Optional) The site url from the Health probes"
  type        = string
  default     = null
}
variable "cl_app_gateway_probe_path" {
  description = "(Optional) The probe path from the Health probes"
  default     = "/"
}
variable "cl_app_gateway_probe_interval" {
  description = "(Optional) The probe interval from the Health probes"
  default     = 10
}
variable "cl_app_gateway_probe_timeout" {
  description = "(Optional) The timeout from the Health probes"
  default     = 30
}
variable "cl_app_gateway_probe_unhealthy_threshold" {
  description = "(Optional) The unhealthy threshold from the Health probes"
  default     = 3
}
variable "cl_app_gateway_probe_protocol" {
  description = "(Optional) The probe protocol from the Health probes"
  default     = "Https"
}
variable "cl_app_gateway_nsg_rules" {
  type = map(object({
    name                         = string
    priority                     = number
    direction                    = string
    access                       = string
    protocol                     = string
    source_port_range            = string
    source_port_ranges           = list(string)
    destination_port_range       = string
    destination_port_ranges      = list(string)
    source_address_prefix        = string
    source_address_prefixes      = list(string)
    destination_address_prefix   = string
    destination_address_prefixes = list(string)
  }))
  description = "(Optional) Define additional NSG rules for app gateway subnet."
  default     = {}
}
variable "cl_app_gateway_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["ApplicationGatewayAccessLog", "ApplicationGatewayPerformanceLog", "ApplicationGatewayFirewallLog"]
    metrics = ["AllMetrics"]
  }
}
variable "cl_app_gateway_log_analytics_solutions" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    AzureAppGatewayAnalytics = {
      publisher = "Microsoft"
      product   = "OMSGallery/AzureAppGatewayAnalytics"
    }
  }
}
variable "cl_app_gateway_http_listener_hostname" {
  description = "(Optional) The Hostname which should be used for this HTTP Listener. Setting this value changes Listener Type to Multi site"
  default     = null
}
variable "cl_app_gateway_https_listener_hostname" {
  description = "(Optional) The Hostname which should be used for this HTTPS Listener. Setting this value changes Listener Type to Multi site"
  default     = null
}
variable "cl_app_gateway_disable_bgp_route_propagation" {
  description = "(Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable"
  default     = true
}
variable "cl_app_gateway_http_settings_timeout" {
  description = "(Optional) The timeout for HTTP response."
  type        = number
  default     = 600
}
variable "cl_app_gateway_additional_http_listener" {
  type = map(object({
    name                 = string
    protocol             = string
    host_name            = string
    frontend_port_name   = string
    ssl_certificate_name = string
  }))
  description = "(Optional) Array for additional HTTP listeners."
  default     = {}
}
variable "cl_app_gateway_additional_http_settings" {
  type = map(object({
    name                                = string
    request_timeout                     = number
    probe_name                          = string
    host_name                           = string
    pick_host_name_from_backend_address = bool
  }))
  description = "(Optional) Array for additional HTTP settings."
  default     = {}
}
variable "cl_app_gateway_additional_probes" {
  type = map(object({
    name                = string
    host                = string
    path                = string
    interval            = number
    timeout             = number
    unhealthy_threshold = number
    protocol            = string
  }))
  description = "(Optional) Array for additional health probes."
  default     = {}
}
variable "cl_app_gateway_additional_route_rules" {
  type = map(object({
    name                        = string
    rule_type                   = string
    http_listener_name          = string
    backend_address_pool        = string
    backend_http_settings_name  = string
    redirect_configuration_name = string
  }))
  description = "(Optional) Array for additional routing rules."
  default     = {}
}
variable "cl_app_gateway_additional_backend_address_pool" {
  type = map(object({
    name  = string
    fqdns = list(string)
  }))
  description = "(Optional) Array for additional backend address pool."
  default     = {}
}
variable "cl_app_gateway_additional_redirect_configurations" {
  type = map(object({
    name                 = string
    redirect_type        = string
    target_listener_name = string
  }))
  description = "(Optional) Array for additional redirect configurations."
  default     = {}
}
variable "cl_app_gateway_additional_ssl_certificate" {
  type = map(object({
    name                = string
    data                = string
    password            = string
    key_vault_secret_id = string
  }))
  description = "(Optional) Array for additional ssl certificates."
  default     = {}
}
variable "cl_app_gateway_rewrite_rules" {
  type = list(object({
    name            = string
    rule_sequence   = number
    conditions = list(object({
      variable    = string
      pattern     = string
      ignore_case = bool
      negate      = bool
    }))
    request_header_configurations = list(object({
      header_name   = string
      header_value  = string
    }))
    response_header_configurations = list(object({
      header_name   = string
      header_value  = string
    }))  
    urls  = list(object({
      path          = string
      query_string  = string
      reroute       = string
    }))         
  }))
  description = "(Optional) Array for rewrite rules."
  default     = []
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
  timeout_duration      = "2h"
  cl_app_gateway_subnet = var.cl_app_gateway_deploy_subnet ? azurerm_subnet.cl_app_gateway_subnet[0] : null
  cl_app_gateway        = var.set_private_ip_listener ? azurerm_application_gateway.cl_app_gateway_peninsula[0] : azurerm_application_gateway.cl_app_gateway_island[0]

  # IP configurations
  gateway_ip_configuration_name          = "gw-ip-conf"
  frontend_ip_configuration_name_private = "private-ip"
  frontend_ip_configuration_name_public  = "public-ip"

  # Frontend configurations
  frontend_port_http_name  = "frontend-port-80"
  frontend_port_http       = 80
  frontend_port_https_name = "frontend-port-443"
  frontend_port_https      = 443


  # Listener configurations
  https_listener_peninsula = {
    name                           = "https-listener-private"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_private
    frontend_port_name             = local.frontend_port_https_name
    protocol                       = "Https"
    ssl_certificate_name           = "frontend_ssl_cert"
  }
  http_listener_peninsula = {
    name                           = "http-listener-private"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_private
    frontend_port_name             = local.frontend_port_http_name
    protocol                       = "Http"
  }
  https_listener_island = {
    name                           = "https-listener-public"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_public
    frontend_port_name             = local.frontend_port_https_name
    protocol                       = "Https"
    ssl_certificate_name           = "frontend_ssl_cert"
  }
  http_listener_island = {
    name                           = "http-listener-public"
    frontend_ip_configuration_name = local.frontend_ip_configuration_name_public
    frontend_port_name             = local.frontend_port_http_name
    protocol                       = "Http"
  }
  ssl_certificate_name = "frontend_ssl_cert"

  redirect_configuration_peninsula = {
    name                 = "http-to-https-redirect-private"
    redirect_type        = "Permanent"
    target_listener_name = local.https_listener_peninsula.name
  }

  redirect_configuration_island = {
    name                 = "http-to-https-redirect-public"
    redirect_type        = "Permanent"
    target_listener_name = local.https_listener_island.name
  }

  # Backend  configurations
  backend_address_pool_name = "backend-address-pool"

  backend_http_settings = {
    name                  = "backend-https-settings"
    cookie_based_affinity = "Disabled"
    port                  = 443
    protocol              = "Https"
  }

  # Routing rules configurations
  request_routing_rule_peninsula_http_to_https = {
    name                        = "http-to-https-rule-private"
    rule_type                   = "Basic"
    http_listener_name          = local.http_listener_peninsula.name
    redirect_configuration_name = local.redirect_configuration_peninsula.name
  }
  request_routing_rule_peninsula_https = {
    name                       = "backend-https-rule-private"
    rule_type                  = "Basic"
    http_listener_name         = local.https_listener_peninsula.name
    backend_address_pool_name  = local.backend_address_pool_name
    backend_http_settings_name = local.backend_http_settings.name
  }
  request_routing_rule_island_http_to_https = {
    name                        = "http-to-https-rule-public"
    rule_type                   = "Basic"
    http_listener_name          = local.http_listener_island.name
    redirect_configuration_name = local.redirect_configuration_island.name
  }
  request_routing_rule_island_https = {
    name                       = "backend-https-rule-public"
    rule_type                  = "Basic"
    http_listener_name         = local.https_listener_island.name
    backend_address_pool_name  = local.backend_address_pool_name
    backend_http_settings_name = local.backend_http_settings.name
  }
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_app_gateway_subnet" {
  value = local.cl_app_gateway_subnet
}
output "cl_app_gateway_nsg" {
  value = azurerm_network_security_group.cl_app_gateway_nsg
}
output "cl_app_gateway_route_table" {
  value = azurerm_route_table.cl_app_gateway_route_table
}
output "cl_app_gateway_rt_default_route" {
  value = azurerm_route.cl_app_gateway_rt_default_route
}
output "cl_app_gateway_rt_associate_subnet" {
  value = azurerm_subnet_route_table_association.cl_app_gateway_rt_associate_subnet
}
output "cl_app_gateway_public_ip" {
  value = azurerm_public_ip.cl_app_gateway_public_ip
}
output "cl_app_gateway" {
  value = local.cl_app_gateway
}
output "cl_app_gateway_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_app_gateway_diagnostic_setting
}
output "cl_app_gateway_log_analytics_solution" {
  value = azurerm_log_analytics_solution.cl_app_gateway_log_analytics_solution
}
//**********************************************************************************************
```


## Notes

You will need to store a base64 certificate and cert password in jenkins credentials used by JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX and JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS variables.
Some modifications on JenkinsFile will be required to import this Credentials variables.

The powershell command converts your pfx certificate file to base64 format:
```powershell
$fileContentBytes = get-content '<yourcertificate.pfx>' -Encoding Byte [System.Convert]::ToBase64String($fileContentBytes) | Out-File 'certbase64.txt'
```

## Usage

1. Deploy Application Gateway with an existing Web Application Firewall Polcies

```terraform
module "cl_app_gateway" {
  source                                      = "../tf-azure-component-library/components/cl_application_gateway"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  set_private_ip_listener                     = <true/false>
  cl_app_gateway_firewall_policy_id           = confirm with a cloudops the ID of the Web Application Firewall Policy in order to associate the application gateway
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["70.0.0.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS
  cl_app_gateway_nsg_rules = {
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_app_gateway_additional_probes = {
    portal_health_probe = {
      name                = "apim-portal-probe"
      host                = "portal.azisapinp.amr.xoriant.com"
      path                = "/internal-status-0123456789abcdef"
      interval            = 30
      timeout             = 300
      unhealthy_threshold = 8
      protocol            = "Https" 
    }
  }
  cl_app_gateway_additional_backend_address_pool = {
    kauth_backend_address_pool = {
      name  = "kauth-backend-address-pool"
      fqdns = [module.cl_app_service_app_k_auth.cl_app_service.default_site_hostname]
    }           
  }
  cl_app_gateway_additional_http_settings = {
    kauth_http_settings = {
      name                                = "kauth-https-settings"
      request_timeout                     = 180
      probe_name                          = "https-probe"
      pick_host_name_from_backend_address = true
      host_name                           = null 
    }   
  }
  cl_app_gateway_additional_http_listener = {
    kauth_http_listener = {
      name                  = "kauth-http-listener-public"
      protocol              = "Http"
      host_name             = "kauth.dev.taxdigital.xoriant.com.br"
      frontend_port_name    = "frontend-port-80"
      ssl_certificate_name  = null      
    }       
  }
  cl_app_gateway_additional_route_rules = {
    kauth_http_to_https_route_rule = {
      name                        = "kauth-http-to-https-rule-public"
      rule_type                   = "Basic"
      backend_address_pool        = null
      http_listener_name          = "kauth-http-listener-public"
      backend_http_settings_name  = null
      redirect_configuration_name = "kauth-http-to-https-redirect"
    } 
  }
  cl_app_gateway_additional_redirect_configurations = {
    kauth_http_settings = {
      name                  = "kauth-http-to-https-redirect"
      redirect_type         = "Permanent"
      target_listener_name  = "kauth-https-listener-public"
    }    
  }
  cl_app_gateway_rewrite_rules = [
    {
        name = "test",
        rule_sequence = 100,
        conditions = [
          {
            variable    = "HTTP header"
            pattern     = "(https?):VV.*azurewebsites\.net(.*)$"
            ignore_case = false
            negate      = false
          }
        ],
        request_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        response_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        urls  = [
          {
            path          = "/article.aspx"
            query_string  = "id={var_uri_path_1}"
            reroute       = "/page.aspx"
          }
        ]
    }
]       
}

```

2. Deploy Application Gateway with a new Web Application Firewall Polcies

```terraform
resource "azurerm_web_application_firewall_policy" "web_application_firewall_policy" {
  name                = "${var.env}-${var.postfix}-wafpolicy"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  location            = var.location

    custom_rules {
    name      = "DenyAccess"
    priority  = 1
    rule_type = "MatchRule"

    match_conditions {
      match_variables {
        variable_name = "RemoteAddr"
      }

      operator           = "GeoMatch"
      negation_condition = false
      match_values       = ["RU","BY"]
    }

    action = "Block"
  }

    policy_settings {
    enabled                     = true
    mode                        = "Detection"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.1"
    }
  }
}

module "cl_app_gateway" {
  source                                      = "../caf-tf-modules/cl_application_gateway"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  set_private_ip_listener                     = <true/false>
  cl_app_gateway_firewall_policy_id           = azurerm_web_application_firewall_policy.web_application_firewall_policy.id
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["70.0.0.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFX
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASS
  cl_app_gateway_nsg_rules = {
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }
  }
  cl_app_gateway_additional_probes = {
    portal_health_probe = {
      name                = "apim-portal-probe"
      host                = "portal.azisapinp.amr.xoriant.com"
      path                = "/internal-status-0123456789abcdef"
      interval            = 30
      timeout             = 300
      unhealthy_threshold = 8
      protocol            = "Https" 
    }
  }
  cl_app_gateway_additional_backend_address_pool = {
    kauth_backend_address_pool = {
      name  = "kauth-backend-address-pool"
      fqdns = [module.cl_app_service_app_k_auth.cl_app_service.default_site_hostname]
    }           
  }
  cl_app_gateway_additional_http_settings = {
    kauth_http_settings = {
      name                                = "kauth-https-settings"
      request_timeout                     = 180
      probe_name                          = "https-probe"
      pick_host_name_from_backend_address = true
      host_name                           = null 
    }   
  }
  cl_app_gateway_additional_http_listener = {
    kauth_http_listener = {
      name                  = "kauth-http-listener-public"
      protocol              = "Http"
      host_name             = "kauth.dev.taxdigital.xoriant.com.br"
      frontend_port_name    = "frontend-port-80"
      ssl_certificate_name  = null      
    }       
  }
  cl_app_gateway_additional_route_rules = {
    kauth_http_to_https_route_rule = {
      name                        = "kauth-http-to-https-rule-public"
      rule_type                   = "Basic"
      backend_address_pool        = null
      http_listener_name          = "kauth-http-listener-public"
      backend_http_settings_name  = null
      redirect_configuration_name = "kauth-http-to-https-redirect"
    } 
  }
  cl_app_gateway_additional_redirect_configurations = {
    kauth_http_settings = {
      name                  = "kauth-http-to-https-redirect"
      redirect_type         = "Permanent"
      target_listener_name  = "kauth-https-listener-public"
    }    
  }
  cl_app_gateway_rewrite_rules = [
    {
        name = "test",
        rule_sequence = 100,
        conditions = [
          {
            variable    = "HTTP header"
            pattern     = "(https?):VV.*azurewebsites\.net(.*)$"
            ignore_case = false
            negate      = false
          }
        ],
        request_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        response_header_configurations = [
            {
                header_name = "Authorization"
                header_value = "foo"
            }
        ],
        urls  = [
          {
            path          = "/article.aspx"
            query_string  = "id={var_uri_path_1}"
            reroute       = "/page.aspx"
          }
        ]
    }
]       
}
```

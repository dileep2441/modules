# Azure Bastion Component

Azure Bastion allows to RDP/SSH into a virtual machine without the need for a public IP on the VM (thus enforces secure access). 
This component will create an Azure Bastion and deploy the following for that resource: NSG, NSG inbound & outbound rules, additional security rules and diagnostic settings.

For more information, please visit:  https://docs.microsoft.com/en-us/azure/bastion/bastion-overview

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_azure_bastion_vnet_name" {
  description = "(Required) The name of the core vnet required for the azure bastion subnet."
}
variable "cl_azure_bastion_vnet_rg_name" {
  description = "(Required) The name of the core vnet resource group name."
}
variable "cl_azure_bastion_subnet_prefix" {
  description = "(Required) The prefix of the azure bastion subnet."
}
variable "cl_azure_bastion_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
variable "cl_azure_bastion_centralized_enable" {
  description = "(Required) Enable the creation of a centralized bastion"
  type        = bool
  default     = false
}
variable "cl_azure_bastion_enable" {
  description = "(Required) Enable the creation for azure bastion"
  type        = bool
  default     = true
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}
variable "cl_azure_bastion_subnet_service_endpoints" {
  description = "(Optional) A list of service endpoints that is enabled in the subnet"
  default     = []
}
variable "cl_azure_bastion_nsg_rules" {
  type = map(object({
    name                         = string
    priority                     = number
    direction                    = string
    access                       = string
    protocol                     = string
    source_port_range            = string
    source_port_ranges           = list(string)
    destination_port_range       = string
    destination_port_ranges      = list(string)
    source_address_prefix        = string
    source_address_prefixes      = list(string)
    destination_address_prefix   = string
    destination_address_prefixes = list(string)
  }))
  description = "(Optional) Define additional NSG rules for bastion subnet."
  default     = {}
}
variable "cl_azure_bastion_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["BastionAuditLogs"]
    metrics = []
  }
}
variable "cl_azure_bastion_scale_units" {
  description = "(Optional) The number of scale units with which to provision the Bastion Host. Possible values are between 2 and 50. Defaults to 2."
  type = string
  default = "2"
}
variable "cl_azure_bastion_sku" {
  description = "(Optional) The SKU of the Bastion Host. Accepted values are Basic and Standard. Defaults to Basic."
  type = string
  default = "Basic"
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h"
  cl_azure_bastion_sku = var.cl_azure_bastion_centralized_enable ? "Standard" : "Basic" 
  az_bastion_public_ip_diagnotics_settingss = {
    logs    = ["DDoSProtectionNotifications", "DDoSMitigationFlowLogs", "DDoSMitigationReports"]
    metrics = ["AllMetrics"]
  }
}
//*****************************************************************************************************************************************************************************************
```

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_azure_bastion_rg" {
  value = azurerm_resource_group.cl_azure_bastion_rg
}
output "cl_azure_bastion_subnet" {
  value = azurerm_subnet.cl_azure_bastion_subnet
}
output "cl_azure_bastion_pip" {
  value = azurerm_public_ip.cl_azure_bastion_pip
}
output "cl_azure_bastion_host" {
  value = azurerm_bastion_host.cl_azure_bastion_host
}
output "cl_azure_bastion_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_azure_bastion_diagnostic_setting
}
output "cl_azure_bastion_nsg" {
  value = azurerm_network_security_group.cl_azure_bastion_nsg
}
output "cl_azure_bastion_nsgrule_AllowHttpsInbound" {
  value = azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowHttpsInbound
}
output "cl_azure_bastion_nsgrule_AllowGatewayManagerInbound" {
  value = azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowGatewayManagerInbound
}
output "cl_azure_bastion_nsgrule_AllowAzureLoadBalancerInbound" {
  value = azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowAzureLoadBalancerInbound
}
output "cl_azure_bastion_nsgrule_AllowSshRdpOutbound" {
  value = azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowSshRdpOutbound
}
output "cl_azure_bastion_nsgrule_AllowAzureCloudOutbound" {
  value = azurerm_network_security_rule.cl_azure_bastion_nsgrule_AllowAzureCloudOutbound
}
//**********************************************************************************************
```


## Usage

```terraform
// Azure Bastion
//**********************************************************************************************
module "cl_azure_bastion" {
  source                        = "../caf-tf-modules/cl_azure_bastion"
  env                           = var.env
  postfix                       = var.postfix
  location                      = var.location
  cl_azure_bastion_vnet_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_azure_bastion_vnet_rg_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_azure_bastion_enable       = true
  cl_azure_bastion_centralized_enable = false 
  cl_azure_bastion_subnet_prefix = ["55.0.2.0/24"]
  cl_azure_bastion_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_bastion_nsg_rules     = {
  allow_xoriant_inbound = {
    name                          = "allow-xoriant-inbound"
    priority                      = 1003
    direction                     = "Inbound"
    access                        = "Allow"
    protocol                      = "*"
    source_port_range             = null
    source_port_ranges            = ["80","8531","443","8530"]
    destination_port_range        = "*"    
    destination_port_ranges       = null
    source_address_prefix         = "10.1.1.22/24"
    source_address_prefixes       = null
    destination_address_prefix    = "10.69.2.96/27"
    destination_address_prefixes  = null
  }  
}
//**********************************************************************************************

// Azure Bastion Centralized
//**********************************************************************************************
module "sharedsvcs_azure_bastion" {
  source                        = "../tf-azure-component-library/components/cl_azure_bastion"
  env                           = var.env
  postfix                       = var.postfix
  location                      = var.location
  cl_azure_bastion_enable       = true
  cl_azure_bastion_centralized_enable = true
  cl_azure_bastion_vnet_name    = azurerm_virtual_network.sharedsvcs_vnet.name
  cl_azure_bastion_vnet_rg_name = azurerm_resource_group.sharedsvcs_rg_network.name
  cl_azure_bastion_subnet_prefix = var.sharedsvcs_bastion_sub_address_prefix
  cl_azure_bastion_log_analytics_workspace_id = azurerm_log_analytics_workspace.sharedsvcs_log_analytics_workspace.id
}
//**********************************************************************************************
```
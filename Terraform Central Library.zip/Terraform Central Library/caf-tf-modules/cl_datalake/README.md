# Azure Data Lake Component

Azure Data Lake Storage is an enterprise-wide hyper-scale repository for big data analytic workloads. 
It enables you to capture data of any size, type, and ingestion speed in one single place for operational and exploratory analytics.
This component will deploy a ADLS, private endpoint, azure diagnostics, and configures the storage account with Azure Defender.

For more information, please visit: https://docs.microsoft.com/en-us/azure/data-lake-store/data-lake-store-overview 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_datalake_resource_group_name" {
    description = "(Required) The name of the resource group where the data lake will be deployed to."
}
variable "cl_datalake_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_datalake_allowed_pe_subnet_ids" {
  description = "(Optional) A list of subnets to create a private endpoint that can access the data lake storage account."
  type        = list(string)
  default     = []
}
variable "cl_datalake_allowed_vnet_subnet_ids" {
  description = "(Optional) A list of Subnets of the vnet that can access the data lake storage account though a vnet rule."
  type        = list(string)
  default     = []
}
variable "cl_datalake_tier" {
    description = "(Optional) The pricing tier for the data lake storage account."
    default     = "Standard"
}
variable "cl_datalake_replication_type" {
    description = "(Optional) Defines the type of replication to use for the data lake storage account."
    default     = "LRS"
}
variable "cl_datalake_access_tier" {
    description = "(Optional) Defines the type of access tier to use for the data lake storage account."
    default = "Hot"
}
variable "cl_datalake_account_kind" {
    description = "(Optional) Defines the kind of storage account to deploy."
    default     = "StorageV2"
}
variable "cl_datalake_min_tls_version" {
    description = "(Optional) Defines the minimum TLS version to use for the data lake storage account."
    default = "TLS1_2"
}
variable "cl_datalake_blob_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 365
}
variable "cl_datalake_container_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 7
}
variable "cl_datalake_allowed_ips" {
  description = "(Optional) A list of Ip addresses that can access the data lake storage account. It is recommended that you add your automation tool's IP range here."
  type        = list
  default     = []
}
variable "cl_datalake_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
variable "cl_datalake_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
variable "cl_datalake_file_share_enabled" {
  description = "If set to true, enable file shares"
  type        = bool
  default     = false
}
variable "cl_datalake_sa_file_shares" {
  type = map(object({
    name  = string
    quota  = number 
  }))
  description = "(Optional) Array for the creation of multiple file shares."
  default     = {}
}
variable "cl_datalake_sa_file_enable_backup" {
  description = "If set to true, enable file storage backup."
  type        = bool
  default     = false
}
variable "cl_datalake_sa_recovery_vault_name" {
  description = "(Optional) The name of backup recovery service vault."
  default     = null
}
variable "cl_datalake_sa_backup_policy_fileshare_id" {
  description = "(Optional) The azure file share backup policy from the recovery service vault."
  default     = null
}
variable "cl_datalake_sa_rg_backup_name" {
  description = "(Optional) The RG destination of the azure file share backup."
  default     = null
}
//**********************************************************************************************
```
## Outputs
```terraform
// Outputs
//**********************************************************************************************
output "cl_datalake" {
    value = azurerm_storage_account.cl_datalake
}
output "cl_datalake_network_rules" {
    value = azurerm_storage_account_network_rules.cl_datalake_network_rules
}
output "cl_datalake_filesystem" {
    value = azurerm_storage_data_lake_gen2_filesystem.cl_datalake_filesystem
}
output "cl_datalake_private_endpoint" {
    value = azurerm_private_endpoint.cl_datalake_private_endpoint
}
output "cl_datalake_diagnostic_settings" {
    value = azurerm_monitor_diagnostic_setting.cl_datalake_diagnostic_settings
}
output "cl_datalake_sa_files" {
    value = azurerm_storage_share.cl_datalake_sa_files
}
output "cl_datalake_sa_protection_container" {
    value = azurerm_backup_container_storage_account.cl_datalake_sa_protection_container
}
output "cl_datalake_sa_protected_fileshare" {
    value = azurerm_backup_protected_file_share.cl_datalake_sa_protected_fileshare
}
output "cl_datalake_sa_file_share_private_endpoint" {
    value = azurerm_private_endpoint.cl_datalake_sa_file_share_private_endpoint
}
//**********************************************************************************************
```
## Usage with Private Endpoints (file share backup enabled)

```terraform
resource "azurerm_private_dns_zone" "adls_private_dns_zone" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "adls_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-adls-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.adls_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_datalake" {
    source                                 = "../caf-tf-modules/cl_datalake"
    env                                    = var.env
    postfix                                = var.postfix
    location                               = var.location
    cl_datalake_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datalake_allowed_pe_subnet_ids      = [azurerm_subnet.test_subnet.id]
    cl_datalake_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datalake_private_dns_zone_ids       = [azurerm_private_dns_zone.adls_private_dns_zone.id]
    cl_datalake_file_share_enabled              = true
    cl_datalake_sa_file_shares                  = var.cl_datalake_sa_file_shares
    cl_datalake_sa_file_enable_backup           = true
    cl_datalake_sa_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_datalake_sa_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_datalake_sa_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
}

resource "azurerm_private_dns_a_record" "adls_private_dns_record" {
  name                 = "${var.env}-${var.postfix}-adls-pe-record"
  zone_name            = azurerm_private_dns_zone.adls_private_dns_zone.name
  resource_group_name  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                  = var.adls_private_record_ttl
  records              = module.cl_datalake.cl_datalake_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                 = var.tags
}
```

## Usage with Subnet Connection (file share backup enabled)

```terraform
resource "azurerm_private_dns_zone" "adls_private_dns_zone" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "adls_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-adls-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.adls_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_datalake" {
    source                                 = "../tf-azure-component-library/components/cl_datalake"
    env                                    = var.env
    postfix                                = var.postfix
    location                               = var.location
    cl_datalake_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_datalake_allowed_vnet_subnet_ids    = [azurerm_subnet.test_subnet.id]
    cl_datalake_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_datalake_private_dns_zone_ids       = [azurerm_private_dns_zone.adls_private_dns_zone.id]
    cl_datalake_file_share_enabled              = true
    cl_datalake_sa_file_shares                  = var.cl_datalake_sa_file_shares
    cl_datalake_sa_file_enable_backup           = true
    cl_datalake_sa_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_datalake_sa_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_datalake_sa_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
}

resource "azurerm_private_dns_a_record" "adls_private_dns_record" {
  name                 = "${var.env}-${var.postfix}-adls-pe-record"
  zone_name            = azurerm_private_dns_zone.adls_private_dns_zone.name
  resource_group_name  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                  = var.adls_private_record_ttl
  records              = module.cl_datalake.cl_datalake_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                 = var.tags
}
```
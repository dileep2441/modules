# Azure logic App Component

(Azure Logic App is a serverless workflow service that enables the user to run event-triggered code without having to provision or manage infrastructure.)
This component will deploy an Azure Logic App. It will also deploy a storage account, private endpoints, and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/logic-apps/logic-apps-overview


## Inputs
```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}

//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_logic_app_postfix" {
    description = "(Required) The bespoke name of the app you are deploying."
}
variable "cl_logic_app_rg_name" {
    description = "(Required) The resource group to deploy the logic app into."
}
variable "cl_logic_app_storage_account_rg_name" {
    description = "(Required) The resource group to deploy the storage account needed for the logic app."
}
variable "cl_logic_app_asp_id" {
    description = "(Required) App Service Plan ID used by the logic app."
}
variable "cl_logic_app_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
variable "cl_logic_app_integration_subnet_id" {
    description = "(Required) The ID of the integration subnet the logic app will be associated to (the subnet must have a service_delegation configured for Microsoft.Web/serverFarms)."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}
variable "cl_logic_app_storage_account_tier" {
  description = "(Optional) The pricing tier for the storage account for the logic app audit and security logging."
  default     = "Standard"
}
variable "cl_logic_app_storage_account_kind" {
  description = "(Optional)  Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2."
  default     = "StorageV2"
}
variable "cl_logic_app_storage_account_replication_type" {
  description = "(Optional) Defines the type of replication to use for the storage account for the logic app audit and security logging."
  default     = "LRS"
}
variable "cl_logic_app_storage_account_blob_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 360
}
variable "cl_logic_app_storage_account_container_retention_days" {
  description = "Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7`"
  default     = 7
  type        = number
}
variable "cl_logic_app_storage_account_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
variable "cl_logic_app_https_only" {
    description = "(Optional) Booolean to toggle if the logic app can only be accessed via HTTPS."
    default     = true
}
variable "cl_logic_app_ftps_state" {
    description = "(Optional) State of FTP / FTPS service for this logic app. Possible values include: AllAllowed, FtpsOnly and Disabled."
    default     = "Disabled"
}
variable "cl_logic_app_always_on" {
    description = "(Optional) Should the app be loaded at all times?"
    default     = false
}
variable "cl_logic_app_min_tls_version" {
    description = "(Optional) The minimum supported TLS version for the logic app."
    default     = "1.2"
}
variable "cl_logic_app_http2_enabled" {
    description = "(Optional) Is HTTP2 Enabled on this logic app?"
    default     = false
}
variable "cl_logic_app_use_32_bit_worker_process" {
    description = "(Optional) Should the logic app run in 32 bit mode, rather than 64 bit mode?"
    default     = true
}
variable "cl_logic_app_auth_settings_enabled" {
    description = "(Optional) Enable or disable Authentication Settings"
    default     = "true"
}
variable "cl_logic_app_settings" {
    description = "(Optional) Variables passed as environment variables"
    type        = map
    default     = {}
}
variable "cl_logic_app_os_type" {
    type        = string
    description = "(Optional) The logic app os type. Enter 'linux' for Linux and leave null for Windows. For linux, you will need to set cl_app_service_plan_reserved to true and cl_app_service_plan_kind to logicApp in the app service plan component."
    default     = null
}
variable "cl_logic_app_version" {
    type        = string
    description = "(Optional) The runtime version associated with the logic App. Defaults to ~1"
    default     = "~1"
}
variable "cl_logic_app_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default     = {
        logs    = ["FunctionAppLogs"]
        metrics = ["AllMetrics"]
    }
}
variable "cl_logic_app_pe_subnet_ids" {
    description = "(Optional) A list of subnet IDs the app service will create a private endpoint in."
    default     = []
}
variable "cl_logic_app_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string)
  default     = []
}
variable "cl_logic_app_identity_type" {
  description = "Add an Identity (MSI) to the logic app. Possible values are SystemAssigned or UserAssigned"
  type        = string
  default     = "SystemAssigned"
}
variable "cl_logic_app_identity_ids" {
  description = "UserAssigned Identities ID to add to logic App. Mandatory if type is UserAssigned"
  type        = list(string)
  default     = null
}
variable "cl_logic_app_sa_allowed_vnet_subnet_ids" {
  description = "(Optional) A list of Subnets of the vnet that can access the fcn app storage account."
  type        = list(string)
  default     = []
}
variable "cl_logic_app_sa_allowed_ips" {
  description = "(Optional) A list of Ip addresses that can access the fcn app storage account. It is recommended that you add your automation tool's IP range here."
  type        = list
  default     = []
}
//**********************************************************************************************

// Optional - Azure Blob Storage Backup
//**********************************************************************************************
variable "cl_logic_app_storage_account_enable_backup" {
  description = "(Optional) Toggle the blob storage backup feature."
  default     = false
}
variable "cl_logic_app_storage_account_backup_vault_id" {
   description = "The id of blob storage backup vault."
   default     = null
}
variable "cl_logic_app_storage_account_backup_vault" {
   description = "The blob storage backup vault."
   default     = null
}
variable "cl_logic_app_storage_account_backup_policy_id" {
   description = "The azure blob storage backup policy id from the backup vault."
   default     = null
}
//**********************************************************************************************

// Local Variables
//**********************************************************************************************
locals {
    timeout_duration = "2h"
    cl_storage_account_blob_properties           = (var.cl_logic_app_storage_account_enable_backup ? false : true)
    cl_logic_app_storage_account_infra_encryption_enabled = (var.cl_logic_app_storage_account_kind == "StorageV2" || var.cl_logic_app_storage_account_kind == "BlockBlobStorage" && var.cl_logic_app_storage_account_tier == "Premium" ? true : false)
    cl_logic_app_storage_account_modify_name = {
        "sbox-pr" = "sboxpr"
        "nprd-pr" = "nprdpr"
        "nprd-dr" = "nprddr"
        "prod-pr" = "prodpr"
        "prod-dr" = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
//**********************************************************************************************

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_logic_app_storage_account" {
    value = azurerm_storage_account.cl_logic_app_storage_account
}
output "cl_logic_app" {
    value = azurerm_logic_app_standard.cl_logic_app
}
output "cl_logic_app_private_endpoint"{
    value = azurerm_private_endpoint.cl_logic_app_private_endpoint
}
output "cl_logic_app_storage_account_protected_blob" {
     value = azurerm_data_protection_backup_instance_blob_storage.cl_logic_app_storage_account_protected_blob
}
//**********************************************************************************************
```

## Usage
#### Linux logic App (logic app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../caf-tf-modules/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_deploy_rg                             = false
  cl_app_service_plan_rg_name                               = azurerm_resource_group.cl_logic_app_rg.name
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.0/27"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_sku_size                              = var.app_service_plan_sku_size
  cl_app_service_plan_sku_tier                              = var.app_service_plan_sku_tier
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "logic_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "logic_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.logic_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_logic_app" {
  depends_on                                      = [module.cl_app_service_plan, azurerm_resource_group.cl_logic_app_rg]
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_logic_app"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_logic_app_postfix                            = "lgcapp"
  cl_logic_app_rg_name                            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_storage_account_rg_name            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_asp_id                             = module.cl_app_service_plan.cl_app_service_plan.id
  cl_logic_app_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_logic_app_os_type                            = "linux"
  cl_logic_app_version                            = "~3"
  cl_logic_app_pe_subnet_ids                      = [azurerm_subnet.test_subnet.id]
  #cl_app_service_private_dns_zone_ids            = azurerm_private_dns_zone.logic_app_private_dns_zone.id
  cl_logic_app_integration_subnet_id              = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  # cl_logic_app_allowed_vnet_subnet_ids          = var.cl_logic_app_allowed_vnet_subnet_ids
  # cl_logic_app_allowed_ips                      = var.cl_logic_app_allowed_ips
  cl_logic_app_sa_allowed_vnet_subnet_ids         = [module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id]
  cl_logic_app_storage_account_enable_backup      = false
  cl_logic_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_logic_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_logic_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```
#### Windows logic App (logic app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../dn-tads_tf-azure-gov_component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  }
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "logic_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.us"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "logic_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.logic_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_logic_app" {
  depends_on                                      = [module.cl_app_service_plan, azurerm_resource_group.cl_logic_app_rg]
  source                                          = "../dn-tads_tf-azure-component-library/components/cl_logic_app"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_logic_app_postfix                            = "lgcapp"
  cl_logic_app_rg_name                            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_storage_account_rg_name            = azurerm_resource_group.cl_logic_app_rg.name
  cl_logic_app_asp_id                             = module.cl_app_service_plan.cl_app_service_plan.id
  cl_logic_app_log_analytics_workspace_id         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_logic_app_pe_subnet_ids                      = [azurerm_subnet.test_subnet.id]
  #cl_app_service_private_dns_zone_ids            = azurerm_private_dns_zone.logic_app_private_dns_zone.id
  cl_logic_app_integration_subnet_id              = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  # cl_logic_app_allowed_vnet_subnet_ids          = var.cl_logic_app_allowed_vnet_subnet_ids
  # cl_logic_app_allowed_ips                      = var.cl_logic_app_allowed_ips
  cl_logic_app_sa_allowed_vnet_subnet_ids         = [module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id]
  cl_logic_app_storage_account_enable_backup      = false
  cl_logic_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_logic_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_logic_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```


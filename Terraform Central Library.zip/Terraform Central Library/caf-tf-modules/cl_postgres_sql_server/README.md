# Postgresql Server Component

Azure Database for PostgreSQL Single Server is a fully managed database service. 
This server platform is designed to handle most of the database management functions such as patching, backups, high availability, security with minimal user configuration and control. 
This component will deploy Azure Postgresql Server, private endpoint and diagnostic settings for the server.

For more information, please visit: https://docs.microsoft.com/en-us/azure/postgresql/overview 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}


// PostgreSQL Vars
// Required Variables
//**********************************************************************************************
variable "cl_postgres_sql_server_admin_login" {
  type          = string
  description   = "(Required) Login to authenticate to PostgreSQL Server"
}
variable "cl_postgres_sql_server_admin_password" {
  type          = string
  description   = "(Required) Password to authenticate to PostgreSQL Server"
}
variable "cl_postgres_sql_server_log_analytics_workspace_id" {
    description = "(Required) The ID for the network resources"
}
variable "cl_postgres_sql_server_resource_group_name" {
    description = "(Required) Specifies the Azure SQL Server resource group"
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_postgres_sql_server_pe_subnet_ids" {
    description = "(Required) The subnet ids where the private endoint will be created."
    default     = []    
}
variable "cl_postgres_sql_server_version" {
  type        = string
  description = "PostgreSQL Server version to deploy"
  default     = "11"
}
variable "cl_postgres_sql_server_sku_name" {
  type        = string
  description = "PostgreSQL SKU Name"
  default     = "GP_Gen5_4"
}
variable "cl_postgres_sql_server_storage" {
  type        = string
  description = "PostgreSQL Storage in MB"
  default     = "10240"
}
variable "cl_postgres_sql_server_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["PostgreSQLLogs"]
    metrics = ["AllMetrics"]
  }
} 
variable cl_postgres_sql_server_auto_grow_enabled { 
  description = "(Optional) Enable grow database as needed."
  type        = bool
  default     = false 
}
variable cl_postgres_sql_server_backup_retention_days { 
  description = "(Optional) Number of backup retention days."
  type        = number
  default     = 21
}
variable cl_postgres_sql_server_geo_redundant_backup_enabled { 
  description = "(Optional) Enable or disable georedundant backup."
  type        = bool
  default     = false  
}
variable cl_postgres_sql_server_public_network_access_enabled { 
  description = "(Optional) Enable or disable access from public network."
  type        = bool
  default     = false
}
variable cl_postgres_sql_server_ssl_enforcement_enabled { 
  description = "(Optional) Enable or disable ssl."
  type        = bool
  default     = true
}
variable cl_postgres_sql_server_ssl_minimal_tls_version_enforced { 
  description = "(Optional) Minimun version of TLS."
  type        = string
  default     = "TLS1_2"
}
variable "cl_postgres_sql_server_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}

//**********************************************************************************************
```

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_postgres_sql_server" {
  value = azurerm_postgresql_server.cl_postgres_sql_server
}

output "cl_postgres_sql_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_postgres_sql_diagnostic_setting
}
```

## Usage

```terraform
// Deploy Postgres Server
//**********************************************************************************************
module "cl_postgres_sql_server" {
  source                                                      = "../caf-tf-modules/cl_postgres_sql_server"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  cl_postgres_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_postgres_sql_server_admin_login                          = "adminsql"
  cl_postgres_sql_server_admin_password                       = "Abc1234567890."
  cl_postgres_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_postgres_sql_server_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_postgres_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.cl_azure_private_dns_zone_db.id]
}
//**********************************************************************************************


// Deploy Azure DNS Private Zone for db.
// This allows to connect to the DB via dns name.
// **********************************************************************************************
resource "azurerm_private_dns_zone" "cl_azure_private_dns_zone_db" {
  name                = "privatelink.postgres.database.azure.com"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}
//**********************************************************************************************

// Link DB DNS zone to Virtual Network
// ************************************************************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "cl_linkdnstosubnet_db" {
  name                  = "linkdb"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.cl_azure_private_dns_zone_db.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}
//**********************************************************************************************

// Deploy Subnet for private endpoints
//**********************************************************************************************
resource "azurerm_subnet" "cl_private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                   = ["60.0.3.0/24"]
  enforce_private_link_endpoint_network_policies     = true
}
//**********************************************************************************************
```
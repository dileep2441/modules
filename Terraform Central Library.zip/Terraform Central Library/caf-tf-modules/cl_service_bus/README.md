# Azure Service Bus Component

Azure Service Bus is a messaging service on cloud used to connect any applications, devices, and services running in the cloud to any other applications or services. 
As a result, it acts as a messaging backbone for applications available in the cloud or across any devices.
This component will deploy Azure Service Bus, Athoritation rules, Monitor Diagnostics, Monitor Autoscale, Network Security and Private Endpoint for allowed Subnets.

Service Bus comes in Basic, standard, and premium tiers. with the following table you can select the value of the sku variable that you require:

FEATURE				            BASIC		    STANDARD	    PREMIUM
Queues					        Available	    Available	    Available
Scheduled messages			    Available	    Available	    Available
Topics					        Not available	Available	    Available
Transactions				    Not available	Available	    Available
De-duplication				    Not available	Available	    Available
Sessions				        Not available	Available	    Available
ForwardTo/SendVia			    Not available	Available	    Available
Message Size				    256 KB		    256 KB		    1 MB
Resource isolation			    Not available	Not available	Available
Geo-Disaster Recovery (Geo-DR)	Not available	Not available	Available							
Availability Zones (AZ) support	Not available	Not available	Available

For more information, please information: https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-messaging-overview

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "The cloud region where resources will be deployed into."
}
//*******************************************************************************************

// Required Variables
//*******************************************************************************************
variable "cl_service_bus_rg_name"{
    description = "Name of resource name"
    type = string

variable "cl_service_bus_logging_rg_name" {
    description = "(Required) The resource group for the service bus log analytics solution."
}
variable "cl_service_bus_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
variable "cl_service_bus_log_analytics_workspace_name" {
    description = "(Required) The the log analytics workspace name for diagnostics."
}

//*******************************************************************************************
// Optional Variables
//*******************************************************************************************
 variable "cl_service_bus_namespace_sku" { 
   description = "Defines which tier to use. Options are basic, standard or premium" 
   default     = "Premium" 
 } 
 
  variable "cl_service_bus_namespace_capacity" { 
   description = "Specifies the capacity. When sku is Premium, capacity can be 1, 2, 4 or 8. When sku is Basic or Standard, capacity can be 0 only" 
   default     = 2 
 } 

 variable "cl_service_bus_zone_redundant" { 
   description = "Whether or not this resource is zone redundant. sku needs to be Premium. Defaults to false." 
   default     = false 
 } 
 variable "tags" { 
   description = "(Optional) A mapping of tags to assign to the resource" 
   type        = map(string) 
   default     = {} 
 } 

variable "cl_service_bus_allowed_subnets" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access this service bus."
    default     = []
}

variable "cl_service_bus_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default     = {
        logs    = ["OperationalLogs"]
        metrics = ["AllMetrics"]
    }
}

variable "cl_service_bus_autoscale_settings_default" {
    description = "(Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 1 and 8."
    default     = 1
}

variable "cl_service_bus_autoscale_settings_minimum" {
    description = "(Optional) The minimum number of instances for this resource. Valid values are between 1 and 8."
    default     = 1
}

variable "cl_service_bus_autoscale_settings_maximum" {
    description = "(Optional) The maximum number of instances for this resource. Valid values are between 1 and 8."
    default     = 2
}

variable "cl_service_bus_autoscale_settings_metric_name" {
    description = "(Optional) The name of the metric that defines what the rule monitors."
    default     = "NamespaceCpuUsage"
}

variable "cl_service_bus_autoscale_settings_metric_name_memory" {
    description = "(Optional) The name of the metric that defines what the rule monitors."
    default     = "NamespaceMemoryUsage"
}

variable "cl_service_bus_autoscale_settings_time_grain" {
    description = "(Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string."
    default     = "PT1M"
}

variable "cl_service_bus_autoscale_settings_statistic" {
    description = "(Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max."
    default     = "Average"
}

variable "cl_service_bus_autoscale_settings_time_window" {
    description = "(Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string."
    default     = "PT5M"
}

variable "cl_service_bus_autoscale_settings_time_aggregation" {
    description = "(Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total."
    default     = "Average"
}

variable "cl_service_bus_autoscale_settings_scale_out_operator" {
    description = "(Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual."
    default     = "GreaterThan"
}

variable "cl_service_bus_autoscale_settings_scale_out_threshold" {
    description = "(Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action."
    default     = 75
}

variable "cl_service_bus_autoscale_settings_scale_in_operator" {
    description = "(Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual."
    default     = "LessThan"
}

variable "cl_service_bus_autoscale_settings_scale_in_threshold" {
    description = "(Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action."
    default     = 25
}

variable "cl_service_bus_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
//*******************************************************************************************

## Outputs

```terraform
// Outputs Service Bus
//**********************************************************************************************
output "cl_service_bus" {
    description = "Azure service Bus output"
    value = azurerm_servicebus_namespace.cl_service_bus
}
output "azurerm_monitor_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_service_bus_diagnostic_setting
}
output "azurerm_private_endpoint" {
    value = azurerm_private_endpoint.cl_service_bus_private_endpoint_service_bus
}
output "cl_service_bus_namespace_rule" {
    value = azurerm_servicebus_namespace_authorization_rule.cl_service_bus_namespace_rule
}
output "cl_app_service_plan_autoscale_settings" {
    value = azurerm_monitor_autoscale_setting.cl_service_bus_autoscale_settings
}
//**********************************************************************************************

## Usage

```terraform
resource "azurerm_private_dns_zone" "service_bus_private_dns_zone" {
  name                = "privatelink.servicebus.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "service_bus_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.service_bus_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_service_bus" {
    source = "../caf-tf-modules/cl_service_bus"
    env                                            = var.env
    postfix                                        = var.postfix
    location                                       = var.location
    cl_service_bus_rg_name                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_service_bus_log_analytics_workspace_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_service_bus_log_analytics_workspace_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
    cl_service_bus_allowed_subnets                = [azurerm_subnet.test_subnet1.id, azurerm_subnet.test_subnet2.id, azurerm_subnet.test_subnet3.id]
    cl_service_bus_private_dns_zone_ids           = [azurerm_private_dns_zone.service_bus_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "service_bus_private_dns_record" {
  name                                         = "${var.env}-${var.postfix}-app-service-int-pe-record"
  zone_name                                    = azurerm_private_dns_zone.service_bus_private_dns_zone.name
  resource_group_name                          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                                          = var.service_bus_private_record_ttl
  records                                      = module.cl_app_service.cl_service_bus_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                                         = var.tags
}
```

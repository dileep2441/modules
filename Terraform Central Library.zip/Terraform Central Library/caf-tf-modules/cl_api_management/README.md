# Azure API Management Component

Azure API Management is a fully managed service that enables customers to publish, secure, transform, maintain, and monitor APIs. 
It can be leveraged as a "front-door" through which external and internal applications can access data or business logic that is running in Azure or on-premises.
This component will create an Azure API Management service and deploy the following resources for it: Subnet, route table, NSG, Inbound and Outbound NSG rules, custom domain & diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/api-management/api-management-key-concepts 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_api_mgmt_rg_name" {
  description = "(Required) The name of the resource group where the api management will be deployed to."
}
variable "cl_api_mgmt_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
variable "cl_api_mgmt_publisher_name" {
  description = " (Required) The name of publisher/company."
  type        = string
}
variable "cl_api_mgmt_publisher_email" {
  description = " (Required) The email of publisher/company."
  type        = string
}
variable "cl_api_mgmt_subnet_vnet_name" {
  description = "(Required) The name of the core vnet required for the Api mgmt subnet."
}
variable "cl_api_mgmt_subnet_prefix" {
  description = "(Required) The prefix of the api mgmt subnet."
}
variable "cl_api_mgmt_subnet_vnet_rg_name" {
  description =  "(Required) The name of the resource group that the core vnet is in"
}
variable "cl_api_mgmt_route_table" {
  type        = string
  description = "(Required) The route_table id allowed to connect to this API Mgmt."
}
variable "cl_api_mgmt_inbound_cidrs" {
  type          = list(string)
  description = "(Required) A list of CIDRs to allow to communicate with API Management."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}
variable "cl_api_mgmt_sku_name" {
  description = " (Optional) sku_name is a string consisting of two parts separated by an underscore(_)"
  type        = string
  default     = "Developer_1"
}
variable "cl_api_mgmt_subnet_service_enpoints" {
  description = "(Optional) The service endpoints for the api mgmt subnet."
  type        = list(string)
  default     = []
}
variable "cl_api_mgmt_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
variable "cl_api_mgmt_identity_type" {
    description = "(Optional) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned"
    type        = string
    default     = "SystemAssigned"
}
variable "cl_api_mgmt_identity_identity_ids" {
    description = "(Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned."
    type        = list(string)
    default     = null
}
variable "cl_api_mgmt_deploy_custom_domain" {
    description = "(Optional) Specifies if custom domain for API management should be deployed or not."
    type        = bool
    default     = false
}
variable "cl_api_mgmt_proxies" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    default_ssl_binding           = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management proxy deployment."
  default     = {}
}
variable "cl_api_mgmt_developer_portals" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management developer portal deployment."
  default     = {}
}
variable "cl_api_mgmt_managements" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management managements deployment."
  default     = {}
}
variable "cl_api_mgmt_portals" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management portals deployment."
  default     = {}
}
variable "cl_api_mgmt_scms" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management SCM deployment."
  default     = {}
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_api_mgmt" {
  value = azurerm_api_management.cl_api_mgmt
}
output "cl_api_mgmt_subnet" {
  value = azurerm_subnet.cl_api_mgmt_subnet
}
output "cl_api_mgmt_subnet_nsg" {
  value = azurerm_network_security_group.cl_api_mgmt_subnet_nsg
}
output "cl_api_mgmt_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_api_mgmt_diagnostic_setting
}
//**********************************************************************************************
```


## Usage

```terraform
// Azure API Management
//**********************************************************************************************
 module "cl_api_mgmt" {
  source                                    = "../caf-tf-modules/cl_api_mgmt"
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  cl_api_mgmt_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_api_mgmt_log_analytics_workspace_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_api_mgmt_route_table                   = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_api_mgmt_subnet_vnet_rg_name           = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name 
  cl_api_mgmt_subnet_vnet_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_api_mgmt_subnet_prefix                 = ["55.0.3.0/24"]
  cl_api_mgmt_publisher_name                = "My-Company-xoriant"
  cl_api_mgmt_publisher_email               = "company@terraform.io"
  cl_api_mgmt_inbound_cidrs                 = ["199.206.0.0/15"]
  cl_api_mgmt_proxies                       = {
    api_mgmt_proxy = {
      host_name                     = "api.ati.xoriant.com.br"
      certificate                   = var.APP_GW_TLS_CERT_PFX_BASE64
      certificate_password          = var.APP_GW_TLS_CERT_PASS
      negotiate_client_certificate  = false
      default_ssl_binding           = false
      key_vault_id                  = null 
    }
  }
  cl_api_mgmt_developer_portals             = {
    api_mgmt_proxy = {
      host_name                     = "portal.ati.xoriant.com.br"
      certificate                   = var.APP_GW_TLS_CERT_PFX_BASE64
      certificate_password          = var.APP_GW_TLS_CERT_PASS
      negotiate_client_certificate  = false
      key_vault_id                  = null 
    }
  }  
}
//**********************************************************************************************
```
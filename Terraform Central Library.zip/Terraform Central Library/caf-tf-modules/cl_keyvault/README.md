# Azure Key Vault Component

Azure Key Vault is a cloud service for securely storing and accessing secrets. 
Key Vault service supports two types of containers: vaults and managed hardware security module (HSM) pools. 
Vaults support storing software and HSM-backed keys, secrets, and certificates. Managed HSM pools only support HSM-backed keys. 
This component will deploy Azure Key Vault, Private Endpoint and diagnostics settings for the Key Vault.

For more information, please visit: https://docs.microsoft.com/en-us/azure/key-vault/general/basic-concepts

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
variable "tenant_id" {
    description = "(Required) The tenant ID that the resources will reside in."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_keyvault_rg_name" {
    description = "(Required) The resource group for the keyvault."
}
variable "cl_keyvault_logging_rg_name" {
    description = "(Required) The resource group for the keyvault log analytics solution."
}
variable "cl_keyvault_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
variable "cl_keyvault_log_analytics_workspace_name" {
    description = "(Required) The the log analytics workspace name for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_keyvault_sku_name" {
    description = "(Optional) The Name of the SKU used for Key Vault"
    type        = string
    default     = "standard"
}
variable "cl_keyvault_enabled_for_deployment" {
    type        = bool
    description = "(Optional) Boolean to enable vms to be able to fetch from keyvault."
    default     = true
}
variable "cl_keyvault_enabled_for_disk_encryption" {
    type        = bool
    description = "(Optional) Boolean to enable vms to use keyvault certificates for disk encryption."
    default     = true
}
variable "cl_keyvault_enabled_for_template_deployment" {
    type        = bool
    description = "(Optional) Boolean to enable azure resource manager deployments to be able to fetch from keyvault."
    default     = false
}
variable "cl_keyvault_soft_delete_enabled" {
    description = "(Optional) When soft-delete is enabled, resources marked as deleted resources are retained for a specified period (90 days by default)."
    type        = bool
    default     = true
}
variable "cl_keyvault_purge_protection_enabled" {
    type        = bool
    description = "(Optional) When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed."
    default     = true
}
variable "cl_keyvault_nacl_default_action" {
    description = "(Optional) The Default Action to use when no rules match from ip_rules / virtual_network_subnet_ids."
    type        = string
    default     = "Deny"
}
variable "cl_keyvault_az_svcs_bypass" {
    type        = string
    description = "(Optional) Specifies which traffic can bypass the network rules."
    default     = "AzureServices"
}
variable "cl_keyvault_nacl_allowed_ips" {
    type        = list(string)
    description = "(Optional)  One or more IP Addresses, or CIDR Blocks which should be able to access the Key Vault."
    default     = []
}
variable "cl_keyvault_nacl_allowed_subnets" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access this Key Vault."
    default     = []
}
variable "cl_keyvault_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
variable "cl_keyvault_allowed_pe_subnet_ids" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access through a private endpoint to this Key Vault."
    default     = []
}
variable "cl_keyvault_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["AuditEvent"]
    metrics = ["AllMetrics"]
  }
}
variable "cl_keyvault_log_analytics_solutions" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    KeyVaultAnalytics = {
      publisher = "Microsoft"
      product   = "OMSGallery/KeyVaultAnalytics"
    }
  }
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_keyvault" {
  value = azurerm_key_vault.cl_keyvault
}
output "cl_keyvault_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_keyvault_diagnostic_setting
}
output "cl_keyvault_log_analytics_solution" {
  value = azurerm_log_analytics_solution.cl_keyvault_log_analytics_solution
}
output "cl_keyvault_private_endpoint" {
  value = azurerm_private_endpoint.cl_keyvault_private_endpoint
}
//**********************************************************************************************
```


## Usage

```terraform
module "cl_keyvault" {
  source                                   = "../caf-tf-modules/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_keyvault_private_dns_zone_ids         = [var.private_dns_zone_id]
  cl_keyvault_nacl_allowed_subnets         = [azurerm_subnet.test_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
}
```
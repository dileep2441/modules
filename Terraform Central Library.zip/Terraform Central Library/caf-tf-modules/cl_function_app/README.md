# Azure Function App Component

A function app lets you group Azure functions as a logical unit for easier management, deployment, scaling, and sharing of resources. 
(Azure Function is a serverless compute service that enables user to run event-triggered code without having to provision or manage infrastructure.)
This component will deploy an Azure Function App resource in either Windows or Linux flavors. It will also deploy a storage account, private endpoints, and diagnostic settings.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-functions/functions-overview

## Inputs
```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_function_app_postfix" {
    description = "(Required) The bespoke name of the app you are deploying."
}
variable "cl_function_app_rg_name" {
    description = "(Required) The resource group to deploy the function app into."
}
variable "cl_function_app_storage_account_rg_name" {
    description = "(Required) The resource group to deploy the storage account needed for the function app."
}
variable "cl_function_app_asp_id" {
    description = "(Required) App Service Plan ID used by the function app."
}
variable "cl_function_app_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
variable "cl_function_app_integration_subnet_id" {
    description = "(Required) The ID of the integration subnet the function app will be associated to (the subnet must have a service_delegation configured for Microsoft.Web/serverFarms)."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}
variable "cl_function_app_storage_account_tier" {
  description = "(Optional) The pricing tier for the storage account for the function app audit and security logging."
  default     = "Standard"
}
variable "cl_function_app_storage_account_replication_type" {
  description = "(Optional) Defines the type of replication to use for the storage account for the function app audit and security logging."
  default     = "LRS"
}
variable "cl_function_app_storage_account_blob_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 365
}
variable "cl_function_app_storage_account_container_retention_days" {
  description = "Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7`"
  default     = 7
  type        = number
}
variable "cl_function_app_storage_account_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["StorageRead","StorageWrite","StorageDelete"] 
    metrics = ["Transaction"]
  }
}
variable "cl_function_app_https_only" {
    description = "(Optional) Booolean to toggle if the function app can only be accessed via HTTPS."
    default     = true
}
variable "cl_function_app_client_affinity_enabled" {
    description = "(Optional) Should the function app send session affinity cookies, which route client requests in the same session to the same instance?"
    default     = false
}
variable "cl_function_app_ftps_state" {
    description = "(Optional) State of FTP / FTPS service for this function app. Possible values include: AllAllowed, FtpsOnly and Disabled."
    default     = "Disabled"
}
variable "cl_function_app_always_on" {
    description = "(Optional) Should the app be loaded at all times?"
    default     = false
}
variable "cl_function_app_min_tls_version" {
    description = "(Optional) The minimum supported TLS version for the function app."
    default     = "1.2"
}
variable "cl_function_app_http2_enabled" {
    description = "(Optional) Is HTTP2 Enabled on this function app?"
    default     = false
}
variable "cl_function_app_use_32_bit_worker_process" {
    description = "(Optional) Should the function app run in 32 bit mode, rather than 64 bit mode?"
    default     = true
}
variable "cl_function_app_auth_settings_enabled" {
    description = "(Optional) Enable or disable Authentication Settings"
    default     = "true"
}
variable "cl_function_app_auth_settings_default_provider"{
    description = "(Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter."
    default     = null
}
variable "cl_function_app_auth_settings_unauthenticated_client_action" {
    description = " (Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage."
    default     = null
}
variable "cl_function_app_auth_settings_aad_client_id" {
    description = "(Optional) The Client ID of this relying party application. Enables OpenIDConnection authentication with Azure Active Directory."
    default     = null 
}
variable "cl_function_app_auth_settings_aad_client_secret" {
    description = "(Optional) The Client Secret of this relying party application. If no secret is provided, implicit flow will be used."
    default     = null
}
variable "cl_function_app_auth_settings_aad_allowed_audiences" {
    description = "(Optional) Allowed audience values to consider when validating JWTs issued by Azure Active Directory."
    default     = null  
}
variable "cl_function_app_settings" {
    description = "(Optional) Variables passed as environment variables"
    type        = map
    default     = {}
}
variable "cl_function_app_os_type" {
    type        = string
    description = "(Optional) The function app os type. Enter 'linux' for Linux and leave null for Windows. For linux, you will need to set cl_app_service_plan_reserved to true and cl_app_service_plan_kind to FunctionApp in the app service plan component."
    default     = null
}
variable "cl_function_app_version" {
    type        = string
    description = "(Optional) The runtime version associated with the Function App. Defaults to ~1"
    default     = "~1"
}
variable "cl_function_app_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default     = {
        logs    = ["FunctionAppLogs"]
        metrics = ["AllMetrics"]
    }
}
variable "cl_function_app_pe_subnet_ids" {
    description = "(Optional) A list of subnet IDs the app service will create a private endpoint in."
    default     = []
}
variable "cl_function_app_private_dns_zone_ids" {
    description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
    type        = list(string) 
    default     = []  
}
variable "cl_function_app_identity_type" {
    description = "Add an Identity (MSI) to the function app. Possible values are SystemAssigned or UserAssigned"
    type        = string
    default     = null
}
variable "cl_function_app_identity_ids" {
    description = "UserAssigned Identities ID to add to Function App. Mandatory if type is UserAssigned"
    type        = list(string)
    default     = null
}
variable "cl_function_app_storage_account_network_default_action" {
    description = "(Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow."
    type        = string
    default     = "Deny"
}
variable "cl_function_app_storage_account_ip_rules" {
    description = "(Optional) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed."
    type        = list(string)
    default     = []
}
variable "cl_function_app_storage_account_subnet_ids" {
    description = "(Optional) A list of resource ids for subnets."
    type        = list(string)
    default     = []
}
variable "cl_function_app_storage_account_bypass" {
    description = "(Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None."
    type        = list(string)
    default     = ["None"]
}
variable "cl_function_app_storage_account_pe_subnet_ids" {
    description = "(Optional) A list of subnet IDs the app service will create a private endpoint in."
    default     = []
}
variable "cl_function_app_storage_account_private_dns_zone_ids" {
    description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
    type        = list(string) 
    default     = []
}
variable "cl_function_app_client_cert_mode" {
    description = "(Optional) The mode of the Function App's client certificates requirement for incoming requests.  Possible values are Required and Optional."
    type = string
    default = "Optional"
}
variable "cl_function_app_dotnet_framework_version" {
    description = "(Optional) The version of the .net framework's CLR used in this function app. Possible values are v4.0 (including .NET Core 2.1 and 3.1), v5.0 and v6.0. Defaults to v4.0."
    type        = string
    default     = "v4.0"
}
// Blob Storage Backup
variable "cl_function_app_storage_account_enable_backup" {
  description = "(Optional) Toggle the blob storage backup feature."
  default     = false
}
variable "cl_function_app_storage_account_backup_vault_id" {
   description = "The id of blob storage backup vault."
   default     = null
}
variable "cl_function_app_storage_account_backup_vault" {
   description = "The blob storage backup vault."
   default     = null
}
variable "cl_function_app_storage_account_backup_policy_id" {
   description = "The azure blob storage backup policy id from the backup vault."
   default     = null
}
//**********************************************************************************************

// Local Variables
//**********************************************************************************************
locals {
    timeout_duration = "2h"
    cl_storage_account_blob_properties           = (var.cl_function_app_storage_account_enable_backup ? false : true)
    cl_function_app_storage_account_modify_name = {
        "sbox-pr"  = "sboxpr"
        "nprd-pr"  = "nprdpr"
        "nprd-dr"  = "nprddr"
        "prod-pr"  = "prodpr" 
        "prod-dr"  = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
//**********************************************************************************************
```

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_function_app_storage_account" {
    value = azurerm_storage_account.cl_function_app_storage_account
}
output "cl_function_app" {
    value = azurerm_function_app.cl_function_app
}
output "cl_funtion_app_private_endpoint"{
    value = azurerm_private_endpoint.cl_function_app_private_endpoint
}
output "cl_function_app_storage_account_private_endpoint"{
    value = azurerm_private_endpoint.cl_function_app_storage_account_private_endpoint
}
output "cl_function_app_storage_account_protected_blob" {
     value = azurerm_data_protection_backup_instance_blob_storage.cl_function_app_storage_account_protected_blob
}
//**********************************************************************************************
```

## Usage
#### Linux Function App (function app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../caf-tf-modules/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  } 
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "function_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "function_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.function_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_function_app" {
  source                                     = "../tf-azure-component-library/components/cl_function_app"
  env                                        = var.env
  postfix                                    = var.postfix
  location                                   = var.location
  cl_function_app_postfix                    = "testapp"
  cl_function_app_rg_name                    = module.cl_app_service_plan.cl_app_service_plan_rg
  cl_function_app_storage_account_rg_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_function_app_asp_id                     = module.cl_app_service_plan.cl_app_service_plan.id
  cl_function_app_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_function_app_os_type                    = "linux"
  cl_function_app_version                    = "~3"
  cl_app_service_private_dns_zone_ids        = [azurerm_private_dns_zone.function_app_private_dns_zone.id]
  cl_function_app_integration_subnet_id      = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  cl_function_app_storage_account_enable_backup      = true
  cl_function_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_function_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_function_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```
#### Windows Function App (function app SA backup enabled)
```terraform
module "cl_app_service_plan" {
  source                                                    = "../tf-azure-component-library/components/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  } 
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "function_app_private_dns_zone" {
  name                = "privatelink.azurewebsites.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "function_app_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.function_app_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_function_app" {
  source                                     = "../tf-azure-component-library/components/cl_function_app"
  env                                        = var.env
  postfix                                    = var.postfix
  location                                   = var.location
  cl_function_app_postfix                    = "testapp"
  cl_function_app_rg_name                    = module.cl_app_service_plan.cl_app_service_plan_rg
  cl_function_app_storage_account_rg_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_function_app_asp_id                     = module.cl_app_service_plan.cl_app_service_plan.id
  cl_function_app_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_function_app_pe_subnet_ids              = [azurerm_subnet.test_subnet.id]
  cl_function_app_private_dns_zone_ids       = [azurerm_private_dns_zone.function_app_private_dns_zone.id] //cl_app_service_private_dns_zone_ids 
  cl_function_app_integration_subnet_id      = module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id
  cl_function_app_storage_account_enable_backup      = true
  cl_function_app_storage_account_backup_vault_id    = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_function_app_storage_account_backup_vault       = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_function_app_storage_account_backup_policy_id   = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}

resource "azurerm_private_dns_a_record" "function_app_private_dns_record" {
  name                                         = "${var.env}-${var.postfix}-app-service-int-pe-record"
  zone_name                                    = azurerm_private_dns_zone.function_app_private_dns_zone.name
  resource_group_name                          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                                          = var.function_app_private_record_ttl
  records                                      = module.cl_function_app.cl_function_app_private_endpoint[*].private_service_connection[0].private_ip_address
  tags                                         = var.tags
}
```

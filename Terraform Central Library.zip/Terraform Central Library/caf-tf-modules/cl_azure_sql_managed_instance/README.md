# Azure SQL Managed Instance Component

Azure SQL Managed Instance is the intelligent, scalable cloud database service that combines the broadest SQL Server database engine compatibility with all the benefits of a fully managed and evergreen platform as a service. SQL Managed Instance has near 100% compatibility with the latest SQL Server (Enterprise Edition) database engine, providing a native virtual network (VNet) implementation that addresses common security concerns, and a business model favorable for existing SQL Server customers. SQL Managed Instance allows existing SQL Server customers to lift and shift their on-premises applications to the cloud with minimal application and database changes. At the same time, SQL Managed Instance preserves all PaaS capabilities (automatic patching and version updates, automated backups, high availability) that drastically reduce management overhead and TCO.

For more information, please visit: 
docs.microsoft.com/en-us/azure/azure-sql/managed-instance/sql-managed-instance-paas-overview


## Inputs
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables for SQL Managed Instance
//**********************************************************************************************
variable "cl_azure_sql_managed_instance_administrator" {
  description = "(Required) The administrator login name for the new server. Changing this forces a new resource to be created"
}
variable "cl_azure_sql_managed_instance_password" {
  description = "(Required) The password associated with the cl_azure_sql_managed_instance_administrator user. Needs to comply with Azure's Password Policy"
}
//**********************************************************************************************

// Optional Variables for Sql Managed Instance
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map(any)
  default     = {}
}
variable "cl_azure_sql_server_postfix" {
  description = "(Required) The posftfix for sql servr. Part of the naming scheme."
  default     = "global"
}
variable "cl_azure_sql_managed_instance_rg" {
  description = "(Required) The name of the resource group in which to create the SQL Server"
  type        = string
  default     = ""
}
variable "cl_azure_sql_managed_instance_sku" {
  description = "(Required) Specifies the SKU Name for the SQL Managed Instance. Valid values include GP_Gen4, GP_Gen5, BC_Gen4, BC_Gen5"
  type        = string
  default     = "GP_Gen5"
}
variable "cl_azure_sql_managed_instance_vcores" {
  description = "(Required) Number of cores that should be assigned to your instance. Values can be 8, 16, or 24 if sku_name is GP_Gen4, or 8, 16, 24, 32, or 40 if sku_name is GP_Gen5"
  type        = number
  default     = 4
}
variable "cl_azure_sql_managed_instance_storage_size" {
  description = "(Required) Maximum storage space for your instance. It should be a multiple of 32GB"
  type        = number
  default     = 32
}
variable "cl_azure_sql_managed_instance_storage_license_type" {
  description = "(Required) What type of license the Managed Instance will use. Valid values include can be LicenseIncluded or BasePrice"
  type        = string
  default     = "BasePrice"
}
variable "cl_azure_sql_managed_instance_collation" {
  description = "(Optional) Specifies how the SQL Managed Instance will be collated. Default value is SQL_Latin1_General_CP1_CI_AS. Changing this forces a new resource to be created"
  type        = string
  default     = "SQL_Latin1_General_CP1_CI_AS"
}
variable "cl_azure_sql_managed_instance_minimum_tls_version" {
  description = "(Optional) The Minimum TLS Version. Default value is 1.2 Valid values include 1.0, 1.1, 1.2"
  type        = string
  default     = "1.2"
}
variable "cl_azure_sql_managed_instance_proxy_override" {
  description = "(Optional) Specifies how the SQL Managed Instance will be accessed. Default value is Default. Valid values include Default, Proxy, and Redirect."
  type        = string
  default     = "Default"
}
variable "cl_azure_sql_managed_instance_timezone_id" {
  description = "(Optional) The TimeZone ID that the SQL Managed Instance will be operating in. Default value is UTC. Changing this forces a new resource to be created."
  type        = string
  default     = "UTC"
}
variable "cl_azure_sql_managed_instance_storage_account_type" {
  description = "(Optional) Specifies the storage account type used to store backups for this database. Changing this forces a new resource to be created. Possible values are GRS, LRS and ZRS. The default value is GRS."
  type        = string
  default     = "LRS"
}
variable "cl_azure_sql_managed_instance_public_data_endpoint_enabled" {
  description = "(Optional) Is the public data endpoint enabled? Default value is false"
  type        = bool
  default     = false
}
//**********************************************************************************************


//Optional Variables for Vnet Subnet
//**********************************************************************************************
variable "cl_azure_sql_mananged_instance_subnet_prefix" {
  description = "(Optional) The prefix of the sql managed instance subnet with address prefix 0.0.0.0/27 & Only one instance per subnet is recommended"
  default     = null
}
variable "cl_azure_sql_mananged_instance_subnet_service_enpoints" {
  description = "(Optional) specify the subnet service endpoints to open."
  type        = list(string)
  default     = ["Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.ContainerRegistry", "Microsoft.KeyVault", "Microsoft.AzureActiveDirectory"]
}
variable "cl_azure_sql_mananged_instance_subnet_id" {
  description = "(Optional) The subnet ID where the Sql MI will be deployed to. Use this only if cl_azure_sql_mananged_instance_subnet_id = false."
  default     = null
}
variable "cl_azure_sql_mananged_instance_delegation_name" {
  description = "(Optional) name for the subnet delegation"
  default     = "managedinstancedelegation"
}
variable "cl_azure_sql_mananged_instance_service_delegation_name" {
  description = "(Optional) name for the subnet delegation service"
  default     = "Microsoft.Sql/managedInstances"
}
variable "cl_azure_sql_mananged_instance_service_actions" {
  description = "(Optional) name for the subnet delegation service"
  default     = ["Microsoft.Network/virtualNetworks/subnets/join/action", "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action", "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action"]
}
variable "cl_azure_sql_mananged_instance_subnet_address_prefix" {
  description = "(Optional) The prefix of the sql managed instance existing subnet with address prefix for network rules"
  default     = null
}
//**********************************************************************************************


// Optional Variables for other components
//**********************************************************************************************
variable "cl_azure_sql_deploy_rg" {
  description = "(Optional) A boolean to enable/disable the deployment of a resource group for the SQL."
  default     = true
}
variable "cl_azure_sql_mananged_deploy_subnet" {
  description = "(Optional) A boolean to enable/disable the deployment of a subnet for the SQL managed instance."
  default     = true
}
variable "cl_azure_sql_mananged_instance_deploy_subnet_nsg" {
  description = "(Optional) A boolean to enable/disable the deployment of a subnet NSG"
  default     = true
}
variable "cl_azure_sql_mananged_instance_vnet_rg_name" {
  description = "(Required) The name of the resource group that the core vnet is in"
}
variable "cl_azure_sql_mananged_instance_vnet_name" {
  description = "(Required) The name of the core vnet required for the sql managed instance subnet."
}
//**********************************************************************************************

// Variables for route table, routes and its association
//**********************************************************************************************
variable "cl_azure_sql_mananged_instance_deploy_subnet_routetable" {
  description = "(Optional) A boolean to enable/disable the deployment of a subnet route table"
  default     = true
}
variable "core_route_table_bgp_propagation" {
  description = "(Optional) A boolean variable indicating if the propagation of on-premise routes to the NICs of the subnet associated to it."
  type        = bool
  default     = true
}
variable "cl_azure_sql_mananged_instance_next_hop_type" {
  description = "(Optional) Next hop type for subnet route table"
  default     = "Internet"
}
//**********************************************************************************************

// Optional Variables Sets up diagnostics for Azure Sql Managed Instance
//**********************************************************************************************
variable "cl_azure_sql_mananged_instance_workspace_id" {
  description = "(Required) The log analytics workspace ID for diagnostics"
}
variable "cl_azure_sql_mananged_instance_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["SQLSecurityAuditEvents", "ResourceUsageStats", "DevOpsOperationsAudit"]
    metrics = ["AllMetrics"]
  }
}
//**********************************************************************************************

// Optional Variables Private endpoint Variables for Azure Sql Managed Instance
//**********************************************************************************************
variable "cl_azure_sql_mananged_instance_deploy_pe" {
  description = "(Required) Specify whether to deploy Private end point or not not"
  type        = bool
  default     = false
}
variable "cl_azure_sql_mananged_private_endpoint_subnet" {
  description = "(Optional) Specifies the list of subnets for private endpint"
}
variable "cl_azure_sql_mananged_instance_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string)
  default     = []
}
variable "manual_connection" {
  description = "(Required) Does the Private Endpoint require Manual Approval from the remote resource owner? Changing this forces a new resource to be created."
  type        = bool
  default     = false
}
variable "subresource_names" {
  description = "(Optional) A list of subresource names which the Private Endpoint is able to connect to. subresource_names corresponds to group_id"
  type        = list(string)
  default     = ["managedInstance"]
}
//**********************************************************************************************

// Local Variables
//**********************************************************************************************
locals {
  timeout_duration                      = "2h"
  cl_azure_sql_managed_instance_rg      = var.cl_azure_sql_deploy_rg ? azurerm_resource_group.cl_azure_sql_managed_instance_rg[0].name : var.cl_azure_sql_managed_instance_rg
  cl_azure_sql_mananged_instance_nsg    = var.cl_azure_sql_mananged_instance_deploy_subnet_nsg ? azurerm_network_security_group.cl_azure_sql_mananged_instance_nsg[0] : null
  cl_azure_sql_mananged_instance_subnet = var.cl_azure_sql_mananged_deploy_subnet ? azurerm_subnet.cl_azure_sql_mananged_instance_subnet[0] : var.cl_azure_sql_mananged_instance_subnet_id
}
//**********************************************************************************************


## Outputs

// Outputs
//**********************************************************************************************
output "cl_azure_sql_managed_instance_rg" {
  value = local.cl_azure_sql_managed_instance_rg
}
output "cl_azure_sql_mananged_instance_subnet" {
  value = local.cl_azure_sql_mananged_instance_subnet
}
output "cl_azure_sql_mananged_instance_nsg" {
  value = local.cl_azure_sql_mananged_instance_nsg
}
output "cl_azure_sql_mananged_instance_name" {
  value = azurerm_mssql_managed_instance.cl_azure_sql_mananged_instance.name
}
output "cl_azure_sql_mananged_instance_id" {
  value = azurerm_mssql_managed_instance.cl_azure_sql_mananged_instance.id
}
output "cl_azure_sql_mananged_instance_administrator_login" {
  value = azurerm_mssql_managed_instance.cl_azure_sql_mananged_instance.administrator_login
}
output "cl_azure_sql_mananged_instance_fqdn" {
  value = azurerm_mssql_managed_instance.cl_azure_sql_mananged_instance.fqdn
}
output "cl_azure_sql_mananged_instance_identity" {
  value = azurerm_mssql_managed_instance.cl_azure_sql_mananged_instance.identity
}
//**********************************************************************************************

//**********************************************************************************************

Note: It is recommended to create One SQL Managed instance to a single subnet and multiple SQL MI instances in a single subnet is not recommended. 

## Usage
### Deploy single SQL Managed Instance component
```terraform
module "cl_azure_sql_mananged_instance" {
  source                                  = "../caf-tf-modules/cl_azure_sql_managed_instance"
  env                                                     = var.env
  postfix                                                 = var.postfix
  location                                                = var.location
  cl_azure_sql_managed_instance_sku                       = var.cl_azure_sql_managed_instance_sku
  cl_azure_sql_managed_instance_vcores                    = var.cl_azure_sql_managed_instance_vcores
  cl_azure_sql_managed_instance_storage_size              = var.cl_azure_sql_managed_instance_storage_size
  cl_azure_sql_managed_instance_storage_license_type      = var.cl_azure_sql_managed_instance_storage_license_type
  cl_azure_sql_mananged_instance_vnet_rg_name             = var.cl_azure_sql_managed_instance_vnet_rg_name
  cl_azure_sql_mananged_instance_vnet_name                = var.cl_azure_sql_managed_instance_vnet_name
  cl_azure_sql_mananged_instance_subnet_prefix            = var.cl_azure_sql_managed_instance_subnet_prefix
  cl_azure_sql_managed_instance_administrator             = var.cl_azure_sql_managed_instance_administrator
  cl_azure_sql_managed_instance_password                  = var.cl_azure_sql_managed_instance_password
  cl_azure_sql_deploy_rg                                  = true
  cl_azure_sql_mananged_deploy_subnet                     = true
  cl_azure_sql_mananged_instance_deploy_subnet_nsg        = true
  cl_azure_sql_mananged_instance_deploy_subnet_routetable = true
  cl_azure_sql_mananged_instance_workspace_id             = var.cl_azure_sql_mananged_instance_workspace_id
}
```
//**********************************************************************************************






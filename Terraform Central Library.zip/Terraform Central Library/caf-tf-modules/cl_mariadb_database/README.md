# Azure Database for MariaDB servers

Azure Database for MariaDB is a relational database service based on the open-source MariaDB Server engine. 
It's a fully managed database as a service offering that can handle mission-critical workloads with predictable performance and dynamic scalability.  
This component deploys just the mariadb database.

For more information, please visit: https://docs.microsoft.com/en-us/azure/mariadb/ 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
  type        = string
}
variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
  type        = string
}
variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
  type        = string
}
//**********************************************************************************************

// Required Variables
//**********************************************************************************************
variable "cl_mariadb_database_postfix" {
  description = "(Required) A string that is appended to the end of the the MariaDB Database name to identify it."
  type        = string
}
variable "cl_mariadb_database_server_name" {
  description = "(Required) A string server_name of the the MariaDB Database name to add it."
  type        = string
}
variable "cl_mariadb_database_resource_group_name" {
  description = "(Required) Specifies the Azure Database for MariaDB servers resource group"
  type        = string
}
//**********************************************************************************************

// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "Tags to apply to all resources"
  default     = {}
  type        = map(string)
}
variable "cl_mariadb_database_charset" {
  description = "Specifies the Charset for each MariaDB Database"
  type        = string
  default     = "utf8"
}
variable "cl_mariadb_database_collation" {
  description = "Specifies the Collation for each MariaDB Database"
  type        = string
  default     = "utf8_unicode_ci"
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h"
}
//**********************************************************************************************
```

## Outputs

```terraform
//**********************************************************************************************
// Outputs
//**********************************************************************************************
output "cl_mariadb_database" {
  description = "MariaDB Database"
  value       = azurerm_mariadb_database.cl_mariadb_database
}
//**********************************************************************************************
```

## Usages

```terraform
//**********************************************************************************************
resource "azurerm_subnet" "cl_mariadb_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault"]
}

resource "azurerm_private_dns_zone" "mariadb_private_dns_zone" {
  name                = "privatelink.mariadb.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "mariadb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-mariadb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.mariadb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}

module "cl_mariadb_server" {
  source                                                 = "../caf-tf-modules/cl_mariadb_server"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  cl_mariadb_server_postfix                              = "global"
  cl_mariadb_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_mariadb_server_administrator_login                  = "adminmariadb"
  cl_mariadb_server_administrator_password               = "Abc1234567890."
  cl_mariadb_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_mariadb_server_nacl_allowed_subnets                 = [azurerm_subnet.cl_mariadb_private_subnet.id]
  cl_mariadb_server_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_mariadb_server_vnet_rules                           = [azurerm_subnet.cl_mariadb_private_subnet.id]  
  cl_mariadb_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.mariadb_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "mariadb_private_dns_record" {
  name                 = "${var.env}-${var.postfix}-mariadb-pe-record"
  zone_name            = azurerm_private_dns_zone.mariadb_private_dns_zone.name
  resource_group_name  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                  = 600
  records              = module.cl_mariadb_server.cl_mariadb_server_private_endpoint[*].private_service_connection[0].private_ip_address
}

module "cl_mariadb_database" {
  source                                           = "../tf-azure-component-library/components/cl_mariadb_database"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_mariadb_database_postfix                      = "globaldb"
  cl_mariadb_database_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_mariadb_database_server_name                  = module.cl_mariadb_server.cl_mariadb_server.name
  cl_mariadb_database_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
}
//**********************************************************************************************
```
# Azure App Insights Component

Azure Application Insights is a Application Performance Management (APM) service that is used to monitor live applications. 
This service provides insights on app availability, performance, failures and usage.
This component will deploy Azure Application insights and make itself available for App/Web monitoring.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-monitor/app/app-insights-overview

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_app_insights_resource_group_name" {
  description = "(Required) The name of the resource group in which to create the Application Insights component."
}
variable "cl_app_insights_application_type" {
  description = " (Required) Specifies the type of Application Insights to create."
  type        = string
}
variable "cl_app_insights_content" {
  description = " (Required) The content for the Analytics Item."
  type        = string
}
variable "cl_app_insights_scope" {
  description = "  (Required) The scope for the Analytics Item."
  type        = string
}
variable "cl_app_insights_type" {
  description = " (Required) Specifies the type of Application Insights to create."
  type        = string
}
variable "cl_app_insights_web_test_kind" {
  description = "(Required) The kind of web test that this web test watches."
  type        = string
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "cl_app_insights_read_permissions" {
  description = "(Optional) Specifies the list of read permissions granted to the API key."
  type        = list(string)
  default     = ["agentconfig","aggregate", "api", "draft", "extendqueries", "search"]
}
variable "cl_app_insights_write_permissions" {
  description = "(Optional) Specifies the list of write permissions granted to the API key."
  type        = list(string)
  default     = ["annotations"]
}
variable "sdk_control_channel_read_permission" {
  description = "(Optional) Specifies the list of read permissions granted to the API key."
  type        = list(string)
  default     = ["agentconfig"]
}
variable "cl_app_insights_web_test" {
  type = map(object({
    frequency           = number
    timeout             = number
    enabled             = string
    geo_locations       = list(string)
    test_method         = string
    test_url            = string
    test_response_code  = number
  }))
  description = "(Optional) Define additional NSG rules"
  default     = {}
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h"
}
//**********************************************************************************************

# // Outputs
# //**********************************************************************************************
output "instrumentation_key" {
  value = azurerm_application_insights.cl_app_insights.instrumentation_key
}

output "app_id" {
  value = azurerm_application_insights.cl_app_insights.app_id
}

output "read_telemetry_api_key" {
  value = azurerm_application_insights_api_key.cl_app_insights_read_telemetry.api_key
}

output "write_annotations_api_key" {
  value = azurerm_application_insights_api_key.cl_app_insights_write_annotations.api_key
}

output "authenticate_sdk_control_channel" {
  value = azurerm_application_insights_api_key.cl_app_insights_authenticate_sdk_control_channel.api_key
}

output "full_permissions_api_key" {
  value = azurerm_application_insights_api_key.cl_app_insights_full_permissions.api_key
}

output "cl_app_insights_web_test" {
  value = azurerm_application_insights_web_test.cl_app_insights_web_test
}
//**********************************************************************************************



## Usage

```terraform

// ADI code starts from here *********************************************************************

// Azure Application Insights
//**********************************************************************************************
module "cl_app_insights" {
  source                              = "../caf-tf-modules/cl_app_insights"
  env                                 = var.env
  postfix                             = var.postfix
  location                            = var.location
  cl_app_insights_resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_app_insights_application_type    = "web"
  cl_app_insights_content                      = "requests //simple example query"
  cl_app_insights_scope                        = "shared"
  cl_app_insights_type                         = "query"
  cl_app_insights_web_test_kind                = "ping"
  cl_app_insights_web_test            = {
    web_test = {
     frequency                    = 300
      timeout                     = 60
      enabled                     = true
      geo_locations               = ["us-tx-sn1-azr", "us-il-ch1-azr"]
      test_method = "GET"
      test_url = "http://xxxxxxxx"
      test_response_code = 200
    }
  }
 }
//************************************************************************************************************************


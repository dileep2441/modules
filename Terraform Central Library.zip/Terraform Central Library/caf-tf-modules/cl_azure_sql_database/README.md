# Azure SQL Database Component

Azure SQL Database is a fully managed platform as a service (PaaS) database engine that handles most of the database management functions such as upgrading, patching, backups, and monitoring without user involvement. 
This component will deploy an Azure SQL Database, audit policy and a diagnostic settings for the Azure SQL Database.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview

## Information
## Enabled extended auditing policy to Azure Sql Server and enabled integration with AAD:
```terraform
1. Deploy the infrastructure to Azure Sql Server and Azure Sql Database
2. Before to deploy the extended_auditing_policy, with a Admin cloudops request the role assignment to the Storage Account created for it in component Azure Sql server
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/and select the name for the Azure Sql server created
3. Add the variables to enabled the deploy for the extended_auditing_policy in azure sql server and azure sql database
   
   in module cl_azure_sql_server
   cl_azure_sql_server_audit_enabled              = true

   in module cl_azure_sql_database
   cl_azure_sql_database_audit_enabled             = true
```

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_azure_sql_database_postfix" {
  description = "(Required) A string that is appended to the end of the database name to identify it."
}

variable "cl_azure_sql_server_id" {
    description = "(Required) The id of the Ms SQL Server on which to create the database. Changing this forces a new resource to be created."
}

variable "cl_azure_storage_account_endpoint" {
    description = "(Required) Specifies the blob storage endpoint."
}

variable "cl_azure_storage_account_access_key" {
    description = "(Required) Specifies the access key to use for the auditing storage account."
}

variable "cl_azure_sql_database_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}

variable "cl_azure_sql_database_collation" {
    description = "(Optional) Specifies the collation of the database. Changing this forces a new resource to be created."
    type        = string
    default     = "SQL_Latin1_General_CP1_CI_AS"
}

variable "cl_azure_sql_database_license" {
    description = "(Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice."
    type        = string
    default     = "BasePrice"
}

variable "cl_azure_sql_database_size" {
    description = "(Optional) The max size of the database in gigabytes."
    type        = number
    default     = 4
}

variable "cl_azure_sql_database_read" {
    description = "(Optional) If enabled, connections that have application intent set to readonly in their connection string may be routed to a readonly secondary replica. This property is only settable for Premium and Business Critical databases."
    type        = bool
    default     = false
}

variable "cl_azure_sql_database_sku" {
    description = "(Optional) Specifies the name of the sku used by the database. Changing this forces a new resource to be created. Single Database default value: BC_Gen5_2. If the database require be include in Elastic Pool group, in variable sku default value: ElasticPool"
    type        = string
    default     = "BC_Gen5_2"
}

variable "cl_azure_sql_database_redudant" {
    description = "(Optional) Whether or not this database is zone redundant, which means the replicas of this database will be spread across multiple availability zones. This property is only settable for Premium and Business Critical databases."
    type        = bool
    default     = false
}

variable "cl_azure_sql_database_create_mode" {
    type        = string
    description = "(Optional) The create mode of the database. Possible values are Copy, Default, OnlineSecondary, PointInTimeRestore, Recovery, Restore, RestoreExternalBackup, RestoreExternalBackupSecondary, RestoreLongTermRetentionBackup and Secondary."
    default     = "Default"
}

variable "cl_azure_sql_database_replica_count" {
    description = "(Optional) The number of readonly secondary replicas associated with the database to which readonly application intent connections may be routed. This property is only settable for Hyperscale edition databases."
    type        = number
    default     = null
}

variable "cl_azure_sql_database_STR_retention" {
    description = "(Required) Point In Time Restore configuration. Value has to be between 7 and 35."
    type        = number
    default     = 35
}

variable "cl_azure_sql_database_LTR_weekly_retention" {
    description = "(Optional) The monthly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D."
    type        = string
    default     = "P4W"
}

variable "cl_azure_sql_database_LTR_week_of_year" {
    description = "(Optional) The week of year to take the yearly backup in an ISO 8601 format. Value has to be between 1 and 52."
    type        = number
    default     = 1
}

variable "cl_azure_sql_database_threat_policy_state" {
    description = "(Optional) The State of the Policy. Possible values are Enabled, Disabled or New."
    type        = string
    default     = "Enabled"
}

variable "cl_azure_sql_database_disabled_alerts" {
    description = "(Optional) Specifies a list of alerts which should be disabled. Possible values include Access_Anomaly, Sql_Injection and Sql_Injection_Vulnerability."
    type        = list(string)
    default     = []
}

variable "cl_azure_sql_database_threat_logs_retention" {
    description = "(Optional) Specifies the number of days to keep in the Threat Detection audit logs."
    type        = number
    default     = 7
}

variable "cl_azure_sql_database_threat_email_admins" {
    description = "(Optional) Should the account administrators be emailed when this alert is triggered?"
    type        = string
    default     = "Disabled"
}

variable "cl_azure_sql_database_threat_emails" {
    description = "(Optional) A list of email addresses which alerts should be sent to."
    type        = list(string)
    default     = []
}

variable "cl_azure_storage_account_secondary_access_key" {
    description = "(Optional) Specifies whether cl_azure_storage_account_access_key value is the storage's secondary key."
    type        = bool
    default     = false
}

variable "cl_azure_sql_database_audit_retention_days" {
    description = "(Optional) Specifies the number of days to retain logs for in the storage account."
    type        = number
    default     = 7
}

variable "cl_azure_sql_database_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["SQLInsights", "AutomaticTuning", "QueryStoreRuntimeStatistics", "QueryStoreWaitStatistics", "Errors", "DatabaseWaitStatistics", "Timeouts", "Blocks", "Deadlocks"]
    metrics = ["Basic", "InstanceAndAppAdvanced", "WorkloadManagement"]
  }
}

variable "cl_azure_sql_database_elastic_pool_id" {
   description = "(Optional) The Elastic Pool id to Integrate the DB with one azure sql elastic pool."
   type        = string
   default     = null
}

variable "cl_azure_sql_database_enabled_diagnostic_settings" {
    description = "(Optional) Boolean to enable monitor diagnostic setting resource creation"
    type        = bool
    default     = true    
}

variable "cl_azure_sql_database_audit_enabled" {
    description = "(Optional) Boolean to enable sql db extended auditing policy resource creation"
    type        = bool
    default     = false    
}
//**********************************************************************************************



// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h" 
}
//**********************************************************************************************
```

## Outputs

// Outputs
//**********************************************************************************************
output "cl_azure_sql_database" {
  value = azurerm_mssql_database.cl_azure_sql_database
}

output "cl_azure_sql_database_audit_policy" {
  value = azurerm_mssql_database_extended_auditing_policy.cl_azure_sql_database_audit_policy
}

output "cl_azure_sql_database_diagnostic_settings" {
  value = azurerm_monitor_diagnostic_setting.cl_azure_sql_database_diagnostic_settings
}
//**********************************************************************************************

## Usage
### Deploy single SQL Database
```terraform
module "cl_azure_sql_server" {
  source                                           = "../caf-tf-modules/cl_azure_sql_server"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]

}

module "cl_azure_sql_database" {
  source                                           = "../tf-azure-component-library/components/cl_azure_sql_database"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_azure_sql_database_postfix                    = "globaldb"
  cl_azure_sql_server_id                           = module.cl_azure_sql_server.cl_azure_sql_server.id
  cl_azure_storage_account_endpoint                = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_blob_endpoint
  cl_azure_storage_account_access_key              = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_access_key
  cl_azure_sql_database_workspace_id               = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
}
```

### Deploy SQL Database with SQL Elastic Pool
```terraform
module "cl_azure_sql_elastic_pool" {
   source                                               = "../tf-azure-component-library/components/cl_azure_sql_elastic_pool"
   cl_azure_sql_elastic_pool_enable                     = true
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_azure_sql_elastic_pool_postfix                    = "globaldb"
   cl_azure_sql_elastic_pool_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
   cl_azure_sql_elastic_pool_server_name                = module.cl_azure_sql_server.cl_azure_sql_server.name
   cl_azure_sql_elastic_pool_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
}

module "cl_azure_sql_server" {
  source                                           = "../tf-azure-component-library/components/cl_azure_sql_server"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
}

module "cl_azure_sql_database" {
  source                                           = "../tf-azure-component-library/components/cl_azure_sql_database"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_azure_sql_database_postfix                    = "globaldb"
  cl_azure_sql_database_sku                        = "ElasticPool"
  cl_azure_sql_server_id                           = module.cl_azure_sql_server.cl_azure_sql_server.id
  cl_azure_storage_account_endpoint                = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_blob_endpoint
  cl_azure_storage_account_access_key              = module.cl_azure_sql_server.cl_azure_sql_server_storage_account.primary_access_key
  cl_azure_sql_database_workspace_id               = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_azure_sql_database_license                    = "LicenseIncluded"
  cl_azure_sql_database_elastic_pool_id            = module.cl_azure_sql_elastic_pool.cl_azure_sql_elastic_pool[0].id
}
```
# Azure Purview

Microsoft Purview is a unified data governance service that helps you manage and govern your on-premises, multi-cloud, and software-as-a-service (SaaS) data. Microsoft Purview allows you to:

Create a holistic, up-to-date map of your data landscape with automated data discovery, sensitive data classification, and end-to-end data lineage.
Enable data curators to manage and secure your data estate.
Empower data consumers to find valuable, trustworthy data.

For more information, please visit:  https://docs.microsoft.com/en-us/azure/purview/overview

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_purview_account_resource_group_name" {
   description = "(Required) The the resource group for private end points."
}
variable "cl_purview_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map(any)
  default     = {}
}
variable "cl_purview_account_rg_deploy_rg" {
  description = "(Optional) A boolean to enable/disable the deployment of a resource group for the purview Account."
  type        = bool
  default     = true
}
variable "cl_purview_public_network_enabled" {
  description = "(Optional) Should the Purview Account be visible to the public network"
  type        = bool
  default     = false
}
variable "cl_purvie_managed_resource_group_name" {
  description = "(Optional) The name which should be used for the new Resource Group where Purview Account creates the managed resources. Changing this forces a new Purview Account to be created."
  default = ""  
}
variable "cl_purview_account_allowed_pe_subnet_ids" {
  type        = list(string)
  description = "(Opional) One or more Subnet ID's which should be able to access through a private endpoint to this purview Account."
  default     = []
}
variable "cl_purview_account_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
variable "cl_purview_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["AuditEvent"]
    metrics = ["AllMetrics"]
  }
}

// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h" 
  cl_purview_account_resource_group_name      = var.cl_purview_account_rg_deploy_rg ? azurerm_resource_group.cl_purview_account_rg[0].name : var.cl_purview_account_resource_group_name 
}
//*****************************************************************************************************************************************************************************************

## Outputs

// Outputs
//**********************************************************************************************
output "cl_purview_account" {
  value = azurerm_purview_account.cl_purview_account
}
output "cl_purview_managed_resources" {
  value = azurerm_purview_account.cl_purview_account.managed_resources
}
output "cl_purview_storage_account_id" {
  value = azurerm_purview_account.cl_purview_account.managed_resources[*].storage_account_id
}
output "cl_purview_event_hub_namespace_id" {
  value =azurerm_purview_account.cl_purview_account.managed_resources[*].event_hub_namespace_id
}
//**********************************************************************************************



## Usage

```terraform
// Azure Purview
//**********************************************************************************************
module "cl_azure_purview" {
  source                                      = "../caf-tf-modules/cl_azure_purview"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  cl_purview_account_postfix                  = var.cl_purview_account_postfix
  cl_purview_account_rg_deploy_rg             = var.cl_purview_account_rg_deploy_rg
  cl_purview_account_resource_group_name      = var.cl_purview_account_resource_group_name
  cl_purvie_managed_resource_group_name       = var.cl_purview_managed_resource_group_name
  cl_purview_public_network_enabled           = var.cl_purview_public_network_enabled
  cl_purview_account_allowed_pe_subnet_ids    = var.cl_purview_account_allowed_pe_subnet_ids
  cl_purview_account_private_dns_zone_ids     = var.cl_purview_account_private_dns_zone_ids
  cl_purview_portal_private_dns_zone_ids      = var.cl_purview_portal_private_dns_zone_ids
  cl_purview_blob_private_dns_zone_ids        = var.cl_purview_blob_private_dns_zone_ids
  cl_purview_queue_private_dns_zone_ids       = var.cl_purview_queue_private_dns_zone_ids
  cl_purview_servicebus_private_dns_zone_ids  = var.cl_purview_servicebus_private_dns_zone_ids
  cl_purview_log_analytics_workspace_id       = var.cl_purview_log_analytics_workspace_id  
}
//**********************************************************************************************

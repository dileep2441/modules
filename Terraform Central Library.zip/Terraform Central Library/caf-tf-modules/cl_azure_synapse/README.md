# Azure Synapse Component

Azure Synapse is a analytics service that brings together data integration, enterprise data warehousing, and big data analytics. 
With these capabilties - synapse allows to ingest, transform and manage data for immediate BI and machine learning needs.
This component will deploy a random password and KV secret for SQL admin for AZ Synapse. It also creates a workspace, dedicated sql pool, private link hub, diagnostics and private endpoint for AZ synapse.

For more information, please visit: https://docs.microsoft.com/en-us/azure/synapse-analytics/overview-what-is 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}

variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}

variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_azure_synapse_resource_group_name" {
  description = "(Required) The name of the resource group where the synapse resources will be deployed to."
  type        = string
}
variable "cl_azure_synapse_storage_data_lake_gen2_filesystem_id" {
  description = "(Required) The id of the data lake filesystem to be used by synapse."
  type        = string
}
variable "cl_azure_synapse_subnet_id" {
  description = "(Required) The id of the synapse subnet id."
  type        = list(string)
}
variable "cl_azure_synapse_virtual_network_id" {
  description = "(Required) The id of the synapse virtual network id."
  type        = string
}
variable "cl_azure_synapse_postfix"{
  description = "alias azure synapse deployment"
  type        = string
}

// AZ Synapse KV
variable "cl_azure_synapse_keyvault_id" {
  description = "(Required) The id of the synapse keyvault id."
  type        = string
}

// AZ Synapse diag settings
variable "cl_azure_synapse_log_analytics_workspace_id" {
  description = "(Required) The id of the synapse workspace."
  type        = string
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map(any)
  default     = {}
}
variable "cl_azure_synapse_enabled_audit_security_logs"{
  description = "(Optional) enabled and save audit and security logs in storage account audit."
  type        = bool
  default     = false
}
variable "cl_azure_synapse_data_exfiltration_protection_enabled" {
  description = "(Optional) data exfiltration protection enabled."
  type        = bool
  default     = true
}
variable "cl_azure_synapse_managed_virtual_network_enabled" {
  description = "(Optional) managed virtual network enabled."
  type        = bool
  default     = true
}
variable "cl_azure_synapse_sql_admin_password" {
  description = "(Optional) SQL Admin Password"
  type        = object({
    length           = number,
    special          = bool,
    upper            = bool,
    number           = bool,
    override_special = string
  })
  default = {
    length           = 16,
    special          = true,
    upper            = true,
    number           = true,
    override_special = "$#%"
  }
}

// AZ Synapse Workspace
variable "cl_azure_synapse_sql_administrator_login" {
  description = "(Optional) The id of the synapse subnet id."
  type        = string
  default     = "sqladminuser"
}
variable "cl_azure_synapse_sql_administrator_login_password" {
  description = "(Optional) SQL admin login password"
  type        = string
  default     = null
}
variable "cl_azure_synapse_sql_identity_control_enabled" {
  description = "(Optional) Are pipelines (running as workspace's system assigned identity) allowed to access SQL pools?"
  type        =  bool
  default     =  false 
}

// Firewall rules
variable "cl_azure_synapse_firewall_rules" {
  type = map(object({
    start_ip                 = string
    end_ip                   = string
  }))
  description = "(Optional) Define additional firewall rules"
  default     = {}
}

// Private endpoints
variable "cl_azure_synapse_sql_private_dns_zone_id" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string)
  default     = []
}
variable "cl_azure_synapse_dev_private_dns_zone_id" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string)
  default     = []
}

// Dedicate SQL Pool
variable "cl_azure_synapse_sql_pool" {
  description = "(Optional) Dedicated SQL pool variables"
  type = map(object({
    name = string,
    sku_name = string,
    create_mode = string,
    collation = string,
    data_encrypted = bool
  }))
  default = {
  }
}

// Storage Account
variable "cl_azure_synapse_storage_account_tier" {
  description = "(Optional) The pricing tier for the storage account for Azure SQL server audit and security logging."
  default     = "Standard"
}
variable "cl_azure_synapse_storage_account_replication_type" {
  description = "(Optional) Defines the type of replication to use for the storage account for Azure SQL server audit and security logging."
  default     = "LRS"
}
variable "cl_azure_synapse_storage_account_blob_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 360
}
variable "cl_azure_synapse_storage_account_container_retention_days" {
  description = "Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7`"
  default     = 7
  type        = number
}
variable "cl_azure_synapse_storage_account_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["StorageRead","StorageWrite","StorageDelete"] 
    metrics = ["Transaction"]
  }
}
variable "cl_azure_synapse_storage_account_network_default_action" {
    description = "(Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow."
    type        = string
    default     = "Deny"
}
variable "cl_azure_synapse_storage_account_ip_rules" {
    description = "(Optional) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed."
    type        = list(string)
    default     = []
}
variable "cl_azure_synapse_storage_account_subnet_ids" {
    description = "(Optional) A list of resource ids for subnets."
    type        = list(string)
    default     = []
}
variable "cl_azure_synapse_storage_account_bypass" {
    description = "(Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None."
    type        = list(string)
    default     = ["Logging", "Metrics", "AzureServices"]
}
variable "cl_azure_synapse_storage_account_private_dns_zone_ids" {
    description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
    type        = list(string) 
    default     = []
}
variable "cl_azure_synapse_sa_enable_backup" {
  description = "(Optional) Toggle the blob storage backup feature."
  default     = false
}
variable "cl_azure_synapse_sa_backup_vault_id" {
   description = "The id of blob storage backup vault."
   default     = null
}
variable "cl_azure_synapse_sa_backup_vault" {
   description = "The blob storage backup vault."
   default     = null
}
variable "cl_azure_synapse_sa_backup_policy_id" {
   description = "The azure blob storage backup policy id from the backup vault."
   default     = null
}
variable "cl_azure_synapse_enabled_sa_diagnostic_settings" {
    description = "(Optional) Boolean to enable sa monitor diagnostic setting resource creation"
    type        = bool
    default     = true    
}
variable "cl_azure_synapse_audit_retention_days" {
    description = "(Optional) Specifies the number of days to retain logs for in the storage account."
    type        = number
    default     = 7
}
variable "cl_azure_synapse_alert_retention_days" {
    description = "(Optional) Specifies the number of days to keep in the Threat Detection audit logs."
    type        = number
    default     = 7
}
variable "cl_azure_synapse_disabled_alerts" {
    description = "(Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql_Injection, Sql_Injection_Vulnerability, Access_Anomaly, Data_Exfiltration, Unsafe_Action."
    type        = list(string)
    default     = []
}
variable "cl_azure_synapse_workspace_disabled_alerts" {
    description = "(Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql_Injection, Sql_Injection_Vulnerability, Access_Anomaly, Data_Exfiltration, Unsafe_Action."
    type        = list(string)
    default     = []
}
variable "cl_azure_synapse_policy_state" {
  description = " (Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific SQL pool. Allowed values are: Disabled, Enabled."
  type        = string
  default     = "Enabled"  
}
variable "cl_azure_synapse_security_scans" {
    description = "(Optional) Boolean flag which specifies if recurring scans is enabled or disabled."
    type        = bool
    default     = true
}
variable "cl_azure_synapse_security_email_subscription" {
    description = "(Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators."
    type        = bool
    default     = false
}
variable "cl_azure_synapse_security_emails" {
    description = "(Optional) Specifies an array of e-mail addresses to which the scan notification is sent."
    type        = list(string)
    default     = []
}

// manage private endpoint
variable "cl_azure_synapse_manage_private_endpoint" {
  description = "(Optional) Manage private endpoint variables"
  type = map(object({
    name = string,
    target_resource_id = string,
    subresource_name = string
  }))
  default = {
  }
}

// Monitor
variable "cl_azure_synapse_diagnostic_setting" {
  description = "(Optional) Monitor Diagnostic Settings"
  type        = object({
    logs    = list(string)
    metrics = list(string)
    log_retention_policy_enabled = bool,
    log_retention_policy_days = number,
    metric_retention_policy_enabled = bool,
    metric_retention_policy_days = number
  })
  default = {
    logs    = ["SynapseRbacOperations", "GatewayApiRequests", "BuiltinSqlReqsEnded", "IntegrationPipelineRuns", "IntegrationActivityRuns", "IntegrationTriggerRuns", "SQLSecurityAuditEvents"],
    metrics = ["AllMetrics"],
    log_retention_policy_enabled = false,
    log_retention_policy_days = 0,
    metric_retention_policy_enabled = false,
    metric_retention_policy_days = 0
  }
}
variable "cl_azure_synapse_sql_diagnostic_setting" {
  description = "(Optional) Monitor Diagnostic Settings"
  type        = object({
    logs    = list(string)
    metrics = list(string)
    log_retention_policy_enabled = bool,
    log_retention_policy_days = number,
    metric_retention_policy_enabled = bool,
    metric_retention_policy_days = number
  })
  default = {
    logs    = ["SqlRequests", "ExecRequests", "RequestSteps", "DmsWorkers", "SQLSecurityAuditEvents", "Waits"],
    metrics = ["AllMetrics"],
    log_retention_policy_enabled = false,
    log_retention_policy_days = 0,
    metric_retention_policy_enabled = false,
    metric_retention_policy_days = 0
  }
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h" 
  cl_azure_synapse_storage_account_blob_properties = (var.cl_azure_synapse_sa_enable_backup ? false : true)
  cl_azure_synapse_storage_account = {
    "sbox-pr"  = "sboxpr"
    "nprd-pr"  = "nprdpr"
    "nprd-dr"  = "nprddr"
    "prod-pr"  = "prodpr" 
    "prod-dr"  = "proddr"
    "nprod-pr" = "nprodpr"
  }
}
//**********************************************************************************************
```

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_azure_synapse_sql_admin_password" {
  value = azurerm_key_vault_secret.cl_azure_synapse_sql_admin_password
}
output "cl_azure_synapse_workspace" {
  value = azurerm_synapse_workspace.cl_azure_synapse_workspace
}
output "cl_azure_synapse_sql_pool" {
  value = azurerm_synapse_sql_pool.cl_azure_synapse_sql_pool
}
output "cl_azure_synapse_private_link_hub" {
  value = azurerm_synapse_private_link_hub.cl_azure_synapse_private_link_hub
}
output "cl_azure_synapse_sql_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_azure_synapse_sql_diagnostic_setting
}
output "cl_azure_synapse_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_azure_synapse_diagnostic_setting
}
output "cl_azure_synapse_storage_account_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_azure_synapse_storage_account_diagnostic_setting
}
output "cl_azure_synapse_firewall_rules" {
  value = azurerm_synapse_firewall_rule.cl_azure_synapse_firewall_rules
}
output "cl_azure_synapse_storage_account" {
  value = azurerm_storage_account.cl_azure_synapse_storage_account
}
output "cl_azure_synapse_workspace_extended_auditing_policy" {
  value = azurerm_synapse_workspace_extended_auditing_policy.cl_azure_synapse_workspace_extended_auditing_policy
}
output "cl_azure_synapse_workspace_alert_policy" {
  value = azurerm_synapse_workspace_security_alert_policy.cl_azure_synapse_workspace_alert_policy
}
output "cl_azure_synapse_workspace_security_assessment" {
  value = azurerm_synapse_workspace_vulnerability_assessment.cl_azure_synapse_workspace_security_assessment
}
output "cl_azure_synapse_sql_audit_policy" {
  value = azurerm_synapse_sql_pool_extended_auditing_policy.cl_azure_synapse_sql_audit_policy
}
output "cl_azure_synapse_sql_security_assessment" {
  value = azurerm_synapse_sql_pool_vulnerability_assessment.cl_azure_synapse_sql_security_assessment
}
output "cl_azure_synapse_sql_alert_policy" {
  value = azurerm_synapse_sql_pool_security_alert_policy.cl_azure_synapse_sql_alert_policy
}
output "cl_azure_synapse_private_endpoint_sql" {
  value = azurerm_private_endpoint.cl_azure_synapse_private_endpoint_sql
}
output "cl_azure_synapse_private_endpoint_sqlondemand" {
  value = azurerm_private_endpoint.cl_azure_synapse_private_endpoint_sqlondemand
}
output "cl_azure_synapse_private_endpoint_dev" {
  value = azurerm_private_endpoint.cl_azure_synapse_private_endpoint_dev
}
output "cl_azure_synapse_storage_account_private_endpoint" {
  value = azurerm_private_endpoint.cl_azure_synapse_storage_account_private_endpoint
}
output "cl_azure_synapse_plinkhub_managed_pe" {
  value = azurerm_synapse_managed_private_endpoint.cl_azure_synapse_plinkhub_managed_pe
}
output "cl_azure_synapse_managed_pe" {
  value = azurerm_synapse_managed_private_endpoint.cl_azure_synapse_managed_pe
}
//**********************************************************************************************

```
## Information
## Enabled extended auditing policy to Azure Synpase Workspace and Sql Pool's:
```terraform
1. Deploy the infrastructure to Azure Synpase
3. Before to deploy the extended_auditing_policy, with a Admin CloudOps request the role assignment to the Storage Account created for audit in component Azure Synapse
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/ to manage identity for Azure Synapse name
4. Add the variable to enabled the deploy for the extended_auditing_policy in Azure Synapse Workspace and Sql Pool's
   
   cl_azure_synapse_enabled_audit_security_logs = true
```
## Usage
```terraform
resource "azurerm_private_dns_zone" "synapse_sql_private_dns_zone" {
  name                = "privatelink.sql.azuresynapse.net"
  resource_group_name =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "synapse_sql_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-synapse-sql-link"
  resource_group_name   =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_sql_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
}

resource "azurerm_private_dns_zone" "synapse_dev_private_dns_zone" {
  name                = "privatelink.dev.azuresynapse.net"
  resource_group_name =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "synapse_dev_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-synapse-dev-link"
  resource_group_name   =  data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.synapse_dev_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
}

module "cl_azure_synapse" {
  source                                                = "../caf-tf-modules/cl_azure_synapse"
  env                                                   = var.env
  postfix                                               = var.postfix
  location                                              = var.location
  cl_azure_synapse_postfix                              = "xxxx"
  cl_azure_synapse_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_synapse_virtual_network_id                   = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  cl_azure_synapse_subnet_id                            = [azurerm_subnet.test_subnet.id]
  cl_azure_synapse_keyvault_id                          = "keyVault.id"
  cl_azure_synapse_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_synapse_storage_data_lake_gen2_filesystem_id = "storage_data_lake_gen2_filesystem.id"
  cl_azure_synapse_sql_private_dns_zone_id              = [azurerm_private_dns_zone.synapse_sql_private_dns_zone.id]
  cl_azure_synapse_dev_private_dns_zone_id              = [azurerm_private_dns_zone.synapse_dev_private_dns_zone.id]
  cl_azure_synapse_storage_account_ip_rules             = ["20.242.108.56/24", "23.102.127.160/24"]
  cl_azure_synapse_storage_account_subnet_ids           = [azurerm_subnet.test_subnet.id]
  cl_azure_synapse_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "x.x.x.x"
          end_ip   = "x.x.x.x"
    }
  }
  cl_azure_synapse_sql_pool                             = {
        pool1 = {
          name                 = "dedicatedpool01"
          sku_name             = "DW300c"
          create_mode          = "Default"
          collation            = "SQL_Latin1_General_CP1_CI_AS"
          data_encrypted       = "true"
          }
         pool2 = {
            name                 = "dedicatedpool02"
            sku_name             = "DW300c"
            create_mode          = "Default"
            collation            = "SQL_Latin1_General_CP1_CI_AS"
            data_encrypted       = "true"
            }
  }
  //this is an example if the project requiere to integrate a resource with a manage private endpoint
  //Resources availables to integrate with Azure Synapse: Azure Blob Storage, Azure Cosmos DB(MongoDB API),Azure Cosmos DB (SQL API), Azure Data Explorer (Kusto),Azure Data Lake Storage Gen2, Azure Database for MariaDB, Azure Database for MySQL, Azure Database for PostgreSQL, Azure Event Hubs, Azure File Storage, Azure Funtion, Azure Key Vault, Azure Machine Learning, Azure Monitor Private Link Scope, Azure Queue Storage, Azure SQL Database, Azure Sql Database Managed Instance, Azure Search, Azure Synapse Analytics, Azure Table Storage, Cognitive Services, Microsoft Purview and Private Link Service
  cl_azure_synapse_manage_private_endpoint = {
    manage_pe_1 = {
        name = "dlsa"
        target_resource_id = "storageAccount.id"
        subresource_name = "blob"
    }
  }
}
```
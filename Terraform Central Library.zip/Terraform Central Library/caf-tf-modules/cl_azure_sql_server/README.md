# Azure SQL Server Component

SQL Server on Azure Virtual Machines enables users to use full versions of SQL Server in the cloud without having to manage any on-premises hardware. 
SQL Server virtual machines (VMs) also simplify licensing costs when you pay as you go.
This component will deploy a new Azure SQL Server, storage account for audit & security logging, diagnostic settings for the storage account, storage container, SQL Server audit policy, SQL Server security alert policy, Azure SQL Server security assessment, a private endpoint for Azure SQL Server, firewall rules, vnet rules and logs solutions for Azure SQL Server.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview 

## Information
## Enabled extended auditing policy to Azure Sql Server and enabled integration with AAD:
```terraform
1. For the integration with AAD confirm with the project the admin sql server group name and the object id group name
2. Deploy the infrastructure to Azure Sql Server and Azure Sql Database
3. Before to deploy the extended_auditing_policy, with a Admin cloudops request the role assignment to the Storage Account created for it in component Azure Sql server
   * Find an enter to the Storage account, select Access Control (IAM)/Add Role assignments/select Role "Storage Blob Data Contributor"/and select the name for the Azure Sql server created
4. Add the variables to enabled the deploy for the extended_auditing_policy in azure sql server and azure sql database
   
   in module cl_azure_sql_server
   cl_azure_sql_server_audit_enabled              = true

   in module cl_azure_sql_database
   cl_azure_sql_database_audit_enabled             = true
```

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}

variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}

variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_azure_sql_server_resource_group_name" {
    description = "(Required) Specifies the Azure SQL Server resource group"
}

variable "cl_azure_sql_server_postfix" {
  description = "(Required) A string that is appended to the end of the Azure SQL Server name to identify it."
}

variable "cl_azure_sql_server_administrator" {
    description = "(Required) The administrator login name for the new server. Changing this forces a new resource to be created."
}

variable "cl_azure_sql_server_password" {
    description = "(Required) The password associated with the cl_azure_sql_server_administrator user."
}

variable "cl_azure_sql_server_logging_rg_name" {
    description = "(Required) The resource group for log analytics."
}

variable "cl_azure_sql_server_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}

variable "cl_azure_sql_server_log_analytics_workspace_name" {
    description = "(Required) The log analytics workspace name for diagnostics."
}

variable "cl_azure_sql_server_azuread_login_username" {
   description = "(Optional) The login username of the Azure AD Administrator of this SQL Server."
   type        = string
}

 variable "cl_azure_sql_server_azuread_object_id" {
   description = "(Optional) The object id of the Azure AD Administrator of this SQL Server."
   type        = string
 }
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}

variable "cl_azure_sql_server_version" {
  description = "(Optional) The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server)."
  type        = string
  default     = "12.0"
}

variable "cl_azure_sql_server_connection_policy" {
  description = "(Optional) The connection policy the server will use. Possible values are Default, Proxy, and Redirect."
  type        = string
  default     = "Default"
}

variable "cl_azure_sql_server_tls" {
  description = "(Optional) The Minimum TLS Version for all SQL Database and SQL Data Warehouse databases associated with the server. Valid values are: 1.0, 1.1 and 1.2."
  type        = string
  default     = "1.2"
}

variable "cl_azure_sql_server_public_network_access" {
  description = "(Optional) Whether or not public network access is allowed for this server."
  type        = bool
  default     = false
}

variable "cl_azure_sql_server_storage_account_tier" {
  description = "(Optional) The pricing tier for the storage account for Azure SQL server audit and security logging."
  default     = "Standard"
}

variable "cl_azure_sql_server_storage_account_replication_type" {
  description = "(Optional) Defines the type of replication to use for the storage account for Azure SQL server audit and security logging."
  default     = "LRS"
}

variable "cl_azure_sql_server_storage_account_blob_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 365
}

variable "cl_azure_sql_server_storage_account_container_retention_days" {
  description = "Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7`"
  default     = 7
  type        = number
}

variable "cl_azure_sql_server_storage_account_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["StorageRead","StorageWrite","StorageDelete"] 
    metrics = ["Transaction"]
  }
}

variable "cl_azure_sql_server_audit_retention_days" {
    description = "(Optional) Specifies the number of days to retain logs for in the storage account."
    type        = number
    default     = 7
}

variable "cl_private_endpoint_subresource_names" {
    type        = list(string)
    description = "(Optional) A list of subresources to be included in the private endpoint."
    default     = ["sqlServer"]
}

variable "cl_azure_sql_server_disabled_alerts" {
    description = "(Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql_Injection, Sql_Injection_Vulnerability, Access_Anomaly, Data_Exfiltration, Unsafe_Action."
    type        = list(string)
    default     = []
}

variable "cl_azure_sql_server_alert_state" {
    description = "(Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific database server. Allowed values are: Disabled, Enabled."
    type        = string
    default     = "Enabled"
}

variable "cl_azure_sql_server_alert_retention_days" {
    description = "(Optional) Specifies the number of days to keep in the Threat Detection audit logs."
    type        = number
    default     = 7
}

variable "cl_azure_sql_server_alert_email_enabled" {
    description = "(Optional) Boolean flag which specifies if the alert is sent to the account administrators or not."
    type        = bool
    default     = false
}

variable "cl_azure_sql_server_alert_emails" {
    description = "(Optional) Specifies an array of e-mail addresses to which the alert is sent."
    type        = list(string)
    default     = []
}

variable "cl_azure_sql_server_security_scans" {
    description = "(Optional) Boolean flag which specifies if recurring scans is enabled or disabled."
    type        = bool
    default     = true
}

variable "cl_azure_sql_server_security_email_subscription" {
    description = "(Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators."
    type        = bool
    default     = false
}

variable "cl_azure_sql_server_security_emails" {
    description = "(Optional) Specifies an array of e-mail addresses to which the scan notification is sent."
    type        = list(string)
    default     = []
}

variable "cl_azure_sql_server_nacl_allowed_subnets" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access the Azure SQL Server."
    default     = []
}

variable "cl_azure_sql_server_firewall_rules" {
  type = map(object({
    start_ip                 = string
    end_ip                   = string
  }))
  description = "(Optional) Define additional firewall rules"
  default     = {}
}

variable "cl_azure_sql_server_vnet_rules" {
  type        = list(string)
  description = "(Optional) Define additional virtual network rules"
  default     = []
}

variable "cl_azure_sql_server_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}

variable "cl_azure_sql_server_log_analytics_solution" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    AzureSQLAnalytics = {
      publisher = "Microsoft"
      product   = "OMSGallery/AzureSQLAnalytics"
    }
  }
}
variable "cl_azure_sql_server_storage_account_network_default_action" {
    description = "(Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow."
    type        = string
    default     = "Deny"
}
variable "cl_azure_sql_server_storage_account_ip_rules" {
    description = "(Optional) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed."
    type        = list(string)
    default     = []
}
variable "cl_azure_sql_server_storage_account_subnet_ids" {
    description = "(Optional) A list of resource ids for subnets."
    type        = list(string)
    default     = []
}
variable "cl_azure_sql_server_storage_account_bypass" {
    description = "(Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None."
    type        = list(string)
    default     = ["None"]
}
variable "cl_azure_sql_server_storage_account_pe_subnet_ids" {
    description = "(Optional) A list of subnet IDs the app service will create a private endpoint in."
    default     = []
}
variable "cl_azure_sql_server_storage_account_private_dns_zone_ids" {
    description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
    type        = list(string) 
    default     = []
}
variable "cl_azure_sql_server_sa_enable_backup" {
  description = "(Optional) Toggle the blob storage backup feature."
  default     = false
}
variable "cl_azure_sql_server_sa_backup_vault_id" {
   description = "The id of blob storage backup vault."
   default     = null
}
variable "cl_azure_sql_server_sa_backup_vault" {
   description = "The blob storage backup vault."
   default     = null
}
variable "cl_azure_sql_server_sa_backup_policy_id" {
   description = "The azure blob storage backup policy id from the backup vault."
   default     = null
}
//**********************************************************************************************

//Azure Ad config variables
//**********************************************************************************************
variable "login_username" {
    description = "(Optional) User name for Azure Ad administrator, pls note this variable is created to match the records with tfstate however it is not required for real environment"
    type        = string
    default     = "Nexus DMG LCAW"
}

variable "object_id" {
    description = "(Optional) object id for Azure Ad administrator, pls note this variable is created to match the records with tfstate however it is not required for real environment"
    type        = string
    default     = "2a80fa11-48c3-4f57-8535-fd0214476eb5"
}

variable "tenant_id" {
    description = "(Optional) tenant id for Azure Ad administrator, pls note this variable is created to match the records with tfstate however it is not required for real environment"
    type        = string
    default     = "166643ea-1561-4130-a01a-780f6d1b2dec"
}

variable "principal_id" {
    description = "(Optional) principal_id for identity, pls note this variable is created to match the records with tfstate however it is not required for real environment"
    type        = string
    default     = ""
}

variable "type_identity" {
    description = "(Optional) User name for Azure Ad administrator, pls note this variable is created to match the records with tfstate however it is not required for real environment"
    type        = string
    default     = "UserAssigned"
}
variable "cl_azure_sql_server_enabled_sa_diagnostic_settings" {
    description = "(Optional) Boolean to enable sa monitor diagnostic setting resource creation"
    type        = bool
    default     = true    
}
variable "cl_azure_sql_server_audit_enabled" {
    description = "(Optional) Boolean to enable sql server extended auditing policy resource creation"
    type        = bool
    default     = false    
}
//**********************************************************************************************

// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h"
  cl_storage_account_blob_properties = (var.cl_azure_sql_server_sa_enable_backup ? false : true)
  cl_azure_sql_server_storage_account = {
    "sbox-pr"  = "sboxpr"
    "nprd-pr"  = "nprdpr"
    "nprd-dr"  = "nprddr"
    "prod-pr"  = "prodpr" 
    "prod-dr"  = "proddr"
    "nprod-pr" = "nprodpr"
  }
}
//**********************************************************************************************
```

## Outputs
```terraform
// Outputs
//**********************************************************************************************
output "cl_azure_sql_server" {
  value = azurerm_mssql_server.cl_azure_sql_server
}

output "cl_azure_sql_server_storage_account" {
  value = azurerm_storage_account.cl_azure_sql_server_storage_account
}

output "cl_azure_sql_server_storage_account_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_azure_sql_server_storage_account_diagnostic_setting
}

output "cl_azure_sql_server_sa_atp" {
    value = azurerm_advanced_threat_protection.cl_azure_sql_server_sa_atp
}

output "cl_azure_sql_server_audit_policy" {
  value = azurerm_mssql_server_extended_auditing_policy.cl_azure_sql_server_audit_policy
}

output "cl_azure_sql_server_alert_policy" {
  value = azurerm_mssql_server_security_alert_policy.cl_azure_sql_server_alert_policy
}

output "cl_azure_sql_server_security_assessment" {
  value = azurerm_mssql_server_vulnerability_assessment.cl_azure_sql_server_security_assessment
}

output "cl_azure_sql_server_private_endpoint" {
  value = azurerm_private_endpoint.cl_azure_sql_server_private_endpoint
}

output "cl_azure_sql_server_firewall_rules" {
  value = azurerm_sql_firewall_rule.cl_azure_sql_server_firewall_rules
}

output "cl_azure_sql_server_vnet_rules" {
  value = azurerm_sql_virtual_network_rule.cl_azure_sql_server_vnet_rules
}

output "cl_azure_sql_server_log_analytics_solution" {
  value = azurerm_log_analytics_solution.cl_azure_sql_server_log_analytics_solution
}
output "cl_azure_sql_server_storage_account_private_endpoint"{
    value = azurerm_private_endpoint.cl_azure_sql_server_storage_account_private_endpoint
}
output "cl_azure_sql_server_sa_protected_blob" {
    value = azurerm_data_protection_backup_instance_blob_storage.cl_azure_sql_server_sa_protected_blob
}
//**********************************************************************************************
```

## Usage
```terraform

resource "azurerm_private_dns_zone" "sqldb_private_dns_zone" {
  name                = "privatelink.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sqldb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-sqldb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.sqldb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                   = var.tags
}

module "cl_azure_sql_server" {
  source                                           = "../tf-azure-component-library/components/cl_azure_sql_server"
  env                                              = var.env
  postfix                                          = var.postfix
  location                                         = var.location
  cl_azure_sql_server_postfix                      = "global"
  cl_azure_sql_server_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                = "sqladmin"
  cl_azure_sql_server_password                     = "Portal123456!"
  cl_azure_sql_server_azuread_login_username       = confirm the ADD group with the sql admins for the project
  cl_azure_sql_server_azuread_object_id            = confirme the group admin sql object id created for variable cl_azure_sql_server_azuread_login_username
  cl_azure_sql_server_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets         = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules               = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_azure_sql_server_vnet_rules                   = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids         = [azurerm_private_dns_zone.sqldb_private_dns_zone.id]
  cl_azure_sql_server_sa_enable_backup             = true
  cl_azure_sql_server_sa_backup_vault_id           = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_azure_sql_server_sa_backup_vault              = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_azure_sql_server_sa_backup_policy_id          = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
  cl_azure_sql_server_storage_account_bypass       = ["AzureServices"]
  cl_azure_sql_server_storage_account_ip_rules     = ["199.206.0.0/15"] //Jenkins IP
}
```

## Deploying the SQL Server's storage account with private endpoints

```terraform

resource "azurerm_private_dns_zone" "sqldb_private_dns_zone" {
  name                = "privatelink.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sqldb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-sqldb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.sqldb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  tags                   = var.tags
}

resource "azurerm_private_dns_zone" "blob_private_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "blob_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-blob-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.blob_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.id
  tags                   = var.tags
}

module "cl_azure_sql_server" {
  source                                                   = "../caf-tf-modules/cl_azure_sql_server"
  env                                                      = var.env
  postfix                                                  = var.postfix
  location                                                 = var.location
  cl_azure_sql_server_postfix                              = "global"
  cl_azure_sql_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_azure_sql_server_administrator                        = "sqladmin"
  cl_azure_sql_server_password                             = "Portal123456!"
  cl_azure_sql_server_azuread_login_username               = confirm the ADD group with the sql admins for the project
  cl_azure_sql_server_azuread_object_id                    = confirme the group admin sql object id created for variab
  cl_azure_sql_server_logging_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_azure_sql_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id 
  cl_azure_sql_server_log_analytics_workspace_name         = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_azure_sql_server_nacl_allowed_subnets                 = [azurerm_subnet.subnet.id]
  cl_azure_sql_server_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_azure_sql_server_vnet_rules                           = [azurerm_subnet.subnet.id]  
  cl_azure_sql_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.sqldb_private_dns_zone.id]
  cl_azure_sql_server_storage_account_private_dns_zone_ids = [azurerm_private_dns_zone.blob_private_dns_zone.id]
  cl_azure_sql_server_storage_account_pe_subnet_ids        = [azurerm_subnet.pe_subnet.id]
  cl_azure_sql_server_storage_account_bypass               = ["AzureServices"]
  cl_azure_sql_server_storage_account_ip_rules             = ["199.206.0.0/15"] //Jenkins IP
}
```
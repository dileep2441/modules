

This module deploys log analytics workspace.

For more information, please visit: https://learn.microsoft.com/en-us/azure/azure-monitor/logs/quick-create-workspace?tabs=azure-portal

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
// Common Variables
//**********************************************************************************************
variable "env" {
  type        = string
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
  type        = string
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
  type        = string
  description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************

// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map(any)
  default     = {}
}

// Local Variables
//**********************************************************************************************
locals {
    
  timeout_duration = "2h"
  core_subscription_diagnostics_settings = {
    logs    = ["Administrative", "Security", "ServiceHealth", "Alert", "Recommendation", "Policy", "Autoscale", "ResourceHealth"]
    metrics = []
  }  
}
//**********************************************************************************************

// Outputs
//**********************************************************************************************
output "core_rg_logging" {
  value = azurerm_resource_group.core_rg_logging
}
output "core_log_analytics_workspace" {
  value = azurerm_log_analytics_workspace.core_log_analytics_workspace
}
//**********************************************************************************************
```

## Usage
```terraform

module "cl_log_analytics" {
    source                                                              = "..caf-tf-modules/cl_log_analytics"
    env                                                                 = var.env
    postfix                                                             = var.postfix
    location                                                            = var.location
    }
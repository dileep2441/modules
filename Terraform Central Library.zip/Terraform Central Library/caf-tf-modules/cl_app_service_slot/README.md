# Azure App Service Slot Component

App Service Slot is an additional feature to Azure App Service. It allows to perform blue-green deployments for the App Service, eliminating downtime on deployments or even allow to run separate versions of the Application on the same Azure App Service.
This component will deploy an app service slot in the target app service (hence on the same App Service Plan), bind the app service slot to the integration subnet,
configure a private endpoint, custom domain and diagnostics for the app service.

For more information, please visit: https://docs.microsoft.com/en-us/azure/app-service/deploy-staging-slots

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_app_service_slot_app_postfix" {
    description = "(Required) The bespoke name of the app you are deploying."
}
variable "cl_app_service_slot_app_service" {
    description = "(Required) The app service output cl_app_service from the app service module. Internally used to get all required values."
}
variable "cl_app_service_slot_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_app_service_slot_integration_subnet_id" {
    description = "(Optional) The ID of the integration subnet the app service will be associated to (the subnet must have a service_delegation configured for Microsoft.Web/serverFarms)."
    default     = null
}
variable "cl_app_service_plan_deploy_integration_subnet" {
    description = "(Optional) A boolean that toggles the deployment of the vnet integration subnet."
    default     = true
}
variable "cl_app_service_slot_https_only" {
    description = "(Optional) Booolean to toggle if the App Service can only be accessed via HTTPS."
    default     = true
}
variable "cl_app_service_slot_enabled" {
    description = "(Optional) Set the slot enable after deployment if true. Default set to true."
    default     = true
}
variable "cl_app_service_slot_identity_type" {
    description = "(Optional) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned"
    default     = "SystemAssigned"
}
variable "cl_app_service_slot_identity_identity_ids" {
    description = "(Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned."
    default     = null
}
variable "cl_app_service_slot_auth_settings_enabled" {
    description = "(Optional) Enable or disable Authentication Settings"
    default     = true
}
variable "cl_app_service_slot_auth_settings_default_provider"{
    description = "(Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter."
    default     = "AzureActiveDirectory"
}
variable "cl_app_service_slot_auth_settings_unauthenticated_client_action" {
    description = "(Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage."
    default     = null
}
variable "cl_app_service_slot_auth_settings_aad_client_id" {
    description = "(Optional) The Client ID of this relying party application. Enables OpenIDConnection authentication with Azure Active Directory."
    default     = null  
}
variable "cl_app_service_slot_auth_settings_aad_client_secret" {
    description = "(Optional) The Client Secret of this relying party application. If no secret is provided, implicit flow will be used."
    default     = null  
}
variable "cl_app_service_slot_auth_settings_aad_allowed_audiences" {
    description = "(Optional) Allowed audience values to consider when validating JWTs issued by Azure Active Directory."
    default     = null  
}
variable "cl_app_service_slot_ftps_state" {
    description = "(Optional) State of FTP / FTPS service for this App Service. Possible values include: AllAllowed, FtpsOnly and Disabled."
    default     = "Disabled"
}
variable "cl_app_service_slot_is_docker" {
    type = bool
    default = false
    description = "Specifies if the app service will be using containers. This will change the populations of variables on the app service and build the app_setting on its own"
}
variable "cl_app_service_slot_linux_fx_version" {
    description = "(Optional) Linux App Framework and version for the App Service."
    default     = ""
}
variable "cl_app_service_slot_always_on" {
    description = "(Optional) Should the app be loaded at all times?"
    default     = false
}
variable "cl_app_service_slot_min_tls_version" {
    description = "(Optional) The minimum supported TLS version for the app service"
    default     = "1.2"
}
variable "cl_app_service_slot_http2_enabled" {
    description = "(Optional) Is HTTP2 Enabled on this App Service?"
    default     = true
}
variable "cl_app_service_slot_number_of_workers" {
    description = "(Optional) The scaled number of workers (for per site scaling) of this App Service."
    default     = 1
}
variable "cl_app_service_slot_default_documents" {
    description = "(Optional) The ordering of default documents to load, if an address isn't specified."
    default     = []
}
variable "cl_app_service_slot_remote_debugging_enabled" {
    description = "(Optional) Is Remote Debugging Enabled?"
    default     = false
}
variable "cl_app_service_slot_remote_debugging_version" {
    description = "(Optional) Which version of Visual Studio should the Remote Debugger be compatible with?"
    default     = "VS2017"
}
variable "cl_app_service_slot_use_32_bit_worker_process" {
    description = "(Optional) Should the App Service run in 32 bit mode, rather than 64 bit mode?"
    default     = true
}
variable "cl_app_service_slot_scm_type" { 
    type = string
    default = "None"
    description = "Type of the source control enabled for this App Service. Defaults to None"
}
variable "cl_app_service_slot_health_check_path" {
    type = string
    default = ""
    description = "The health check path to be pinged by App Service"
}
variable "cl_app_service_slot_dotnet_framework_version" {
    type = string
    default = "v5.0"
    description = "(Optional) The version of the .net framework's CLR used in this App Service."
}
variable "cl_app_service_slot_acr_use_managed_identity_credentials" {
    type = bool
    default = false
    description = "(Optional) Are Managed Identity Credentials used for Azure Container Registry pull"
}
variable "cl_app_service_slot_acr_user_managed_identity_client_id" {
    type = string
    default = null
    description = "(Optional) If using User Managed Identity, the User Managed Identity Client Id"
}
variable "cl_app_service_slot_app_command_line" {
    type = string
    default = ""
    description = "(Optional) The app command line to launch."    
}
variable "cl_app_service_slot_cors_allowed_origins" {
    type = list(string)
    default = ["*"]
    description = "(Optional) A list of origins which should be able to make cross-origin calls. * can be used to allow all calls."    
}
variable "cl_app_service_slot_support_cors_credentials" {
    type = bool
    default = false
    description = "(Optional) Are credentials supported?."    
}
variable "cl_app_service_slot_acr_login_server" {
    type = string
    default = ""
    description = "Is the Azure Container Registry server"
}
variable "cl_app_service_slot_acr_image" {
    type = string
    default = ""
    description = "Is the Azure Container Registry image to be used. For example myapp:latest"
}
variable "cl_app_service_slot_acr_scm_type" { 
    type = string
    default = "VSTSRM"
    description = "Type of the source control enabled for this App Service using ACR. Defaults to VSTSRM"
}
variable "cl_app_service_slot_dns_server" { 
    type = string
    default = "168.63.129.16"
    description = "Custom DNS service for app service routing."
}
variable "cl_app_service_slot_acr_username" {
    type = string
    default = ""
    description = "Is the Azure Container Registry username to access the repository"
}
variable "cl_app_service_slot_acr_password" {
    type = string
    default = ""
    description = "Is the Azure Container Registry password of the username to be used"
}
variable "cl_app_service_slot_vnet_route_server"{
    type = number
    default = 1
    description = "(Optional) Should all outbound traffic to have Virtual Network Security Groups and User Defined Routes applied."
}
variable "cl_app_service_slot_connection_strings" {
  type = map(object({
    name                  = string
    type                  = string
    value                 = string
  }))
  description = "(Optional) Connection strings for App Service."
  default     = {}
}
variable "cl_app_service_slot_settings" {
    description = "(Optional) Variables passed as environment variables"
    type        = map
    default     = {}
}
variable "cl_app_service_slot_client_affinity_enabled" {
    description = "(Optional) Should the App Service Slot send session affinity cookies, which route client requests in the same session to the same instance?"
    default     = false
}
variable "cl_app_service_slot_pe_subnet_ids" {
    description = "(Optional) A list of subnet IDs the app service slot will create a private endpoint in."
    default     = []
}
variable "cl_app_service_slot_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
variable "cl_app_service_slot_is_custom_domain_enable" {
    type = bool
    default = false
    description = "(Optional) Is the app service using a custom domain?."    
}
variable "cl_app_service_slot_custom_domain_hostname" {
    type = string
    default = ""
    description = "(Optional) App service custom domain hostname."
}
variable "cl_app_service_slot_custom_domain_thumbprint" {
    type = string
    default = ""
    description = "(Optional) The app service custom domain thumbprint."    
}
variable "cl_app_service_slot_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default = {
        logs    = ["AppServiceAntivirusScanAuditLogs", "AppServiceHTTPLogs", "AppServiceConsoleLogs", "AppServiceAppLogs", "AppServiceFileAuditLogs", "AppServiceAuditLogs", "AppServiceIPSecAuditLogs", "AppServicePlatformLogs"]
        metrics = ["AllMetrics"]
    }
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
    timeout_duration = "2h"
    cl_app_service_slot_rg               = var.cl_app_service_slot_app_service.resource_group_name
    cl_app_service_slot_asp_id           = var.cl_app_service_slot_app_service.app_service_plan_id
    cl_app_service_slot_app_service_name = var.cl_app_service_slot_app_service.name
    cl_app_service_slot_app_service_id   = var.cl_app_service_slot_app_service.id
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_app_service_slot" {
    value = azurerm_app_service_slot.cl_app_service_slot
}
output "cl_app_service_slot_private_endpoint" {
    value = azurerm_private_endpoint.cl_app_service_slot_private_endpoint
}
output "cl_app_service_slot_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_app_service_slot_plan_diagnostic_setting
}
//**********************************************************************************************
```

## Usage

### Deploy App Service Slot with vnet integration subnet

```terraform
module "cl_app_service_plan" {
  source                                                    = "../caf-tf-modules/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = var.app_service_nsg_rules
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}

resource "azurerm_private_dns_zone" "app_service_private_dns_zone" {
  name                = "privatelink.azurewebsites.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}


resource "azurerm_private_dns_zone_virtual_network_link" "app_service_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-app-service-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.app_service_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags  
}

module "cl_app_service" {
  source                                              = "../dn-tads_tf-azure-component-library/components/cl_app_service"
  env                                                 = var.env
  postfix                                             = var.postfix
  location                                            = var.location
  cl_app_service_plan_deploy_integration_subnet       = true
  cl_app_service_integration_subnet_id                = var.app_service_plan_deploy_integration_subnet ? module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id : null
  cl_app_service_client_affinity_enabled              = var.app_service_client_affinity_enabled
  cl_app_service_pe_subnet_ids                        = [azurerm_subnet.private_link_subnet.id]
  cl_app_service_app_postfix                          = var.postfix
  cl_app_service_rg_name                              = module.cl_app_service_plan.cl_app_service_plan_rg
  cl_app_service_asp_id                               = module.cl_app_service_plan.cl_app_service_plan.id
  cl_app_service_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_service_diagnostics                          = var.app_service_diagnostics
  cl_app_service_settings                             = var.app_service_settings
  cl_app_service_private_dns_zone_ids                 = [azurerm_private_dns_zone.app_service_private_dns_zone.id]

  //Site_Config
  cl_app_service_linux_fx_version                     = var.app_service_linux_fx_version
  cl_app_service_default_documents                    = var.app_service_default_documents
  cl_app_service_use_32_bit_worker_process            = var.app_service_use_32_bit_worker_process  
  tags                                                = var.tags
 }


module "cl_app_service_slot" {
  source                                              = "../dn-tads_tf-azure-component-library/components/cl_app_service_slot"
  env                                                 = var.env
  postfix                                             = var.postfix
  location                                            = var.location
  cl_app_service_slot_app_postfix                     = "releaseX"
  cl_app_service_slot_app_service                     = module.cl_app_service.cl_app_service
  cl_app_service_plan_deploy_integration_subnet       = true
  cl_app_service_slot_integration_subnet_id           = var.app_service_plan_deploy_integration_subnet ? module.cl_app_service_plan.cl_app_service_plan_integration_subnet.id : null
  cl_app_service_slot_pe_subnet_ids                   = [azurerm_subnet.private_link_subnet.id]
  cl_app_service_slot_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                = var.tags
 }
```
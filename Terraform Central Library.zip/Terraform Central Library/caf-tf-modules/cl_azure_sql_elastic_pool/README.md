# Azure SQL Elastic Pool

Azure SQL Database elastic pools are a simple, cost-effective solution for managing and scaling multiple databases that have varying and unpredictable usage demands. 
The databases in an elastic pool are on a single server and share a set number of resources at a set price.
This component will deploy an Azure SQL Elastic Pool and diagnostic settings. 

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-sql/database/elastic-pool-overview

## Inputs

```terraform

// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}

variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}

variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************

// Required Variables SQL Elastic pools variables
//**********************************************************************************************
variable "cl_azure_sql_elastic_pool_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}

variable "cl_azure_sql_elastic_pool_postfix" {
  description = "(Required) A string that is appended to the end of the Azure SQL Server name to identify it."
}

variable "cl_azure_sql_elastic_pool_resource_group_name" {
    description = "(Required) Specifies the Azure SQL Server resource group"
}

variable "cl_azure_sql_elastic_pool_server_name" {
    description = "(Required) The name of the Ms SQL Server on which to create the sql elastic pool. Changing this forces a new resource to be created."
}
//**********************************************************************************************

// Optional Variables SQL Elastic pools variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}

variable "cl_azure_sql_elastic_pool_zone_redundant" { 
   description = "Whether or not the Elastic Pool is zone redundant, SKU tier must be Premium to use it. This is mandatory for high availability." 
   type        = bool 
   default     = false 
 } 
 variable "cl_azure_sql_elastic_pool_database_min_capacity" { 
   description = "The minimum capacity all databases are guaranteed in the Elastic Pool. Defaults to 0." 
   type        = string 
   default     = "0" 
 } 
 variable "cl_azure_sql_elastic_pool_database_max_dtu_capacity" { 
   description = "The maximum capacity any one database can consume in the Elastic Pool. Default to the max Elastic Pool capacity." 
   type        = string 
   default     = "1" 
 } 
 variable "cl_azure_sql_elastic_pool_max_size" { 
   description = "Maximum size of the Elastic Pool in gigabytes" 
   type        = string 
   default     = "1024"
 } 

 variable "cl_azure_sql_elastic_pool_sku" {
  type = object({
    name     = string,
    tier     = string,
    family   = string,
    capacity = string
  })
  description = "SKU for the Elastic Pool with tier and eDTUs capacity. Premium tier with zone redundancy is mandatory for high availability. Possible values for tier are Basic, Standard, or Premium. Example tier=Standard, capacity=50. See https://docs.microsoft.com/en-us/azure/sql-database/sql-database-dtu-resource-limits-elastic-pools"
  default = {
    name = "BC_Gen5"
    tier = "BusinessCritical"
    family = "Gen5"
    capacity = "4"
 }
}
variable "cl_azure_sql_elastic_pool_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
 variable "cl_azure_sql_elastic_pool_enable" {
  description = "(Optional) Enable the creation for sql elastic pool"
  type        = bool
  default     = true
}
variable "cl_azure_sql_elastic_pool_license_type" { 
   description = "(Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice." 
   type        = string 
   default     = "BasePrice"
 } 
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h"
}
//**********************************************************************************************

 ## Usage
 module "cl_azure_sql_elastic_pool" {
   source                                               = "../caf-tf-modules/cl_azure_sql_elastic_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_azure_sql_elastic_pool_postfix                    = "globaldb"
   cl_azure_sql_elastic_pool_enable                     = true
   cl_azure_sql_elastic_pool_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
   cl_azure_sql_elastic_pool_server_name                = module.cl_azure_sql_server.cl_azure_sql_server.name
   cl_azure_sql_elastic_pool_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  }
  ```
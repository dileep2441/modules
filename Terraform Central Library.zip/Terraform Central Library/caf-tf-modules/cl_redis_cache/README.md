# Azure Redis Cache Component

The Azure Redis Cache is a high-performance caching service that provides in-memory data store for faster retrieval of data.
It ensures low latency and high throughput by reducing the need to perform slow I/O operations.

This component will deploy Azure Redis Cache and make itself available inside of a subnet.

For more information, please visit: https://docs.microsoft.com/en-us/azure/azure-cache-for-redis/cache-overview

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_redis_cache_vnet_rg_name" {
  description = "(Required) The name of the resource group that the core vnet is in."
}
variable "cl_redis_cache_vnet_name" {
  description = "(Required) The name of the core vnet required for the redis cache subnet."
}
variable "cl_redis_cache_subnet_prefix" {
  description = "(Required) The prefix of the redis cache subnet."
}
variable "cl_redis_cache_resource_group_name" {
  description = "(Required) The name of the resource group where the redis cache will be deployed to."
}
variable "cl_redis_cache_postfix" {
  description = "(Required) The postfix for the redis cache. Use this to make the name globally unique."
}
variable "cl_redis_cache_route_table_id" {
  description = "(Required) The route table to associate the redis cache subnet with."
}
variable "cl_redis_cache_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_redis_cache_subnet_service_enpoints" {
  description = "(Optional) The service endpoints for the redis cache subnet."
  type        = list (string)
  default     = ["Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.ContainerRegistry", "Microsoft.KeyVault"]
}
variable "cl_redis_cache_capacity" {
  description = "(Optional) The size of the Redis cache to deploy. Valid values for a SKU family of C (Basic/Standard) are 0, 1, 2, 3, 4, 5, 6, and for P (Premium) family are 1, 2, 3, 4."
  type = number
  default = 1
}
variable "cl_redis_cache_family" {
  description = "(Optional) The SKU family/pricing group to use. Valid values are C (for Basic/Standard SKU family) and P (for Premium)."
  type        = string
  default     = "P"
}
variable "cl_redis_cache_sku_name" {
  description = "(Optional) The SKU of Redis to use. Possible values are Basic, Standard and Premium."
  type        = string
  default     = "Premium"
}
variable "cl_redis_cache_minimum_tls_version" {
  description = "(Optional) The minimum TLS version."
  type        = string
  default     = "1.2"
}
variable "cl_redis_cache_enable_non_ssl_port" {
  description = "(Optional) Enable the non ssl port for redis cache."
  default     = false
}
variable "cl_redis_cache_configuration_maxmemory_reserved" {
  description = "(Optional) Value in megabytes reserved for non-cache usage e.g. failover."
  type = number
  default = 50
}
variable "cl_redis_cache_configuration_maxmemory_delta" {
  description = "(Optional) The max-memory delta for this Redis instance."
  type = number
  default = 50
}
variable "cl_redis_cache_configuration_maxfragmentationmemory_reserved" {
  description = "(Optional) lue in megabytes reserved to accommodate for memory fragmentation."
  type = number
  default = 50
}
variable "cl_redis_cache_configuration_maxmemory_policy" {
  description = "(Optional) How Redis will select what to remove when maxmemory is reached."
  type        = string
  default     = "volatile-lru"
}
variable "cl_redis_cache_rdb_backup_enabled" {
  description = "(Optional) Is Backup Enabled? Only supported on Premium SKU's"
  type        = bool
  default     = false
}
variable "cl_redis_cache_rdb_backup_frequency" {
  description = "(Optional) The Backup Frequency in Minutes. Only supported on Premium SKU's"
  type        = number
  default     = 360
}
variable "cl_redis_cache_rdb_backup_max_snapshot_count" {
  description = "(Optional) The maximum number of snapshots to create as a backup. Only supported for Premium SKU's"
  type        = number
  default     = 1
}
variable "cl_redis_cache_rdb_backup_storage_account_endpoint" {
  description = "(Optional) Only supported for Premium SKU's"  
  default     = null
}
variable "cl_redis_cache_rdb_backup_storage_account_name" {
  description = "(Optional) Name of backup storage account name. Only supported for Premium SKU's"  
  default     = null
}
variable "cl_redis_cache_rdb_backup_storage_account_key" {
  description = "(Optional) storage account key. Only supported for Premium SKU's"  
  default     = null
}
variable "cl_redis_cache_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
variable "cl_redis_cache_nsg_rules" {
  type = map(object({
    name                          = string
    priority                      = number
    direction                     = string
    access                        = string
    protocol                      = string
    source_port_range             = string
    source_port_ranges            = list(string)
    destination_port_range        = string
    destination_port_ranges       = list(string)    
    source_address_prefix         = string
    source_address_prefixes       = list(string)
    destination_address_prefix    = string
    destination_address_prefixes  = list(string)    
  }))
  description = "(Optional) Define additional NSG rules for app gateway subnet."
  default     = {}
}
variable "cl_redis_cache_enable"{
  description = "Enable/disabled creation module Redis Cache"
  type        = bool
  default     = true 
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_redis_cache_subnet" {
  value = azurerm_redis_cache.cl_redis_cache_subnet
}
output "cl_redis_cache_subnet_nsg" {
  value = azurerm_network_security_group.cl_redis_cache_subnet_nsg
}
output "cl_redis_cache_subnet_association" {
  value = azurerm_subnet_network_security_group_association.cl_redis_cache_subnet_association
}
output "cl_redis_cache_route_table_associate" {
  value = azurerm_subnet_route_table_association.cl_redis_cache_route_table_associate
}
output "cl_redis_cache" {
  value = azurerm_redis_cache.cl_redis_cache
}
output "cl_redis_cache_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_redis_cache_diagnostic_setting
}
//**********************************************************************************************
```


## Usage

```terraform
// Azure Redis Cache
//**********************************************************************************************
 module "cl_redis_cache" {
  source                                    = "../caf-tf-modules/cl_redis_cache"
  cl_redis_cache_enable                     = true/false
  env                                       = var.env
  postfix                                   = var.postfix
  location                                  = var.location
  cl_redis_cache_vnet_rg_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_redis_cache_vnet_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_redis_cache_subnet_prefix              = ["55.0.3.0/24"]
  cl_redis_cache_resource_group_name        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_redis_cache_postfix                    = "app1"
  cl_redis_cache_route_table_id             = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_redis_cache_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_redis_cache_nsg_rules                  = {
    allow_redis_6379_6380 = {
      name                        = "Allow6379and6380Inbound"
      priority                    = 1013
      direction                   = "Inbound"
      access                      = "Allow"
      protocol                    = "Tcp"
      source_port_range           = "*"
      source_port_ranges          = null
      destination_port_range      = null
      destination_port_ranges     = ["6379", "6380"]
      source_address_prefix       = "10.69.22.78/27"
      source_address_prefixes     = null
      destination_address_prefix  = "10.69.22.89/27"  
      destination_address_prefixes  = null  
    }
  }
}
//***************************************************************************************************
```
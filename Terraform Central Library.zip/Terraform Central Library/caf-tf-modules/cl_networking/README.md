# Networking

This module deploys vnets, vnet peering, route tables, network gateways, key vault, security center, public IPs, etc.

```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "hub_env" {
  type        = string
  description = "(Required) Transit hub environment name: nprd-pr, prod-pr, prod-dr, used to determine on-prem connection settings"
}

variable "core_vnet_address_space" {
  type        = list(string)
  description = "(Required) The address space for the virtual network."
}

variable "gateway_sub_address_prefix" {
  type        = list(string)
  description = "(Required) The address prefix for the gateway subnet."
}

variable "vgw_lgw_conn_shared_key" {
  type        = string
  description = "(Required) The shared key to use for the VGW to LGW connections."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map(any)
  default     = {}
}

variable "core_vnet_dns_servers" {
  description = "(Optional) A list of DNS servers to use. If left empty, defaults to Azure servers."
  type        = list(string)
  default     = []
}

variable "core_route_table_disable_bgp_propagation" {
  description = "(Optional) A boolean variable indicating whether to disable the propagation of on-premise routes to the NICs of the subnet associated to it."
  type        = bool
  default     = true
}
variable "core_azure_defender_resources" {
    description = "(Optional) A list of resources with Azure Defender Enabled."
    type        = list
    default     = ["VirtualMachines", "AppServices", "ContainerRegistry", "KeyVaults", "KubernetesService", "SqlServers", "SqlServerVirtualMachines", "StorageAccounts", "Arm", "Dns"]
}
//**********************************************************************************************

// Optional Variables 
//**********************************************************************************************
variable "core_private_link_subnet_address_prefixes" {
  description = "(Optional) The address prefixes for the subnet of key vault."
  type        = list(string)
  default     = []
}
variable "core_private_link_subnet_enforce_endpoint_network_policies" {
  description = "(Optional) "
  type        = bool
  default     = true
}
variable "core_private_link_subnet_service_endpoints" {
  description = "(Optional) "
  type        = list(string)
  default     = []
}
//**********************************************************************************************

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "core_rg_network" {
  value = azurerm_resource_group.core_rg_network
}
output "core_rg_security" {
  value = azurerm_resource_group.core_rg_security
}
output "core_vnet" {
  value = azurerm_virtual_network.core_vnet
}
output "core_gateway_subnet" {
  value = azurerm_subnet.core_gateway_subnet
}
output "core_route_table" {
  value = azurerm_route_table.core_route_table
}
output "core_default_internet_route" {
  value = azurerm_route.core_default_internet_route
}
output "core_security_center_pricing" {
  value = azurerm_security_center_subscription_pricing.core_security_center_pricing
}
output "core_primary_local_network_gateway" {
  value = azurerm_local_network_gateway.core_primary_local_network_gateway
}
output "core_secondary_local_network_gateway" {
  value = azurerm_local_network_gateway.core_secondary_local_network_gateway
}
output "core_primary_vgw_pip" {
  value = azurerm_public_ip.core_primary_vgw_pip
}
output "core_secondary_vgw_pip" {
  value = azurerm_public_ip.core_secondary_vgw_pip
}
output "core_virtual_network_gateway" {
  value = azurerm_virtual_network_gateway.core_virtual_network_gateway
}
output "core_primary_vgw_to_lgw_connection" {
  value = azurerm_virtual_network_gateway_connection.core_primary_vgw_to_lgw_connection
}
output "core_secondary_vgw_to_lgw_connection" {
  value = azurerm_virtual_network_gateway_connection.core_secondary_vgw_to_lgw_connection
}
output "core_peering" {
  value = azurerm_virtual_network_peering.core_peering
}
output "core_private_link_subnet" {
  value = azurerm_subnet.core_private_link_subnet
}
//**********************************************************************************************
```

## Usage
```terraform
module "core_us_peninsula" {
    source                          = "../tf-azure-component-library/core/core_us_peninsula"
    env                             = var.env
    postfix                         = var.postfix
    location                        = var.location
    hub_env                         = "nprd-pr"
    core_vnet_address_space         = ["10.0.1.0/24"]
    gateway_sub_address_prefix      = ["10.0.1.0/27"]
}



# Azure Kubernetes service Component

Azure Kubernetes Service (AKS) simplifies deploying a managed Kubernetes cluster in Azure by offloading the operational overhead to Azure. 
As a hosted Kubernetes service, Azure handles critical tasks, like health monitoring and maintenance. 
Since Kubernetes masters are managed by Azure, you only manage and maintain the agent nodes. 
Thus, AKS is free; you only pay for the agent nodes within your clusters, not for the masters.

For more information, please visit: https://docs.microsoft.com/en-us/azure/aks/intro-kubernetes 

```terraform
1. Azure Kubernetes Cluster Egress Traffic UDR Prerequisites:

* Create the following firewall rules with source vnet aks node pool - Restrict egress traffic in Azure Kubernetes Service (AKS) - https://docs.microsoft.com/en-us/azure/aks/limit-egress-traffic

   * *:123 or ntp.ubuntu.com:123 - Required for Network Time Protocol (NTP) time synchronization on Linux nodes.
   * CustomDNSIP:53 - If you're using custom DNS servers, you must ensure they're accessible by the cluster nodes.
   * *.hcp.<location>.azmk8s.io: HTTPS 443 - Required for Node <-> API server communication. Replace <location> with the region where your AKS cluster is deployed.
   * mcr.microsoft.com: HTTPS 443 - Required to access images in Microsoft Container Registry (MCR). This registry contains first-party images/charts (for example, coreDNS, etc.). These images are required for the correct creation and functioning of the cluster, including scale and upgrade operations.
   * *.data.mcr.microsoft.com: HTTPS 443 - Required for MCR storage backed by the Azure content delivery network (CDN).
   * management.azure.com: HTTPS 443 - Required for Kubernetes operations against the Azure API.
   * login.microsoftonline.com: HTTPS 443 - Required for Azure Active Directory authentication.
   * packages.microsoft.com: HTTPS 443 - This address is the Microsoft packages repository used for cached apt-get operations. Example packages include Moby, PowerShell, and Azure CLI.
   * acs-mirror.azureedge.net: HTTPS 443 - This address is for the repository required to download and install required binaries like kubenet and Azure CNI.
   * nvidia.github.io: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * us.download.nvidia.com: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * apt.dockerproject.org: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * ServiceTag - AzureMonitor: HTTPS 443 - This endpoint is used to send metrics data and logs to Azure Monitor and Log Analytics.
   * dc.services.visualstudio.com: HTTPS 443 - This endpoint is used for metrics and monitoring telemetry using Azure Monitor.
   * *.ods.opinsights.azure.com: HTTPS 443 - This endpoint is used by Azure Monitor for ingesting log analytics data.
   * *.oms.opinsights.azure.com: HTTPS 443 - This endpoint is used by omsagent, which is used to authenticate the log analytics service.
   * *.monitoring.azure.com:	HTTPS 443 - This endpoint is used to send metrics data to Azure Monitor.
   * data.policy.core.windows.net: HTTPS 443 - This address is used to pull the Kubernetes policies and to report cluster compliance status to policy service.
   * store.policy.core.windows.net: HTTPS 443 - This address is used to pull the Gatekeeper artifacts of built-in policies.
   * dc.services.visualstudio.com: HTTPS 443 - Azure Policy add-on that sends telemetry data to applications insights endpoint.
   * motd.ubuntu.com:  HTTPS 443 - is a package that makes a call periodically to Canonical servers to get updated news for support and informational purposes.
   * optional rule windows server node pool: HTTPS 443 - onegetcdn.azureedge.net, go.microsoft.com - To install windows-related binaries
   * optional rule windows server node pool: HTTP 80 - *.mp.microsoft.com, www.msftconnecttest.com, ctldl.windowsupdate.com - To install windows-related binaries
   * optional rules: HTTP 80 - security.ubuntu.com, azure.archive.ubuntu.com, changelogs.ubuntu.com - This address lets the Linux cluster nodes download the required security patches and updates.

2. Azure Kubernetes service Component will deploy the following resources:

* Resource Group for Azure Kubernetes Cluster - Optional resource creation
* Private Kubernetes Cluster - A private cluster uses an internal IP address to ensure that network traffic between the API server and node pools remains on a private network only.
* Resource Group Node Pool with the following components
   * Kubelet Managed Indentity
   * Ingress Application Gateway Managed Identity
   * Azure Policy Managed Identity
   * Oms Agent Managed Identity
   * Private endpoint
   * Private DNS zone
   * Kube Api server Network interface subnet node pool
   * Network security group
* Log Analytics Solution
* Monitor Diagnostic Settings - "kube-apiserver","kube-audit","kube-audit-admin","kube-controller-manager","kube-scheduler","cluster-autoscaler","guard"

3. Azure Kubernetes service Component will deploy the resources with the following Configurations:

* Private Cluster Enabled
* Egress traffic userDefinedRouting (UDR)
* Local Account Disabled
* Public fqdn Disabled
* Manage Identity SystemAssigned
* RBAC &  AAD Enabled
* Network Plugins Azure CNI
* Network Policy Azure
* Add-on ingress_application_gateway Enabled
* Add-on oms_agent Enabled 
* Add-onh http application routing Disabled
* Add-on kube_dashboard Disabled
* Default Node Pool Public Ip Disabled
* Default Node Pool only critical addons Enabled
```

#### Note:
To add windows node pool to kubernetes cluster, it needs Terraform version 0.15 or later.

// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************

// Required Variables Azure Kubernetes Services
//**********************************************************************************************
variable "cl_kubernetes_postfix" {
  description = "(Required) A string that is appended to the end of the aks name to identify it."
  type        = string
}
variable "cl_kubernetes_logging_rg_name"{
  description = "(Required) Specifies monitor components resource group"
  type        = string
}
variable "cl_kubernetes_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
  type        = string
}
variable "cl_kubernetes_log_analytics_workspace_name" {
  description = "(Required) The the log analytics workspace name for diagnostics."
  type        = string
}
//**********************************************************************************************

// Optional Variables
//**********************************************************************************************
// Azure Kubernetes Services Cluster variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_kubernetes_deploy_rg" {
  description = "(Optional) A boolean to enable/disable the deployment of a resource group for AKS."
  default     = true
}
variable "cl_kubernetes_rg_name" {
  description = "(Optional) The name of the aks resource group if cl_aks_services_deploy_rg = false."
  default     = null
}
variable "cl_kubernetes_kubernetes_version" {
  description = "(Optional) Version of Kubernetes specified when creating the AKS managed cluster. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade)."
  type        = string
  default     = "1.16.9"  
}
variable "cl_kubernetes_private_cluster_enabled"{
  description = "(Optional)This provides a Private IP Address for the Kubernetes API on the Virtual Network where the Kubernetes Cluster is located. Defaults to false. Changing this forces a new resource to be created."
  type        = bool
  default     = true
}
//One of dns_prefix or dns_prefix_private_cluster must be specified.
variable "cl_kubernetes_dns_prefix"{
  description = "(Optional) DNS prefix specified when creating the managed cluster. Changing this forces a new resource to be created. The dns_prefix must contain between 3 and 45 characters, and can contain only letters, numbers, and hyphens. It must start with a letter and must end with a letter or a number."
  type        = string
  default     = null
}
variable "cl_kubernetes_dns_prefix_private_cluster"{
  description = "(Optional) Specifies the DNS prefix to use with private clusters. Changing this forces a new resource to be created."
  type        = string
  default     = null
}
variable "cl_kubernetes_automatic_channel_upgrade"{
  description = "(Optional) The upgrade channel for this Kubernetes Cluster. Possible values are patch, rapid, node-image and stable. Cluster Auto-Upgrade will update the Kubernetes Cluster (and it's Node Pools) to the latest GA version of Kubernetes automatically."
  type        = string      
  default     = null
}
variable "cl_kubernetes_api_server_authorized_ip_ranges" {
  description = " (Optional) The IP ranges to allow for incoming traffic to the server nodes."
  type        = list(string)
  default     = []   
}
variable "cl_kubernetes_disk_encryption_set_id" {
  description = "(Optional) The ID of the Disk Encryption Set which should be used for the Nodes and Volumes."
  type        = string
  default     = null  
}
variable "cl_kubernetes_local_account_disabled" {
  description = "(Optional) Is local account disabled for AAD integrated kubernetes cluster"
  type        = bool
  default     = true    
}

//It should always be empty for public cluster"
variable "cl_kubernetes_private_dns_zone_id" {
  description = "(Optional) Either the ID of Private DNS Zone which should be delegated to this Cluster, System to have AKS manage this or None. In case of None you will need to bring your own DNS server and set up resolving, otherwise cluster will have issues after provisioning."
  type        = string
  default     = "System"  
}
//This requires that the Preview Feature Microsoft.ContainerService/EnablePrivateClusterPublicFQDN is enabled and the Resource Provider is re-registered, see the documentation for more information. If you use BYO DNS Zone, AKS cluster should either use a User Assigned Identity or a service principal (which is deprecated) with the Private DNS Zone Contributor role and access to this Private DNS Zone. If UserAssigned identity is used - to prevent improper resource order destruction - cluster should depend on the role assignment.
variable "cl_kubernetes_private_cluster_public_fqdn_enabled" {
  description = "(Optional) Specifies whether a Public FQDN for this Private Cluster should be added. Defaults to false."
  type        = bool
  default     = false  
}
variable "cl_kubernetes_sku_tier" {
  description = "(Optional) The SKU Tier that should be used for this Kubernetes Cluster. Possible values are Free and Paid (which includes the Uptime SLA). Defaults to Free."
  type        = string
  default     = null  
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - default_node_pool block
//**********************************************************************************************
//Every AKS cluster must contain at least one system node pool with at least one node. If you run a single system node pool for your AKS cluster in a production environment, we recommend you use at least three nodes for the node pool.
//The name of a node pool may only contain lowercase alphanumeric characters and must begin with a lowercase letter. For Linux node pools, the length must be between 1 and 12 characters. 
variable "cl_kubernetes_default_node_pool_name"{
  description = "(Optional)The name which should be used for the default Kubernetes Node Pool. Changing this forces a new resource to be created."
  type        = string
  default     = "systempool"
}
variable "cl_kubernetes_default_node_pool_node_count" {
  description = "(Optional) The initial number of nodes which should exist in this Node Pool. If specified this must be between 1 and 1000 and between min_count and max_count"
  type        = number
  default     = 3
}
variable "cl_kubernetes_default_node_pool_vm_size" {
  description = "(Optional)The size of the Virtual Machine, such as Standard_DS2_v2"
  type        = string
  default     = "standard_ds2_v2"
}
variable "cl_kubernetes_default_node_pool_type"{
  description = "(Optional) The type of Node Pool which should be created. Possible values are AvailabilitySet and VirtualMachineScaleSets. Defaults to VirtualMachineScaleSets."
  type        = string
  default     = "VirtualMachineScaleSets"
}
variable "cl_kubernetes_default_node_pool_vnet_subnet_id"{
  description = "(Optional) The ID of a Subnet where the Kubernetes Node Pool should exist. Changing this forces a new resource to be created."
  type        = string
  default     = ""
}
variable "cl_kubernetes_default_node_pool_availability_zones" {
  description = "(Optional) A list of Availability Zones across which the Node Pool should be spread. Changing this forces a new resource to be created."
  type        = list(string)
  default     = []
}
variable "cl_kubernetes_default_node_pool_os_disk_size_gb" {
  description = "(Optional) The size of the OS Disk which should be used for each agent in the Node Pool. Changing this forces a new resource to be created."
  type        = number
  default     = 256
}
variable "cl_kubernetes_default_node_pool_enable_auto_scaling"{
  description = "(Optional) Should the Kubernetes Auto Scaler be enabled for this Node Pool? Defaults to false. If you're using AutoScaling, you may wish to use Terraform's ignore_changes functionality to ignore changes to the node_count field."
  type        =  bool
  default     =  true
}
variable "cl_kubernetes_default_node_pool_enable_host_encryption"{
  description = "(Optional) Should the nodes in the Default Node Pool have host encryption enabled? Defaults to false. Encryption at host feature must be enabled on the subscription: https://docs.microsoft.com/azure/virtual-machines/linux/disks-enable-host-based-encryption-cli"
  type        =  bool
  default     =  false
}
variable "cl_kubernetes_default_node_pool_enable_node_public_ip"{
  description = "(Optional) Should each node have a Public IP Address? Defaults to false."
  type        = bool
  default   = false
} 
variable "cl_kubernetes_default_node_pool_fips_enabled" {
  description = "(Optional) Should the nodes in this Node Pool have Federal Information Processing Standard enabled? Changing this forces a new resource to be created.FIPS support is in Public Preview"
  type        =  bool
  default     = false  
}
variable "cl_kubernetes_default_node_pool_kubelet_disk_type" {
  description = "(Optional) The type of disk used by kubelet. At this time the only possible value is OS."
  type        = string
  default     = null 
}
variable "cl_kubernetes_default_node_pool_max_pods" {
  description = "(Optional) The maximum number of pods that can run on each agent. Changing this forces a new resource to be created."
  type        = number
  default     = 110
}
variable "cl_kubernetes_default_node_pool_node_public_ip_prefix_id" {
  description = "(Optional) Resource ID for the Public IP Addresses Prefix for the nodes in this Node Pool."
  type        = string
  default     = null  
}
variable "cl_kubernetes_default_node_pool_node_labels" {
  description = "(Optional) A map of Kubernetes labels which should be applied to nodes in the Default Node Pool. Changing this forces a new resource to be created."
  type        = map(string)
  default     = {}
}
//isolate critical system pods from your application pods, for enforce this behavior Use the CriticalAddonsOnly=true:NoSchedule taint to prevent application pods from being scheduled on system node pools.
variable "cl_kubernetes_default_node_pool_only_critical_addons_enabled" {
  description = "(Optional) Enabling this option will taint default node pool with CriticalAddonsOnly=true:NoSchedule taint. Changing this forces a new resource to be created."
  type        = bool
  default     = true 
}
//This version must be supported by the Kubernetes Cluster - as such the version of Kubernetes used on the Cluster/Control Plane may need to be upgraded first.
variable "cl_kubernetes_default_node_pool_orchestrator_version"{
  description = "(Optional) Version of Kubernetes used for the Agents. If not specified, the latest recommended version will be used at provisioning time (but won't auto-upgrade)"
  type        = string
  default     = null
}
variable "cl_kubernetes_default_node_pool_os_disk_type" {
  description = "(Optional) The type of disk which should be used for the Operating System. Possible values are Ephemeral and Managed. Defaults to Managed. Changing this forces a new resource to be created."
  type        = string
  default     = "Managed"  
}
variable "cl_kubernetes_default_node_pool_os_sku"{
  description = "(Optional) OsSKU to be used to specify Linux OSType. Not applicable to Windows OSType. Possible values include: Ubuntu, CBLMariner. Defaults to Ubuntu. Changing this forces a new resource to be created."
  type        = string
  default     = "Ubuntu"
}
//This requires that the Preview Feature Microsoft.ContainerService/PodSubnetPreview is enabled and the Resource Provider is re-registered.
variable "cl_kubernetes_default_node_pool_pod_subnet_id"{
  description = "(Optional) The ID of the Subnet where the pods in the default Node Pool should exist. Changing this forces a new resource to be created."
  type        = string
  default     = null
}
variable "cl_kubernetes_default_node_pool_ultra_ssd_enabled" {
  description = "(Optional) Used to specify whether the UltraSSD is enabled in the Default Node Pool. Defaults to false."
  type        = bool
  default     = false  
}
//If enable_auto_scaling is set to true, then the following fields can also be configured:
variable "cl_kubernetes_default_node_pool_max_count" {
  description = "(Required) The maximum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be greater than or equal to min_count."
  type        = number
  default     = 5
}
variable "cl_kubernetes_default_node_pool_min_count" {
  description = "(Required) The minimum number of nodes which should exist within this Node Pool. Valid values are between 0 and 1000 and must be less than or equal to max_count."
  type        = number
  default     = 1
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - default_node_pool block - upgrade_settings
//**********************************************************************************************
//Max surge percent values can be a minimum of 1% and a maximum of 100%. For production node pools, we recommend a max_surge setting of 33%. If a percentage is provided, the number of surge nodes is calculated from the node_count value on the current cluster. Node surge can allow a cluster to have more nodes than max_count during an upgrade. Ensure that your cluster has enough IP space during an upgrade.
variable "cl_kubernetes_default_node_pool_upgrade_max_surge" {
  description = "(Optional) The maximum number or percentage of nodes which will be added to the Node Pool size during an upgrade"
  type        = string
  default     = null
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - default_node_pool block - kubelet_config
//**********************************************************************************************

//allowed_unsafe_sysctls: Specifies the allow list of unsafe sysctls command or patterns (ending in *). Changing this forces a new resource to be created."
//container_log_max_line:Specifies the maximum number of container log files that can be present for a container. must be at least 2. Changing this forces a new resource to be created."
//container_log_max_size_mb: Specifies the maximum size (e.g. 10MB) of container log file before it is rotated. Changing this forces a new resource to be created."
//cpu_cfs_quota_enabled:Is CPU CFS quota enforcement for containers enabled? Changing this forces a new resource to be created."
//cpu_cfs_quota_period: Specifies the CPU CFS quota period value. Changing this forces a new resource to be created."
//cpu_manager_policy: Specifies the CPU Manager policy to use. Possible values are none and static, Changing this forces a new"
//image_gc_high_threshold: Specifies the percent of disk usage above which image garbage collection is always run. Must be between 0 and 100. Changing this forces a new resource to be created."
//image_gc_low_threshold: Specifies the percent of disk usage lower than which image garbage collection is never run. Must be between 0 and 100. Changing this forces a new resource to be created."
//pod_max_pid: Specifies the maximum number of processes per pod. Changing this forces a new resource to be created."
//topology_manager_policy: Specifies the Topology Manager policy to use. Possible values are none, best-effort, restricted or single-numa-node. Changing this forces a new resource to be created."

variable "cl_kubernetes_kubelet_config" {
  type = map(object({
    allowed_unsafe_sysctls      = list(string)
    container_log_max_line      = number
    container_log_max_size_mb   = number
    cpu_cfs_quota_enabled       = bool
    cpu_cfs_quota_period        = string  
    cpu_manager_policy          = string
    image_gc_high_threshold     = number
    image_gc_low_threshold      = number
    pod_max_pid                 = number
    topology_manager_policy     = string
  }))
  description = "(Optional) Customizing your node configuration allows you to configure or tune your operating system (OS) settings or the kubelet parameters to match the needs of the workloads. When you create an AKS cluster or add a node pool to your cluster, you can customize a subset of commonly used OS and kubelet settings. To configure settings beyond this subset."
  default     = {}
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - RBAC azure_active_directory block
//**********************************************************************************************
variable "cl_kubernetes_rbac_aad_enable"{
  description = "(Optional)Is Role Based Access Control Enabled. Changing this forces a new resource to be created."
  type        = bool
  default     = true
}
variable "cl_kubernetes_rbac_aad_managed"{
  description = "(Optional) When managed is set to true the following properties can be specified:admin_group_object_ids and azure_rbac_enabled, When managed is set to false the following properties can be specified:Client_app_id, Server_app_id and Server_app_secret."
  type        = bool
  default     = true
}
variable "cl_kubernetes_rbac_aad_admin_group_object_ids"{
  description = "(Optional) A list of Object IDs of Azure Active Directory Groups which should have Admin Role on the Cluster."
  type        = list(string)
  default     = []
}
variable "cl_kubernetes_rbac_aad_client_app_id"{
  description = "(Optional) The Client ID of an Azure Active Directory Application. When managed is set to false"
  type        = string
  default     = ""
} 
variable "cl_kubernetes_rbac_aad_server_app_id"{
  description = "(Optional) The Server ID of an Azure Active Directory Application. When managed is set to false"
  type        = string
  default     = ""
} 
variable "cl_kubernetes_rbac_aad_server_app_secret"{
  description = "(Optional) The Server Secret of an Azure Active Directory Application. When managed is set to false"
  type        = string
  default     = ""
} 
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - service_principal block
//**********************************************************************************************
//you can setup service_principal or identity. Not both at the same time.
variable "cl_kubernetes_service_principal_client_id"{
  description = "(Optional) The Client ID for the Service Principal."
  type        = string
  default     = ""
} 
variable "cl_kubernetes_service_principal_client_secret"{
  description = "(Optional) The Client Secret for the Service Principal."
  type        = string
  default     = ""
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - identity block
//**********************************************************************************************
//you can setup service_principal or identity. Not both at the same time.
variable "cl_kubernetes_identity_type"{
  description = "(Optional) The type of identity used for the managed cluster. Possible values are SystemAssigned and UserAssigned. If UserAssigned is set, a user_assigned_identity_id must be set as well."
  type        = string
  default     = null
}
variable "cl_kubernetes_user_assigned_identity_id"{
  description = "(Optional) The ID of a user assigned identity."
  type        = string
  default     = null
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - Linux_profile block
//**********************************************************************************************
variable "cl_kubernetes_linux_profile" {
  description = "(Optional) Username and ssh key for accessing Linux machines with ssh."
  type = object({
    username = string
    ssh_key  = string
  })
  default = null
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - Windows_profile block
//**********************************************************************************************
variable "cl_kubernetes_windows_profile" {
  description = "(Optional) Admin username, password and license for Windows hosts."
  type = object({
    username = string
    password = string
    license  = string
  })
  default = null
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - maintenance_window block - allowed
//**********************************************************************************************
variable "cl_kubernetes_main_window_allowed" {
  description = "(Optional) Planned Maintenance allows you to schedule weekly maintenance windows that will update your control plane as well as your kube-system Pods on a VMSS instance and minimize workload impact."
  type        = object({
    day       = string
    hours     = list(string)
  })
  default     = {
    day       = "Sunday"
    hours     = [1,2]
  }
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - maintenance_window block - not allowed
//**********************************************************************************************
variable "cl_kubernetes_main_window_not_allowed" {
  description = "(Optional) Planned Maintenance allows you to schedule weekly maintenance windows that will update your control plane as well as your kube-system Pods on a VMSS instance and minimize workload impact."
  type        = object({
    end       = string
    start     = string
  })
  default     = {
    end       = "2021-05-30T12:00:00Z"
    start     = "2021-05-26T03:00:00Z"
  }
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - kubelet_identity block
//**********************************************************************************************
variable "cl_kubernetes_kubelet_identity" {
  description = "(Optional) Managed Identity to be assigned to the Kubelets. If not specified a Managed Identity is created automatically."
  type = object({
    client_id                 = string
    object_id                 = string
    user_assigned_identity_id = string
  })
  default = null
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - network_profile block
//**********************************************************************************************
variable "cl_kubernetes_network_profile_network_plugin"{
  description = "(Optional) If network_profile is not defined, kubenet profile will be used by default. Network plugin to use for networking. Currently supported values are azure and kubenet. Changing this forces a new resource to be created."
  type        = string
  default     = "azure"
}
variable "cl_kubernetes_network_profile_network_mode"{
  description = "(Optional) Network mode to be used with Azure CNI. Possible values are bridge and transparent. Changing this forces a new resource to be created."
  type        = string
  default     = "transparent"
}
variable "cl_kubernetes_network_profile_network_policy" {
  description = "(Optional) Sets up network policy to be used with Azure CNI. Network policy allows us to control the traffic flow between pods. Currently supported values are calico and azure. Changing this forces a new resource to be created."
  type        = string
  default     = "azure"  
}
variable "cl_kubernetes_network_profile_dns_service_ip"{
  description = "(Optional)The K8S's DNS Service IP, /24 represents 256 IPs. IP address within the Kubernetes service address range that will be used by cluster service discovery (kube-dns). Changing this forces a new resource to be created."
  type        = string
  default     = "60.0.0.12"
}
variable "cl_kubernetes_network_profile_docker_bridge_cidr" {
  description = "(Optional) The K8S's Docker bridge CIDR, /27 represents 32 IPs.  (Optional) IP address (in CIDR notation) used as the Docker bridge IP address on nodes. Changing this forces a new resource to be created."
  type        = string
  default     = "172.17.0.1/16"  
}
variable "cl_kubernetes_network_profile_outbound_type"{
  description = "(Optional) The outbound (egress) routing method which should be used for this Kubernetes Cluster. Possible values are loadBalancer and userDefinedRouting. Defaults to loadBalancer."
  type        = string
  default     = "userDefinedRouting"
}
variable "cl_kubernetes_network_profile_pod_cidr"{
  description = "(Optional) The CIDR to use for pod IP addresses. This field can only be set when network_plugin is set to kubenet. Changing this forces a new resource to be created."
  type        = string
  default     = ""
}
variable "cl_kubernetes_network_profile_service_cidr" {
  description = "(Optional) The K8S's Service CIDR, /24 represents 256 IPs. (Optional) The Network Range used by the Kubernetes service. Changing this forces a new resource to be created."
  type        = string
  default     = "60.100.0.0/16"
}
variable "cl_kubernetes_network_profile_load_balancer_sku"{
  description = "(Optional) Specifies the SKU of the Load Balancer used for this Kubernetes Cluster. Possible values are Basic and Standard. Defaults to Standard."
  type        = string
  default     = null
}
//**************************************************************************************************

// Azure Kubernetes Services Cluster variables - network_profile load_balancer_profile enabled block
//**************************************************************************************************

//outbound_ip_address_ids:The ID of the Public IP Addresses which should be used for outbound communication for the cluster load balancer."
//outbound_ports_allocated: Number of desired SNAT port for each VM in the clusters load balancer. Must be between 0 and 64000 inclusive. Defaults to 0."
//idle_timeout_in_minutes: Desired outbound flow idle timeout in minutes for the cluster load balancer. Must be between 4 and 120 inclusive. Defaults to 30."
//managed_outbound_ip_count: Count of desired managed outbound IPs for the cluster load balancer. Must be between 1 and 100 inclusive."
//outbound_ip_prefix_ids:The ID of the outbound Public IP Address Prefixes which should be used for the cluster load balancer."

variable "cl_kubernetes_load_balancer_profile" {
  type = map(object({
    outbound_ip_address_ids   =list(string)
    outbound_ports_allocated  = number
    idle_timeout_in_minutes   = number
    managed_outbound_ip_count = number
    outbound_ip_prefix_ids    =list(string) 
  }))
  description = "(Optional) Array for load_balancer_profile."
  default     = {}
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - auto_scaler_profile block
//**********************************************************************************************

//balance_similar_node_groups:Detect similar node groups and balance the number of nodes between them. Defaults to false."
//expander:Expander to use. Possible values are least-waste, priority, most-pods and random. Defaults to random."
//max_graceful_termination_sec:Maximum number of seconds the cluster autoscaler waits for pod termination when trying to scale down a node. Defaults to 600."
//max_node_provisioning_time:Maximum time the autoscaler waits for a node to be provisioned. Defaults to 15m."
//max_unready_nodes:Maximum Number of allowed unready nodes. Defaults to 3."
//max_unready_percentage:Maximum percentage of unready nodes the cluster autoscaler will stop if the percentage is exceeded. Defaults to 45."
//new_pod_scale_up_delay:For scenarios like burst/batch scale where you don't want CA to act before the kubernetes scheduler could schedule all the pods, you can tell CA to ignore unscheduled pods before they're a certain age. Defaults to 10s."
//scale_down_delay_after_add:How long after the scale up of AKS nodes the scale down evaluation resumes. Defaults to 10m."
//scale_down_delay_after_delete:How long after node deletion that scale down evaluation resumes. Defaults to the value used for scan_interval."
//scale_down_delay_after_failure:How long after scale down failure that scale down evaluation resumes. Defaults to 3m."
//scan_interval:How often the AKS Cluster should be re-evaluated for scale up/down. Defaults to 10s."
//scale_down_unready:How long an unready node should be unneeded before it is eligible for scale down. Defaults to 20m."
//scale_down_unneeded: How long a node should be unneeded before it is eligible for scale down. Defaults to 10m."
//scale_down_utilization_threshold: Node utilization level, defined as sum of requested resources divided by capacity, below which a node can be considered for scale down. Defaults to 0.5."
//empty_bulk_delete_max:Maximum number of empty nodes that can be deleted at the same time. Defaults to 10."
//skip_nodes_with_local_storage:If true cluster autoscaler will never delete nodes with pods with local storage, for example, EmptyDir or HostPath. Defaults to true."
//skip_nodes_with_system_pods:If true cluster autoscaler will never delete nodes with pods from kube-system (except for DaemonSet or mirror pods). Defaults to true."

variable "cl_kubernetes_auto_scaler_profile" {
  type = map(object({
    balance_similar_node_groups      = bool
    expander                         = string
    max_graceful_termination_sec     = number
    max_node_provisioning_time       = string
    max_unready_nodes                = number
    max_unready_percentage           = number
    new_pod_scale_up_delay           = string
    scale_down_delay_after_add       = string
    scale_down_delay_after_delete    = string
    scale_down_delay_after_failure   = string
    scan_interval                    = string 
    scale_down_unready               = string
    scale_down_unneeded              = string
    scale_down_utilization_threshold = string
    empty_bulk_delete_max            = number
    skip_nodes_with_local_storage    = bool
    skip_nodes_with_system_pods      = bool
  }))
  description = "(Optional) The cluster autoscaler profile affects all node pools that use the cluster autoscaler. You can't set an autoscaler profile per node pool. auto_scaler_profile can configure more granular details of the cluster autoscaler by changing the default values in the cluster-wide autoscaler profile. For example, a scale down event happens after nodes are under-utilized after 10 minutes. If you had workloads that ran every 15 minutes, you may want to change the autoscaler profile to scale down under utilized nodes after 15 or 20 minutes. When you enable the cluster autoscaler, a default profile is used unless you specify different settings. for more information https://docs.microsoft.com/en-us/azure/aks/cluster-autoscaler"
  default     = {}
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - addon_profile aci_connector_linux block
//**********************************************************************************************
variable "cl_kubernetes_addon_profile_acilnx_enabled"{
  description = "(Optional) Is the virtual node addon enabled"
  type        = bool
  default     = false
}
variable "cl_kubernetes_addon_profile_acilnx_subnet_name"{
  description = "(Optional) The subnet name for the virtual nodes to run. This is required when aci_connector_linux enabled argument is set to true."
  type        = string
  default     = ""
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - azure_policy block
//**********************************************************************************************
variable "cl_kubernetes_addon_profile_azure_policy_enabled"{
  description = "(Optional) Is the Azure Policy for Kubernetes Add On enabled. At this time Azure Policy is not supported in Azure US Government and it is in Public Preview"
  type        = bool
  default     = true 
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - http_application_routing  block
//**********************************************************************************************
//At this time HTTP Application Routing is not supported in Azure China or Azure US Government.
variable "cl_kubernetes_addon_profile_http_application_routing_enabled"{
  description = "(Optional) Is HTTP Application Routing Enabled. At this time HTTP Application Routing is not supported in Azure China or Azure US Government."
  type        = bool
  default     = false
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - kube_dashboard  block
//**********************************************************************************************
variable "cl_kubernetes_addon_profile_kube_dashboard_enabled"{
  description = "(Optional) Is the Kubernetes Dashboard enabled"
  type        = bool
  default     = false
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - oms_agent block
//**********************************************************************************************
variable "cl_kubernetes_addon_profile_oms_agent_enabled"{
  description = "(Optional) Is the OMS Agent Enabled"
  type        = bool
  default     = true
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - ingress_application_gateway block
//**********************************************************************************************
variable "cl_kubernetes_addon_profile_ingress_application_gateway_enabled"{
  description = "(Optional) Is the Application Gateway ingress controller integrated with this Kubernetes Cluster"
  type        = bool
  default     = false
}
variable "cl_kubernetes_addon_profile_ingress_application_gateway_effective_id"{
  description = "(Optional) The ID of the Application Gateway associated with the ingress controller deployed to this Kubernetes Cluster."
  type        = string
  default     = null
}
variable "cl_kubernetes_addon_profile_ingress_application_gateway_id"{
  description = "(Optional) The ID of the Application Gateway integrated with the ingress controller of this Kubernetes Cluster. This attribute is only set when gateway_id is specified when configuring the ingress_application_gateway addon."
  type        = string
  default     = null
} 
variable "cl_kubernetes_addon_profile_ingress_application_gateway_subnet_cidr"{
  description = "(Optional) The subnet CIDR used to create an Application Gateway, which in turn will be integrated with the ingress controller of this Kubernetes Cluster. This attribute is only set when subnet_cidr is specified when configuring the ingress_application_gateway addon."
  type        = string
  default     = null
}
variable "cl_kubernetes_addon_profile_ingress_application_gateway_subnet_id"{
  description = "(Optional) The ID of the subnet on which to create an Application Gateway, which in turn will be integrated with the ingress controller of this Kubernetes Cluster. This attribute is only set when subnet_id is specified when configuring the ingress_application_gateway addon"
  type        = string
  default     = null
}
//************************************************************************************************

// Azure Kubernetes Services Cluster variables - azure_keyvault_secrets_provider block
//**********************************************************************************************
variable "cl_kubernetes_addon_profile_azure_keyvault_secrets_provider_enabled"{
  description = "(Optional) Is the Azure Keyvault Secrets Providerenabled"
  type        = bool
  default     = true
}
variable "cl_kubernetes_addon_profile_azure_keyvault_secrets_provider_secret_rotation_enabled"{
  description = "(Optional) Is secret rotation enabled"
  type        = bool
  default     = false
}
variable "cl_kubernetes_addon_profile_azure_keyvault_secrets_provider_secret_rotation_interval"{
  description = "(Optional) The interval to poll for secret rotation. This attribute is only set when secret_rotation is true and defaults to 2m."
  type        = string
  default     = "2m"
}
//************************************************************************************************


//Azure Kubernetes Service route table variables
//**********************************************************************************************
variable "cl_kubernetes_latam_rt" {
  description = "(Optional) add route table for LATAM in true and is the value is false add route table for US"
  type        = bool
  default     = true  
}
variable "cl_kubernetes_rt_resource_group_name"{
  description = "(Optional) resource group for route table. Changing this forces a new resource to be created."
  type        = string
  default     = null
}
variable "cl_kubernetes_disable_bgp_route_propagation"{
  description = "(Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable"
  type        = bool
  default     = false
}
variable "cl_kubernetes_next_hop_in_ip_address"{
  description = "(Optional) Contains the IP address packets should be forwarded to. Next hop values are only allowed in routes where the next hop type is VirtualAppliance."
  type        = string
  default     = "10.0.0.4"
}
//**********************************************************************************************

//Associates Azure Kubernetes Service subnet with route table variables - AKS outbound traffic UDR
//************************************************************************************************
variable "cl_kubernetes_route_table_subnet"{
  description = "(Optional) The ID of the Subnet. Changing this forces a new resource to be created."
  type        = string
  default     = ""
}
//**********************************************************************************************

// Azure Kubernetes Services Cluster variables - diagnostics for AKS
//**********************************************************************************************
variable "cl_kubernetes_log_analytics_solutions" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    "ContainerInsights" = {
      publisher = "Microsoft"
      product   = "OMSGallery/ContainerInsights"
    }
  }
}

variable "cl_kubernetes_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["kube-apiserver","kube-audit","kube-audit-admin","kube-controller-manager","kube-scheduler","cluster-autoscaler","guard"]
    metrics = ["AllMetrics"]
  }
}
//**********************************************************************************************

// Local Variables
//**********************************************************************************************
locals {
    timeout_duration              = "2h"
}
//**********************************************************************************************
```

## Outputs

```terraform
// Outputs Azure Kubernetes Services
//**********************************************************************************************
output "cl_kubernetes_rg"{
  value = azurerm_resource_group.cl_kubernetes_rg
}
output "cl_kubernetes" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster
}
output "cl_kubernetes_id" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.id
}
output "cl_kubernetes_kube_admin_config" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.kube_admin_config
}
output "cl_kubernetes_kube_config" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.kube_config_raw
}
output "cl_kubernetes_client_key" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.kube_config.0.client_key
}
output "cl_kubernetes_client_certificate" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.kube_config.0.client_certificate
}
output "cl_kubernetes_cluster_ca_certificate" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.kube_config.0.cluster_ca_certificate
}
output "cl_kubernetes_host" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.kube_config.0.host
}
output "cl_kubernetes_addon_profile" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.addon_profile
}
output "cl_kubernetes_identity" {
  value = azurerm_kubernetes_cluster.cl_kubernetes_cluster.identity
}
output "cl_kubernetes_log_analytics_solution" {
  value = azurerm_log_analytics_solution.cl_kubernetes_log_analytics_solution
}
output "cl_kubernetes_diagnostic_settings"{
  value = azurerm_monitor_diagnostic_setting.cl_kubernetes_diagnostic_settings
}
//**********************************************************************************************
```

## Usage Azure Kubernetes private cluster integrated with a private Azure Container Registry and add-on AGIC Application Gateway

```terraform

resource "azurerm_subnet" "cl_azure_kubernetes_nodes_subnet" {
  name                                                   = "${var.env}-${var.postfix}-aks-nodes-sn"
  resource_group_name                                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                                   = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                       = ["10.66.0.0/20"]
  enforce_private_link_endpoint_network_policies         = true
  service_endpoints                                      = ["Microsoft.ContainerRegistry","Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.KeyVault"]
}

resource "azurerm_subnet" "private_endpoint_subnet" {
  name                                               = "private_endpoint_subnet"
  resource_group_name                                = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                               = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                                   = ["10.66.18.0/24"]
  enforce_private_link_endpoint_network_policies     = true
  service_endpoints                                  = ["Microsoft.ContainerRegistry"]
}

module "cl_azure_container_registry" {
    source                                                      = "../caf-tf-modules/cl_azure_container_registry"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
    cl_azure_container_registry_rg_name                         = module.cl_azure_kubernetes_service.cl_kubernetes_rg[0].name
    cl_azure_container_registry_log_analytics_workspace_id      = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_content_trust_enabled           = true
    cl_azure_container_registry_admin_enabled                   = false
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
    cl_azure_container_registry_allowed_vnet_ids                = [data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id]
    cl_azure_container_registry_allowed_subnets                 = [azurerm_subnet.private_endpoint_subnet.id]
    cl_azure_container_registry_public_network_access_enabled   = false
}

module "cl_app_gateway" {
  source                                      = "../tf-azure-component-library/components/cl_application_gateway"
  env                                         = var.env
  postfix                                     = var.postfix
  location                                    = var.location
  set_private_ip_listener                     = false
  cl_app_gateway_vnet_rg_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_vnet_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_gateway_subnet_address_prefix        = ["10.66.17.0/24"]
  cl_app_gateway_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_gateway_logging_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_gateway_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_app_gateway_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  cl_app_gateway_frontend_tls_cert            = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
  cl_app_gateway_frontend_tls_cert_pass       = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
}

module "cl_azure_kubernetes_service"{
   source                                                               = "../tf-azure-component-library/components/cl_azure_kubernetes_service"
   env                                                                  = var.env
   postfix                                                              = var.postfix
   location                                                             = var.location
   cl_kubernetes_deploy_rg                                              = true
   cl_kubernetes_postfix                                                = "demo"
   cl_kubernetes_kubernetes_version                                     = "1.20.9"
   cl_kubernetes_private_cluster_enabled                                = true
   cl_kubernetes_dns_prefix                                             = "${var.env}-${var.postfix}-aks-dns"
   cl_kubernetes_latam_rt                                               = true/false #true add route to LATAM and false add route to US
   cl_kubernetes_default_node_pool_node_count                           = 3
   cl_kubernetes_default_node_pool_vm_size                              = "Standard_D4ds_v4" 
   cl_kubernetes_default_node_pool_type                                 = "VirtualMachineScaleSets"
   cl_kubernetes_default_node_pool_availability_zones                   = [1]
   cl_kubernetes_default_node_pool_enable_auto_scaling                  = true
   cl_kubernetes_default_node_pool_min_count                            = 1
   cl_kubernetes_default_node_pool_max_count                            = 5
   cl_kubernetes_default_node_pool_upgrade_max_surge                    = "33%"
   cl_kubernetes_default_node_pool_vnet_subnet_id                       = azurerm_subnet.cl_azure_kubernetes_nodes_subnet.id  
   cl_kubernetes_network_profile_service_cidr                           = "10.0.0.0/16"
   cl_kubernetes_network_profile_dns_service_ip                         = "10.0.0.12"
   cl_kubernetes_network_profile_docker_bridge_cidr                     = "172.17.0.1/16"
   cl_kubernetes_logging_rg_name                                        = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
   cl_kubernetes_log_analytics_workspace_id                             = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
   cl_kubernetes_log_analytics_workspace_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
   cl_kubernetes_identity_type                                          = "SystemAssigned"
   cl_kubernetes_addon_profile_ingress_application_gateway_enabled      = true
   cl_kubernetes_addon_profile_ingress_application_gateway_id           = module.cl_app_gateway.cl_app_gateway.id
   cl_kubernetes_addon_profile_azure_policy_enabled                     = true
   cl_kubernetes_rbac_aad_managed                                       = true
   cl_kubernetes_route_table_subnet                                     = azurerm_subnet.cl_azure_kubernetes_nodes_subnet.id  
   cl_kubernetes_rt_resource_group_name                                 = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

module "cl_azure_kubernetes_service_node_pool"{
   source                                               = "../tf-azure-component-library/components/cl_azure_kubernetes_service_node_pool"
   env                                                  = var.env
   postfix                                              = var.postfix
   location                                             = var.location
   cl_kubernetes_node_pool_name                         = "internal"
   cl_kubernetes_node_pool_kubernetes_cluster_id        =  module.cl_azure_kubernetes_service.cl_kubernetes_id
   cl_kubernetes_node_pool_vm_size                      = "Standard_B2s"
   cl_kubernetes_node_pool_availability_zones           = [1]
   cl_kubernetes_node_pool_os_disk_size_gb              = 256
   cl_kubernetes_node_pool_enable_auto_scaling          = true
   cl_kubernetes_node_pool_enable_host_encryption       = false
   cl_kubernetes_node_pool_enable_node_public_ip        = false
   cl_kubernetes_node_pool_os_disk_type                 = "Managed"
   cl_kubernetes_node_pool_os_sku                       = "Ubuntu"
   cl_kubernetes_node_pool_os_type                      = "Linux"
   cl_kubernetes_node_pool_mode                         = "User"
   cl_kubernetes_node_pool_node_count                   = 3
   cl_kubernetes_node_pool_max_count                    = 5
   cl_kubernetes_node_pool_min_count                    = 1
   cl_kubernetes_node_pool_max_pods                     = 110
   cl_kubernetes_node_pool_max_surge                    = "33%"
   cl_kubernetes_node_pool_priority                     = "Regular"
}
```
# Azure Active Directory Component

Azure Active Directory (Azure AD) is an enterprise identity service that manages your organization's user lifecycle. The Azure AD Terraform provider lets organization administrators manage users, groups, service principals, and applications as code.


For more information, please visit: https://learn.microsoft.com/en-us/azure/active-directory/fundamentals/

## Inputs

```terraform
// Required Variables
//
**********************************************************************************************


variable "aadusers" {
  type        = map(any)
  description = "(Required) Azure active directory users "
}

variable "aadgroups" {
  type        = map(any)
  description = "(Required) azure active directory groups"
}


variable "aad_groups_users" {
  type        = map(any)
  description = "(Required) Adding users into azure active directory groups"
}


//
**********************************************************************************************
```



```terraform
// Optional Variables
//
**********************************************************************************************


variable "force_password_change" {
  type        = bool
  description = "(Optional) During user creation, user is forced to change the password during the next sign-in for xoriant users"

}

variable "usage_location" {
  type        = string
  description = "(Optional) The usage location of the xoriant user.The usage location is a two letter country code"
}

variable "prevent_duplicate_names" {
  type        = string
  description = "(Optional) For azure active directory groups variable return an error if existing group is found with the same name."
}

variable "storage_tfstate_accounts" {}
variable "spn_role" {} (Optional)
variable "spn_owners" {} (Optional)


//
**********************************************************************************************
```


## Usage

```terraform
// Azure Active Directory 
//
**********************************************************************************************

module "ad" {

    source = "../cat-tf-modules/ad"
    aadusers = " "
    aadgroups = " "
    aad_groups_users = " "

}

//
**********************************************************************************************
```






















# Azure Database for MariaDB servers

Azure Database for MariaDB is a relational database service based on the open-source MariaDB Server engine. 
It's a fully managed database as a service offering that can handle mission-critical workloads with predictable performance and dynamic scalability. 
This component will deploy the MariaDB server, configures the vnet rules, firewall rules, private endpoint and diagnostic settings for that resource.

For more information, please visit: https://docs.microsoft.com/en-us/azure/mariadb/overview 
## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
  type = string
}
variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
  type = string
}
variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
  type = string
}
//**********************************************************************************************

// Required Variables
//**********************************************************************************************
variable "cl_mariadb_server_postfix" {
  description = "(Required) A string that is appended to the end of the the MariaDB Server name to identify it."
  type        = string
}
variable "cl_mariadb_server_administrator_login" {
  description = "(Required) Login to authenticate for the MariaDB Server. Changing this forces a new resource to be created."
  type        = string
}
variable "cl_mariadb_server_administrator_password" {
  description = "(Required) The Password associated with the administrator_login for the MariaDB Server."
  type        = string
}
variable "cl_mariadb_server_log_analytics_workspace_id" {
  description = "(Required) The ID for the network resources"
  type        = string
}
variable "cl_mariadb_server_resource_group_name" {
  description = "(Required) Specifies the Azure Database for MariaDB servers resource group"
  type        = string
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "cl_mariadb_server_public_network_access_enabled" {
  description = "(Optional) Whether or not public network access is allowed for this server."
  type        = bool
  default     = false
}
variable "cl_mariadb_server_sku_name" {
  description = "Specifies the SKU Name for this MariaDB Server. tier + family + cores pattern  B_Gen4_1, GP_Gen5_8, GP_Gen5_2"
  default     = "GP_Gen5_2"
  type        = string
}
variable "cl_mariadb_server_storage_mb" {
  description = <<EOD
    Max storage allowed for a server. Possible values are:
      - between 5120 MB(5GB) and 1048576 MB(1TB) for the Basic SKU
      - between 5120 MB(5GB) and 4194304 MB(4TB) for General Purpose/Memory Optimized SKUs
EOD
  default     = 5120
  type        = number
}
variable "cl_mariadb_server_backup_retention_days" {
  description = "Backup retention days for the server, supported values are between 7 and 35 days."
  default     = 7
  type        = number
}
variable "cl_mariadb_server_geo_redundant_backup" {
  description = "Enable Geo-redundant or not for server backup. Valid values for this property are Enabled or Disabled, not supported for the basic tier."
  default     = true
  type        = bool
}
variable "cl_mariadb_server_auto_grow" {
  description = "Whether autogrow is true"
  default     = true
  type        = bool
}
variable "cl_mariadb_server_server_version" {
  description = "Specifies the version of MariaDB to use."
  default     = "10.3"
  type        = string
}
variable "cl_mariadb_server_ssl_enforcement" {
  description = "Specifies if SSL should be enforced on connections. Possible values are true and false."
  default     = true
  type        = bool
}
variable "cl_mariadb_server_firewall_rules" {
  type = map(object({
    start_ip = string
    end_ip   = string
  }))
  description = "(Optional) Define additional firewall rules. It'll only work if you have public network enabled"
  default     = {}
}
variable "cl_mariadb_server_vnet_rules" {
  type        = list(string)
  description = "(Optional) Define additional virtual network rules. It'll only work if you have public network enabled"
  default     = []
}
variable "cl_mariadb_server_mariadb_configurations" {
  type = map(object({
    name  = string
    value = string
  }))
  description = "(Optional) Array for mariadb configurations."
  default = {
    configuration_1 = {
      name  = "audit_log_enabled"
      value = "ON"
    },
    configuration_2 = {
      name  = "audit_log_events"
      value = "CONNECTION,GENERAL"
    }
  }
}
variable "tags" {
  description = "Tags to apply to all resources"
  default     = {}
  type        = map(string)
}
variable "cl_mariadb_server_nacl_allowed_subnets" {
  type        = list(string)
  description = "(Optional) One or more Subnet ID's which should be able to access the Azure MariaDB Server."
  default     = []
}
variable "cl_mariadb_server_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string)
  default     = []
}
variable "cl_mariadb_server_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["MySqlSlowLogs", "MySqlAuditLogs"]
    metrics = ["AllMetrics"]
  }
}
variable "cl_mariadb_server_create_mode" {
  description = "(Optional) The creation mode. Can be used to restore or replicate existing servers. Possible values are Default, Replica, GeoRestore, and PointInTimeRestore. Defaults to Default."
  type = string
  default = "Default"
}
variable "cl_mariadb_server_creation_source_server_id" {
  description = "(Optional) For creation modes other than Default, the source server ID to use"
  type = string
  default = null
}
variable "cl_mariadb_server_restore_point_in_time" {
  description = "(Optional) When create_mode is PointInTimeRestore, specifies the point in time to restore from creation_source_server_id."
  type = string
  default = null
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
  timeout_duration = "2h"
}
//**********************************************************************************************
```

## Outputs


```terraform
//**********************************************************************************************
// Outputs
//**********************************************************************************************
output "cl_mariadb_server" {
  description = "MariaDB server"
  value       = azurerm_mariadb_server.cl_mariadb_server
}
output "cl_mariadb_server_server_fqdn" {
  description = "FQDN of MariaDB server"
  value       = azurerm_mariadb_server.cl_mariadb_server.fqdn
}
output "cl_mariadb_server_private_endpoint" {
  value = azurerm_private_endpoint.cl_mariadb_server_private_endpoint
}
output "cl_mariadb_server_firewall_rules" {
  value = azurerm_mariadb_firewall_rule.cl_mariadb_server_firewall_rules
}
output "cl_mariadb_server_vnet_rules" {
  value =azurerm_mariadb_virtual_network_rule.cl_mariadb_server_vnet_rules
}
output "cl_mariadb_server_diagnostic_setting" {
  value = azurerm_monitor_diagnostic_setting.cl_mariadb_server_diagnostic_setting
}
//**********************************************************************************************
```

## Usage

```terraform
//**********************************************************************************************
resource "azurerm_subnet" "cl_mariadb_private_subnet" {
  name                                           = "${var.env}-${var.postfix}-private-link-sn"
  resource_group_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  virtual_network_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  address_prefixes                               = ["60.0.1.0/24"]
  enforce_private_link_endpoint_network_policies = true
  service_endpoints                              = ["Microsoft.web", "Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.KeyVault"]
}

resource "azurerm_private_dns_zone" "mariadb_private_dns_zone" {
  name                = "privatelink.mariadb.database.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "mariadb_private_dns_vnet_link" {
  name                   = "${var.env}-${var.postfix}-private-dns-vnet-mariadb-link"
  resource_group_name    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name  = azurerm_private_dns_zone.mariadb_private_dns_zone.name
  virtual_network_id     = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}

module "cl_mariadb_server" {
  source                                                 = "../caf-tf-modules/cl_mariadb_server"
  env                                                    = var.env
  postfix                                                = var.postfix
  location                                               = var.location
  cl_mariadb_server_postfix                              = "global"
  cl_mariadb_server_log_analytics_workspace_id           = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_mariadb_server_administrator_login                  = "adminmariadb"
  cl_mariadb_server_administrator_password               = "Abc1234567890."
  cl_mariadb_server_resource_group_name                  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  cl_mariadb_server_nacl_allowed_subnets                 = [azurerm_subnet.cl_mariadb_private_subnet.id]
  cl_mariadb_server_firewall_rules                       = {
      allow_internal_usage = {
          start_ip = "60.0.1.0"
          end_ip   = "60.0.1.255"
    }
  }
  cl_mariadb_server_vnet_rules                           = [azurerm_subnet.cl_mariadb_private_subnet.id]  
  cl_mariadb_server_private_dns_zone_ids                 = [azurerm_private_dns_zone.mariadb_private_dns_zone.id]
}

resource "azurerm_private_dns_a_record" "mariadb_private_dns_record" {
  name                 = "${var.env}-${var.postfix}-mariadb-pe-record"
  zone_name            = azurerm_private_dns_zone.mariadb_private_dns_zone.name
  resource_group_name  = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ttl                  = 600
  records              = module.cl_mariadb_server.cl_mariadb_server_private_endpoint[*].private_service_connection[0].private_ip_address
}
//**********************************************************************************************
```
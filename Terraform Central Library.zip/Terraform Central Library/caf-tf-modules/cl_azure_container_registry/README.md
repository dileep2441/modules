# Azure Container Registry Component

Azure Container Registry (ACR) is a managed service that allows you to build, store, and manage docker container images/artifacts in a private registry for all types of container deployments. 
This component deploys Azure Container Registry with: IP rules, Content Trust option. Also Private DNS Zone, DNS Zone link for VNET's of allowed subnets, Diagnostic Settings and Private Endpoint for allowed Subnets.

For further detailed overview, please visit: https://docs.microsoft.com/en-us/azure/container-registry/ 

Important! If admin is enabled please store and maintain the user and password as secrets into a KeyVault.

Azure Defender only supported for Linux images with public and shell access:
https://docs.microsoft.com/en-us/azure/security-center/defender-for-container-registries-introduction

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_azure_container_registry_rg_name" {
    description = "(Required) The resource group for the datafactory."
}
variable "cl_azure_container_registry_log_analytics_workspace_id" {
    description = "(Required) The log analytics workspace ID required for PostgreSQL diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_azure_container_registry_sku" {
    type        = string
    description = "(Optional) Desire SKU for the Container Registry. Can be Basic, Standard or Premium."
    default     = "Premium"
}
variable "cl_azure_container_registry_allowed_subnets" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access this Container Registry."
    default     = []
}
variable "cl_azure_container_registry_allowed_vnet_ids" {
    type        = list(string)
    description = "(Optional) One or more VNET ID's which should be linked to the Private DNS Zone for ACR name resolution and access trough Private Endpoint."
    default     = []
}
variable "cl_azure_container_registry_network_rule_set_default_action" {
    type        = string
    description = "(Optional) The behaviour for requests matching no rules. Either Allow or Deny. Defaults to Deny"
    default     = "Deny"
}
variable "cl_azure_container_registry_admin_enabled" {
    description = "(Optional) Specifies whether the admin user is enabled."
    default     = false
}
variable "cl_azure_container_registry_ip_rule_action" {
    description = "(Optional) The action for the IP rule."
    default     = "Allow"
}
variable "cl_azure_container_registry_ip_rule_ranges" {
    description = "(Optional) The CIDR range for the IP rule."
    type        = list(string)
    default     = []
}
variable "cl_azure_container_registry_public_network_access_enabled" {
    description = "(Optional) Whether public network access is allowed for the container registry."
    default     = true
}
variable "cl_azure_container_registry_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default = {
        logs    = ["ContainerRegistryRepositoryEvents", "ContainerRegistryLoginEvents"]
        metrics = ["AllMetrics"]
    }
}
variable "cl_azure_container_registry_dns_zone_enabled"{
    description = "(Optional) Enabled creation of acr dns private zone."
    default     = true
}
variable "cl_azure_container_registry_private_dns_zone_id" {
    description = "(Optional) existing Private Dns zone id"
    default = null
}
variable "cl_azure_container_registry_dns_zone_name" {
    description = "Is the private link to be associated with the Private DNS Zone. By default it uses recommended Private DNS Zone name"
    type        = string
    default     = "privatelink.azurecr.io"
}
variable "cl_azure_container_registry_content_trust_enabled" {
    description = "(Optional) Enables content trust for the sign of images being pushed to the registry"
    type        = bool
    default     = false
}
variable "cl_azure_container_registry_key_vault_id" {
    description = "If admin user is enabled then Key Vault ID should be received in order to store user and pass secrets into it"
    type        = string
    default     = ""
}
//**********************************************************************************************


// Local Variables
//**********************************************************************************************
locals {
    timeout_duration = "2h"
}
//**********************************************************************************************
```

## Outputs

```terraform
output "cl_azure_container_registry" {
    value = azurerm_container_registry.cl_azure_container_registry
}
output "cl_azure_container_registry_private_dns_zone" {
    value = azurerm_private_dns_zone.cl_azure_container_registry_private_dns_zone
}
output "cl_azure_container_registry_private_endpoint" {
    value = azurerm_private_endpoint.cl_azure_container_registry_private_endpoint
}
output "cl_azure_container_registry_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_azure_container_registry_diagnostic_setting
}
output "cl_azure_container_registry_admin_username" {
    value = azurerm_container_registry.cl_azure_container_registry.admin_username
    sensitive = true
}
output "cl_azure_container_registry_admin_username" {
    value = azurerm_container_registry.cl_azure_container_registry.admin_password
    sensitive = true
}
```

## Usage

```terraform
module "cl_azure_container_registry" {
    source = "../caf-tf-modules/cl_azure_container_registry"
    env                                                    = var.env
    postfix                                                = var.postfix
    location                                               = var.location
    cl_azure_container_registry_rg_name                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
    cl_azure_container_registry_log_analytics_workspace_id = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_azure_container_registry_allowed_subnets            = [subnetID_1, subnetID_2, subnetID_N]
    cl_azure_container_registry_allowed_vnets              = [vnetID_1, vnetID_2, vnetID_N]
    cl_azure_container_registry_ip_rule_ranges             = ["CIDR_1", "CIDR_N"]
}
```
# Azure Storage Acccount Component

This is the Storage Account component. It will deploy Storage Account, Storage Files, Storage Queues, Monitor and Private Endpoint for Storage Account.

The following table describes the types of storage accounts, the services they support, and the supported deployment models for each account type:

Storage account type	                Supported services	                                    Supported performance tiers

General-purpose V2	                  Blob, File, Queue, Table, Disk, and Data Lake Gen22	    Standard, Premium

General-purpose V1	                  Blob, File, Queue, Table, and Disk	                    Standard, Premium

BlockBlobStorage                      Blob (block blobs and append blobs only)	              Premium 

FileStorage	                          File only	                                              Premium

BlobStorage	                          Blob (block blobs and append blobs only)	              Standard


Variables for enabled or disabled queue and file share creations into Storage account:

cl_storage_account_queue_enabled = true // Variable in true/false to enable or diabled queue creation

cl_storage_account_queue_monitor_enabled = false // Variable in true/false to enable or diabled monitor queue creation

cl_storage_account_share_enabled = true  // Variable in true/false to enable or diabled File share creation

For more information, please visit: https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
  description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
  description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
  description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_storage_account_resource_group_name" {
  description = "(Required) The name of the resource group where the storage account will be deployed to."
}
variable "cl_storage_account_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************

// Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}
variable "cl_storage_account_postfix" {
  description = "(Optional) A unique identifier for the storage account. Part of the naming scheme."
  type        = string
  default     = ""
}
variable "cl_storage_account_tier" {
  description = "(Optional) The pricing tier for the storage account."
  default     = "Standard"
}
variable "cl_storage_account_replication_type" {
  description = "(Optional) Defines the type of replication to use for this storage account."
  default     = "LRS"
}
variable "cl_storage_account_blob_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 365
}
variable "cl_storage_account_container_retention_days" {
  description = "Specifies the number of days that the blob should be retained, between `1` and `365` days. Defaults to `7`"
  default     = 7
  type        = number
}
variable "cl_storage_account_allowed_ips" {
  description = "(Optional) A list of Ip addresses that can access the storage account."
  type        = list(string)
  default     = []
}
variable "cl_storage_account_kind" {
  description = "(Optional)  Defines the Kind of account. Valid options are BlobStorage, BlockBlobStorage, FileStorage, Storage and StorageV2."
  default     = "StorageV2"
}
variable "cl_storage_account_access_tier" {
  description = "(Optional) Defines the access tier for BlobStorage, FileStorage and StorageV2 accounts. Valid options are Hot and Cool"
  default     = null
}
variable "cl_storage_account_tls_version" {
  description = "(Optional) The minimum supported TLS version for the storage account. Possible values are TLS1_0, TLS1_1, and TLS1_2."
  default     = "TLS1_2"
}
variable "cl_storage_account_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string) 
  default     = []  
}
variable "cl_storage_account_allowed_vnet_subnet_ids" {
  description = "(Optional) A list of subnets that can access the storage account."
  type        = list(string)
  default     = []
}
variable "cl_storage_account_allowed_pe_subnet_ids" {
  description = "(Optional) A list of subnets to create a Private endpoint that can access the storage account."
  type        = list(string)
  default     = []
}
variable "cl_storage_account_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["StorageRead","StorageWrite","StorageDelete"] 
    metrics = ["Transaction"]
  }
}
//**********************************************************************************************

//Optional - Azure Blob Storage Backup Variables
//**********************************************************************************************
variable "cl_storage_account_blob_enable_backup" {
  description = "(Optional) Toggle the blob storage backup feature."
  default     = false
}
variable "cl_storage_account_blob_backup_vault_id" {
   description = "The id of blob storage backup vault."
   default     = null
}
variable "cl_storage_account_blob_backup_vault" {
   description = "The blob storage backup vault."
   default     = null
}
variable "cl_storage_account_blob_backup_policy_id" {
   description = "The azure blob storage backup policy id from the backup vault."
   default     = null
}
//**********************************************************************************************

//Optional - Azure File Share Variables
//**********************************************************************************************
variable "cl_storage_account_share_enabled" {
  description = "If set to true, enable file shares."
  type        = bool
  default     = false
}
variable "cl_storage_account_large_file_share" {
  description = "Is Large File Share Enabled?"
  type        = bool
  default     = false
}
variable "cl_storage_account_file_shares" {
  type = map(object({
    name  = string
    quota  = number 
  }))
  description = "(Optional) Array for the creation of multiple file shares."
  default     = {}
}
//**********************************************************************************************

//Optional - Azure File Share Backup Variables
//**********************************************************************************************
variable "cl_storage_account_file_enable_backup" {
  description = "If set to true, enable file storage backup."
  type        = bool
  default     = false
}
variable "cl_storage_account_recovery_vault_name" {
  description = "(Optional) The name of backup recovery service vault."
  default     = null
}
variable "cl_storage_account_backup_policy_fileshare_id" {
  description = "(Optional) The azure file share backup policy from the recovery service vault."
  default     = null
}
variable "cl_storage_account_rg_backup_name" {
  description = "(Optional) The RG destination of the azure file share backup."
  default     = null
}
//**********************************************************************************************


// Optional - Azure Queue Variables
//**********************************************************************************************
variable "cl_storage_account_queues" {
	type        = list(string)
	default     = ["queue", "queue1"]
	description = "List of storages queue names."
}
variable "cl_storage_account_queue_enabled" {
  description = "(Optional) If set to true, create queues"
  type        = bool
  default     = false
}
variable "cl_storage_account_queue_monitor_enabled" {
  description = "(Optional) If set to true, create monitor queues"
  type        = bool
  default     = false
}
variable "cors_rule" {
	  description = "CORS rules for queue storage account."
	  type = list(object({
	    allowed_origins    = list(string),
	    allowed_methods    = list(string),
	    allowed_headers    = list(string),
	    exposed_headers    = list(string),
	    max_age_in_seconds = string
	  }))
	  default = []
}
variable "cl_storage_account_diagnostics_queues" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["StorageRead", "StorageWrite","StorageDelete"]
    metrics = ["AllMetrics"]
  }
}
//**********************************************************************************************

// Local Variables
//**********************************************************************************************
locals {
  timeout_duration                    = "2h"
  cl_storage_account_blob_properties  = (var.cl_storage_account_kind == "FileStorage" || var.cl_storage_account_blob_enable_backup ? false : true)
  cl_storage_account_queue_enabled  = (var.cl_storage_account_tier == "Standard" && var.cl_storage_account_kind != "BlobStorage" && var.cl_storage_account_queue_enabled ? true : false)
  cl_storage_account_name = {
        "sbox-pr"  = "sboxpr"
        "nprd-pr"  = "nprdpr"
        "nprd-dr"  = "nprddr"
        "prod-pr"  = "prodpr" 
        "prod-dr"  = "proddr"
        "nprod-pr" = "nprodpr"
    }
}
//**********************************************************************************************
```

## Outputs
```terraform
// Outputs
//**********************************************************************************************
output "cl_storage_account" {
    value = azurerm_storage_account.cl_storage_account
}
output "cl_storage_account_network_rules" {
    value = azurerm_storage_account_network_rules.cl_storage_account_network_rules
}
output "cl_storage_account_files" {
    value = azurerm_storage_share.cl_storage_account_files
}
output "cl_advanced_threat_protection" {
    value = azurerm_advanced_threat_protection.cl_advanced_threat_protection
}
output "cl_storage_account_protection_container" {
    value = azurerm_backup_container_storage_account.cl_storage_account_protection_container
}
output "cl_storage_account_protected_fileshare" {
    value = azurerm_backup_protected_file_share.cl_storage_account_protected_fileshare
}
 output "cl_storage_account_protected_blob" {
     value = azurerm_data_protection_backup_instance_blob_storage.cl_storage_account_protected_blob
 }
output "cl_storage_account_queues" {
    value = azurerm_storage_queue.cl_storage_account_queues
}
output "cl_storage_account_private_endpoint" {
    value = azurerm_private_endpoint.cl_storage_account_private_endpoint
}
output "cl_storage_account_file_share_private_endpoint" {
    value = azurerm_private_endpoint.cl_storage_account_file_share_private_endpoint
}
output "cl_storage_account_queue_private_endpoint" {
    value = azurerm_private_endpoint.cl_storage_account_queue_private_endpoint
}
output "cl_storage_account_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_storage_account_diagnostic_setting
}
output "cl_storage_account_queue_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_storage_account_queue_diagnostic_setting
}
//**********************************************************************************************
```

## Usage
#### Normal Usage (Blob Storage Backup Enabled)
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}


module "cl_storage_account" {
  source                                          = "../caf-tf-modules/cl_storage_account"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows xoriant addresses. need this for terraform to refresh current state
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.web_subnet.id]
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]  
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone.id]
  cl_storage_account_blob_enable_backup           = true
  cl_storage_account_blob_backup_vault_id         = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0].id
  cl_storage_account_blob_backup_vault            = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_vault[0]
  cl_storage_account_blob_backup_policy_id        = module.cl_azure_backup.cl_azure_backup_blob_sa_backup_policy[0].id
}
```

#### For File Share (File Storage Backup Enabled)
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone" {
  name                = "privatelink.file.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_storage_account" {
    source                                          = "../tf-azure-component-library/components/cl_storage_account"
    env                                             = var.env
    postfix                                         = var.postfix
    location                                        = var.location
    cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
    cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
    cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.web_subnet.id]
    cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]
    cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows xoriant addresses. need this for terraform to refresh current state
    cl_storage_account_share_enabled                = true
    cl_storage_account_file_shares                  = var.cl_storage_account_file_shares
    cl_storage_account_file_enable_backup           = true
    cl_storage_account_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
    cl_storage_account_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
    cl_storage_account_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
    cl_storage_account_large_file_share             = true
    cl_storage_account_tier                         = "Premium"
    cl_storage_account_kind                         = "FileStorage"
    cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone.id]
}
```
#### For Azure Queue Storage
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone" {
  name                = "privatelink.queue.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  tags                  = var.tags
}

module "cl_storage_account" {
  source                                          = "../tf-azure-component-library/components/cl_storage_account"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows xoriant addresses. need this for terraform to refresh current state
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]  
  cl_storage_account_queue_enabled                = true
  cl_storage_account_queue_monitor_enabled        = false
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone.id]
}
```
#### For Azure Queue Storage and File Share (File Storage Backup Enabled)
```terraform
resource "azurerm_private_dns_zone" "sa_private_dns_zone_file" {
  name                = "privatelink.file.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link_file" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone_file.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}

resource "azurerm_private_dns_zone" "sa_private_dns_zone_queue" {
  name                = "privatelink.queue.core.windows.net"
  resource_group_name = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "sa_private_dns_vnet_link_queue" {
  name                  = "${var.env}-${var.postfix}-private-dns-vnet-sa-link"
  resource_group_name   = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  private_dns_zone_name = azurerm_private_dns_zone.sa_private_dns_zone_queue.name
  virtual_network_id    = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
}

module "cl_storage_account" {
  source                                          = "../tf-azure-component-library/components/cl_storage_account"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_storage_account_resource_group_name          = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name 
  cl_storage_account_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  cl_storage_account_allowed_ips                  = ["199.206.0.0/15"] //allows xoriant addresses. need this for terraform to refresh current state
  cl_storage_account_allowed_vnet_subnet_ids      = [azurerm_subnet.test_subnet.id]
  cl_storage_account_allowed_pe_subnet_ids        = [azurerm_subnet.test_subnet.id]
  cl_storage_account_share_enabled                = true
  cl_storage_account_file_shares                  = var.cl_storage_account_file_shares
  cl_storage_account_file_enable_backup           = true
  cl_storage_account_rg_backup_name               = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_storage_account_recovery_vault_name          = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_storage_account_backup_policy_fileshare_id   = module.cl_azure_backup.cl_azure_backup_policy_fileshare[0].id
  cl_storage_account_tier                         = "Standard"
  cl_storage_account_kind                         = "StorageV2"
  cl_storage_account_queue_enabled                = true
  cl_storage_account_queue_monitor_enabled        = true
  cl_storage_account_private_dns_zone_ids         = [azurerm_private_dns_zone.sa_private_dns_zone_file.id, azurerm_private_dns_zone.sa_private_dns_zone_queue.id]
}
```

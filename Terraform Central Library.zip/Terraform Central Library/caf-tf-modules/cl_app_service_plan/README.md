# Azure App Service Plan Component

Azure App Service Plan is the container for hosting Web Apps, REST APIs, custom containers and Function Apps.
One or more apps can be configured to run on the same computing resources (or in the same App Service plan). 
This component will deploy an autoscalable App Service Plan and Diagnostics Settings.

https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//*********************************************************************************************
variable "cl_app_service_plan_app_postfix" {
    description = "(Required) The bespoke name of the app service plan you are deploying."
}
variable "cl_app_service_plan_logging_rg_name" {
    description = "(Required) The resource group for the app service plan log analytics solution."
}
variable "cl_app_service_plan_log_analytics_workspace_id" {
    description = "(Required) The the log analytics workspace ID for diagnostics."
}
//**********************************************************************************************


// Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "cl_app_service_plan_deploy_rg" {
  description = "(Optional) A boolean to enable/disable the deployment of a resource group for the App Service Plan."
  default     = true
}
variable "cl_app_service_plan_rg_name" {
  description = "(Optional) The name of the App Service Plan resource group if cl_app_service_plan_deploy_rg = false."
  default     = null
}
variable "cl_app_service_plan_kind" {
    description = "(Optional) The kind of the App Service Plan to create. Possible values are Windows (also available as App), Linux, elastic (for Premium Consumption) and FunctionApp (for a Consumption Plan). Defaults to Windows. Changing this forces a new resource to be created."
    default     = "Windows"
}
variable "cl_app_service_plan_max_elastic_workers" {
    description = "(Optional) The maximum number of total workers allowed for this ElasticScaleEnabled App Service Plan."
    type        = number
    default     = null
}
variable "cl_app_service_plan_reserved" {
    description = "(Optional) Is this App Service Plan Reserved. This has to be false if the kind is Windows."
    type        = bool
    default     = false
}
variable "cl_app_service_plan_per_site_scaling" {
    description = "(Optional) Can Apps assigned to this App Service Plan be scaled independently? If set to false apps assigned to this plan will scale to all instances of the plan."
    type        = bool
    default     = false
}
variable "cl_app_service_plan_deploy_integration_subnet" {
    description = "(Optional) A boolean that toggles the deployment of the vnet integration subnet."
    default     = true
}
variable "cl_app_service_plan_integration_vnet_rg_name" {
    description = "(Optional) The name of the VNet resource group where the app service subnet will be deployed into. cl_app_service_plan_deploy_integration_subnet needs to be set to true."
    default     = ""
}
variable "cl_app_service_plan_integration_vnet_name" {
    description = "(Optional) The name of the VNet where the app service subnet will be deployed into. cl_app_service_plan_deploy_integration_subnet needs to be set to true."
    default     = ""
}
variable "cl_app_service_plan_integration_subnet_prefix" {
    description = "(Optional) The CIDR prefix for the app service subnet. cl_app_service_plan_deploy_integration_subnet needs to be set to true. cl_app_service_plan_deploy_integration_subnet needs to be set to true."
    default     = ""
}
variable "cl_app_service_plan_integration_subnet_service_endpoints" {
    description = "(Optional) A list of service endpoints that is enabled in the subnet. cl_app_service_plan_deploy_integration_subnet needs to be set to true."
    default     = []
}
variable "cl_app_service_plan_route_table_id" {
    description = "(Optional) The ID of the route table that will be associated to the subnet"
    default     = ""
}
variable "cl_app_service_plan_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default = {
        logs    = [] //Is there any logs? No logs indicated while testing on portal
        metrics = ["AllMetrics"]
    }
}

// SKU Variables
// https://azure.microsoft.com/en-us/pricing/details/app-service/windows/
variable "cl_app_service_plan_sku_tier" {
    description = "(Optional) Specifies the plan's pricing tier."
    default     = "PremiumV2"
}
variable "cl_app_service_plan_sku_size" {
    description = "(Optional) Specifies the plan's instance size."
    default     = "P1v2"
}
variable "cl_app_service_plan_sku_capacity" {
    description = "(Optional) Specifies the number of workers associated with this App Service Plan."
    default     = 1
}

// Autoscale Variables
// https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_autoscale_setting
variable "cl_app_service_plan_deploy_autoscale_settings" {
    description = "(Optional) Choose to deploy autoscale settings or not. If the plan is serverless, this needs to be set to false"
    default     = true
}
variable "cl_app_service_plan_autoscale_settings_default" {
    description = "(Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 0 and 1000."
    default     = 1
}
variable "cl_app_service_plan_autoscale_settings_minimum" {
    description = "(Optional) The minimum number of instances for this resource. Valid values are between 0 and 1000."
    default     = 1
}
variable "cl_app_service_plan_autoscale_settings_maximum" {
    description = "(Optional) The maximum number of instances for this resource. Valid values are between 0 and 1000."
    default     = 10
}
variable "cl_app_service_plan_autoscale_settings_metric_name" {
    description = "(Optional) The name of the metric that defines what the rule monitors."
    default     = "CpuPercentage"
}
variable "cl_app_service_plan_autoscale_settings_time_grain" {
    description = "(Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string."
    default     = "PT1M"
}
variable "cl_app_service_plan_autoscale_settings_statistic" {
    description = "(Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max."
    default     = "Average"
}
variable "cl_app_service_plan_autoscale_settings_time_window" {
    description = "(Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string."
    default     = "PT5M"
}
variable "cl_app_service_plan_autoscale_settings_time_aggregation" {
    description = "(Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total."
    default     = "Average"
}
variable "cl_app_service_plan_autoscale_settings_scale_out_operator" {
    description = "(Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual."
    default     = "GreaterThan"
}
variable "cl_app_service_plan_autoscale_settings_scale_out_threshold" {
    description = "(Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action."
    default     = 75
}
variable "cl_app_service_plan_autoscale_settings_scale_in_operator" {
    description = "(Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual."
    default     = "LessThan"
}
variable "cl_app_service_plan_autoscale_settings_scale_in_threshold" {
    description = "(Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action."
    default     = 25
}
//**********************************************************************************************
```


## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_app_service_plan_rg" {
    value = azurerm_resource_group.cl_app_service_plan_rg
}
output "cl_app_service_plan" {
    value = azurerm_app_service_plan.cl_app_service_plan
}
output "cl_app_service_plan_diagnostic_setting" {
    value = azurerm_monitor_diagnostic_setting.cl_app_service_plan_diagnostic_setting
}
output "cl_app_service_plan_autoscale_settings" {
    value = azurerm_monitor_autoscale_setting.cl_app_service_plan_autoscale_settings
}
//**********************************************************************************************
```


## Usage
```terraform
// App Service Plan
//**********************************************************************************************
module "cl_app_service_plan" {
  source                                                    = "../caf-tf-modules/cl_app_service_plan"
  env                                                       = var.env
  postfix                                                   = var.postfix
  location                                                  = var.location
  cl_app_service_plan_app_postfix                           = var.asp_postfix
  cl_app_service_plan_deploy_integration_subnet             = true
  cl_app_service_plan_integration_vnet_rg_name              = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  cl_app_service_plan_integration_vnet_name                 = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  cl_app_service_plan_integration_subnet_prefix             = var.app_service_plan_integration_subnet_prefix
  cl_app_service_plan_int_subnet_user_defined_nsg_rules     = {
    allow_xoriant_inbound = {
      name                          = "allow-xoriant-inbound"
      priority                      = 1003
      direction                     = "Inbound"
      access                        = "Allow"
      protocol                      = "*"
      source_port_range             = null
      source_port_ranges            = ["80","8531","443","8530"]
      destination_port_range        = "*"    
      destination_port_ranges       = null
      source_address_prefix         = "10.1.1.22/24"
      source_address_prefixes       = null
      destination_address_prefix    = "10.69.2.96/27"
      destination_address_prefixes  = null
    }       
  } 
  cl_app_service_plan_integration_subnet_service_endpoints  = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  cl_app_service_plan_route_table_id                        = data.terraform_remote_state.core.outputs.core_latam_island.core_route_table.id
  cl_app_service_plan_kind                                  = var.app_service_plan_kind
  cl_app_service_plan_reserved                              = var.app_service_plan_reserved
  cl_app_service_plan_logging_rg_name                       = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  cl_app_service_plan_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  tags                                                      = var.tags
}
//**********************************************************************************************
```

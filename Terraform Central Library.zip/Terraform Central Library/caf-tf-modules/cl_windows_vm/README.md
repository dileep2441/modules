# Azure Windows VM Component

Windows virtual machine is a computer within a computer that provides the user the same experience they would have on the host operating system itself. 
Each virtual machine provides its own virtual hardware including CPUs, memory, hard drives, network interfaces, and other devices.
This Windows VM component will deploy a new resource group, Vnet, Subnet, Public IP, NIC Interface, Windows VM, Recovery Services Vault, Backup policy and a Backup Protected VM.

For more information, please visit: https://docs.microsoft.com/en-us/azure/virtual-machines/windows/overview 

## Inputs

```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************


// Required Variables
//**********************************************************************************************
variable "cl_windows_vm_image_id" {
  description = "(Required) The Windows image id to be used for the vm creation module."
}
variable "cl_windows_vm_app_name" {
  description = "(Required) A string that is appended to the end of the VM name to identify it."
}
variable "cl_windows_vm_vnet_name" {
  description = "(Required) The name of the core vnet required for the windows vm subnet."
}
variable "cl_windows_vm_vnet_rg_name" {
  description = "(Required) The name of the resource group that the core vnet is in."
}
variable "cl_windows_vm_log_analytics_workspace_id" {
  description = "(Required) The log analytics workspace ID for diagnostics."
}
variable "cl_windows_vm_log_analytics_primary_shared_key" {
  description = "(Required) The log analytics workspace primary shared key."
}
variable "cl_windows_vm_route_table_id" {
  description = "(Required) The ID of the route table from Core. required for subnet association."
}
variable "cl_windows_vm_computer_name" {
  description = "(Required) Specifies the Hostname which should be used for this Virtual Machine."
  type        = string
}
variable "cl_windows_vm_admin_user" {
  description = "(Required) The name of the windows OS admin."
  type        = string
}
variable "cl_windows_vm_admin_pass" {
  description = "(Required) The password of the windows OS admin."
  type        = string
}
variable "cl_windows_vm_availability_set_id" {
  description = "(Required) The ID of the availability set for the VM. Required for the VM provisioning."
}
//**********************************************************************************************


// Optional Variables - Bastion Connect
//**********************************************************************************************
// For Bastion Connection
variable "cl_windows_vm_deploy_subnet" {
  description = "(Optional) A boolean to enable/disable the deployment of a subnet for the VM."
  default     = false
}
variable "cl_windows_vm_deploy_subnet_nsg" {
  description = "(Optional) A boolean to enable/disable the deployment of a subnet NSG for the VM."
  default     = false
}
variable "cl_windows_vm_subnet_prefix" {
  description = "(Optional) The prefix of the windows vm subnet."
  default     = null
} 
variable "cl_windows_vm_bastion_enable" {
  description = "(Optional) Enable te creation for azure bastion"
  default = false
}
variable "cl_windows_vm_bastion_subnet_prefix" {
  description = "(Required) The subnet prefix for the bastion."
  default     = null
}
//**********************************************************************************************

// Additional Optional Variables
//**********************************************************************************************
variable "tags" {
  description = "(Optional) A mapping of tags to assign to all resources."
  type        = map
  default     = {}
}
variable "cl_windows_vm_deploy_rg" {
  description = "(Optional) A boolean to enable/disable the deployment of a resource group for the VM."
  default     = false
}
variable "cl_windows_vm_rg_name" {
  description = "(Optional) The name of the windows VM resource group if cl_windows_vm_deploy_rg = false."
  default     = null
}
variable "cl_windows_vm_subnet_id" {
  description = "(Optional) The subnet ID where the Windows VM will be deployed to. Use this only if cl_windows_vm_deploy_subnet = false."
  default     = null
}
variable "cl_windows_vm_azurerm_subnet_service_enpoints" {
  description = "(Optional) The Size of the windows vm."
  type        = list (string)
  default     = ["Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.ContainerRegistry", "Microsoft.KeyVault"]
}
variable "cl_windows_vm_size" {
  description = "(Optional) The Size of the windows vm."
  type        = string
  default     = "Standard_DS1_v2"
}
variable "cl_windows_vm_os_disk_caching" {
  description = "(Optional) The caching for the os disk of the windows vm."
  type        = string
  default     = "ReadWrite"
}
variable "cl_windows_vm_os_disk_storage_account_type" {
  description = "(Optional) The storage account type for the os disk of the windows vm."
  type        = string
  default     = "Standard_LRS"
}
variable "cl_windows_vm_os_disk_disk_size_gb" {
  description = "(Optional) The disk size gb for the os disk of the windows vm."
  default     = "128"
}
variable "cl_windows_vm_enable_automatic_updates" {
  type        = bool
  description = "(Optional) Boolean to enable automatic updates."
  default     = true
}
variable "cl_windows_vm_provision_vm_agent" {
  type        = bool
  description = "(Optional) Boolean to enable provision vm agent."
  default     = true
}
variable "cl_windows_vm_os_disk_write_accelerator_enabled" {
  type        = bool
  description = "(Optional) Boolean to enable write accelerator enabled."
  default     = false
}
variable "cl_windows_vm_timezone" {
  description = "(Optional) The timezone of the windows vm."
  default     = null
}
variable "cl_windows_vm_os_ultra_ssd_enabled" {
  type        = bool
  description = "(Optional) Boolean to enable ultra ssd enabled."
  default     = false
}
variable "cl_windows_vm_enable_domain_join"{
  description = "(Optional) Toggle the domain join feature."
  default     = false
}
variable "cl_windows_vm_domain_name" {
  description = "(Optional) Name of the domain to join"
  default     = ""
}
variable "cl_windows_vm_ou_path" {
  description = "(Optional) OU path to us during domain join"
  default     = ""
}
variable "cl_windows_vm_domain_user_upn" {
  description = "(Optional) UPN of the user to authenticate with the domain"
  default     = ""
}
variable "cl_windows_vm_domain_password" {
  description = "(Optional) Password of the user to authenticate with the domain"
  default     = ""
}
variable "cl_windows_vm_enable_backup" {
  description = "(Optional) Toggle the backup feature."
  default     = false
}
variable "cl_windows_vm_enable_log_analytics_settings" {
  description = "(Optional) Toggle the log analytics extension on or off."
  default     = true
}
variable "cl_windows_vm_recovery_vault_name" {
  description = "(Optional) The name of recovery backup vault."
  default     = null
}
variable "cl_windows_vm_rg_backup_name" {
  description = "(Optional) The RG destination of the windows vm backup."
  default     = null
}
variable "cl_windows_vm_backup_policy_vm_id" {
  description = "(Optional) The backup policy from the backup vault."
  default     = null
}
variable "cl_windows_vm_enable_encryption_at_host_enabled" {
  type        = bool
  description = "(Optional) Boolean to enable encryption_at_host_enabled."
  default     = true
}
variable "cl_windows_vm_user_defined_nsg_rules" {
  type = map(object({
    name                          = string
    priority                      = number
    direction                     = string
    access                        = string
    protocol                      = string
    source_port_range             = string
    source_port_ranges            = list(string)
    destination_port_range        = string
    destination_port_ranges       = list(string)    
    source_address_prefix         = string
    source_address_prefixes       = list(string)
    destination_address_prefix    = string
    destination_address_prefixes  = list(string)    
  }))
  description = "(Optional) Define additional NSG rules"
  default     = {}
}
variable "cl_windows_vm_license_type" {
  type        = string
  description = "(Optional) Specifies the type of on-premise license (also known as Azure Hybrid Use Benefit) which should be used for this Virtual Machine. Possible values are None, Windows_Client and Windows_Server."
  default     = "Windows_Server"
}
variable "cl_windows_vm_identity_type" {
  type = string
  description = "(Optional) Managed identity type for VM"
  default = null
}
variable "cl_windows_vm_identity_ids" {
  type = list(string)
  description = "(Optional) A list of User Managed Identity ID's which should be assigned to the Windows Virtual Machine"
  default = []
}
//**********************************************************************************************

// Optional - DevOps Agent Variables
//**********************************************************************************************
variable "cl_windows_vm_enable_devops_agent" {
  description = "(Optional) A boolean variable indicating if devops agent should be installed or not."
  default     = false
}
variable "cl_windows_vm_devops_agent_team_project" {
    type        = string
    description = "(Optional) Team Project of Azure DevOps"
    default     = ""
}
variable "cl_windows_vm_devops_agent_deployment_group" {
    type        = string
    description = "(Optional) Deployment Group of Azure DevOps"
    default     = ""
}
variable "cl_windows_vm_devops_agent_pat" {
    type        = string
    description = "(Optional) A Personal Access Token (PAT) is used as an alternate password to authenticate into Azure DevOps."
    default     = ""
}
variable "cl_windows_vm_devops_agent_org_url" {
    type        = string
    description = "(Optional) Organization of Azure DevOps"
    default     = ""
}
variable "cl_windows_vm_managed_disks" {
  description = "(Optional) Map containing the managed disks attributes"
  type = map(object({
    storage_account_type = string
    disk_size            = string
    lun                  = string
    caching              = string
  }))
  default = {}
}
//**********************************************************************************************
```

## Outputs

```terraform
// Outputs
//**********************************************************************************************
output "cl_windows_vm_rg" {
  value = local.cl_windows_vm_rg
}
output "cl_windows_vm_subnet" {
  value = local.cl_windows_vm_subnet
}
output "cl_windows_vm_nic" {
  value = azurerm_network_interface.cl_windows_vm_nic
}
output "cl_windows_vm_nsg" {
  value = local.cl_windows_vm_nsg
}
output "cl_windows_vm_machine" {
  value = azurerm_windows_virtual_machine.cl_windows_vm_machine
}
output "cl_windows_vm_protected_vm" {
  value = azurerm_backup_protected_vm.cl_windows_vm_protected_vm
}
output "cl_windows_log_analytics_settings" {
  value = length(azurerm_virtual_machine_extension.cl_windows_log_analytics_settings) > 0 ? azurerm_virtual_machine_extension.cl_windows_log_analytics_settings : null // https://github.com/hashicorp/terraform/issues/23222
}
output "cl_windows_vm_domain_join" {
  value = azurerm_virtual_machine_extension.cl_windows_vm_domain_join
}
output "cl_windows_vm_user_defined_nsg_rules" {
  value = azurerm_network_security_rule.cl_windows_vm_user_defined_nsg_rules
}
output "cl_windows_vm_managed_disk" {
  value = azurerm_managed_disk.cl_windows_vm_managed_disk
}
//**********************************************************************************************
```

## Usage

### Azure Devops Pipelines Agent Installation
Azure Pipelines Agent extension can be installed to deploy software using Azure DevOps Services to the virtual machines hosted in Microsoft Azure. When installed, the extension automatically downloads the Azure Pipelines Agent MSI, installs it, and registers the agent with the specified Deployment Group within your Azure DevOps Organization Project.

For the agent installation, the parameters below should be defined on VM module:

```terraform
  cl_windows_vm_enable_devops_agent               = true
  cl_windows_vm_devops_agent_org_url              = "https://dev.azure.com/<organization>"
  cl_windows_vm_devops_agent_pat                  = "<PERSONAL ACCESS TOKEN>"
  cl_windows_vm_devops_agent_team_project         = "<TEAM PROJECT NAME>"
  cl_windows_vm_devops_agent_deployment_group     = "<DEPLOYMENT GROUPS NAME>"
```

#### Useful Links
[Get started with the agent](https://docs.microsoft.com/azure/devops/pipelines/agents/agents?view=azure-devops#install).
[Azure Pipelines](https://azure.microsoft.com/en-us/services/devops/pipelines/)
[Deployment Groups](https://aka.ms/832442)
[Personal access tokens](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate)

#### Deploy VM With Azure Devops Agent
```terraform
// Deploys Windows VM with the Azure Devops Agent installed
//**********************************************************************************************
module "cl_windows_vm" {
  source                                          = "../caf-tf-modules/cl_windows_vm"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_windows_vm_app_name                          = var.windows_vm_app_name
  cl_windows_vm_computer_name                     = var.windows_vm_computer_name  
  cl_windows_vm_image_id                          = var.windows_vm_image_id
  cl_windows_vm_availability_set_id               = var.availability_set_id
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = true
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host_enabled = false
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS
# cl_windows_vm_user_defined_nsg_rules            = {
#     allow_6379_6380 = {
#       name                        = "Allow6379and6380Inbound"
#       priority                    = 1013
#       direction                   = "Inbound"
#       access                      = "Allow"
#       protocol                    = "Tcp"
#       source_port_range           = "*"
#       source_port_ranges          = null
#       destination_port_range      = null
#       destination_port_ranges     = ["6379", "6380"]
#       source_address_prefix       = "10.69.22.78/27"
#       source_address_prefixes     = null
#       destination_address_prefix  = "10.69.22.89/27"  
#       destination_address_prefixes  = null  
#     }
}
  
  // DevOps Configs
  cl_windows_vm_enable_devops_agent               = true
  cl_windows_vm_devops_agent_org_url              = "https://dev.azure.com/contoso"
  cl_windows_vm_devops_agent_pat                  = "xmtvguqak3k2lxi5gu633c6pgzjbjznczxwlvxmp2glluot4dkftfqx"
  cl_windows_vm_devops_agent_team_project         = "CONTOSO"
  cl_windows_vm_devops_agent_deployment_group     = "CONTOSO-SBOX"
}
//**********************************************************************************************
```
#### Deploy VM Without Azure Devops Agent
```terraform
// Deploys Windows VM without the Azure Devops Agent installed
//***************************************************************************************************
module "cl_windows_vm_power_bi_gateway" {
  source                                          = "../tf-azure-component-library/components/cl_windows_vm"
  env                                             = var.env
  postfix                                         = var.postfix
  location                                        = var.location
  cl_windows_vm_app_name                          = var.power_bi_gateway_vm_app_name
  cl_windows_vm_computer_name                     = var.power_bi_gateway_vm_computer_name  
  cl_windows_vm_image_id                          = var.power_bi_gateway_vm_image_id
  cl_windows_vm_vnet_name                         = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_vnet.name
  cl_windows_vm_vnet_rg_name                      = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_rg_network.name
  cl_windows_vm_enable_backup                     = false
  cl_windows_vm_deploy_rg                         = true
  cl_windows_vm_rg_backup_name                    = module.cl_azure_backup.cl_azure_backup_rg.name
  cl_windows_vm_recovery_vault_name               = module.cl_azure_backup.cl_azure_backup_sv[0].name
  cl_windows_vm_backup_policy_vm_id               = module.cl_azure_backup.cl_azure_backup_policy_vm[0].id
  cl_windows_vm_deploy_subnet                     = true
  cl_windows_vm_deploy_subnet_nsg                 = true
  cl_windows_vm_subnet_prefix                     = ["172.16.1.0/24"]
  cl_windows_vm_bastion_enable                    = true # variable in false don´t send value for cl_windows_vm_bastion_subnet_prefix
  cl_windows_vm_log_analytics_workspace_id        = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.workspace_id
  cl_windows_vm_log_analytics_primary_shared_key  = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_log_analytics_workspace.primary_shared_key
  cl_windows_vm_route_table_id                    = data.terraform_remote_state.core.outputs.core_latam_peninsula.core_route_table.id
  cl_windows_vm_enable_encryption_at_host_enabled = false
  cl_windows_vm_bastion_subnet_prefix             = module.cl_azure_bastion.cl_azure_bastion_subnet[0].address_prefix 
  cl_windows_vm_admin_user                        = var.WINDOWS_VM_USER
  cl_windows_vm_admin_pass                        = var.WINDOWS_VM_PASS
  cl_windows_vm_managed_disks                     = {
                                                        data = {
                                                            storage_account_type = "StandardSSD_LRS"
                                                            disk_size            = "80"
                                                            lun                  = "1"
                                                            caching              = "None"
                                                        }
                                                    } 
}
//***************************************************************************************************
```
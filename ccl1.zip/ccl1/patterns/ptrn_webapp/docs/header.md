# Azure Web App Pattern 

This is the WebApp Pattern. It'll deploy the following Components:
* Application Gateway
* App Service Plan
* Service App
* Azure SQL Database
* SQL elastic pools - Optional module, in case to desabled SQL elastic pools after being   deployed is necessary to remove the databases from the elastic pool.


It will also deploy other components such a private endpoint network for intercomunication between components.

All the original variables from the original components was preserved with same default values.
## Note:
To add windows node pool to kubernetes cluster, it needs Terraform version 0.15 or later.
It can be specified on Jenkinsfile:
```jenkinsfile
stage("Terraform *** ") {
    agent {
        docker {
            image 'dn-cloud-docker.artifactory.us.kworld.kpmg.com/azure-terraform-0-15-4:latest'
            ...
```
Specify TF version in `pattern_backend`, moving also the azurerm provider version constraint to `required_providers` section, inside `terraform` to avoid deprecation warnings.
```
// Terraform Plugins version minimum requirement
//**********************************************************************************************
provider "azurerm" {
  features {}
}
//**********************************************************************************************
// Backend Storage
//**********************************************************************************************
terraform {
  // Terraform Minimum version required
  required_version = ">= 0.15.4"
  backend "azurerm" {}
  required_providers {
    azurerm = {
      version = ">=2.12.0"
    }
  }
}
//**********************************************************************************************
```   
## Information
```terraform
1. Azure Kubernetes Cluster Egress Traffic UDR Prerequisites:

* Create the following firewall rules with source vnet aks node pool - Restrict egress traffic in Azure Kubernetes Service (AKS) - https://docs.microsoft.com/en-us/azure/aks/limit-egress-traffic

      * *:123 or ntp.ubuntu.com:123 - Required for Network Time Protocol (NTP) time synchronization on Linux nodes.
   * CustomDNSIP:53 - If you're using custom DNS servers, you must ensure they're accessible by the cluster nodes.
   * *.hcp.<location>.azmk8s.io: HTTPS 443 - Required for Node <-> API server communication. Replace <location> with the region where your AKS cluster is deployed.
   * mcr.microsoft.com: HTTPS 443 - Required to access images in Microsoft Container Registry (MCR). This registry contains first-party images/charts (for example, coreDNS, etc.). These images are required for the correct creation and functioning of the cluster, including scale and upgrade operations.
   * *.data.mcr.microsoft.com: HTTPS 443 - Required for MCR storage backed by the Azure content delivery network (CDN).
   * management.azure.com: HTTPS 443 - Required for Kubernetes operations against the Azure API.
   * login.microsoftonline.com: HTTPS 443 - Required for Azure Active Directory authentication.
   * packages.microsoft.com: HTTPS 443 - This address is the Microsoft packages repository used for cached apt-get operations. Example packages include Moby, PowerShell, and Azure CLI.
   * acs-mirror.azureedge.net: HTTPS 443 - This address is for the repository required to download and install required binaries like kubenet and Azure CNI.
   * nvidia.github.io: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * us.download.nvidia.com: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * apt.dockerproject.org: HTTPS 443 - This address is used for correct driver installation and operation on GPU-based nodes.
   * ServiceTag - AzureMonitor: HTTPS 443 - This endpoint is used to send metrics data and logs to Azure Monitor and Log Analytics.
   * dc.services.visualstudio.com: HTTPS 443 - This endpoint is used for metrics and monitoring telemetry using Azure Monitor.
   * *.ods.opinsights.azure.com: HTTPS 443 - This endpoint is used by Azure Monitor for ingesting log analytics data.
   * *.oms.opinsights.azure.com: HTTPS 443 - This endpoint is used by omsagent, which is used to authenticate the log analytics service.
   * *.monitoring.azure.com:	HTTPS 443 - This endpoint is used to send metrics data to Azure Monitor.
   * data.policy.core.windows.net: HTTPS 443 - This address is used to pull the Kubernetes policies and to report cluster compliance status to policy service.
   * store.policy.core.windows.net: HTTPS 443 - This address is used to pull the Gatekeeper artifacts of built-in policies.
   * dc.services.visualstudio.com: HTTPS 443 - Azure Policy add-on that sends telemetry data to applications insights endpoint.
   * motd.ubuntu.com:  HTTPS 443 - is a package that makes a call periodically to Canonical servers to get updated news for support and informational purposes.
   * optional rule windows server node pool: HTTPS 443 - onegetcdn.azureedge.net, go.microsoft.com - To install windows-related binaries
   * optional rule windows server node pool: HTTP 80 - *.mp.microsoft.com, www.msftconnecttest.com, ctldl.windowsupdate.com - To install windows-related binaries
   * optional rules: HTTP 80 - security.ubuntu.com, azure.archive.ubuntu.com, changelogs.ubuntu.com - This address lets the Linux cluster nodes download the required security patches and updates.

2. When the infrastructure is created, please finalice the configuration required for the differentes integrations with deployment guide https://kcentralint.us.kpmg.com/BPG/techeng/ea/ProjectDocuments/DMND0077160%20-%20KPMG%20Americas%20Platform%20Enhancements/Cloud%20Arch%20and%20Engineering/Deployment%20and%20Runbooks/Azure%20Kubernetes%20Service%20Deployment%20Guide%20v1.0.docx

3. The Application Gateway Ingress Contoller (AGIC) is goning to be deployed with Add-On AGIC for your AKS cluster. the second is through AKS as an add-on. (https://docs.microsoft.com/en-us/azure/application-gateway/ingress-controller-overview) :

   Helm deployment values cannot be modified on the AKS add-on:
   * verbosityLevel will be set to 5 by default
   * usePrivateIp will be set to be false by default; this can be overwritten by the use-private-ip annotation
   * shared is not supported on add-on
   * reconcilePeriodSeconds is not supported on add-on
   * armAuth.type is not supported on add-on
   * AGIC deployed via Helm supports ProhibitedTargets, which means AGIC can configure the Application Gateway specifically for AKS clusters without affecting other existing backends. AGIC add-on doesn't currently support this.
   * Since AGIC add-on is a managed service, customers will automatically be updated to the latest version of AGIC add-on, unlike AGIC deployed through Helm where the customer must manually update AGIC. 
   * Customers can only deploy one AGIC add-on per AKS cluster, and each AGIC add-on currently can only target one Application Gateway. For deployments that require more than one AGIC per cluster or multiple AGICs targeting one Application Gateway, please continue to use AGIC deployed through Helm.

4. To create an AKS cluster with Azure Key Vault Provider for Secrets Store CSI Driver capability, we are going to use the azure-keyvault-secrets-provider add-on. Follow the deployment guide to confirm configuration required into kubernetes cluster to key vault access. https://kcentralint.us.kpmg.com/BPG/techeng/ea/ProjectDocuments/DMND0077160%20-%20KPMG%20Americas%20Platform%20Enhancements/Cloud%20Arch%20and%20Engineering/Deployment%20and%20Runbooks/Azure%20Kubernetes%20Service%20Deployment%20Guide%20v1.0.docx

```
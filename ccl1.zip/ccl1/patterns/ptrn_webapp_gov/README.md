<!-- BEGIN_TF_DOCS -->

# Azure Web App Pattern 

This is the WebApp Pattern. It'll deploy the following Components:
* Application Gateway
* App Service Plan
* Service App
* Azure SQL Database
* SQL elastic pools - Optional module, in case to desabled SQL elastic pools after being   deployed is necessary to remove the databases from the elastic pool.


It will also deploy other components such a private endpoint network for intercomunication between components.

All the original variables from the original components was preserved with same default values.



## Resources

| Name | Type |
|------|------|
| [azurerm_subnet.private_endpoint_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_ptrn_webapp_analytics_rg"></a> [ptrn\_webapp\_analytics\_rg](#input\_ptrn\_webapp\_analytics\_rg) | (Required) The Resource group name for the Analytics resources | `any` | n/a | yes |
| <a name="input_ptrn_webapp_app_gateway_additional_backend_address_pool"></a> [ptrn\_webapp\_app\_gateway\_additional\_backend\_address\_pool](#input\_ptrn\_webapp\_app\_gateway\_additional\_backend\_address\_pool) | (Optional) Array for additional backend address pool. | <pre>map(object({<br>    name  = string<br>    fqdns = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_additional_http_listener"></a> [ptrn\_webapp\_app\_gateway\_additional\_http\_listener](#input\_ptrn\_webapp\_app\_gateway\_additional\_http\_listener) | (Optional) Array for additional HTTP listeners. | <pre>map(object({<br>    name                      = string<br>    protocol                  = string<br>    host_name                 = string<br>    frontend_port_name        = string<br>    ssl_certificate_name      = string    <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_additional_http_settings"></a> [ptrn\_webapp\_app\_gateway\_additional\_http\_settings](#input\_ptrn\_webapp\_app\_gateway\_additional\_http\_settings) | (Optional) Array for additional HTTP settings. | <pre>map(object({<br>    name                                = string<br>    request_timeout                     = number<br>    probe_name                          = string<br>    host_name                           = string<br>    pick_host_name_from_backend_address = bool<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_additional_probes"></a> [ptrn\_webapp\_app\_gateway\_additional\_probes](#input\_ptrn\_webapp\_app\_gateway\_additional\_probes) | (Optional) Array for additional health probes. | <pre>map(object({<br>    name                = string<br>    host                = string<br>    path                = string<br>    interval            = number<br>    timeout             = number<br>    unhealthy_threshold = number<br>    protocol            = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_additional_redirect_configurations"></a> [ptrn\_webapp\_app\_gateway\_additional\_redirect\_configurations](#input\_ptrn\_webapp\_app\_gateway\_additional\_redirect\_configurations) | (Optional) Array for additional redirect configurations. | <pre>map(object({<br>    name                  = string<br>    redirect_type         = string<br>    target_listener_name  = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_additional_route_rules"></a> [ptrn\_webapp\_app\_gateway\_additional\_route\_rules](#input\_ptrn\_webapp\_app\_gateway\_additional\_route\_rules) | (Optional) Array for additional routing rules. | <pre>map(object({<br>    name                        = string<br>    rule_type                   = string<br>    http_listener_name          = string<br>    backend_address_pool        = string<br>    backend_http_settings_name  = string<br>    redirect_configuration_name = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_additional_ssl_certificate"></a> [ptrn\_webapp\_app\_gateway\_additional\_ssl\_certificate](#input\_ptrn\_webapp\_app\_gateway\_additional\_ssl\_certificate) | (Optional) Array for additional SSL Certificates. | <pre>map(object({<br>    name                = string<br>    data                = string<br>    password            = string<br>    key_vault_secret_id = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_backend_address"></a> [ptrn\_webapp\_app\_gateway\_backend\_address](#input\_ptrn\_webapp\_app\_gateway\_backend\_address) | (Optional) The backend ip or fqdns address from the address pool | `list` | `null` | no |
| <a name="input_ptrn_webapp_app_gateway_backend_host_name"></a> [ptrn\_webapp\_app\_gateway\_backend\_host\_name](#input\_ptrn\_webapp\_app\_gateway\_backend\_host\_name) | (Optional) Host header to be sent to the backend servers. Cannot be set if pick\_host\_name\_from\_backend\_address is set to true | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_gateway_diagnostics"></a> [ptrn\_webapp\_app\_gateway\_diagnostics](#input\_ptrn\_webapp\_app\_gateway\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ApplicationGatewayAccessLog",<br>    "ApplicationGatewayPerformanceLog",<br>    "ApplicationGatewayFirewallLog"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_webapp_app_gateway_disable_bgp_route_propagation"></a> [ptrn\_webapp\_app\_gateway\_disable\_bgp\_route\_propagation](#input\_ptrn\_webapp\_app\_gateway\_disable\_bgp\_route\_propagation) | (Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_gateway_domain_name_label"></a> [ptrn\_webapp\_app\_gateway\_domain\_name\_label](#input\_ptrn\_webapp\_app\_gateway\_domain\_name\_label) | (Optional) Label for the Domain Name. Will be used to make up the FQDN. If a domain name label is specified, an A DNS record is created for the public IP in the Microsoft Azure DNS system. | `string` | `null` | no |
| <a name="input_ptrn_webapp_app_gateway_firewall_mode"></a> [ptrn\_webapp\_app\_gateway\_firewall\_mode](#input\_ptrn\_webapp\_app\_gateway\_firewall\_mode) | (Required) Resource group where the Core VNet exists. | `string` | `"Prevention"` | no |
| <a name="input_ptrn_webapp_app_gateway_frontend_tls_cert"></a> [ptrn\_webapp\_app\_gateway\_frontend\_tls\_cert](#input\_ptrn\_webapp\_app\_gateway\_frontend\_tls\_cert) | (Required) The name of the ssl cert file in pfx format that exists in the same folder that TF plan/apply is executed on. The file must not be base64 encrypted. | `string` | n/a | yes |
| <a name="input_ptrn_webapp_app_gateway_frontend_tls_cert_keyvault_id"></a> [ptrn\_webapp\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id](#input\_ptrn\_webapp\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id) | (Optional) Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in Azure KeyVault. | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_gateway_frontend_tls_cert_pass"></a> [ptrn\_webapp\_app\_gateway\_frontend\_tls\_cert\_pass](#input\_ptrn\_webapp\_app\_gateway\_frontend\_tls\_cert\_pass) | (Required) The password for the front end ssl cert file | `string` | n/a | yes |
| <a name="input_ptrn_webapp_app_gateway_http_listener_hostname"></a> [ptrn\_webapp\_app\_gateway\_http\_listener\_hostname](#input\_ptrn\_webapp\_app\_gateway\_http\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTP Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_gateway_http_settings_timeout"></a> [ptrn\_webapp\_app\_gateway\_http\_settings\_timeout](#input\_ptrn\_webapp\_app\_gateway\_http\_settings\_timeout) | (Optional) The timeout for HTTP response. | `number` | `600` | no |
| <a name="input_ptrn_webapp_app_gateway_https_listener_hostname"></a> [ptrn\_webapp\_app\_gateway\_https\_listener\_hostname](#input\_ptrn\_webapp\_app\_gateway\_https\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTPS Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_gateway_identity_ids"></a> [ptrn\_webapp\_app\_gateway\_identity\_ids](#input\_ptrn\_webapp\_app\_gateway\_identity\_ids) | (Optional) Specifies a list with a single user managed identity id to be assigned to the Application Gateway | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_app_gateway_log_analytics_solutions"></a> [ptrn\_webapp\_app\_gateway\_log\_analytics\_solutions](#input\_ptrn\_webapp\_app\_gateway\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>     publisher = string #(Required) The publisher of the solution<br>     product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureAppGatewayAnalytics": {<br>    "product": "OMSGallery/AzureAppGatewayAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_webapp_app_gateway_max_capacity"></a> [ptrn\_webapp\_app\_gateway\_max\_capacity](#input\_ptrn\_webapp\_app\_gateway\_max\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `5` | no |
| <a name="input_ptrn_webapp_app_gateway_min_capacity"></a> [ptrn\_webapp\_app\_gateway\_min\_capacity](#input\_ptrn\_webapp\_app\_gateway\_min\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `1` | no |
| <a name="input_ptrn_webapp_app_gateway_nsg_flow_log_postfix"></a> [ptrn\_webapp\_app\_gateway\_nsg\_flow\_log\_postfix](#input\_ptrn\_webapp\_app\_gateway\_nsg\_flow\_log\_postfix) | (Required) The postfix for app gateway nsg flow logs. | `any` | n/a | yes |
| <a name="input_ptrn_webapp_app_gateway_nsg_rules"></a> [ptrn\_webapp\_app\_gateway\_nsg\_rules](#input\_ptrn\_webapp\_app\_gateway\_nsg\_rules) | (Optional) Define additional NSG rules for app gateway subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_gateway_pick_host_backend"></a> [ptrn\_webapp\_app\_gateway\_pick\_host\_backend](#input\_ptrn\_webapp\_app\_gateway\_pick\_host\_backend) | true/false to use host from backend configuration. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_gateway_pick_host_name"></a> [ptrn\_webapp\_app\_gateway\_pick\_host\_name](#input\_ptrn\_webapp\_app\_gateway\_pick\_host\_name) | true/false to override the host name | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_gateway_probe_host"></a> [ptrn\_webapp\_app\_gateway\_probe\_host](#input\_ptrn\_webapp\_app\_gateway\_probe\_host) | (Optional) The site url from the Health probes | `string` | `"www.google.com"` | no |
| <a name="input_ptrn_webapp_app_gateway_probe_interval"></a> [ptrn\_webapp\_app\_gateway\_probe\_interval](#input\_ptrn\_webapp\_app\_gateway\_probe\_interval) | (Optional) The probe interval from the Health probes | `number` | `10` | no |
| <a name="input_ptrn_webapp_app_gateway_probe_name"></a> [ptrn\_webapp\_app\_gateway\_probe\_name](#input\_ptrn\_webapp\_app\_gateway\_probe\_name) | (Optional) The probe name from Health probes | `string` | `"https-probe"` | no |
| <a name="input_ptrn_webapp_app_gateway_probe_path"></a> [ptrn\_webapp\_app\_gateway\_probe\_path](#input\_ptrn\_webapp\_app\_gateway\_probe\_path) | (Optional) The probe path from the Health probes | `string` | `"/hostingstart.html"` | no |
| <a name="input_ptrn_webapp_app_gateway_probe_protocol"></a> [ptrn\_webapp\_app\_gateway\_probe\_protocol](#input\_ptrn\_webapp\_app\_gateway\_probe\_protocol) | (Optional) The probe protocol from the Health probes | `string` | `"Https"` | no |
| <a name="input_ptrn_webapp_app_gateway_probe_timeout"></a> [ptrn\_webapp\_app\_gateway\_probe\_timeout](#input\_ptrn\_webapp\_app\_gateway\_probe\_timeout) | (Optional) The timeout from the Health probes | `number` | `30` | no |
| <a name="input_ptrn_webapp_app_gateway_probe_unhealthy_threshold"></a> [ptrn\_webapp\_app\_gateway\_probe\_unhealthy\_threshold](#input\_ptrn\_webapp\_app\_gateway\_probe\_unhealthy\_threshold) | (Optional) The unhealthy threshold from the Health probes | `number` | `3` | no |
| <a name="input_ptrn_webapp_app_gateway_public_ip_allocation_method"></a> [ptrn\_webapp\_app\_gateway\_public\_ip\_allocation\_method](#input\_ptrn\_webapp\_app\_gateway\_public\_ip\_allocation\_method) | (Optional) The allocation method for this IP address. Possible values are Static or Dynamic. | `string` | `"Static"` | no |
| <a name="input_ptrn_webapp_app_gateway_public_ip_sku"></a> [ptrn\_webapp\_app\_gateway\_public\_ip\_sku](#input\_ptrn\_webapp\_app\_gateway\_public\_ip\_sku) | (Optional) The SKU of the Public IP. Accepted values are Basic and Standard | `string` | `"Standard"` | no |
| <a name="input_ptrn_webapp_app_gateway_reverse_fqdn"></a> [ptrn\_webapp\_app\_gateway\_reverse\_fqdn](#input\_ptrn\_webapp\_app\_gateway\_reverse\_fqdn) | (Optional) A fully qualified domain name that resolves to this public IP address | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_gateway_rewrite_rules"></a> [ptrn\_webapp\_app\_gateway\_rewrite\_rules](#input\_ptrn\_webapp\_app\_gateway\_rewrite\_rules) | (Optional) Array for rewrite rules. | <pre>list(object({<br>    name            = string<br>    rule_sequence   = number<br>    conditions = list(object({<br>      variable    = string<br>      pattern     = string<br>      ignore_case = bool<br>      negate      = bool<br>    }))<br>    request_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))<br>    response_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))  <br>    urls  = list(object({<br>      path          = string<br>      query_string  = string<br>      reroute       = string<br>    }))         <br>  }))</pre> | `[]` | no |
| <a name="input_ptrn_webapp_app_gateway_rg"></a> [ptrn\_webapp\_app\_gateway\_rg](#input\_ptrn\_webapp\_app\_gateway\_rg) | (Required) The name of the resource group where the application gateway will be deployed to. | `any` | n/a | yes |
| <a name="input_ptrn_webapp_app_gateway_ssl_policy_name"></a> [ptrn\_webapp\_app\_gateway\_ssl\_policy\_name](#input\_ptrn\_webapp\_app\_gateway\_ssl\_policy\_name) | (Optional) The Name from SSL Policy | `string` | `"AppGwSslPolicy20170401S"` | no |
| <a name="input_ptrn_webapp_app_gateway_ssl_policy_protocol_version"></a> [ptrn\_webapp\_app\_gateway\_ssl\_policy\_protocol\_version](#input\_ptrn\_webapp\_app\_gateway\_ssl\_policy\_protocol\_version) | (Optional) The Minimun Protocol Version from SSL Policy | `string` | `"TLSv1_2"` | no |
| <a name="input_ptrn_webapp_app_gateway_ssl_policy_type"></a> [ptrn\_webapp\_app\_gateway\_ssl\_policy\_type](#input\_ptrn\_webapp\_app\_gateway\_ssl\_policy\_type) | (Optional) The Type from SSL Policy | `string` | `"Predefined"` | no |
| <a name="input_ptrn_webapp_app_gateway_subnet_address_prefix"></a> [ptrn\_webapp\_app\_gateway\_subnet\_address\_prefix](#input\_ptrn\_webapp\_app\_gateway\_subnet\_address\_prefix) | (Required) The address prefix of the application gateway subnet. | `list(string)` | n/a | yes |
| <a name="input_ptrn_webapp_app_gateway_subnet_hostnum"></a> [ptrn\_webapp\_app\_gateway\_subnet\_hostnum](#input\_ptrn\_webapp\_app\_gateway\_subnet\_hostnum) | The hostnumber from the subnet prefix for the private IP. | `number` | `15` | no |
| <a name="input_ptrn_webapp_app_gateway_subnet_service_endpoints"></a> [ptrn\_webapp\_app\_gateway\_subnet\_service\_endpoints](#input\_ptrn\_webapp\_app\_gateway\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet | `list` | `[]` | no |
| <a name="input_ptrn_webapp_app_service_acr_login_server"></a> [ptrn\_webapp\_app\_service\_acr\_login\_server](#input\_ptrn\_webapp\_app\_service\_acr\_login\_server) | Is the Azure Container Registry server | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_acr_password"></a> [ptrn\_webapp\_app\_service\_acr\_password](#input\_ptrn\_webapp\_app\_service\_acr\_password) | Is the Azure Container Registry password of the username to be used | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_acr_username"></a> [ptrn\_webapp\_app\_service\_acr\_username](#input\_ptrn\_webapp\_app\_service\_acr\_username) | Is the Azure Container Registry username to access the repository | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_always_on"></a> [ptrn\_webapp\_app\_service\_always\_on](#input\_ptrn\_webapp\_app\_service\_always\_on) | (Optional) Should the app be loaded at all times? | `bool` | `false` | no |
| <a name="input_ptrn_webapp_app_service_app_postfix"></a> [ptrn\_webapp\_app\_service\_app\_postfix](#input\_ptrn\_webapp\_app\_service\_app\_postfix) | (Required) The bespoke name of the app you are deploying. | `string` | n/a | yes |
| <a name="input_ptrn_webapp_app_service_auth_settings_default_provider"></a> [ptrn\_webapp\_app\_service\_auth\_settings\_default\_provider](#input\_ptrn\_webapp\_app\_service\_auth\_settings\_default\_provider) | (Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter. | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_service_auth_settings_enabled"></a> [ptrn\_webapp\_app\_service\_auth\_settings\_enabled](#input\_ptrn\_webapp\_app\_service\_auth\_settings\_enabled) | (Optional) Enable or disable Authentication Settings | `string` | `"true"` | no |
| <a name="input_ptrn_webapp_app_service_auth_settings_unauthenticated_client_action"></a> [ptrn\_webapp\_app\_service\_auth\_settings\_unauthenticated\_client\_action](#input\_ptrn\_webapp\_app\_service\_auth\_settings\_unauthenticated\_client\_action) | (Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage. | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_service_client_affinity_enabled"></a> [ptrn\_webapp\_app\_service\_client\_affinity\_enabled](#input\_ptrn\_webapp\_app\_service\_client\_affinity\_enabled) | (Optional) Should the App Service send session affinity cookies, which route client requests in the same session to the same instance? | `bool` | `false` | no |
| <a name="input_ptrn_webapp_app_service_connection_strings"></a> [ptrn\_webapp\_app\_service\_connection\_strings](#input\_ptrn\_webapp\_app\_service\_connection\_strings) | (Optional) Connection strings for App Service. | <pre>map(object({<br>    name                  = string<br>    type                  = string<br>    value                 = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_service_cors_allowed_origins"></a> [ptrn\_webapp\_app\_service\_cors\_allowed\_origins](#input\_ptrn\_webapp\_app\_service\_cors\_allowed\_origins) | (Optional) A list of origins which should be able to make cross-origin calls. * can be used to allow all calls. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_webapp_app_service_custom_domain_hostname"></a> [ptrn\_webapp\_app\_service\_custom\_domain\_hostname](#input\_ptrn\_webapp\_app\_service\_custom\_domain\_hostname) | (Optional) App service custom domain hostname. | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_custom_domain_thumbprint"></a> [ptrn\_webapp\_app\_service\_custom\_domain\_thumbprint](#input\_ptrn\_webapp\_app\_service\_custom\_domain\_thumbprint) | (Optional) The app service custom domain thumbprint. | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_default_documents"></a> [ptrn\_webapp\_app\_service\_default\_documents](#input\_ptrn\_webapp\_app\_service\_default\_documents) | (Optional) The ordering of default documents to load, if an address isn't specified. | `list` | `[]` | no |
| <a name="input_ptrn_webapp_app_service_diagnostics"></a> [ptrn\_webapp\_app\_service\_diagnostics](#input\_ptrn\_webapp\_app\_service\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AppServiceAntivirusScanAuditLogs",<br>    "AppServiceHTTPLogs",<br>    "AppServiceConsoleLogs",<br>    "AppServiceAppLogs",<br>    "AppServiceFileAuditLogs",<br>    "AppServiceAuditLogs",<br>    "AppServiceIPSecAuditLogs",<br>    "AppServicePlatformLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_webapp_app_service_dns_server"></a> [ptrn\_webapp\_app\_service\_dns\_server](#input\_ptrn\_webapp\_app\_service\_dns\_server) | Custom DNS service for app service routing. | `string` | `"168.63.129.16"` | no |
| <a name="input_ptrn_webapp_app_service_ftps_state"></a> [ptrn\_webapp\_app\_service\_ftps\_state](#input\_ptrn\_webapp\_app\_service\_ftps\_state) | (Optional) State of FTP / FTPS service for this App Service. Possible values include: AllAllowed, FtpsOnly and Disabled. | `string` | `"Disabled"` | no |
| <a name="input_ptrn_webapp_app_service_health_check_path"></a> [ptrn\_webapp\_app\_service\_health\_check\_path](#input\_ptrn\_webapp\_app\_service\_health\_check\_path) | The health check path to be pinged by App Service | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_http2_enabled"></a> [ptrn\_webapp\_app\_service\_http2\_enabled](#input\_ptrn\_webapp\_app\_service\_http2\_enabled) | (Optional) Is HTTP2 Enabled on this App Service? | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_service_https_only"></a> [ptrn\_webapp\_app\_service\_https\_only](#input\_ptrn\_webapp\_app\_service\_https\_only) | (Optional) Booolean to toggle if the App Service can only be accessed via HTTPS. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_service_identity_identity_ids"></a> [ptrn\_webapp\_app\_service\_identity\_identity\_ids](#input\_ptrn\_webapp\_app\_service\_identity\_identity\_ids) | (Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned. | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_service_identity_type"></a> [ptrn\_webapp\_app\_service\_identity\_type](#input\_ptrn\_webapp\_app\_service\_identity\_type) | (Optional) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_ptrn_webapp_app_service_is_custom_domain_enable"></a> [ptrn\_webapp\_app\_service\_is\_custom\_domain\_enable](#input\_ptrn\_webapp\_app\_service\_is\_custom\_domain\_enable) | (Optional) Is the app service using a custom domain?. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_app_service_min_tls_version"></a> [ptrn\_webapp\_app\_service\_min\_tls\_version](#input\_ptrn\_webapp\_app\_service\_min\_tls\_version) | (Optional) The minimum supported TLS version for the app service | `string` | `"1.2"` | no |
| <a name="input_ptrn_webapp_app_service_number_of_workers"></a> [ptrn\_webapp\_app\_service\_number\_of\_workers](#input\_ptrn\_webapp\_app\_service\_number\_of\_workers) | (Optional) The scaled number of workers (for per site scaling) of this App Service. | `number` | `1` | no |
| <a name="input_ptrn_webapp_app_service_pe_subnet_ids"></a> [ptrn\_webapp\_app\_service\_pe\_subnet\_ids](#input\_ptrn\_webapp\_app\_service\_pe\_subnet\_ids) | (Optional) A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_ptrn_webapp_app_service_plan_app_postfix"></a> [ptrn\_webapp\_app\_service\_plan\_app\_postfix](#input\_ptrn\_webapp\_app\_service\_plan\_app\_postfix) | (Required) The bespoke name of the app service plan you are deploying. | `any` | n/a | yes |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_default"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_default](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_default) | (Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_maximum"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_maximum](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_maximum) | (Optional) The maximum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `10` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_metric_name"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_metric\_name](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_metric\_name) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"CpuPercentage"` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_minimum"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_minimum](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_minimum) | (Optional) The minimum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_scale_in_operator"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_in\_operator](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_in\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"LessThan"` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_scale_in_threshold"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_in\_threshold](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_in\_threshold) | (Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action. | `number` | `25` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_scale_out_operator"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_out\_operator](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_out\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"GreaterThan"` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_scale_out_threshold"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_out\_threshold](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_scale\_out\_threshold) | (Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action. | `number` | `75` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_statistic"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_statistic](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_statistic) | (Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max. | `string` | `"Average"` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_time_aggregation"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_time\_aggregation](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_time\_aggregation) | (Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total. | `string` | `"Average"` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_time_grain"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_time\_grain](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_time\_grain) | (Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string. | `string` | `"PT1M"` | no |
| <a name="input_ptrn_webapp_app_service_plan_autoscale_settings_time_window"></a> [ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_time\_window](#input\_ptrn\_webapp\_app\_service\_plan\_autoscale\_settings\_time\_window) | (Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string. | `string` | `"PT5M"` | no |
| <a name="input_ptrn_webapp_app_service_plan_deploy_autoscale_settings"></a> [ptrn\_webapp\_app\_service\_plan\_deploy\_autoscale\_settings](#input\_ptrn\_webapp\_app\_service\_plan\_deploy\_autoscale\_settings) | (Optional) Choose to deploy autoscale settings or not. If the plan is serverless, this needs to be set to false | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_service_plan_deploy_integration_subnet"></a> [ptrn\_webapp\_app\_service\_plan\_deploy\_integration\_subnet](#input\_ptrn\_webapp\_app\_service\_plan\_deploy\_integration\_subnet) | (Optional) A boolean that toggles the deployment of the vnet integration subnet. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_service_plan_deploy_rg"></a> [ptrn\_webapp\_app\_service\_plan\_deploy\_rg](#input\_ptrn\_webapp\_app\_service\_plan\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the App Service Plan. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_service_plan_diagnostics"></a> [ptrn\_webapp\_app\_service\_plan\_diagnostics](#input\_ptrn\_webapp\_app\_service\_plan\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_webapp_app_service_plan_int_subnet_user_defined_nsg_rules"></a> [ptrn\_webapp\_app\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules](#input\_ptrn\_webapp\_app\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules) | (Optional) A map of NSG rules for the integration subnet. | <pre>map(object({<br>        name                          = string<br>        priority                      = number<br>        direction                     = string<br>        access                        = string<br>        protocol                      = string<br>        source_port_range             = string<br>        source_port_ranges            = list(string)<br>        destination_port_range        = string<br>        destination_port_ranges       = list(string)    <br>        source_address_prefix         = string<br>        source_address_prefixes       = list(string)<br>        destination_address_prefix    = string<br>        destination_address_prefixes  = list(string)    <br>    }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_app_service_plan_integration_subnet_prefix"></a> [ptrn\_webapp\_app\_service\_plan\_integration\_subnet\_prefix](#input\_ptrn\_webapp\_app\_service\_plan\_integration\_subnet\_prefix) | (Optional) The CIDR prefix for the app service subnet. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_plan_integration_subnet_service_endpoints"></a> [ptrn\_webapp\_app\_service\_plan\_integration\_subnet\_service\_endpoints](#input\_ptrn\_webapp\_app\_service\_plan\_integration\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `list` | `[]` | no |
| <a name="input_ptrn_webapp_app_service_plan_integration_vnet_rg_name"></a> [ptrn\_webapp\_app\_service\_plan\_integration\_vnet\_rg\_name](#input\_ptrn\_webapp\_app\_service\_plan\_integration\_vnet\_rg\_name) | (Optional) The name of the VNet resource group where the app service subnet will be deployed into. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_plan_max_elastic_workers"></a> [ptrn\_webapp\_app\_service\_plan\_max\_elastic\_workers](#input\_ptrn\_webapp\_app\_service\_plan\_max\_elastic\_workers) | (Optional) The maximum number of total workers allowed for this ElasticScaleEnabled App Service Plan. | `number` | `null` | no |
| <a name="input_ptrn_webapp_app_service_plan_os_type"></a> [ptrn\_webapp\_app\_service\_plan\_os\_type](#input\_ptrn\_webapp\_app\_service\_plan\_os\_type) | (Optional) The kind of the App Service Plan to create. Possible values are Windows (also available as App), Linux, elastic (for Premium Consumption) and FunctionApp (for a Consumption Plan). Defaults to Windows. Changing this forces a new resource to be created. | `string` | `"Windows"` | no |
| <a name="input_ptrn_webapp_app_service_plan_per_site_scaling"></a> [ptrn\_webapp\_app\_service\_plan\_per\_site\_scaling](#input\_ptrn\_webapp\_app\_service\_plan\_per\_site\_scaling) | (Optional) Can Apps assigned to this App Service Plan be scaled independently? If set to false apps assigned to this plan will scale to all instances of the plan. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_app_service_plan_rg_name"></a> [ptrn\_webapp\_app\_service\_plan\_rg\_name](#input\_ptrn\_webapp\_app\_service\_plan\_rg\_name) | (Optional) The name of the App Service Plan resource group if cl\_app\_service\_plan\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_ptrn_webapp_app_service_plan_route_table_id"></a> [ptrn\_webapp\_app\_service\_plan\_route\_table\_id](#input\_ptrn\_webapp\_app\_service\_plan\_route\_table\_id) | (Optional) The ID of the route table that will be associated to the subnet | `string` | `""` | no |
| <a name="input_ptrn_webapp_app_service_plan_sku_capacity"></a> [ptrn\_webapp\_app\_service\_plan\_sku\_capacity](#input\_ptrn\_webapp\_app\_service\_plan\_sku\_capacity) | (Optional) Specifies the number of workers associated with this App Service Plan. | `number` | `1` | no |
| <a name="input_ptrn_webapp_app_service_plan_sku_name"></a> [ptrn\_webapp\_app\_service\_plan\_sku\_name](#input\_ptrn\_webapp\_app\_service\_plan\_sku\_name) | (Optional) Specifies the plan's instance size. | `string` | `"P1v2"` | no |
| <a name="input_ptrn_webapp_app_service_plan_sku_tier"></a> [ptrn\_webapp\_app\_service\_plan\_sku\_tier](#input\_ptrn\_webapp\_app\_service\_plan\_sku\_tier) | (Optional) Specifies the plan's pricing tier. | `string` | `"PremiumV2"` | no |
| <a name="input_ptrn_webapp_app_service_remote_debugging_version"></a> [ptrn\_webapp\_app\_service\_remote\_debugging\_version](#input\_ptrn\_webapp\_app\_service\_remote\_debugging\_version) | (Optional) Which version of Visual Studio should the Remote Debugger be compatible with? | `string` | `"VS2017"` | no |
| <a name="input_ptrn_webapp_app_service_settings"></a> [ptrn\_webapp\_app\_service\_settings](#input\_ptrn\_webapp\_app\_service\_settings) | (Optional) Variables passed as environment variables | `map` | `{}` | no |
| <a name="input_ptrn_webapp_app_service_support_cors_credentials"></a> [ptrn\_webapp\_app\_service\_support\_cors\_credentials](#input\_ptrn\_webapp\_app\_service\_support\_cors\_credentials) | (Optional) Are credentials supported?. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_app_service_use_32_bit_worker_process"></a> [ptrn\_webapp\_app\_service\_use\_32\_bit\_worker\_process](#input\_ptrn\_webapp\_app\_service\_use\_32\_bit\_worker\_process) | (Optional) Should the App Service run in 32 bit mode, rather than 64 bit mode? | `bool` | `true` | no |
| <a name="input_ptrn_webapp_app_service_vnet_route_server"></a> [ptrn\_webapp\_app\_service\_vnet\_route\_server](#input\_ptrn\_webapp\_app\_service\_vnet\_route\_server) | (Optional) Should all outbound traffic to have Virtual Network Security Groups and User Defined Routes applied. | `number` | `1` | no |
| <a name="input_ptrn_webapp_app_storage_account_nsg_flow_log_id"></a> [ptrn\_webapp\_app\_storage\_account\_nsg\_flow\_log\_id](#input\_ptrn\_webapp\_app\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_ptrn_webapp_azure_sql_database_LTR_monthly_retention"></a> [ptrn\_webapp\_azure\_sql\_database\_LTR\_monthly\_retention](#input\_ptrn\_webapp\_azure\_sql\_database\_LTR\_monthly\_retention) | (Optional) The monthly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D. | `string` | `"P1M"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_LTR_week_of_year"></a> [ptrn\_webapp\_azure\_sql\_database\_LTR\_week\_of\_year](#input\_ptrn\_webapp\_azure\_sql\_database\_LTR\_week\_of\_year) | (Optional) The week of year to take the yearly backup in an ISO 8601 format. Value has to be between 1 and 52. | `number` | `1` | no |
| <a name="input_ptrn_webapp_azure_sql_database_LTR_weekly_retention"></a> [ptrn\_webapp\_azure\_sql\_database\_LTR\_weekly\_retention](#input\_ptrn\_webapp\_azure\_sql\_database\_LTR\_weekly\_retention) | (Optional) The weekly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D. | `string` | `"P1W"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_LTR_yearly_retention"></a> [ptrn\_webapp\_azure\_sql\_database\_LTR\_yearly\_retention](#input\_ptrn\_webapp\_azure\_sql\_database\_LTR\_yearly\_retention) | (Optional) The yearly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 10 years. e.g. P1Y, P12M, P52W or P365D. | `string` | `"P1Y"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_STR_retention"></a> [ptrn\_webapp\_azure\_sql\_database\_STR\_retention](#input\_ptrn\_webapp\_azure\_sql\_database\_STR\_retention) | (Required) Point In Time Restore configuration. Value has to be between 7 and 35. | `number` | `35` | no |
| <a name="input_ptrn_webapp_azure_sql_database_audit_retention_days"></a> [ptrn\_webapp\_azure\_sql\_database\_audit\_retention\_days](#input\_ptrn\_webapp\_azure\_sql\_database\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `7` | no |
| <a name="input_ptrn_webapp_azure_sql_database_collation"></a> [ptrn\_webapp\_azure\_sql\_database\_collation](#input\_ptrn\_webapp\_azure\_sql\_database\_collation) | (Optional) Specifies the collation of the database. Changing this forces a new resource to be created. | `string` | `"SQL_Latin1_General_CP1_CI_AS"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_create_mode"></a> [ptrn\_webapp\_azure\_sql\_database\_create\_mode](#input\_ptrn\_webapp\_azure\_sql\_database\_create\_mode) | (Optional) The create mode of the database. Possible values are Copy, Default, OnlineSecondary, PointInTimeRestore, Recovery, Restore, RestoreExternalBackup, RestoreExternalBackupSecondary, RestoreLongTermRetentionBackup and Secondary. | `string` | `"Default"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_diagnostics"></a> [ptrn\_webapp\_azure\_sql\_database\_diagnostics](#input\_ptrn\_webapp\_azure\_sql\_database\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "SQLInsights",<br>    "AutomaticTuning",<br>    "QueryStoreRuntimeStatistics",<br>    "QueryStoreWaitStatistics",<br>    "Errors",<br>    "DatabaseWaitStatistics",<br>    "Timeouts",<br>    "Blocks",<br>    "Deadlocks"<br>  ],<br>  "metrics": [<br>    "Basic",<br>    "InstanceAndAppAdvanced",<br>    "WorkloadManagement"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_webapp_azure_sql_database_disabled_alerts"></a> [ptrn\_webapp\_azure\_sql\_database\_disabled\_alerts](#input\_ptrn\_webapp\_azure\_sql\_database\_disabled\_alerts) | (Optional) Specifies a list of alerts which should be disabled. Possible values include Access\_Anomaly, Sql\_Injection and Sql\_Injection\_Vulnerability. | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_database_elastic_pool_enable"></a> [ptrn\_webapp\_azure\_sql\_database\_elastic\_pool\_enable](#input\_ptrn\_webapp\_azure\_sql\_database\_elastic\_pool\_enable) | (Optional) Enable te creation for sql elastic pool | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_database_elastic_pool_id"></a> [ptrn\_webapp\_azure\_sql\_database\_elastic\_pool\_id](#input\_ptrn\_webapp\_azure\_sql\_database\_elastic\_pool\_id) | (Optional) The Elastic Pool id to Integrate the DB with one azure sql elastic pool. | `string` | `null` | no |
| <a name="input_ptrn_webapp_azure_sql_database_license"></a> [ptrn\_webapp\_azure\_sql\_database\_license](#input\_ptrn\_webapp\_azure\_sql\_database\_license) | (Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_postfix"></a> [ptrn\_webapp\_azure\_sql\_database\_postfix](#input\_ptrn\_webapp\_azure\_sql\_database\_postfix) | (Required) A string that is appended to the end of the database name to identify it. | `string` | n/a | yes |
| <a name="input_ptrn_webapp_azure_sql_database_read"></a> [ptrn\_webapp\_azure\_sql\_database\_read](#input\_ptrn\_webapp\_azure\_sql\_database\_read) | (Optional) If enabled, connections that have application intent set to readonly in their connection string may be routed to a readonly secondary replica. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_database_redudant"></a> [ptrn\_webapp\_azure\_sql\_database\_redudant](#input\_ptrn\_webapp\_azure\_sql\_database\_redudant) | (Optional) Whether or not this database is zone redundant, which means the replicas of this database will be spread across multiple availability zones. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_database_replica_count"></a> [ptrn\_webapp\_azure\_sql\_database\_replica\_count](#input\_ptrn\_webapp\_azure\_sql\_database\_replica\_count) | (Optional) The number of readonly secondary replicas associated with the database to which readonly application intent connections may be routed. This property is only settable for Hyperscale edition databases. | `number` | `null` | no |
| <a name="input_ptrn_webapp_azure_sql_database_size"></a> [ptrn\_webapp\_azure\_sql\_database\_size](#input\_ptrn\_webapp\_azure\_sql\_database\_size) | (Optional) The max size of the database in gigabytes. | `number` | `1` | no |
| <a name="input_ptrn_webapp_azure_sql_database_sku"></a> [ptrn\_webapp\_azure\_sql\_database\_sku](#input\_ptrn\_webapp\_azure\_sql\_database\_sku) | (Optional) Specifies the name of the sku used by the database. Changing this forces a new resource to be created. Single Database default value: BC\_Gen5\_2. If the database require be include in Elastic Pool group, in variable sku default value: ElasticPool. | `string` | `"BC_Gen5_2"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_threat_email_admins"></a> [ptrn\_webapp\_azure\_sql\_database\_threat\_email\_admins](#input\_ptrn\_webapp\_azure\_sql\_database\_threat\_email\_admins) | (Optional) Should the account administrators be emailed when this alert is triggered? | `string` | `"Disabled"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_threat_emails"></a> [ptrn\_webapp\_azure\_sql\_database\_threat\_emails](#input\_ptrn\_webapp\_azure\_sql\_database\_threat\_emails) | (Optional) A list of email addresses which alerts should be sent to. | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_database_threat_logs_retention"></a> [ptrn\_webapp\_azure\_sql\_database\_threat\_logs\_retention](#input\_ptrn\_webapp\_azure\_sql\_database\_threat\_logs\_retention) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_ptrn_webapp_azure_sql_database_threat_policy_state"></a> [ptrn\_webapp\_azure\_sql\_database\_threat\_policy\_state](#input\_ptrn\_webapp\_azure\_sql\_database\_threat\_policy\_state) | (Optional) The State of the Policy. Possible values are Enabled, Disabled or New. | `string` | `"Enabled"` | no |
| <a name="input_ptrn_webapp_azure_sql_database_threat_server_default"></a> [ptrn\_webapp\_azure\_sql\_database\_threat\_server\_default](#input\_ptrn\_webapp\_azure\_sql\_database\_threat\_server\_default) | (Optional) Should the default server policy be used? | `string` | `"Disabled"` | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_database_max_dtu_capacity"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_database\_max\_dtu\_capacity](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_database\_max\_dtu\_capacity) | The maximum capacity any one database can consume in the Elastic Pool. Default to the max Elastic Pool capacity. | `string` | `"1"` | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_database_min_capacity"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_database\_min\_capacity](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_database\_min\_capacity) | The minimum capacity all databases are guaranteed in the Elastic Pool. Defaults to 0. | `string` | `"0"` | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_diagnostic"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_diagnostic](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_enable"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_enable](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_enable) | (Optional) Enable te creation for sql elastic pool | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_license_type"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_license\_type](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_license\_type) | (Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_max_size"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_max\_size](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_max\_size) | Maximum size of the Elastic Pool in gigabytes | `string` | `"1024"` | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_postfix"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_postfix](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `string` | `"globaldb"` | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_sku"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_sku](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_sku) | SKU for the Elastic Pool with tier and eDTUs capacity. Premium tier with zone redundancy is mandatory for high availability. Possible values for tier are Basic, Standard, or Premium. Example tier=Standard, capacity=50. See https://docs.microsoft.com/en-us/azure/sql-database/sql-database-dtu-resource-limits-elastic-pools | <pre>object({<br>    name     = string,<br>    tier     = string,<br>    family   = string,<br>    capacity = string<br>  })</pre> | <pre>{<br>  "capacity": "4",<br>  "family": "Gen5",<br>  "name": "BC_Gen5",<br>  "tier": "BusinessCritical"<br>}</pre> | no |
| <a name="input_ptrn_webapp_azure_sql_elastic_pool_zone_redundant"></a> [ptrn\_webapp\_azure\_sql\_elastic\_pool\_zone\_redundant](#input\_ptrn\_webapp\_azure\_sql\_elastic\_pool\_zone\_redundant) | Whether or not the Elastic Pool is zone redundant, SKU tier must be Premium to use it. This is mandatory for high availability. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_server_administrator"></a> [ptrn\_webapp\_azure\_sql\_server\_administrator](#input\_ptrn\_webapp\_azure\_sql\_server\_administrator) | (Required) The administrator login name for the new server. Changing this forces a new resource to be created. | `string` | n/a | yes |
| <a name="input_ptrn_webapp_azure_sql_server_alert_email_enabled"></a> [ptrn\_webapp\_azure\_sql\_server\_alert\_email\_enabled](#input\_ptrn\_webapp\_azure\_sql\_server\_alert\_email\_enabled) | (Optional) Boolean flag which specifies if the alert is sent to the account administrators or not. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_server_alert_emails"></a> [ptrn\_webapp\_azure\_sql\_server\_alert\_emails](#input\_ptrn\_webapp\_azure\_sql\_server\_alert\_emails) | (Optional) Specifies an array of e-mail addresses to which the alert is sent. | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_server_alert_retention_days"></a> [ptrn\_webapp\_azure\_sql\_server\_alert\_retention\_days](#input\_ptrn\_webapp\_azure\_sql\_server\_alert\_retention\_days) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `90` | no |
| <a name="input_ptrn_webapp_azure_sql_server_alert_state"></a> [ptrn\_webapp\_azure\_sql\_server\_alert\_state](#input\_ptrn\_webapp\_azure\_sql\_server\_alert\_state) | (Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific database server. Allowed values are: Disabled, Enabled. | `string` | `"Enabled"` | no |
| <a name="input_ptrn_webapp_azure_sql_server_audit_retention_days"></a> [ptrn\_webapp\_azure\_sql\_server\_audit\_retention\_days](#input\_ptrn\_webapp\_azure\_sql\_server\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `90` | no |
| <a name="input_ptrn_webapp_azure_sql_server_connection_policy"></a> [ptrn\_webapp\_azure\_sql\_server\_connection\_policy](#input\_ptrn\_webapp\_azure\_sql\_server\_connection\_policy) | (Optional) The connection policy the server will use. Possible values are Default, Proxy, and Redirect. | `string` | `"Default"` | no |
| <a name="input_ptrn_webapp_azure_sql_server_disabled_alerts"></a> [ptrn\_webapp\_azure\_sql\_server\_disabled\_alerts](#input\_ptrn\_webapp\_azure\_sql\_server\_disabled\_alerts) | (Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql\_Injection, Sql\_Injection\_Vulnerability, Access\_Anomaly, Data\_Exfiltration, Unsafe\_Action. | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_server_firewall_rules"></a> [ptrn\_webapp\_azure\_sql\_server\_firewall\_rules](#input\_ptrn\_webapp\_azure\_sql\_server\_firewall\_rules) | (Optional) Define additional firewall rules | <pre>map(object({<br>    start_ip                 = string<br>    end_ip                   = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_webapp_azure_sql_server_log_analytics_solution"></a> [ptrn\_webapp\_azure\_sql\_server\_log\_analytics\_solution](#input\_ptrn\_webapp\_azure\_sql\_server\_log\_analytics\_solution) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureSQLAnalytics": {<br>    "product": "OMSGallery/AzureSQLAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_webapp_azure_sql_server_login_username"></a> [ptrn\_webapp\_azure\_sql\_server\_login\_username](#input\_ptrn\_webapp\_azure\_sql\_server\_login\_username) | (Required) Login username Mandatory if azuread\_administrator is true | `string` | `null` | no |
| <a name="input_ptrn_webapp_azure_sql_server_nacl_allowed_subnets"></a> [ptrn\_webapp\_azure\_sql\_server\_nacl\_allowed\_subnets](#input\_ptrn\_webapp\_azure\_sql\_server\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure SQL Server. | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_server_object_id"></a> [ptrn\_webapp\_azure\_sql\_server\_object\_id](#input\_ptrn\_webapp\_azure\_sql\_server\_object\_id) | (Required) AD Objetct id Mandatory if azuread\_administrator is true | `string` | `null` | no |
| <a name="input_ptrn_webapp_azure_sql_server_password"></a> [ptrn\_webapp\_azure\_sql\_server\_password](#input\_ptrn\_webapp\_azure\_sql\_server\_password) | (Required) The password associated with the ptrn\_webapp\_azure\_sql\_server\_administrator user. | `string` | n/a | yes |
| <a name="input_ptrn_webapp_azure_sql_server_postfix"></a> [ptrn\_webapp\_azure\_sql\_server\_postfix](#input\_ptrn\_webapp\_azure\_sql\_server\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `string` | n/a | yes |
| <a name="input_ptrn_webapp_azure_sql_server_public_network_access"></a> [ptrn\_webapp\_azure\_sql\_server\_public\_network\_access](#input\_ptrn\_webapp\_azure\_sql\_server\_public\_network\_access) | (Optional) Whether or not public network access is allowed for this server. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_server_resource_group_name"></a> [ptrn\_webapp\_azure\_sql\_server\_resource\_group\_name](#input\_ptrn\_webapp\_azure\_sql\_server\_resource\_group\_name) | (Required) Specifies the Azure SQL Server resource group | `any` | n/a | yes |
| <a name="input_ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids"></a> [ptrn\_webapp\_azure\_sql\_server\_sa\_allowed\_pe\_subnet\_ids](#input\_ptrn\_webapp\_azure\_sql\_server\_sa\_allowed\_pe\_subnet\_ids) | (Required) A list of Ip addresses that can access the storage account. It is recommended that you add your automation tool's IP range here. | `list` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids"></a> [ptrn\_webapp\_azure\_sql\_server\_sa\_allowed\_vnet\_subnet\_ids](#input\_ptrn\_webapp\_azure\_sql\_server\_sa\_allowed\_vnet\_subnet\_ids) | (Required) A list of Subnets of the vnet that can access the sql server storage account. | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_server_security_email_subscription"></a> [ptrn\_webapp\_azure\_sql\_server\_security\_email\_subscription](#input\_ptrn\_webapp\_azure\_sql\_server\_security\_email\_subscription) | (Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_azure_sql_server_security_emails"></a> [ptrn\_webapp\_azure\_sql\_server\_security\_emails](#input\_ptrn\_webapp\_azure\_sql\_server\_security\_emails) | (Optional) Specifies an array of e-mail addresses to which the scan notification is sent. | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_sql_server_security_scans"></a> [ptrn\_webapp\_azure\_sql\_server\_security\_scans](#input\_ptrn\_webapp\_azure\_sql\_server\_security\_scans) | (Optional) Boolean flag which specifies if recurring scans is enabled or disabled. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_azure_sql_server_storage_account_blob_retention_days"></a> [ptrn\_webapp\_azure\_sql\_server\_storage\_account\_blob\_retention\_days](#input\_ptrn\_webapp\_azure\_sql\_server\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `365` | no |
| <a name="input_ptrn_webapp_azure_sql_server_storage_account_diagnostics"></a> [ptrn\_webapp\_azure\_sql\_server\_storage\_account\_diagnostics](#input\_ptrn\_webapp\_azure\_sql\_server\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_webapp_azure_sql_server_storage_account_tier"></a> [ptrn\_webapp\_azure\_sql\_server\_storage\_account\_tier](#input\_ptrn\_webapp\_azure\_sql\_server\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for Azure SQL server audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_ptrn_webapp_azure_sql_server_tls"></a> [ptrn\_webapp\_azure\_sql\_server\_tls](#input\_ptrn\_webapp\_azure\_sql\_server\_tls) | (Optional) The Minimum TLS Version for all SQL Database and SQL Data Warehouse databases associated with the server. Valid values are: 1.0, 1.1 and 1.2. | `string` | `"1.2"` | no |
| <a name="input_ptrn_webapp_azure_sql_server_version"></a> [ptrn\_webapp\_azure\_sql\_server\_version](#input\_ptrn\_webapp\_azure\_sql\_server\_version) | (Optional) The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server). | `string` | `"12.0"` | no |
| <a name="input_ptrn_webapp_azure_sql_server_vnet_rules"></a> [ptrn\_webapp\_azure\_sql\_server\_vnet\_rules](#input\_ptrn\_webapp\_azure\_sql\_server\_vnet\_rules) | (Optional) Define additional virtual network rules | `list(string)` | `[]` | no |
| <a name="input_ptrn_webapp_azure_storage_account_secondary_access_key"></a> [ptrn\_webapp\_azure\_storage\_account\_secondary\_access\_key](#input\_ptrn\_webapp\_azure\_storage\_account\_secondary\_access\_key) | (Optional) Specifies whether cl\_azure\_storage\_account\_access\_key value is the storage's secondary key. | `bool` | `false` | no |
| <a name="input_ptrn_webapp_deploy_private_dns_zone_app"></a> [ptrn\_webapp\_deploy\_private\_dns\_zone\_app](#input\_ptrn\_webapp\_deploy\_private\_dns\_zone\_app) | (Optional) A boolean to enable/disable the deployment of a private\_dns\_zone\_app for the app service private endpoint. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_deploy_private_dns_zone_db"></a> [ptrn\_webapp\_deploy\_private\_dns\_zone\_db](#input\_ptrn\_webapp\_deploy\_private\_dns\_zone\_db) | (Optional) A boolean to enable/disable the deployment of a private\_dns\_zone\_app for the azure SQL private endpoint. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_endpoint_address_prefixes"></a> [ptrn\_webapp\_endpoint\_address\_prefixes](#input\_ptrn\_webapp\_endpoint\_address\_prefixes) | (Required) Subnet where the private endpoints are going to be added | `list(string)` | n/a | yes |
| <a name="input_ptrn_webapp_log_analytics_workspace_name"></a> [ptrn\_webapp\_log\_analytics\_workspace\_name](#input\_ptrn\_webapp\_log\_analytics\_workspace\_name) | (Required) The Analytics Workspace Name | `any` | n/a | yes |
| <a name="input_ptrn_webapp_network_rg"></a> [ptrn\_webapp\_network\_rg](#input\_ptrn\_webapp\_network\_rg) | (Required) The rg name for the network resources | `any` | n/a | yes |
| <a name="input_ptrn_webapp_private_endpoint_subnet_service_endpoints"></a> [ptrn\_webapp\_private\_endpoint\_subnet\_service\_endpoints](#input\_ptrn\_webapp\_private\_endpoint\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `list` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.Storage",<br>  "Microsoft.KeyVault"<br>]</pre> | no |
| <a name="input_ptrn_webapp_private_endpoint_subresource_names"></a> [ptrn\_webapp\_private\_endpoint\_subresource\_names](#input\_ptrn\_webapp\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "sqlServer"<br>]</pre> | no |
| <a name="input_ptrn_webapp_service_log_analytics_workspace_id"></a> [ptrn\_webapp\_service\_log\_analytics\_workspace\_id](#input\_ptrn\_webapp\_service\_log\_analytics\_workspace\_id) | (Required) The ID for the network resources | `any` | n/a | yes |
| <a name="input_ptrn_webapp_set_private_ip_listener"></a> [ptrn\_webapp\_set\_private\_ip\_listener](#input\_ptrn\_webapp\_set\_private\_ip\_listener) | (Optional) A boolean variable indicating which environment the app gateway is being deployed into. | `bool` | `true` | no |
| <a name="input_ptrn_webapp_vnet_id"></a> [ptrn\_webapp\_vnet\_id](#input\_ptrn\_webapp\_vnet\_id) | (Required) The ID of the virtual Network | `any` | n/a | yes |
| <a name="input_ptrn_webapp_vnet_name"></a> [ptrn\_webapp\_vnet\_name](#input\_ptrn\_webapp\_vnet\_name) | (Required) The Name of the virtual network | `any` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |



## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_azure_sql_elastic_pool"></a> [cl\_azure\_sql\_elastic\_pool](#output\_cl\_azure\_sql\_elastic\_pool) | n/a |
| <a name="output_ptrn_webapp_app_gateway"></a> [ptrn\_webapp\_app\_gateway](#output\_ptrn\_webapp\_app\_gateway) | n/a |
| <a name="output_ptrn_webapp_app_service"></a> [ptrn\_webapp\_app\_service](#output\_ptrn\_webapp\_app\_service) | n/a |
| <a name="output_ptrn_webapp_azure_sql_database"></a> [ptrn\_webapp\_azure\_sql\_database](#output\_ptrn\_webapp\_azure\_sql\_database) | n/a |
| <a name="output_ptrn_webapp_azure_sql_server"></a> [ptrn\_webapp\_azure\_sql\_server](#output\_ptrn\_webapp\_azure\_sql\_server) | n/a |
| <a name="output_ptrn_webapp_private_endpoint_subnet"></a> [ptrn\_webapp\_private\_endpoint\_subnet](#output\_ptrn\_webapp\_private\_endpoint\_subnet) | Outputs ********************************************************************************************** |
| <a name="output_ptrn_webapp_service_plan"></a> [ptrn\_webapp\_service\_plan](#output\_ptrn\_webapp\_service\_plan) | Module Outputs ********************************************************************************************** |



## Usage

```terraform
//1. Deploy Pattern
//**********************************************************************************************
module "ptrn_webapp" {
  source                                                       = "../dn-tads_tf-azure-component-library/patterns/ptrn_webapp_gov"
  env                                                          = var.env
  postfix                                                      = var.postfix
  location                                                     = var.location
  suffix                                                       = var.suffix
  tags                                                         = var.tags
  ptrn_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA       
  ptrn_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  ptrn_webapp_app_gateway_subnet_address_prefix                = ["60.0.1.0/24"]
  ptrn_webapp_set_private_ip_listener                          = true
  ptrn_webapp_app_gateway_rg                                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_network_rg                                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_vnet_id                                          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  ptrn_webapp_vnet_name                                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  ptrn_webapp_analytics_rg                                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  ptrn_webapp_service_log_analytics_workspace_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_webapp_log_analytics_workspace_name                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  ptrn_webapp_app_service_plan_integration_vnet_rg_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ptrn_webapp_app_service_plan_deploy_integration_subnet       = true
  ptrn_webapp_app_service_plan_integration_subnet_service_endpoints = ["Microsoft.AzureActiveDirectory", "Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web"]
  ptrn_webapp_app_service_plan_integration_subnet_prefix       = ["60.0.2.0/24"]
  ptrn_webapp_app_service_app_postfix                          = "app1"
  ptrn_webapp_app_service_plan_app_postfix                     = "apppsfx"
  ptrn_webapp_app_service_plan_route_table_id                  = azurerm_route_table.routetable60.id
  ptrn_webapp_app_service_auth_settings_enabled                = false
  ptrn_webapp_azure_sql_server_resource_group_name             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_webapp_azure_sql_server_postfix                         = "global"
  ptrn_webapp_azure_sql_server_administrator                   = "xxxxxxx"
  ptrn_webapp_azure_sql_server_password                        = "xxxxxxx"
  ptrn_webapp_azure_sql_server_login_username                  = "xxxx@kpmg.com"
  ptrn_webapp_azure_sql_server_object_id                       = "xxxxxxxxxxxxxxx"
  ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = var.ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids
  ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = var.ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids
  ptrn_webapp_azure_sql_elastic_pool_enable                    = true # true deploy elastic pool module / false no deploy 
  ptrn_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_webapp_azure_sql_elastic_pool_enable in false dont send values for variable ptrn_webapp_azure_sql_database_sku
  ptrn_webapp_azure_sql_database_postfix                       = "globaldb"
  ptrn_webapp_endpoint_address_prefixes                        = ["60.0.3.0/24"]
  ptrn_webapp_app_storage_account_nsg_flow_log_id               = var.ptrn_webapp_app_storage_account_nsg_flow_log_id
  ptrn_webapp_app_gateway_nsg_flow_log_postfix                  = var.ptrn_webapp_app_gateway_nsg_flow_log_postfix
}
```
//2. Deploy Pattern with App Service single-container and ACR 
//**********************************************************************************************
```terraform

//Deploy Module ACR for single container App Servie
module "cl_azure_container_registry" {
    source                                                      = "../dn-tads_tf-azure-component-library/components/cl_azure_container_registry"
    env                                                         = var.env
    postfix                                                     = var.postfix
    location                                                    = var.location
     tags                                                         = var.tags
    cl_azure_container_registry_rg_name                         = module.ptrn_webapp.ptrn_webapp_service_rg
    cl_azure_container_registry_log_analytics_workspace_id      = var.cl_b2c_manager_core_log_analytics_workspace_id
    cl_azure_container_registry_allowed_vnet_ids                = [var.cl_b2c_manager_core_vnet_id]
    cl_azure_container_registry_content_trust_enabled           = false
    cl_azure_container_registry_admin_enabled                   = true
    cl_azure_container_registry_network_rule_set_default_action = "Allow"
}

// Deploy Module ptrn webapp: Application Gateway, App Service Plan, App Service and Azure SQL

module "ptrn_webapp" {
  source                                                            = "../dn-tads_tf-azure-component-library/patterns/ptrn_webapp_gov"
  env                                                               = var.env
  postfix                                                           = var.postfix
  location                                                          = var.location
  suffix                                                            = var.suffix
  tags                                                              = var.tags
  ptrn_webapp_app_gateway_frontend_tls_cert                         = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA       
  ptrn_webapp_app_gateway_frontend_tls_cert_pass                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  ptrn_webapp_app_gateway_subnet_address_prefix                     = ["10.1.3.0/24"]
  ptrn_webapp_set_private_ip_listener                               = true
  ptrn_webapp_app_gateway_rg                                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_network_rg                                            = var.cl_b2c_manager_core_rg_network_name
  ptrn_webapp_vnet_id                                               = var.cl_b2c_manager_core_vnet_id
  ptrn_webapp_vnet_name                                             = var.cl_b2c_manager_core_vnet_name
  ptrn_webapp_analytics_rg                                          = var.cl_b2c_manager_core_rg_logging_name
  ptrn_webapp_service_log_analytics_workspace_id                    = var.cl_b2c_manager_core_log_analytics_workspace_id
  ptrn_webapp_log_analytics_workspace_name                          = var.cl_b2c_manager_core_log_analytics_workspace_name
  ptrn_webapp_app_service_plan_integration_vnet_rg_name             = var.cl_b2c_manager_core_rg_network_name
  ptrn_webapp_app_service_plan_deploy_integration_subnet            = true
  ptrn_webapp_app_service_plan_integration_subnet_service_endpoints = ["Microsoft.AzureActiveDirectory", "Microsoft.Sql", "Microsoft.Storage", "Microsoft.Web", "Microsoft.ContainerRegistry"]
  ptrn_webapp_app_service_plan_integration_subnet_prefix            = ["10.1.4.0/27"]
  ptrn_webapp_app_service_app_postfix                               = "b2cmanagement"
  ptrn_webapp_app_service_plan_app_postfix                          = "b2cmanager"
  ptrn_webapp_app_service_plan_route_table_id                       = var.cl_b2c_route_table_defatul_id
  ptrn_webapp_app_service_auth_settings_enabled                     = false
  ptrn_webapp_azure_sql_server_resource_group_name                  = module.ptrn_webapp.ptrn_webapp_service_rg
  ptrn_webapp_azure_sql_server_postfix                              = "b2cmanager"
  ptrn_webapp_azure_sql_server_administrator                        = "xxxxx"
  ptrn_webapp_azure_sql_server_password                             = "xxxxx"
  ptrn_webapp_azure_sql_server_login_username                  = "xxxx@kpmg.com"
  ptrn_webapp_azure_sql_server_object_id                       = "xxxxxxxxxxxxxxx"
  ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = var.ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids
  ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = var.ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids
  ptrn_webapp_azure_sql_elastic_pool_enable                    = true # true deploy elastic pool module / false no deploy 
  ptrn_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / variable ptrn_webapp_azure_sql_elastic_pool_enable in false dont send values for variable ptrn_webapp_azure_sql_database_sku
  ptrn_webapp_azure_sql_database_postfix                            = "b2cmanager"
  ptrn_webapp_endpoint_address_prefixes                             = ["10.1.5.0/24"]
  ptrn_webapp_app_storage_account_nsg_flow_log_id               = var.ptrn_webapp_app_storage_account_nsg_flow_log_id
  ptrn_webapp_app_gateway_nsg_flow_log_postfix                  = var.ptrn_webapp_app_gateway_nsg_flow_log_postfix
  ptrn_webapp_app_service_plan_os_type                              = "Windows"
  ptrn_webapp_app_service_plan_reserved                             = true
  ptrn_webapp_app_service_http2_enabled                             = true
  ptrn_webapp_app_service_use_32_bit_worker_process                 = true
  #ptrn_webapp_app_service_is_docker                                 = true
  #ptrn_webapp_app_service_acr_image                                 = "imagename:version" 
  #ptrn_webapp_app_service_acr_scm_type                              = "None"    
  ptrn_webapp_app_service_acr_login_server  = module.cl_azure_container_registry.cl_azure_container_registry.login_server
  ptrn_webapp_app_service_acr_username      = module.cl_azure_container_registry.cl_azure_container_registry_admin_username
  ptrn_webapp_app_service_acr_password      = module.cl_azure_container_registry.cl_azure_container_registry_admin_password
  ptrn_webapp_app_service_connection_strings = {
      connection_string = {
        name      = "sa_peninsula_connection"
        type      = "Custom"
        value     = var.cl_b2c_manager_app_service_connection_string_value
      }
    }
    }
```
```terraform
//3. Deploy Pattern with key vault to save Application Gateway certificates and Managed Identity asigned
//**********************************************************************************************
//Get the current client config
//***************************************************************************************************
data "azurerm_client_config" "current" {}

//Get the Principle(Object) Id of Application Gateway's Managed Identoty
//***************************************************************************************************
resource "azurerm_user_assigned_identity" "appgateway_keyvault_integration" {
  name                = "ptrn-iaas-webap-pappgwy-msi"
  location            = var.location
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
}

//Deploy Key vault
//Note: KeyVault Adminstrator role needs to be granted to SPN on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//Note:  KeyVault Secrets user/crypto user/certificates officer role needs to be granted to Application Gateway's Managed Identitity on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//***************************************************************************************************
module "cl_keyvault" {
  source                                   = "../dn-tads_tf-azure-component-library/components/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  suffix                                   = var.suffix
  tags                                     = var.tags
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_keyvault_nacl_allowed_ips             = ["199.206.0.0/15"]
  // ToDo: Remove app gateway subnet if dependency fails
  cl_keyvault_nacl_allowed_subnets         = [module.ptrn_webapp.ptrn_webapp_private_endpoint_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [module.ptrn_webapp.ptrn_webapp_private_endpoint_subnet.id]
}


//Add secrets/certificates to keyvault
//***************************************************************************************************
resource "azurerm_key_vault_certificate" "appgateway_cert" {
  name         = "ptrn-iaas-webapp-appgateway-cert"
  key_vault_id = module.cl_keyvault.cl_keyvault.id

  certificate {
    contents = filebase64(var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA)
    password = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  }

  certificate_policy {
    issuer_parameters {
      name = "Unknown"
    }

    key_properties {
      exportable = true
      key_size   = 2048
      key_type   = "RSA"
      reuse_key  = false
    }

    secret_properties {
      content_type = "application/x-pkcs12"
    }
  }
}

//Deploy webapp pattern 
//***************************************************************************************************
module "ptrn_webapp" {
  source                                                       = "../dn-tads_tf-azure-component-library/patterns/ptrn_webapp_gov"
  env                                                          = var.env
  postfix                                                      = var.postfix
  location                                                     = var.location
  suffix                                                       = var.suffix
  tags                                                         = var.tags
  ptrn_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA       
  ptrn_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  ptrn_webapp_app_gateway_subnet_address_prefix                = ["60.0.1.0/24"]
  ptrn_webapp_set_private_ip_listener                          = true
  ptrn_webapp_app_gateway_rg                                   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_network_rg                                       = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
  ptrn_webapp_vnet_id                                          = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  ptrn_webapp_vnet_name                                        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  ptrn_webapp_analytics_rg                                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  ptrn_webapp_service_log_analytics_workspace_id               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_webapp_log_analytics_workspace_name                     = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  ptrn_webapp_app_service_plan_integration_vnet_rg_name        = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ptrn_webapp_app_service_plan_deploy_integration_subnet       = true
  ptrn_webapp_app_service_plan_integration_subnet_service_endpoints = ["Microsoft.AzureCosmosDB", "Microsoft.Storage", "Microsoft.Web", "Microsoft.KeyVault"]
  ptrn_webapp_app_service_plan_integration_subnet_prefix       = ["60.0.2.0/24"]
  ptrn_webapp_app_service_app_postfix                          = "app1"
  ptrn_webapp_app_service_plan_app_postfix                     = "apppsfx"
  ptrn_webapp_app_service_plan_route_table_id                  = azurerm_route_table.routetable60.id
  ptrn_webapp_app_service_auth_settings_enabled                = false
  ptrn_webapp_azure_sql_server_resource_group_name             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_webapp_azure_sql_server_postfix                         = "global"
  ptrn_webapp_azure_sql_server_administrator                   = "xxxxxxx"
  ptrn_webapp_azure_sql_server_password                        = "xxxxxxx"
  ptrn_webapp_azure_sql_server_login_username                  = "xxxx@kpmg.com"
  ptrn_webapp_azure_sql_server_object_id                       = "xxxxxxxxxxxxxxx"
  ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = var.ptrn_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids
  ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = var.ptrn_webapp_azure_sql_server_sa_allowed_pe_subnet_ids
  ptrn_webapp_azure_sql_elastic_pool_enable                    = true # true deploy elastic pool module / false no deploy 
  ptrn_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_webapp_azure_sql_elastic_pool_enable in false dont send values for variable ptrn_webapp_azure_sql_database_sku
  ptrn_webapp_azure_sql_database_postfix                       = "globaldb"
  ptrn_webapp_endpoint_address_prefixes                        = ["60.0.3.0/24"]
  ptrn_webapp_app_storage_account_nsg_flow_log_id               = var.ptrn_webapp_app_storage_account_nsg_flow_log_id
  ptrn_webapp_app_gateway_nsg_flow_log_postfix                  = var.ptrn_webapp_app_gateway_nsg_flow_log_postfix
  ptrn_webapp_app_gateway_identity_ids                         = [azurerm_user_assigned_identity.appgateway_keyvault_integration.id]
  ptrn_webapp_app_gateway_frontend_tls_cert_keyvault_id        = azurerm_key_vault_certificate.appgateway_cert.secret_id
}
```
<!-- END_TF_DOCS -->
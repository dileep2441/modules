# Azure Openai Pattern 

This is the Azure OpenAI Pattern. It'll deploy the following Components:
* Application Gateway & WAF
* App service Plan
* App services
* Azure Container Registry
* Azure SQL Database
* Azure SQL Server
* Azure SQL Elastic Pool
* cognitive services (AOAI)
* Storage account
* Redis Cache (regular and enterprise cluster)
* APIM
* App Insights

## Variables
```terraform
// Common Variables
//**********************************************************************************************
variable "env" {
    description = "(Required) The environment where resources will be deployed into. Part of the naming scheme."
}
variable "postfix" {
    description = "(Required) A unique identifier for the deployment. Part of the naming scheme."
}
variable "location" {
    description = "(Required) The cloud region where resources will be deployed into."
}
//**********************************************************************************************

//**********************************************************************************************
                          // Azure Container Resgistry Variables
//**********************************************************************************************
// Required
variable "ptrn_openai_deploy_container_registry" {
  description = "(Required) set to true to enable the creation for ACR"
  default     = true
}
variable "ptrn_openai_azure_container_registry_rg_name" {
    description = "(Required) The resource group for the azure container registry."
    type        = string
    default     = null
}
variable "ptrn_openai_azure_container_registry_sku" {
    type        = string
    description = "(Required) Desire SKU for the Container Registry. Can be Basic, Standard or Premium."
    default     = "Premium"
}
variable "ptrn_openai_core_log_analytics_workspace_resource_id" {
    type        = string
    description = "(Required) Spoke log analytics workspace ID."
    default     = ""
}
variable "ptrn_openai_azure_container_registry_allowed_subnets" {
    type        = list(string)
    description = "(Required) One or more Subnet ID's which should be able to access this Container Registry."
    default     = null
}
variable "ptrn_openai_azure_container_registry_nacl_allowed_subnets" {
    type        = list(string)
    description = "(Optional) One or more Subnet ID's which should be able to access the Azure Container Registry."
    default     = []
}
variable "ptrn_openai_azure_container_registry_allowed_vnet_ids" {
    type        = list(string)
    description = "(Required) One or more VNET ID's which should be linked to the Private DNS Zone for ACR name resolution and access trough Private Endpoint."
    default     = [""]
}
variable "ptrn_openai_azure_container_registry_private_dns_zone_id" {
    description = "(Required) existing Private Dns zone id for ACR"
    type = string
    default = null
}
// Optional
variable "ptrn_openai_azure_container_registry_admin_enabled" {
    description = "(Optional) Specifies whether the admin user is enabled."
    default     = false
}
variable "ptrn_openai_azure_container_registry_ip_rule_action" {
    description = "(Optional) The action for the IP rule."
    default     = "Allow"
}
variable "ptrn_openai_azure_container_registry_ip_rule_ranges" {
    description = "(Optional) The CIDR range for the IP rule."
    type        = list(string)
    default     =  ["199.206.0.0/15"]
}
variable "ptrn_openai_azure_container_registry_public_network_access_enabled" {
    description = "(Optional) Whether public network access is allowed for the container registry."
    default     = true #to allow selected network access
}
variable "ptrn_openai_azure_container_registry_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default = {
        logs    = ["ContainerRegistryRepositoryEvents", "ContainerRegistryLoginEvents"]
        metrics = ["AllMetrics"]
    }
}
variable "ptrn_openai_azure_container_registry_dns_zone_enabled"{
    description = "(Optional) Enabled creation of acr dns private zone."
    default     = true
}
variable "ptrn_openai_azure_container_registry_dns_zone_name" {
    description = "Is the private link to be associated with the Private DNS Zone. By default it uses recommended Private DNS Zone name"
    type        = string
    default     = "privatelink.azurecr.us"
}
variable "ptrn_openai_azure_container_registry_content_trust_enabled" {
    description = "(Optional) Enables content trust for the sign of images being pushed to the registry"
    type        = bool
    default     = false
}
variable "ptrn_openai_azure_container_registry_network_rule_set_default_action" {
    type        = string
    description = "(Optional) The behaviour for requests matching no rules. Either Allow or Deny. Defaults to Deny"
    default     = "Deny"
}
//**********************************************************************************************


//**********************************************************************************************
//                             Cognitive Search Variables
//**********************************************************************************************
// Required
variable "ptrn_openai_cl_cognitive_services_openai" {
  type = map(object({
    cog_service_postfix = string
    kind                = string
    sku                 = string
  }))
  default = {
    openai = {
    cog_service_postfix = "openai"
    kind                = "OpenAI"
    sku                 = "S0"
  }
  }
}

variable "ptrn_openai_cl_cognitive_services_deploy_rg" {
  description = "(Required) set to true to deploy dedicated resource group for cog services."
  type    = bool
  default = true
}
variable "ptrn_openai_cl_cognitive_services_pe_rg_name" {
  description = "(Required) pass in pre-existing resource group name."
  type    = string
  default = null
}
variable "ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids" {
  description = "(Required) The ID of the subnet which should be able to access this Cognitive Account."
  type    = string
  default = ""
}
variable "ptrn_openai_cl_cognitive_services_nacl_allowed_subnets" {
    type        = list(string)
    description = "(Required) One or more Subnet ID's in which Azure cognitive services private endpoint should be created"
    default     = [""]
}
variable "ptrn_openai_cl_cognitive_services_private_dns_zone_ids" {
  description = "(Required) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type          = list(string) 
  default       = [""]  
}
variable "ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges" {
    type        = list(string)
    description = "(Required) One or more IP Addresses, or CIDR Blocks which should be able to access the Cognitive Account."
    default     = [""]
}
// Optional
variable "ptrn_openai_cl_cognitive_services_public_network_access_enabled" {
  description = "(Optional) set to true to enable public network access on cog service."
  type    = bool
  default = false
}
//**********************************************************************************************



//**********************************************************************************************
//                             App Service Plan Variables
//**********************************************************************************************
// Required Variables
//**********************************************************************************************
variable "ptrn_openai_app_service_plan_app_postfix" {
    description = "(Required) The bespoke name of the app service plan you are deploying."
    type        = string
}
variable "ptrn_openai_app_service_plan_kind" {
    description = "(Required) The kind of the App Service Plan to create. Possible values are Windows (also available as App), Linux, elastic (for Premium Consumption) and FunctionApp (for a Consumption Plan). Defaults to Windows. Changing this forces a new resource to be created."
    default     = "Linux"
    type        = string
}
variable "ptrn_openai_core_rg_network_name" {
    description = "(Required) name of network resource group"
    type        = string
    default     = ""
}
variable "ptrn_openai_core_vnet_name" {
    description = "(Required) name of virtual network."
    type        = string
    default     = ""
}
variable "ptrn_openai_app_service_plan_deploy_integration_subnet" {
    description = "(Required) A boolean that toggles the deployment of the vnet integration subnet."
    default     = true
}
variable "ptrn_openai_app_service_plan_integration_subnet_prefix" {
    description = "(Required) The CIDR prefix for the app service subnet. cl_app_service_plan_deploy_integration_subnet needs to be set to true. cl_app_service_plan_deploy_integration_subnet needs to be set to true."
    default     = ""
}
//**********************************************************************************************
// App Service Plan Required Variables
//**********************************************************************************************
variable "ptrn_openai_app_service_plan_deploy_autoscale_settings" {
    description = "(Optional) Choose to deploy autoscale settings or not. If the plan is serverless, this needs to be set to false"
    default     = true
    type        = bool
}
variable "ptrn_openai_app_service_plan_max_elastic_workers" {
    description = "(Optional) The maximum number of total workers allowed for this ElasticScaleEnabled App Service Plan."
    type        = number
    default     = 2
}
variable "ptrn_openai_app_service_plan_reserved" {
    description = "(Optional) Is this App Service Plan Reserved. This has to be false if the kind is Windows."
    type        = bool
    default     = true
}
variable "ptrn_openai_app_service_plan_per_site_scaling" {
    description = "(Optional) Can Apps assigned to this App Service Plan be scaled independently? If set to false apps assigned to this plan will scale to all instances of the plan."
    type        = bool
    default     = false
}
variable "ptrn_openai_app_service_plan_integration_subnet_service_endpoints" {
    description = "(Optional) A list of service endpoints that is enabled in the subnet. cl_app_service_plan_deploy_integration_subnet needs to be set to true."
    default     =  ["Microsoft.web", "Microsoft.ServiceBus","Microsoft.Sql", "Microsoft.AzureCosmosDB", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.ContainerRegistry", "Microsoft.KeyVault", "Microsoft.CognitiveServices"]
}
variable "ptrn_openai_app_service_plan_route_table_id" {
    description = "(Optional) The ID of the route table that will be associated to the subnet"
    default     = ""
}
variable "ptrn_openai_app_service_plan_int_subnet_user_defined_nsg_rules" {
    description = "(Optional) A map of NSG rules for the integration subnet."
    type = map(object({
        name                          = string
        priority                      = number
        direction                     = string
        access                        = string
        protocol                      = string
        source_port_range             = string
        source_port_ranges            = list(string)
        destination_port_range        = string
        destination_port_ranges       = list(string)    
        source_address_prefix         = string
        source_address_prefixes       = list(string)
        destination_address_prefix    = string
        destination_address_prefixes  = list(string)    
    }))
    default     = {}
}
variable "ptrn_openai_app_service_plan_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default = {
        logs    = [] //Is there any logs? No logs indicated while testing on portal
        metrics = ["AllMetrics"]
    }
}

// SKU Variables
// https://azure.microsoft.com/en-us/pricing/details/app-service/windows/
variable "ptrn_openai_app_service_plan_sku_tier" {
    description = "(Optional) Specifies the plan's pricing tier."
    default     = "PremiumV2"
}
variable "ptrn_openai_app_service_plan_sku_size" {
    description = "(Optional) Specifies the plan's instance size."
    default     = "P3v2"
}
variable "ptrn_openai_app_service_plan_sku_capacity" {
    description = "(Optional) Specifies the number of workers associated with this App Service Plan."
    default     = 1
}

// Autoscale Variables
// https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_autoscale_setting
variable "ptrn_openai_app_service_plan_autoscale_settings_default" {
    description = "(Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 0 and 1000."
    default     = 1
}
variable "ptrn_openai_app_service_plan_autoscale_settings_minimum" {
    description = "(Optional) The minimum number of instances for this resource. Valid values are between 0 and 1000."
    default     = 1
}
variable "ptrn_openai_app_service_plan_autoscale_settings_maximum" {
    description = "(Optional) The maximum number of instances for this resource. Valid values are between 0 and 1000."
    default     = 10
}
variable "ptrn_openai_app_service_plan_autoscale_settings_metric_name" {
    description = "(Optional) The name of the metric that defines what the rule monitors."
    default     = "CpuPercentage"
}
variable "ptrn_openai_app_service_plan_autoscale_settings_time_grain" {
    description = "(Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string."
    default     = "PT1M"
}
variable "ptrn_openai_app_service_plan_autoscale_settings_statistic" {
    description = "(Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max."
    default     = "Average"
}
variable "ptrn_openai_app_service_plan_autoscale_settings_time_window" {
    description = "(Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string."
    default     = "PT5M"
}
variable "ptrn_openai_app_service_plan_autoscale_settings_time_aggregation" {
    description = "(Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total."
    default     = "Average"
}
variable "ptrn_openai_app_service_plan_autoscale_settings_scale_out_operator" {
    description = "(Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual."
    default     = "GreaterThan"
}
variable "ptrn_openai_app_service_plan_autoscale_settings_scale_out_threshold" {
    description = "(Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action."
    default     = 75
}
variable "ptrn_openai_app_service_plan_autoscale_settings_scale_in_operator" {
    description = "(Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual."
    default     = "LessThan"
}
variable "ptrn_openai_app_service_plan_autoscale_settings_scale_in_threshold" {
    description = "(Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action."
    default     = 25
}


//**********************************************************************************************
//                             App Service Variables
//**********************************************************************************************
// App Service Required Variables
//**********************************************************************************************
variable "ptrn_openai_app_service_pe_subnet_ids" {
    description = "(Required) private endpoint subnet ID for app service."
    type        = list(string)
    default     = [""]
}
variable "ptrn_openai_app_service" {
  type = map(object({
      ptrn_openai_app_service_always_on                    = bool
      ptrn_openai_app_service_app_postfix                  = string
      ptrn_openai_app_service_client_affinity_enabled     = bool
      ptrn_openai_app_service_is_linux_docker             = bool
      ptrn_openai_app_service_is_windows_docker           = bool
      ptrn_openai_app_service_linux_fx_version            = string
      ptrn_openai_app_service_scm_type                    = string
      ptrn_openai_app_service_windows_fx_version          = string
      ptrn_openai_app_service_settings                    = map(any)
  }))
  description = "(Required) key value pairs for deploying diff flavors of cognitive service"
  default     = {}
  }
variable "ptrn_openai_cl_cognitive_services_rg_name" {
  description = "(Required) resource group name of cognitive service"
  type = string
  default = ""
}
variable "ptrn_openai_app_service_identity_type" {
    description = "(Required) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned"
    default     = "SystemAssigned, UserAssigned"
}
variable "ptrn_openai_app_service_identity_identity_ids" {
    description = "(Required) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned."
    default     = null
}
variable "ptrn_openai_app_service_private_dns_zone_id" {
  description = "(Required) Specifies the list of Private DNS Zones to include within the private_dns_zone_group when the private dns zone already exists."
  type        = list(string) 
  default     = [] 
}
variable "ptrn_openai_app_service_dns_server" { 
    type = string
    default = ""
    description = "(Required) Custom DNS service for app service routing."
}
//**********************************************************************************************
// App Service Optional Variables
//**********************************************************************************************
variable "tags" {
    description = "(Optional) A mapping of tags to assign to all resources."
    type        = map
    default     = {}
}
variable "ptrn_openai_app_service_plan_deploy_rg" {
  description = "(Optional) A boolean to enable/disable the deployment of a resource group for the App Service Plan."
  default     = true
}
variable "ptrn_openai_app_service_plan_rg_name" {
  description = "(Optional) The name of the App Service Plan resource group if cl_app_service_plan_deploy_rg = false."
  default     = null
}
variable "ptrn_openai_app_service_https_only" {
    description = "(Optional) Booolean to toggle if the App Service can only be accessed via HTTPS."
    default     = true
}
variable "ptrn_openai_app_service_ftps_state" {
    description = "(Optional) State of FTP / FTPS service for this App Service. Possible values include: AllAllowed, FtpsOnly and Disabled."
    default     = "FtpsOnly"
}
variable "ptrn_openai_app_service_min_tls_version" {
    description = "(Optional) The minimum supported TLS version for the app service"
    default     = "1.2"
}
variable "ptrn_openai_app_service_http2_enabled" {
    description = "(Optional) Is HTTP2 Enabled on this App Service?"
    default     = true
}
variable "ptrn_openai_app_service_use_32_bit_worker_process" {
    description = "(Optional) Should the App Service run in 32 bit mode, rather than 64 bit mode?"
    default     = true
}
variable "ptrn_openai_app_service_number_of_workers" {
    description = "(Optional) The scaled number of workers (for per site scaling) of this App Service."
    default     = 1
}
variable "ptrn_openai_app_service_remote_debugging_enabled" {
    description = "(Optional) Is Remote Debugging Enabled?"
    default     = false
}
variable "ptrn_openai_app_service_remote_debugging_version" {
    description = "(Optional) Which version of Visual Studio should the Remote Debugger be compatible with?"
    default     = "VS2017"
}
variable "ptrn_openai_app_service_auth_settings_enabled" {
    description = "(Optional) Enable or disable Authentication Settings"
    default     = "false"
}
variable "ptrn_openai_app_service_default_documents" {
    description = "(Optional) The ordering of default documents to load, if an address isn't specified."
    default     = []
}
variable "ptrn_openai_app_service_diagnostics" {
    description = "(Optional) Diagnostic settings for those resources that support it."
    type        = object({ logs = list(string), metrics = list(string) })
    default = {
        logs    = ["AppServiceAntivirusScanAuditLogs", "AppServiceHTTPLogs", "AppServiceConsoleLogs", "AppServiceAppLogs", "AppServiceFileAuditLogs", "AppServiceAuditLogs", "AppServiceIPSecAuditLogs", "AppServicePlatformLogs"]
        metrics = ["AllMetrics"]
    }
}
variable "ptrn_openai_app_service_health_check_path" {
    type = string
    default = ""
    description = "(Optional) The health check path to be pinged by App Service"
}
variable "ptrn_openai_app_service_acr_login_server" {
    type = string
    default = ""
    description = "(Optional) Is the Azure Container Registry server"
}
variable "ptrn_openai_app_service_acr_username" {
    type = string
    default = ""
    description = "(Optional) Is the Azure Container Registry username to access the repository"
}
variable "ptrn_openai_app_service_acr_password" {
    type = string
    default = ""
    description = "(Optional) Is the Azure Container Registry password of the username to be used"
}
variable "ptrn_openai_app_service_acr_image" {
    type = string
    default = ""
    description = "(Optional) Is the Azure Container Registry image to be used. For example myapp:latest"
}
variable "ptrn_openai_app_service_acr_scm_type" { 
    type = string
    default = "VSTSRM"
    description = "(Optional) Type of the source control enabled for this App Service using ACR. Defaults to VSTSRM"
}
variable "ptrn_openai_app_service_acr_use_managed_identity_credentials" {
    type = bool
    default = true
    description = "(Optional) Are Managed Identity Credentials used for Azure Container Registry pull"
}
variable "ptrn_openai_app_service_vnet_route_server"{
    type = number
    default = 1
    description = "(Optional) Should all outbound traffic to have Virtual Network Security Groups and User Defined Routes applied."
}
variable "ptrn_openai_app_service_connection_strings" {
  type = map(object({
    name                  = string
    type                  = string
    value                 = string
  }))
  description = "(Optional) Connection strings for App Service."
  default     = {}
}
variable "ptrn_openai_app_service_dotnet_framework_version" {
    type = string
    default = "v5.0"
    description = "(Optional) The version of the .net framework's CLR used in this App Service."
}
variable "ptrn_openai_app_service_auth_settings_default_provider"{
    description = "(Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter."
    default     = "AzureActiveDirectory"
}
variable "ptrn_openai_app_service_auth_settings_unauthenticated_client_action" {
    description = " (Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage."
    default     = "AllowAnonymous"
}
variable "ptrn_openai_app_service_is_custom_domain_enable" {
    type = bool
    default = false
    description = "(Optional) Is the app service using a custom domain?."    
}
variable "ptrn_openai_app_service_custom_domain_hostname" {
    type = string
    default = ""
    description = "(Optional) App service custom domain hostname."
}
variable "ptrn_openai_app_service_custom_domain_thumbprint" {
    type = string
    default = ""
    description = "(Optional) The app service custom domain thumbprint."    
}
variable "ptrn_openai_app_service_cors_allowed_origins" {
    type = list(string)
    default = ["*"]
    description = "(Optional) A list of origins which should be able to make cross-origin calls. * can be used to allow all calls."    
}
variable "ptrn_openai_app_service_support_cors_credentials" {
    type = bool
    default = false
    description = "(Optional) Are credentials supported?."    
}
//**********************************************************************************************
// Required Application Gateway Variables
//**********************************************************************************************
variable "ptrn_openai_app_gateway_rg_name" {
  description = "(Required) The resource group for the Application Gateway."
  type        = string
  default     = null
}
variable "ptrn_openai_core_log_analytics_workspace_name" {
  description = "(Required) The name of the log analytics workspace."
  type        = string
  default     = null
}
variable "ptrn_openai_core_rg_logging_name" {
  description = "(Required) The resource group for the log analytics workspace."
  type        = string
  default     = null
}
variable "ptrn_openai_app_gateway_postfix" {
  description = "(Required) The postfix for the Application Gateway."
  type        = string
  default     = null  
}
variable "ptrn_openai_app_gateway_deploy_subnet" {
  description = "(Required) select true/false to deploy separate APP GW subnet."
  type        = bool
  default     = true
}
variable "ptrn_openai_app_gateway_deploy_subnet_nsg" {
  description = "(Required) select true/false to deploy separate APP GW subnet NSG."
  type        = bool
  default     = true
}
variable "ptrn_openai_app_gateway_subnet_address_prefix" {
  description = "(Required) The address prefix of the application gateway subnet."
  type        = list(string)
  default     = null
}
variable "ptrn_openai_app_gateway_frontend_tls_cert" {
  description = "(Required) The name of the ssl cert file in pfx format that exists in the same folder that TF plan/apply is executed on. The file must not be base64 encrypted."
  default     = ""
}
variable "ptrn_openai_app_gateway_frontend_tls_cert_pass" {
  description = "(Required) The password for the front end ssl cert file"
  default     = ""
}
variable "ptrn_openai_app_gateway_probe_status_code" {
  description = "(Required) A list of allowed status codes for this Health Probe."
  default     = ["200-405"]
}
variable "ptrn_openai_app_gateway_probe_body" {
  description = "(Required) String with the Body."
  default     = ""
}
variable "ptrn_openai_deploy_app_gateway" {
  description = "(Required) deploy or not application gateway"
  type        = bool
  default     = true
}
variable "ptrn_openai_app_gateway_core_sa_enabled" {
  description = "(Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs."
  type        = bool
  default     = true
}
variable "ptrn_openai_app_gateway_nsg_sa_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string)
  default     = []
}
variable "ptrn_openai_app_gateway_storage_account_nsg_flow_log_id" {
 description = "(Optional) The ID of the Storage Account where flow logs are stored."
 type        = string
 default     = null
}
variable "ptrn_openai_app_gateway_nsg_flow_log_postfix" {
  description = "(Required) postfix name for the NSG flow log"
  default     = null
}

# Optional
variable "ptrn_openai_app_gateway_subnet_service_endpoints" {
  description = "(Optional) A list of service endpoints that is enabled in the subnet"
  default     = [  
  "Microsoft.Storage",
  "Microsoft.KeyVault",
  "Microsoft.AzureActiveDirectory",
  "Microsoft.Web",
  "Microsoft.ContainerRegistry",
  "Microsoft.Sql",
  "Microsoft.EventHub",
  "Microsoft.CognitiveServices"
  ]
}
variable "ptrn_openai_app_gateway_frontend_tls_cert_keyvault_id" {
  description = "(Optional) Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in Azure KeyVault."
  default     = null
}
variable "ptrn_openai_app_gateway_identity_ids" {
  type        = list(string)
  description = "(Optional) Specifies a list with a single user managed identity id to be assigned to the Application Gateway"
  default     = []
}
variable "ptrn_openai_app_gateway_firewall_mode" {
  description = "(Optional) Resource group where the Core VNet exists."
  default     = "Detection"
}
variable "ptrn_openai_set_private_ip_listener" {
  description = "(Optional) A boolean variable indicating which environment the app gateway is being deployed into."
  default     = true
}
variable "ptrn_openai_app_gateway_public_ip_allocation_method" {
  description = "(Optional) The allocation method for this IP address. Possible values are Static or Dynamic."
  default     = "Static"
}
variable "ptrn_openai_app_gateway_public_ip_sku" {
  description = "(Optional) The SKU of the Public IP. Accepted values are Basic and Standard"
  default     = "Standard"
}
variable "ptrn_openai_app_gateway_domain_name_label" {
  description = " (Optional) Label for the Domain Name. Will be used to make up the FQDN. If a domain name label is specified, an A DNS record is created for the public IP in the Microsoft Azure DNS system."
  type        = string
  default     = null
}
variable "ptrn_openai_app_gateway_reverse_fqdn" {
  description = "(Optional) A fully qualified domain name that resolves to this public IP address"
  default     = null
}
variable "ptrn_openai_app_gateway_min_capacity" {
  description = "(Optional) The minimum number of app gateway units for autoscaling"
  default     = 1
}
variable "ptrn_openai_app_gateway_max_capacity" {
  description = "(Optional) The minimum number of app gateway units for autoscaling"
  default     = 5
}
variable "ptrn_openai_app_gateway_backend_address" {
  description = "(Optional) The backend ip or fqdns address from the address pool"
  type        = list
  default     = null
}
variable "ptrn_openai_app_gateway_pick_host_name" {
  description = "(Optional) True/false to pick a host from backend pool or overwrite the host name."
  type        = bool
  default     = true
}
variable "ptrn_openai_app_gateway_pick_host_backend" {
  description = "(Optional) True/false to pick the host from the backend configuration"
  type        = bool
  default     = true
}
variable "ptrn_openai_app_gateway_backend_host_name" {
  description = "(Optional) Host header to be sent to the backend servers. Cannot be set if pick_host_name_from_backend_address is set to true"
  default     = null
}
variable "ptrn_openai_app_gateway_subnet_hostnum" {
  description = "(Optional) The hostnumber from the subnet prefix for the private IP."
  default     = 15
}
//SSL Policy
variable "ptrn_openai_app_gateway_ssl_policy_type" {
  description = "(Optional) The Type from SSL Policy"
  default     = "Predefined"
}
variable "ptrn_openai_app_gateway_ssl_policy_name" {
  description = "(Optional) The Name from SSL Policy"
  default     = "AppGwSslPolicy20170401S"
}
variable "ptrn_openai_app_gateway_ssl_policy_protocol_version" {
  description = "(Optional) The Minimun Protocol Version from SSL Policy"
  default     = "TLSv1_2"
}
variable "ptrn_openai_app_gateway_probe_name" {
  description = "(Optional) The probe name from Health probes"
  default     = "https-probe"
}
variable "ptrn_openai_app_gateway_probe_host" {
  description = "(Optional) The site url from the Health probes"
  type        = string
  default     = null
}
variable "ptrn_openai_app_gateway_probe_path" {
  description = "(Optional) The probe path from the Health probes"
  default     = "/"
}
variable "ptrn_openai_app_gateway_probe_interval" {
  description = "(Optional) The probe interval from the Health probes"
  default     = 10
}
variable "ptrn_openai_app_gateway_probe_timeout" {
  description = "(Optional) The timeout from the Health probes"
  default     = 30
}
variable "ptrn_openai_app_gateway_probe_unhealthy_threshold" {
  description = "(Optional) The unhealthy threshold from the Health probes"
  default     = 3
}
variable "ptrn_openai_app_gateway_probe_protocol" {
  description = "(Optional) The probe protocol from the Health probes"
  default     = "Https"
}
variable "ptrn_openai_app_gateway_nsg_rules" {
  type = map(object({
    name                         = string
    priority                     = number
    direction                    = string
    access                       = string
    protocol                     = string
    source_port_range            = string
    source_port_ranges           = list(string)
    destination_port_range       = string
    destination_port_ranges      = list(string)
    source_address_prefix        = string
    source_address_prefixes      = list(string)
    destination_address_prefix   = string
    destination_address_prefixes = list(string)
  }))
  description = "(Optional) Define additional NSG rules for app gateway subnet."
  default     = {}
}
variable "ptrn_openai_app_gateway_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ enabled_log = list(string), metrics = list(string) })
  default = {
    enabled_log = ["ApplicationGatewayAccessLog", "ApplicationGatewayPerformanceLog", "ApplicationGatewayFirewallLog"]
    metrics = ["AllMetrics"]
  }
}
variable "ptrn_openai_app_gateway_log_analytics_solutions" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    AzureAppGatewayAnalytics = {
      publisher = "Microsoft"
      product   = "OMSGallery/AzureAppGatewayAnalytics"
    }
  }
}
variable "ptrn_openai_app_gateway_http_listener_hostname" {
  description = "(Optional) The Hostname which should be used for this HTTP Listener. Setting this value changes Listener Type to Multi site"
  default     = null
}
variable "ptrn_openai_app_gateway_https_listener_hostname" {
  description = "(Optional) The Hostname which should be used for this HTTPS Listener. Setting this value changes Listener Type to Multi site"
  default     = null
}
variable "ptrn_openai_app_gateway_disable_bgp_route_propagation" {
  description = "(Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable"
  default     = true
}
variable "ptrn_openai_app_gateway_http_settings_timeout" {
  description = "(Optional) The timeout for HTTP response."
  type        = number
  default     = 600
}
variable "ptrn_openai_app_gateway_additional_http_listener" {
  type = map(object({
    name                 = string
    protocol             = string
    host_name            = string
    frontend_port_name   = string
    ssl_certificate_name = string
  }))
  description = "(Optional) Array for additional HTTP listeners."
  default     = {}
}
variable "ptrn_openai_app_gateway_additional_http_settings" {
  type = map(object({
    name                                = string
    request_timeout                     = number
    probe_name                          = string
    host_name                           = string
    pick_host_name_from_backend_address = bool
  }))
  description = "(Optional) Array for additional HTTP settings."
  default     = {}
}
variable "ptrn_openai_app_gateway_additional_probes" {
  type = map(object({
    name                = string
    host                = string
    path                = string
    interval            = number
    timeout             = number
    unhealthy_threshold = number
    protocol            = string
  }))
  description = "(Optional) Array for additional health probes."
  default     = {}
}
variable "ptrn_openai_app_gateway_additional_route_rules" {
  type = map(object({
    name                                = string
    rule_type                           = string
    http_listener_name                  = string
    backend_address_pool                = string
    backend_http_settings_name          = string
    redirect_configuration_name         = string
    priority                            = number
    url_path_map_name                   = string   
  }))
  description = "(Optional) Array for additional routing rules."
  default     = {}
}
variable "ptrn_openai_app_gateway_additional_backend_address_pool" {
  type = map(object({
    name  = string
    fqdns = list(string)
  }))
  description = "(Optional) Array for additional backend address pool."
  default     = {}
}
variable "ptrn_openai_app_gateway_additional_redirect_configurations" {
  type = map(object({
    name                 = string
    redirect_type        = string
    target_listener_name = string
  }))
  description = "(Optional) Array for additional redirect configurations."
  default     = {}
}
variable "ptrn_openai_app_gateway_additional_ssl_certificate" {
  type = map(object({
    name                = string
    data                = string
    password            = string
    key_vault_secret_id = string
  }))
  description = "(Optional) Array for additional ssl certificates."
  default     = {}
}
variable "ptrn_openai_app_gateway_rewrite_rules" {
  type = list(object({
    name            = string
    rule_sequence   = number
    conditions = list(object({
      variable    = string
      pattern     = string
      ignore_case = bool
      negate      = bool
    }))
    request_header_configurations = list(object({
      header_name   = string
      header_value  = string
    }))
    response_header_configurations = list(object({
      header_name   = string
      header_value  = string
    }))
    urls  = list(object({
      path          = string
      query_string  = string
      reroute       = string
    }))
  }))
  description = "(Optional) Array for rewrite rules."
  default     = []
}

//**********************************************************************************************


// Required Azure Sql Server Variables
//**********************************************************************************************
variable "ptrn_openai_azure_sql_server_resource_group_name" {
  description = "(Required) Specifies the Azure SQL Server resource group"
  type        = string
  default     = null
}
variable "ptrn_openai_azure_sql_server_vulnerability_enabled" {
  type        = bool
  default     = true
}
variable "ptrn_openai_azure_sql_server_postfix" {
  description = "(Required) A string that is appended to the end of the Azure SQL Server name to identify it."
  type        = string
  default     = "sqlserveropenai"
}
variable "ptrn_openai_azure_sql_server_administrator" {
  description = "(Required) The administrator login name for the new server. Changing this forces a new resource to be created."
  type        = string
  default     = null
}
variable "ptrn_openai_azure_sql_server_password" {
  description = "(Required) The password associated with the cl_azure_sql_server_administrator user."
  type        = string
  default     = null
}
variable "cl_azure_sql_server_sa_enable_backup" {
  default = true
  type = bool
}
 variable "ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids" {
    description = "(Required)  A list of subnet IDs the app service will create a private endpoint in."
    default     = []
}
variable "ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids" {
    description = "(Required)  Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
    type        = list(string) 
    default     = []
}
variable "ptrn_openai_azure_sql_server_storage_account_network_default_action" {
    description = "(Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow."
    type        = string
    default     = "Deny"
}
variable "ptrn_openai_tfstate_select_access" {
    description = "(Optional) Specifies the default action for selected nmtwork access on remote state storage acct."
    type        = bool
    default     = true
}

variable "ptrn_openai_azure_sql_server_storage_account_subnet_ids" {
    description = "(Required) A list of resource ids for subnets."
    type        = list(string)
    default     = []
}
variable "ptrn_openai_azure_sql_server_storage_account_ip_rules" {
    description = "(Required) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed."
    type        = list(string)
    default     = []
}
variable "ptrn_openai_azure_sql_server_vnet_rules" {
  type        = list(string)
  description = "(Required) Define additional virtual network rules"
  default     = []
}
variable "ptrn_openai_azure_sql_server_nacl_allowed_subnets" {
    type        = list(string)
    description = "(Required) One or more Subnet ID's which should be able to access the Azure SQL Server."
    default     = []
}
variable "ptrn_openai_azure_sql_server_private_dns_zone_ids" {
  description = "(Required) Specifies the list of Private DNS Zones to include within the private_dns_zone_group. Resides as a centralized DNS zone within identity subscription."
  type        = list(string)
  default     = []
}

// Optional
variable "ptrn_openai_deploy_azure_sql_server" {
  type        = bool
  description = "(Optional) A boolean to enable/disable the deployment of a  azure SQL in azure openai service pattern."
  default     = true
}
variable "ptrn_openai_azure_sql_server_version" {
  description = "(Optional) The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server)."
  type        = string
  default     = "12.0"
}
variable "ptrn_openai_azure_sql_server_connection_policy" {
  description = "(Optional) The connection policy the server will use. Possible values are Default, Proxy, and Redirect."
  type        = string
  default     = "Default"
}
variable "ptrn_openai_azure_sql_server_tls" {
  description = "(Optional) The Minimum TLS Version for all SQL Database and SQL Data Warehouse databases associated with the server. Valid values are: 1.0, 1.1 and 1.2."
  type        = string
  default     = "1.2"
}
variable "ptrn_openai_azure_sql_server_public_network_access" {
  description = "(Optional) Whether or not public network access is allowed for this server."
  type        = bool
  default     = false
}
variable "ptrn_openai_azure_sql_server_audit_enabled" {
    description = "(Optional) Boolean to enable sql server extended auditing policy resource creation"
    type        = bool
    default     = true    
}
variable "ptrn_openai_azure_sql_server_storage_account_bypass" {
    description = "(Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None."
    type        = list(string)
    default     = ["None"]
}
variable "ptrn_openai_azure_sql_server_storage_account_tier" {
  description = "(Optional) The pricing tier for the storage account for Azure SQL server audit and security logging."
  default     = "Standard"
}
variable "ptrn_openai_azure_sql_server_storage_account_blob_retention_days" {
  description = "(Optional) Specifies the number of days that the blob should be retained."
  default     = 365
}
variable "ptrn_openai_azure_sql_server_storage_account_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
variable "ptrn_openai_azure_sql_server_audit_retention_days" {
    description = "(Optional) Specifies the number of days to retain logs for in the storage account."
    type        = number
    default     = 7
}
variable "ptrn_openai_private_endpoint_subresource_names" {
    type        = list(string)
    description = "(Optional) A list of subresources to be included in the private endpoint."
    default     = ["sqlServer"]
}
variable "ptrn_openai_azure_sql_server_disabled_alerts" {
    description = "(Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql_Injection, Sql_Injection_Vulnerability, Access_Anomaly, Data_Exfiltration, Unsafe_Action."
    type        = list(string)
    default     = []
}
variable "ptrn_openai_azure_sql_server_alert_state" {
    description = "(Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific database server. Allowed values are: Disabled, Enabled."
    type        = string
    default     = "Enabled"
}
variable "ptrn_openai_azure_sql_server_alert_retention_days" {
    description = "(Optional) Specifies the number of days to keep in the Threat Detection audit logs."
    type        = number
    default     = 7
}
variable "ptrn_openai_azure_sql_server_alert_email_enabled" {
    description = "(Optional) Boolean flag which specifies if the alert is sent to the account administrators or not."
    type        = bool
    default     = false
}
variable "ptrn_openai_azure_sql_server_alert_emails" {
    description = "(Optional) Specifies an array of e-mail addresses to which the alert is sent."
    type        = list(string)
    default     = []
}
variable "ptrn_openai_azure_sql_server_security_scans" {
    description = "(Optional) Boolean flag which specifies if recurring scans is enabled or disabled."
    type        = bool
    default     = true
}
variable "ptrn_openai_azure_sql_server_security_email_subscription" {
    description = "(Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators."
    type        = bool
    default     = false
}
variable "ptrn_openai_azure_sql_server_security_emails" {
    description = "(Optional) Specifies an array of e-mail addresses to which the scan notification is sent."
    type        = list(string)
    default     = []
}
variable "ptrn_openai_azure_sql_server_firewall_rules" {
  type = map(object({
    start_ip                 = string
    end_ip                   = string
  }))
  description = "(Optional) Define additional firewall rules"
  default     = {}
}
variable "ptrn_openai_azure_sql_server_log_analytics_solution" {
  type = map(object({
    publisher = string #(Required) The publisher of the solution
    product   = string #(Required) The product name of the solution
  }))
  description = "(Optional) A plan block"
  default = {
    AzureSQLAnalytics = {
      publisher = "Microsoft"
      product   = "OMSGallery/AzureSQLAnalytics"
    }
  }
}
//**********************************************************************************************

// Required redis enterprise Variables
//**********************************************************************************************
variable "ptrn_openai_cl_redis_enterprise_cluster_enable" {
  description = "Enable/disabled creation module Redis Cache"
  type        = bool
  default     = true
}
variable "ptrn_openai_cl_redis_enterprise_cluster_resource_group_name" {
  description = "(Required) The name of the Resource Group where the Redis Enterprise Cluster should exist. Changing this forces a new Redis Enterprise Cluster to be created."
}
variable "ptrn_openai_cl_redis_enterprise_cluster_sku_name" {
  description = " (Required) The sku_name is comprised of two segments separated by a hyphen (e.g. Enterprise_E10-2)."
  type        = string
  default     = ""
}
variable "ptrn_openai_cl_redis_cache_log_analytics_workspace_id" {
  description = "(Required) The the log analytics workspace ID for diagnostics."
  type        = string
  default     = ""
}
variable "ptrn_openai_cl_redis_enterprise_database_module_name" {
  description = " (Required) The name which should be used for this module. Possible values are RedisBloom, RedisTimeSeries, RediSearch and RedisJSON"
  default     = null
  type        = string
}
variable "ptrn_openai_cl_redis_enterprise_cluster_subnet" {
  description = " (Required) The name of subnet which should be used for the Redis cluster private endpoint"
  default     = ""
  type        = string
}
variable "ptrn_openai_cl_redis_enterprise_cluster_private_dns_zone_ids" {
  description = "(Optional) Specifies the list of Private DNS Zones to include within the private_dns_zone_group."
  type        = list(string)
  default     = [""]
}
variable "ptrn_openai_cl_redis_enterprise_database_linked_database_id" {
  description = " (Optional) A list of database resources to link with this database with a maximum of 5."
  type        = list(string)
  default     = []
}
variable "ptrn_openai_cl_redis_enterprise_database_linked_database_group_nickname" {
  description = "(Optional) Nickname of the group of linked databases. Changing this force a new Redis Enterprise Geo Database to be created."
  type        = string
  default     = ""
}
variable "ptrn_openai_cl_redis_enterprise_database_eviction_policy" {
  description = " (Optional) Redis eviction policy - default is VolatileLRU. Possible values are AllKeysLFU, AllKeysLRU, AllKeysRandom, VolatileLRU, VolatileLFU, VolatileTTL, VolatileRandom and NoEviction."
  type        = string
  default     = "VolatileLRU"
}
//**********************************************************************************************

// Required Azure Sql Database Variables
//**********************************************************************************************
variable "ptrn_openai_deploy_azure_sql_database" {
  type        = bool
  description = "(Required) A boolean to enable/disable the deployment of a  azure SQL DB in azure openai service pattern."
  default     = true
}
variable "ptrn_openai_azure_sql_database_postfix" {
  description = "(Required) A string that is appended to the end of the database name to identify it."
  type        = string
  default     = "sqldbopenai"
}
// Optional
variable "ptrn_openai_azure_sql_database_collation" {
    description = "(Optional) Specifies the collation of the database. Changing this forces a new resource to be created."
    type        = string
    default     = "SQL_Latin1_General_CP1_CI_AS"
}
variable "ptrn_openai_azure_sql_database_license" {
    description = "(Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice."
    type        = string
    default     = "BasePrice"
}
variable "ptrn_openai_azure_sql_database_audit_enabled" {
    description = "(Optional) Boolean to enable sql db extended auditing policy resource creation"
    type        = bool
    default     = true   
}
variable "ptrn_openai_azure_sql_database_size" {
    description = "(Optional) The max size of the database in gigabytes."
    type        = number
    default     = 1
}
variable "ptrn_openai_azure_sql_database_read" {
    description = "(Optional) If enabled, connections that have application intent set to readonly in their connection string may be routed to a readonly secondary replica. This property is only settable for Premium and Business Critical databases."
    type        = bool
    default     = false
}
variable "ptrn_openai_azure_sql_database_sku" {
    description = "(Optional) Specifies the name of the sku used by the database. Changing this forces a new resource to be created. Single Database default value: BC_Gen5_2. If the database require be include in Elastic Pool group, in variable sku default value: ElasticPool."
    type        = string
    default     = "BC_Gen5_2"
}
variable "ptrn_openai_azure_sql_database_redudant" {
    description = "(Optional) Whether or not this database is zone redundant, which means the replicas of this database will be spread across multiple availability zones. This property is only settable for Premium and Business Critical databases."
    type        = bool
    default     = false
}
variable "ptrn_openai_azure_sql_database_create_mode" {
    type        = string
    description = "(Optional) The create mode of the database. Possible values are Copy, Default, OnlineSecondary, PointInTimeRestore, Recovery, Restore, RestoreExternalBackup, RestoreExternalBackupSecondary, RestoreLongTermRetentionBackup and Secondary."
    default     = "Default"
}
variable "ptrn_openai_azure_sql_database_replica_count" {
    description = "(Optional) The number of readonly secondary replicas associated with the database to which readonly application intent connections may be routed. This property is only settable for Hyperscale edition databases."
    type        = number
    default     = null
}
variable "ptrn_openai_azure_sql_database_STR_retention" {
    description = "(Required) Point In Time Restore configuration. Value has to be between 7 and 35."
    type        = number
    default     = 35
}
variable "ptrn_openai_azure_sql_database_LTR_weekly_retention" {
    description = "(Optional) The weekly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D."
    type        = string
    default     = "P1W"
}
variable "ptrn_openai_azure_sql_database_LTR_week_of_year" {
    description = "(Optional) The week of year to take the yearly backup in an ISO 8601 format. Value has to be between 1 and 52."
    type        = number
    default     = 1
}
variable "ptrn_openai_azure_sql_database_threat_policy_state" {
    description = "(Optional) The State of the Policy. Possible values are Enabled, Disabled or New."
    type        = string
    default     = "Enabled"
}
variable "ptrn_openai_azure_sql_database_disabled_alerts" {
    description = "(Optional) Specifies a list of alerts which should be disabled. Possible values include Access_Anomaly, Sql_Injection and Sql_Injection_Vulnerability."
    type        = list(string)
    default     = []
}
variable "ptrn_openai_azure_sql_database_threat_logs_retention" {
    description = "(Optional) Specifies the number of days to keep in the Threat Detection audit logs."
    type        = number
    default     = 7
}
variable "ptrn_openai_azure_sql_database_threat_email_admins" {
    description = "(Optional) Should the account administrators be emailed when this alert is triggered?"
    type        = string
    default     = "Disabled"
}
variable "ptrn_openai_azure_sql_database_threat_emails" {
    description = "(Optional) A list of email addresses which alerts should be sent to."
    type        = list(string)
    default     = []
}
variable "ptrn_openai_azure_storage_account_secondary_access_key" {
    description = "(Optional) Specifies whether cl_azure_storage_account_access_key value is the storage's secondary key."
    type        = bool
    default     = false
}
variable "ptrn_openai_azure_sql_database_audit_retention_days" {
    description = "(Optional) Specifies the number of days to retain logs for in the storage account."
    type        = number
    default     = 7
}
variable "ptrn_openai_azure_sql_database_diagnostics" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = ["DevopsoperationsAuditLogs", "SQLSecurityAuditEvent"]
    metrics = ["Basic", "InstanceAndAppAdvanced", "WorkloadManagement"]
  }
}
variable "ptrn_openai_azure_sql_server_azuread_login_username" {
   description = "(Optional) The login username of the Azure AD Administrator of this SQL Server."
   type        = string
   default     = null
}
 variable "ptrn_openai_azure_sql_server_azuread_object_id" {
   description = "(Optional) The object id of the Azure AD Administrator of this SQL Server."
   type        = string
   default     = null
 }
//**********************************************************************************************

// Required Variables SQL Elastic pools variables
//**********************************************************************************************
variable "ptrn_openai_azure_sql_elastic_pool_enable" {
  description = "(Required) Enable te creation for sql elastic pool"
  default = true
}
variable "ptrn_openai_azure_sql_elastic_pool_postfix" {
  description = "(Required) A string that is appended to the end of the Azure SQL Server name to identify it."
  default = "globaldb"
}

// Optional
variable "ptrn_openai_azure_sql_elastic_pool_zone_redundant" { 
   description = "(Optional) Whether or not the Elastic Pool is zone redundant, SKU tier must be Premium to use it. This is mandatory for high availability." 
   type        = bool 
   default     = false 
 } 
 variable "ptrn_openai_azure_sql_elastic_pool_database_min_capacity" { 
   description = "(Optional) The minimum capacity all databases are guaranteed in the Elastic Pool. Defaults to 0." 
   type        = string 
   default     = "0" 
 } 
 variable "ptrn_openai_azure_sql_elastic_pool_database_max_dtu_capacity" { 
   description = "(Optional) The maximum capacity any one database can consume in the Elastic Pool. Default to the max Elastic Pool capacity." 
   type        = string 
   default     = "1" 
 } 

 variable "ptrn_openai_azure_sql_elastic_pool_max_size" { 
   description = "(Optional) Maximum size of the Elastic Pool in gigabytes" 
   type        = string 
   default     = "1024"
 } 
 
 variable "ptrn_openai_azure_sql_elastic_pool_sku" {
  type = object({
    name     = string,
    tier     = string,
    family   = string,
    capacity = string
  })
  description = "(Optional) SKU for the Elastic Pool with tier and eDTUs capacity. Premium tier with zone redundancy is mandatory for high availability. Possible values for tier are Basic, Standard, or Premium. Example tier=Standard, capacity=50. See https://docs.microsoft.com/en-us/azure/sql-database/sql-database-dtu-resource-limits-elastic-pools"
  default = {
    name = "BC_Gen5"
    tier = "BusinessCritical"
    family = "Gen5"
    capacity = "4"
 }
}
variable "ptrn_openai_azure_sql_elastic_pool_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
variable "ptrn_openai_azure_sql_elastic_pool_license_type" { 
   description = "(Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice." 
   type        = string 
   default     = "BasePrice"
 }
//**********************************************************************************************

# Variables in API MGMT
//**********************************************************************************************
variable "ptrn_openai_core_rg_data_name" {
    description = "(Required) The name of the resource group where the api management will be deployed to."
    default     = ""
}
variable "ptrn_openai_api_mgmt_public_network_access_enabled" {
default = false
type = bool
}
variable "ptrn_openai_api_mgmt_enable" {
  description = "(Required) set to true to enable API mgmt."
  type = bool
  default = false
}
variable "ptrn_openai_core_route_table_id" {
  description = "(Required) The route_table id allowed to connect to this API Mgmt."
  type        = string
  default     = ""
}
variable "ptrn_openai_api_mgmt_subnet_vnet_rg_name" {
  description =  "(Required) The name of the resource group that the core vnet is in"
  default = ""
}
variable "ptrn_openai_api_mgmt_subnet_vnet_name" {
    description = "(Required) The name of the core vnet required for the Api mgmt subnet."
    default = ""
}
variable "ptrn_openai_api_mgmt_subnet_prefix" {
    description = "(Required) The prefix of the api mgmt subnet."
    type = list(string)
    default = [""]
} 
variable "ptrn_openai_api_mgmt_publisher_name" {
  description = " (Required) The name of publisher/company."
  type        = string
  default     = ""
}
variable "ptrn_openai_api_mgmt_publisher_email" {
  description = " (Required) The email of publisher/company."
  type        = string
  default     = ""
} 
variable "ptrn_openai_api_mgmt_inbound_cidrs" {
  type        = list(string)
  description = "(Required) A list of CIDRs to allow to communicate with API Management."
  default     = [""]
} 
// Optional
variable "ptrn_openai_api_mgmt_sku_name" {
  description = " (Optional) sku_name is a string consisting of two parts separated by an underscore(_)"
  type        = string
  default     = "Developer_1"
}
variable "ptrn_openai_api_mgmt_subnet_service_enpoints" {
  description = "(Optional) The service endpoints for the api mgmt subnet."
  type        = list(string)
  default     = ["Microsoft.Sql", "Microsoft.EventHub", "Microsoft.Storage", "Microsoft.ServiceBus"]
}
variable "ptrn_openai_api_mgmt_diagnostic" {
  description = "(Optional) Diagnostic settings for those resources that support it."
  type        = object({ logs = list(string), metrics = list(string) })
  default = {
    logs    = []
    metrics = ["AllMetrics"]
  }
}
variable "ptrn_openai_api_mgmt_identity_type" {
    description = "(Optional) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned"
    type        = string
    default     = "SystemAssigned"
}
variable "ptrn_openai_api_mgmt_identity_identity_ids" {
    description = "(Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned."
    type        = list(string)
    default     = null
}
variable "ptrn_openai_api_mgmt_deploy_custom_domain" {
    description = "(Optional) Specifies if custom domain for API management should be deployed or not."
    type        = bool
    default     = false
}
variable "ptrn_openai_api_mgmt_proxies" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    default_ssl_binding           = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management proxy deployment."
  default     = {}
}
variable "ptrn_openai_api_mgmt_developer_portals" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management developer portal deployment."
  default     = {}
}
variable "ptrn_openai_api_mgmt_managements" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management managements deployment."
  default     = {}
}
variable "ptrn_openai_api_mgmt_portals" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management portals deployment."
  default     = {}
}
variable "ptrn_openai_api_mgmt_scms" {
  type = map(object({
    host_name                     = string
    certificate                   = string
    certificate_password          = string
    negotiate_client_certificate  = bool
    key_vault_id                  = string 
  }))
  description = "(Optional) Array for API management SCM deployment."
  default     = {}
}
  //**********************************************************************************************

# Storage_account VARs
  //**********************************************************************************************
variable "ptrn_openai_storage_account_key" {
  type = map(object({
   ptrn_openai_storage_account_private_dns_zone_ids = list(string)
   ptrn_openai_storage_account_blob_enable_backup = bool
   ptrn_openai_storage_account_share_enabled      = bool
   ptrn_openai_storage_account_queue_enabled      = bool
   ptrn_openai_storage_account_file_shares        = map(any)
   ptrn_openai_storage_account_file_enable_backup = bool
   ptrn_openai_storage_account_large_file_share = bool  
   ptrn_openai_storage_account_queues           = list(string)
   ptrn_openai_storage_account_tier             = string
   ptrn_openai_storage_account_kind             = string
    }))
  description = "blob storage account key and values"
  default = {}
}
variable "ptrn_openai_storage_account_resource_group_name" {
  description = "(Required) The name of the resource group where the storage account will be deployed to."
  type = string
  default = ""
}   
variable "ptrn_openai_storage_account_default_to_oauth_authentication" {
  description = "(Optional) Default to Azure Active Directory authorization in the Azure portal when accessing the Storage Account. The default value is false"
  type        = bool
  default     = true
}
variable "ptrn_openai_storage_account_log_analytics_workspace_id" {
  type = string
  default = ""
  description = "(Required) The the log analytics workspace ID for diagnostics."
} 
variable "ptrn_openai_storage_account_allowed_ips" {
  type = list(string)
  default = [""]
  description = "(Optional) A list of ips that can access the storage account."
} 
variable "ptrn_openai_storage_account_allowed_pe_subnet_ids" {
  description = "(Optional) A list of subnets to create a Private endpoint that can access the storage account."
  type = list(string)
  default = [""]
} 
variable "ptrn_openai_storage_account_private_dns_zone_ids" {
   type = list(string)
  default = [""] 
}
variable "ptrn_openai_storage_account_allowed_vnet_subnet_ids" {
  description = "(Optional) A list of subnets that can access the storage account."
  type = list(string)
  default = [""]
} 
variable "ptrn_openai_storage_account_blob_backup_vault_id" {
  description = "(Optional) The id of blob storage backup vault."
  type = string
  default = ""
  
}
variable "ptrn_openai_storage_account_blob_backup_vault" {
  description = "(Optional) The blob storage backup vault."
  type = string
  default = ""
  
}  
variable "ptrn_openai_storage_account_blob_backup_policy_id" {
  description = "(Optional) The azure blob storage backup policy id from the backup vault."
  type = string
  default = ""
}
variable "ptrn_openai_storage_account_rg_backup_name" {
  description = "(Optional) The RG destination of the azure file share backup."
  type = string
  default = ""
}
variable "ptrn_openai_storage_account_recovery_vault_name" {
  description = "(Optional) The name of backup recovery service vault."
  type = string
  default = ""
}
variable "ptrn_openai_storage_account_backup_policy_fileshare_id" {
  description = "(Optional) The azure file share backup policy from the recovery service vault."
  type = string
  default = ""
}
//**********************************************************************************************

#App insights
//**********************************************************************************************
variable "ptrn_openai_app_insights_enable" {
  type = bool
  default = true
  description = "(Required) set to true to create the Application Insights component."
}
variable "ptrn_openai_app_insights_resource_group_name" {
  description = "(Required) The name of the resource group in which to create the Application Insights component."
  type        = string
  default     = ""
}
variable "ptrn_openai_app_insights_application_type" {
  description = " (Required) Specifies the type of Application Insights to create."
  type        = string
  default     = ""
}
variable "ptrn_openai_app_insights_content" {
  description = " (Required) The content for the Analytics Item."
  type        = string
  default     = ""
}
variable "ptrn_openai_app_insights_scope" {
  description = "  (Required) The scope for the Analytics Item."
  type        = string
  default     = ""
}
variable "ptrn_openai_app_insights_type" {
  description = " (Required) Specifies the type of Application Insights to create."
  type        = string
  default     = ""
}
variable "ptrn_openai_app_insights_web_test_kind" {
  description = "(Required) The kind of web test that this web test watches."
  type        = string
  default     = ""
}
variable "ptrn_openai_app_insights_web_test" {
  type = map(object({
    frequency           = number
    timeout             = number
    enabled             = string
    geo_locations       = list(string)
    test_method         = string
    test_url            = string
    test_response_code  = number
  }))
  description = "(Optional) Define additional NSG rules"
  default     = {}
}
  //**********************************************************************************************
```   
## Outputs
```terraform
output "cl_azure_container_registry" {
    value = module.cl_azure_container_registry
}
output "cl_cognitive_services_openai" {
    value = module.cl_cognitive_services_openai
}
output "cl_app_service_plan" {
    value = module.cl_app_service_plan
}
output "cl_app_service" {
    value = module.cl_app_service
}
output "cl_web_application_firewall_policy" {
    value = azurerm_web_application_firewall_policy.cl_web_application_firewall_policy
}
output "cl_app_gateway" {
    value = module.cl_app_gateway
}
output "cl_azure_sql_server" {
    value = module.cl_azure_sql_server
}
output "cl_azure_sql_database" {
    value = module.cl_azure_sql_database
}
output "cl_azure_sql_elastic_pool" {
    value = module.cl_azure_sql_elastic_pool
}
output "cl_api_mgmt" {
    value = module.cl_api_mgmt
}
output "cl_app_insights" {
    value = module.cl_app_insights
}
```   


## Usage
```terraform
//**********************************************************************************************
module "core_openai_ptrn" {
    source                                                                              = "../dn-tads_tf-azure-component-library/patterns/ptrn_openai"
    env                                                                                 = var.env
    postfix                                                                             = var.postfix
    location                                                                            = var.location
    tags                                                                                = var.tags

# Container Registry
    ptrn_openai_deploy_container_registry                                               = true
    ptrn_openai_azure_container_registry_ip_rule_ranges                                 = var.ptrn_openai_azure_container_registry_ip_rule_ranges
    ptrn_openai_azure_container_registry_private_dns_zone_id                            = var.ptrn_openai_azure_container_registry_private_dns_zone_id
    ptrn_openai_azure_container_registry_allowed_vnet_ids                               = var.ptrn_openai_azure_container_registry_allowed_vnet_ids
    ptrn_openai_ptrn_privatelink_subnet                                                 = var.ptrn_openai_ptrn_privatelink_subnet
    ptrn_openai_core_log_analytics_workspace_resource_id                                = var.ptrn_openai_core_log_analytics_workspace_resource_id
    ptrn_openai_core_log_analytics_workspace_name                                       = var.ptrn_openai_core_log_analytics_workspace_name

# cognitive services
    ptrn_openai_cl_cognitive_services_openai                                            = var.ptrn_openai_cl_cognitive_services_openai
    ptrn_openai_cl_cognitive_services_deploy_rg                                         = true
    ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids                  = var.ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids
    ptrn_openai_cl_cognitive_services_nacl_allowed_subnets                              = var.ptrn_openai_cl_cognitive_services_nacl_allowed_subnets
    ptrn_openai_cl_cognitive_services_private_dns_zone_ids                              = var.ptrn_openai_cl_cognitive_services_private_dns_zone_ids
    ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges                           = var.ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges

# App service Plan
    ptrn_openai_app_service_plan_deploy_rg                                              = var.ptrn_openai_app_service_plan_deploy_rg
    ptrn_openai_app_service_plan_reserved                                               = var.ptrn_openai_app_service_plan_reserved
    ptrn_openai_app_service_plan_kind                                                   = var.ptrn_openai_app_service_plan_kind
    ptrn_openai_app_service_plan_deploy_integration_subnet                              = var.ptrn_openai_app_service_plan_deploy_integration_subnet
    ptrn_openai_core_rg_network_name                                                    = var.ptrn_openai_core_rg_network_name
    ptrn_openai_core_vnet_name                                                          = var.ptrn_openai_core_vnet_name
    ptrn_openai_app_service_plan_integration_subnet_prefix                              = var.ptrn_openai_app_service_plan_integration_subnet_prefix
    ptrn_openai_app_service_plan_route_table_id                                         = var.ptrn_openai_app_service_plan_route_table_id
    ptrn_openai_app_service_plan_sku_tier                                               = var.ptrn_openai_app_service_plan_sku_tier
    ptrn_openai_app_service_plan_sku_size                                               = var.ptrn_openai_app_service_plan_sku_size
    ptrn_openai_app_service_plan_sku_capacity                                           = var.ptrn_openai_app_service_plan_sku_capacity
    ptrn_openai_app_service_plan_app_postfix                                            = var.ptrn_openai_app_service_plan_app_postfix

# App Service 
    ptrn_openai_app_service                                                                 = var.ptrn_openai_app_service
    ptrn_openai_app_service_pe_subnet_ids                                                   = var.ptrn_openai_app_service_pe_subnet_ids
    ptrn_openai_app_service_settings                                                        = var.ptrn_openai_app_service_settings
    ptrn_openai_app_service_identity_identity_ids                                           = var.ptrn_openai_app_service_identity_identity_ids
    ptrn_openai_app_service_private_dns_zone_id                                             = var.ptrn_openai_app_service_private_dns_zone_id
    ptrn_openai_app_service_acr_login_server                                                = var.ptrn_openai_app_service_acr_login_server
    ptrn_openai_app_service_acr_username                                                    = var.ptrn_openai_app_service_acr_username
    ptrn_openai_app_service_acr_password                                                    = var.ptrn_openai_app_service_acr_password
    ptrn_openai_app_service_acr_image                                                       = var.ptrn_openai_app_service_acr_image
    ptrn_openai_app_service_acr_scm_type                                                    = var.ptrn_openai_app_service_acr_scm_type
    ptrn_openai_app_service_dns_server                                                      = var.ptrn_openai_app_service_dns_server
    ptrn_openai_app_service_vnet_route_server                                               = var.ptrn_openai_app_service_vnet_route_server
    ptrn_openai_app_service_auth_settings_default_provider                                  = var.ptrn_openai_app_service_auth_settings_default_provider

# App Gateway
    ptrn_openai_app_gateway_rg_name                                                         = var.ptrn_openai_app_gateway_rg_name
    ptrn_openai_core_rg_logging_name                                                        = var.ptrn_openai_core_rg_logging_name
    ptrn_openai_app_gateway_subnet_address_prefix                                           = var.ptrn_openai_app_gateway_subnet_address_prefix
    ptrn_openai_app_gateway_frontend_tls_cert                                                      = var.ptrn_openai_app_gateway_frontend_tls_cert
    ptrn_openai_app_gateway_frontend_tls_cert_pass                                                 = var.ptrn_openai_app_gateway_frontend_tls_cert_pass
    ptrn_openai_app_gateway_backend_address                                                        = var.ptrn_openai_app_gateway_backend_address
    ptrn_openai_app_gateway_backend_host_name                                                      = var.ptrn_openai_app_gateway_backend_host_name
    ptrn_openai_app_gateway_https_listener_hostname                                                = var.ptrn_openai_app_gateway_https_listener_hostname
    ptrn_openai_app_gateway_pick_host_name                                                         = var.ptrn_openai_app_gateway_pick_host_name
    ptrn_openai_app_gateway_pick_host_backend                                                      = var.ptrn_openai_app_gateway_pick_host_backend
      ptrn_openai_app_gateway_subnet_hostnum                                                       = var.ptrn_openai_app_gateway_subnet_hostnum
      ptrn_openai_app_gateway_min_capacity                                                         = var.ptrn_openai_app_gateway_min_capacity
      ptrn_openai_app_gateway_max_capacity                                                         = var.ptrn_openai_app_gateway_max_capacity
      ptrn_openai_app_gateway_probe_name                                                           = var.ptrn_openai_app_gateway_probe_name
      ptrn_openai_app_gateway_probe_host                                                           = var.ptrn_openai_app_gateway_probe_host
      ptrn_openai_app_gateway_probe_path                                                           = var.ptrn_openai_app_gateway_probe_path
      ptrn_openai_app_gateway_nsg_rules                                                            = var.ptrn_openai_app_gateway_nsg_rules
      ptrn_openai_app_gateway_probe_status_code                                                    = var.ptrn_openai_app_gateway_probe_status_code
      ptrn_openai_app_gateway_additional_backend_address_pool                                      = var.ptrn_openai_app_gateway_additional_backend_address_pool
      ptrn_openai_app_gateway_additional_http_settings                                             = var.ptrn_openai_app_gateway_additional_http_settings
      ptrn_openai_app_gateway_additional_http_listener                                             = var.ptrn_openai_app_gateway_additional_http_listener
      ptrn_openai_app_gateway_additional_route_rules                                               = var.ptrn_openai_app_gateway_additional_route_rules
      ptrn_openai_app_gateway_storage_account_nsg_flow_log_id                                      = var.ptrn_openai_app_gateway_storage_account_nsg_flow_log_id
      ptrn_openai_app_gateway_nsg_flow_log_postfix                                                 = var.ptrn_openai_app_gateway_nsg_flow_log_postfix

# SQL SERVER

  ptrn_openai_azure_sql_server_postfix                                                  = var.ptrn_openai_azure_sql_server_postfix
  ptrn_openai_azure_sql_server_resource_group_name                                      = var.ptrn_openai_azure_sql_server_resource_group_name
  ptrn_openai_azure_sql_server_administrator                                            = var.ptrn_openai_azure_sql_server_administrator
  ptrn_openai_azure_sql_server_password                                                 = var.ptrn_openai_azure_sql_server_password
  ptrn_openai_azure_sql_server_firewall_rules                                           = var.ptrn_openai_azure_sql_server_firewall_rules
  ptrn_openai_azure_sql_server_vnet_rules                                               = var.ptrn_openai_azure_sql_server_vnet_rules
  ptrn_openai_azure_sql_server_nacl_allowed_subnets                                     = var.ptrn_openai_azure_sql_server_nacl_allowed_subnets 

  ptrn_openai_azure_sql_server_storage_account_subnet_ids                               = var.ptrn_openai_azure_sql_server_storage_account_subnet_ids 
  ptrn_openai_azure_sql_server_storage_account_ip_rules                                 = var.ptrn_openai_azure_sql_server_storage_account_ip_rules


  ptrn_openai_azure_sql_server_azuread_login_username                                            = var.ptrn_openai_azure_sql_server_azuread_login_username      
  ptrn_openai_azure_sql_server_azuread_object_id                                                 = var.ptrn_openai_azure_sql_server_azuread_object_id
  ptrn_openai_azure_sql_server_private_dns_zone_ids                                              = var.ptrn_openai_azure_sql_server_private_dns_zone_ids
  ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids                                     = var.ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids 
  ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids                              = var.ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids

# TF STATE
  ptrn_openai_storage_account_postfix         = var.ptrn_openai_storage_account_postfix
  ptrn_openai_storage_account_env             = var.ptrn_openai_storage_account_env

# SQL DB
  ptrn_openai_azure_sql_database_postfix        = var.ptrn_openai_azure_sql_database_postfix
  ptrn_openai_azure_sql_database_sku            = var.ptrn_openai_azure_sql_database_sku
  ptrn_openai_azure_sql_server_id               = var.ptrn_openai_azure_sql_server_id
  ptrn_openai_azure_storage_account_endpoint             = var.ptrn_openai_azure_storage_account_endpoint
  ptrn_openai_azure_storage_account_access_key           = var.ptrn_openai_azure_storage_account_access_key
  ptrn_openai_azure_sql_database_elastic_pool_id         = var.ptrn_openai_azure_sql_database_elastic_pool_id

# SQL ELASTIC 
 ptrn_openai_azure_sql_elastic_pool_enable                     = var.ptrn_openai_azure_sql_elastic_pool_enable
 ptrn_openai_azure_sql_elastic_pool_postfix                    = var.ptrn_openai_azure_sql_elastic_pool_postfix 
 ptrn_openai_core_rg_data_name                                 = var.ptrn_openai_core_rg_data_name

# API MGMT
  ptrn_openai_core_route_table_id                    = var.ptrn_openai_core_route_table_id
  ptrn_openai_api_mgmt_subnet_vnet_rg_name           = var.ptrn_openai_api_mgmt_subnet_vnet_rg_name
  ptrn_openai_api_mgmt_subnet_vnet_name              = var.ptrn_openai_api_mgmt_subnet_vnet_name
  ptrn_openai_api_mgmt_subnet_prefix                 = var.ptrn_openai_api_mgmt_subnet_prefix  
  ptrn_openai_api_mgmt_publisher_name                = var.ptrn_openai_api_mgmt_publisher_name
  ptrn_openai_api_mgmt_publisher_email               = var.ptrn_openai_api_mgmt_publisher_email
  ptrn_openai_api_mgmt_inbound_cidrs                 = var.ptrn_openai_api_mgmt_inbound_cidrs 
  ptrn_openai_api_mgmt_proxies                       = var.ptrn_openai_api_mgmt_proxies 
  ptrn_openai_api_mgmt_developer_portals             = var.ptrn_openai_api_mgmt_developer_portals  
}
//**********************************************************************************************
```  

## SAMPLE USAGE
```terraform
// Deploy the SAMPLE OPENAI PATTERN
//**********************************************************************************************
module "core_openai_ptrn" {
    source                                                                              = "../dn-tads_tf-azure-component-library/patterns/ptrn_openai"
    env                                                                                 = "nprd-pr"
    postfix                                                                             = "ai"
    location                                                                            = "eastus"
    tags                                                                                = {}

# Container Registry
    ptrn_openai_deploy_container_registry                                               = true

    ptrn_openai_azure_container_registry_rg_name                                        = "rg-nprd-pr-cclupgd-data"
    ptrn_openai_azure_container_registry_private_dns_zone_id                            = "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.azurecr.io"
    ptrn_openai_azure_container_registry_allowed_vnet_ids                               = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet"]
    ptrn_openai_core_log_analytics_workspace_resource_id                                = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-logging/providers/Microsoft.OperationalInsights/workspaces/oms-nprd-pr-cclupgd-log-analytics"
    ptrn_openai_core_log_analytics_workspace_name                                       = "oms-nprd-pr-cclupgd-log-analytics"
     ptrn_openai_azure_container_registry_ip_rule_ranges                                = ["199.206.0.0/15"]
    ptrn_openai_azure_container_registry_nacl_allowed_subnets                           = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"]

# cognitive services
  ptrn_openai_cl_cognitive_services_openai = {
    openai = {
      cog_service_postfix = "openai"
      kind                = "OpenAI"
      sku                 = "S0"
    }
  }
    ptrn_openai_cl_cognitive_services_deploy_rg                                         = true
    ptrn_openai_cl_cognitive_services_pe_rg_name                                        = "rg-nprd-pr-cclupgd-network"
    ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids                  = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"
    ptrn_openai_cl_cognitive_services_nacl_allowed_subnets                              = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"]
    ptrn_openai_cl_cognitive_services_private_dns_zone_ids                              = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.cognitiveservices.azure.com"]
    ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges                           = ["199.206.0.0/15"]

# App service Plan
    ptrn_openai_app_service_plan_deploy_rg                                              = true
    ptrn_openai_app_service_plan_reserved                                               = true
    ptrn_openai_app_service_plan_kind                                                   = "linux"
    ptrn_openai_app_service_plan_deploy_integration_subnet                              = true
    ptrn_openai_core_rg_network_name                                                    = "rg-nprd-pr-cclupgd-network"
    ptrn_openai_core_vnet_name                                                          = "nprd-pr-cclupgd-vnet"
    ptrn_openai_app_service_plan_integration_subnet_prefix                              = ["192.168.1.160/28"]
    ptrn_openai_app_service_plan_route_table_id                                         = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/routeTables/nprd-pr-cclupgd-rt-default"
    ptrn_openai_app_service_plan_sku_tier                                               = "PremiumV2"
    ptrn_openai_app_service_plan_sku_size                                               = "P3v2"
    ptrn_openai_app_service_plan_sku_capacity                                           = 1
    ptrn_openai_app_service_plan_app_postfix                                            = "asp"

# App Service 
ptrn_openai_app_service = {
    frontend = {
      ptrn_openai_app_service_always_on                    = true
      ptrn_openai_app_service_app_postfix                  = "ui"
      ptrn_openai_app_service_client_affinity_enabled     = false
      ptrn_openai_app_service_is_linux_docker             = false
      ptrn_openai_app_service_is_windows_docker           = false
      ptrn_openai_app_service_linux_fx_version            = "PYTHON|3.10"
      ptrn_openai_app_service_scm_type                    = "None"
      ptrn_openai_app_service_windows_fx_version          = ""
      ptrn_openai_app_service_settings = {
      AZURE_STORAGE_ACCOUNT           = "nprdprgenerativeaiblobsa"
      AZURE_STORAGE_CONTAINER         = "content"
      AZURE_OPENAI_SERVICE            = "nprd-pr-generativeai-cns-openai"
      AZURE_SEARCH_INDEX              = "gptkbindex"
      AZURE_SEARCH_SERVICE            = "nprd-pr-generativeai-srch-gptindex"
      AZURE_OPENAI_GPT_DEPLOYMENT     = "text-davinci-003"
      AZURE_OPENAI_CHATGPT_DEPLOYMENT = "GPT-35-Turbo"
      WEBSITE_VNET_ROUTE_ALL          = "1"
      DOCKER_REGISTRY_SERVER_URL      = "https://acrnprdprnxsgpt.azurecr.io"
      WEBSITES_PORT                   = "4200"
      WEBSITE_PULL_IMAGE_OVER_VNET    = "true"
      minTlsVersion                   = "1.2"
    }
    },
    backend = {
      ptrn_openai_app_service_always_on                    = true
      ptrn_openai_app_service_app_postfix                  = "backend"
      ptrn_openai_app_service_client_affinity_enabled     = false
      ptrn_openai_app_service_is_linux_docker             = false
      ptrn_openai_app_service_is_windows_docker           = false
      ptrn_openai_app_service_linux_fx_version            = "PYTHON|3.10"
      ptrn_openai_app_service_scm_type                    = "None"
      ptrn_openai_app_service_windows_fx_version          = ""
      ptrn_openai_app_service_settings = {
          AZURE_STORAGE_ACCOUNT           = "nprdprgenerativeaiblobsa"
          AZURE_STORAGE_CONTAINER         = "content"
          AZURE_OPENAI_SERVICE            = "nprd-pr-generativeai-cns-openai"
          AZURE_SEARCH_INDEX              = "gptkbindex"
          AZURE_SEARCH_SERVICE            = "nprd-pr-generativeai-srch-gptindex"
          AZURE_OPENAI_GPT_DEPLOYMENT     = "text-davinci-003"
          AZURE_OPENAI_CHATGPT_DEPLOYMENT = "GPT-35-Turbo"
          WEBSITE_VNET_ROUTE_ALL          = "1"
          AZ_CLIENT_ID                    = "d7561831-bab9-4450-b7ee-8f3da0a923cf"
          AZ_CLIENT_SECRET                = "KLKOyPQf6syxBhEkozVwq_zhY93LTwcfhj"
          AZ_TENANT_ID                    = "80186d9c-9d80-40b0-9a2b-54859d39e5d7"
          DATABASE_NAME                   = "nprd-pr-nxsgpt-sqldb-ai"
          DATABASE_PORT                   = "1433"
          DATABASE_SERVER                 = "nprd-pr-nxsgpt-sqlserver-ai.database.windows.net"
          DOCKER_REGISTRY_SERVER_URL      = "https://acrnprdprnxsgpt.azurecr.io"
          KEY_VAULT_URI                   = "https://nprd-pr-nxsgpt-kv-ai.vault.azure.net/"
          WEBSITES_PORT                   = "5000"
          env_type                        = "local"
          minTlsVersion                   = "1.2"
          okta_url                        = "https://kpmgstaging.oktapreview.com/oauth2/default/v1/introspect"
          WEBSITE_PULL_IMAGE_OVER_VNET    = "true"
        }
    }
  }

    ptrn_openai_app_service_pe_subnet_ids                                                   = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"]
    ptrn_openai_app_service_identity_type                                                   = "SystemAssigned"
    ptrn_openai_app_service_private_dns_zone_id                                             = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-network/providers/Microsoft.Network/privateDnsZones/privatelink.azurewebsites.net"]
    ptrn_openai_app_service_auth_settings_default_provider                                  = "AzureActiveDirectory"
    ptrn_openai_app_service_auth_settings_unauthenticated_client_action                     = "AllowAnonymous"


# App Gateway 
    ptrn_openai_deploy_app_gateway                                                          = true
    ptrn_openai_app_gateway_rg_name                                                         = "rg-nprd-pr-cclupgd-data"
    ptrn_openai_app_gateway_postfix                                                         = "apgw"
    ptrn_openai_core_rg_logging_name                                                        = "rg-nprd-pr-cclupgd-logging"
    ptrn_openai_app_gateway_subnet_address_prefix                                           = ["192.168.1.192/27"]
    ptrn_openai_app_gateway_frontend_tls_cert                                                      = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
    ptrn_openai_app_gateway_frontend_tls_cert_pass                                                 = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
    ptrn_openai_app_gateway_backend_address                                                        = ["test"]
    ptrn_openai_app_gateway_backend_host_name                                                      = "test"
    ptrn_openai_app_gateway_https_listener_hostname                                                = "single_site"
      ptrn_openai_app_gateway_nsg_rules                                                            = {}
      ptrn_openai_app_gateway_probe_status_code                                                    = ["200-405"]
      ptrn_openai_app_gateway_additional_backend_address_pool                                      = {}
      ptrn_openai_app_gateway_additional_http_settings                                             = {}
      ptrn_openai_app_gateway_additional_http_listener                                             = {}
      ptrn_openai_app_gateway_additional_route_rules                                               = {}


# SQL SERVER
 ptrn_openai_azure_sql_server_public_network_access                                     = true
 ptrn_openai_azure_sql_server_storage_account_network_default_action                    = "Allow"
  ptrn_openai_deploy_azure_sql_server                                                   = true
  ptrn_openai_azure_sql_server_postfix                                                  = "sql"
  ptrn_openai_azure_sql_server_resource_group_name                                      = "rg-nprd-pr-cclupgd-data"
  ptrn_openai_azure_sql_server_administrator                                            = "sqladmin"
  ptrn_openai_azure_sql_server_password                                                 = "testErhgnl123!"
  ptrn_openai_azure_sql_server_firewall_rules                                           = {}
  ptrn_openai_azure_sql_server_vnet_rules                                               = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"]
  ptrn_openai_azure_sql_server_nacl_allowed_subnets                                     = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"]

  ptrn_openai_azure_sql_server_storage_account_subnet_ids                               = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn", "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-sharedsvc-vnet/subnets/nprd-pr-sharedghr-kubernetes-nodes-sn"]
  ptrn_openai_azure_sql_server_storage_account_ip_rules                                 = ["199.206.0.0/15"]
  ptrn_openai_azure_sql_server_audit_enabled                                            = true
  ptrn_openai_azure_sql_server_vulnerability_enabled                                    = true


  ptrn_openai_azure_sql_server_azuread_login_username                                            = "US-DMG-SQL"
  ptrn_openai_azure_sql_server_azuread_object_id                                                 = "974d0ee2-8635-4332-8d30-b12068cf40de"
  ptrn_openai_azure_sql_server_private_dns_zone_ids                                              = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.database.windows.net"]
  ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids                                     = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"]
  ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids                              = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"]

# SQL DB
  ptrn_openai_azure_sql_database_audit_enabled  = true
  ptrn_openai_deploy_azure_sql_database         = true
  ptrn_openai_azure_sql_database_postfix        = "sqldb"
  ptrn_openai_azure_sql_database_sku            = "ElasticPool"

# SQL ELASTIC 
 ptrn_openai_azure_sql_elastic_pool_enable                     = true
 ptrn_openai_azure_sql_elastic_pool_postfix                    = "sql"
 ptrn_openai_core_rg_data_name                                 = "rg-nprd-pr-cclupgd-data"

# API MGMT
  ptrn_openai_api_mgmt_enable                        = true
  ptrn_openai_core_route_table_id                    = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/routeTables/nprd-pr-cclupgd-rt-default"
  ptrn_openai_api_mgmt_subnet_vnet_rg_name           = "rg-nprd-pr-cclupgd-network"
  ptrn_openai_api_mgmt_subnet_vnet_name              = "nprd-pr-cclupgd-vnet"
  ptrn_openai_api_mgmt_subnet_prefix                 = ["192.168.1.80/28"]
  ptrn_openai_api_mgmt_publisher_name                = "kpmg"
  ptrn_openai_api_mgmt_publisher_email               = "vtirumani@kpmg.com"
  ptrn_openai_api_mgmt_inbound_cidrs                 = ["199.206.0.0/15"]
  ptrn_openai_api_mgmt_public_network_access_enabled  = true

# STG ACCT
  ptrn_openai_storage_account_key                 = {
  blob = {
  ptrn_openai_storage_account_private_dns_zone_ids = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"]
  ptrn_openai_storage_account_blob_enable_backup = true
  ptrn_openai_storage_account_share_enabled = false
  ptrn_openai_storage_account_queue_enabled = false
   ptrn_openai_storage_account_queues = [""]
  ptrn_openai_storage_account_file_shares = {}
  ptrn_openai_storage_account_file_enable_backup = false
  ptrn_openai_storage_account_large_file_share = false
   ptrn_openai_storage_account_tier             = "Standard"
   ptrn_openai_storage_account_kind             = "StorageV2"
  }
}
  ptrn_openai_storage_account_resource_group_name = "rg-nprd-pr-cclupgd-data"
  ptrn_openai_storage_account_log_analytics_workspace_id = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-logging/providers/Microsoft.OperationalInsights/workspaces/oms-nprd-pr-cclupgd-log-analytics"
  ptrn_openai_storage_account_allowed_ips =  ["199.206.0.0/15"]
  ptrn_openai_storage_account_allowed_pe_subnet_ids =  ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"]
  ptrn_openai_storage_account_allowed_vnet_subnet_ids = ["/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn", "/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-sharedsvc-vnet/subnets/nprd-pr-sharedghr-kubernetes-nodes-sn"]
  ptrn_openai_storage_account_private_dns_zone_ids = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"]
  ptrn_openai_storage_account_blob_backup_vault_id = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgdsd-backup/providers/Microsoft.DataProtection/backupVaults/nprd-pr-cclupgdsd-backup-vault"
  ptrn_openai_storage_account_blob_backup_vault  = "nprd-pr-cclupgdsd-backup-vault"
  ptrn_openai_storage_account_blob_backup_policy_id = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgdsd-backup/providers/Microsoft.DataProtection/backupVaults/nprd-pr-cclupgdsd-backup-vault/backupPolicies/nprd-pr-cclupgdsd-blob-backup-policy"

# APP INSIGHTS
  ptrn_openai_app_insights_enable                 = true
  ptrn_openai_app_insights_resource_group_name    = "rg-nprd-pr-cclupgd-network"
  ptrn_openai_app_insights_application_type       = "web"
  ptrn_openai_app_insights_content                = "requests"
  ptrn_openai_app_insights_scope                  = "shared"
  ptrn_openai_app_insights_type                   = "query"
  ptrn_openai_app_insights_web_test_kind          = "ping"

# Tfstate
  ptrn_openai_storage_account_postfix                  = "ai"
  ptrn_openai_storage_account_env             = "nprd-pr"

# REDIS CACHE
  ptrn_openai_cl_redis_enterprise_cluster_enable             = true
  ptrn_openai_cl_redis_enterprise_cluster_resource_group_name = "rg-nprd-pr-cclupgd-data"
  ptrn_openai_cl_redis_enterprise_cluster_sku_name      = "Enterprise_E20-4"
  ptrn_openai_cl_redis_enterprise_database_module_name = "RediSearch"
  ptrn_openai_cl_redis_enterprise_database_eviction_policy = "NoEviction"
  ptrn_openai_cl_redis_enterprise_cluster_subnet       = "/subscriptions/47e90beb-415e-47e6-b985-e079984f4985/resourceGroups/rg-nprd-pr-cclupgd-network/providers/Microsoft.Network/virtualNetworks/nprd-pr-cclupgd-vnet/subnets/nprd-pr-cclupgd-private-link-sn"
  ptrn_openai_cl_redis_enterprise_cluster_private_dns_zone_ids = ["/subscriptions/f4bd0018-73c9-4248-827f-01718adad3c4/resourceGroups/rg-nprd-pr-sharedsvc-privatedns/providers/Microsoft.Network/privateDnsZones/privatelink.redisenterprise.cache.azure.net"]
}             
//**********************************************************************************************
```  
















<!-- BEGIN_TF_DOCS -->

# Azure Openai Pattern 

This is the Azure OpenAI Pattern. It'll deploy the following Components:
* Application Gateway & WAF
* App service Plan
* App services
* Azure Container Registry
* Azure SQL Database
* Azure SQL Server
* Azure SQL Elastic Pool
* cognitive services (AOAI)
* Storage account
* Redis Cache (regular and enterprise cluster)
* APIM
* App Insights



## Resources

| Name | Type |
|------|------|
| [azurerm_web_application_firewall_policy.cl_web_application_firewall_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/web_application_firewall_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cl_azure_sql_server_sa_enable_backup"></a> [cl\_azure\_sql\_server\_sa\_enable\_backup](#input\_cl\_azure\_sql\_server\_sa\_enable\_backup) | n/a | `bool` | `true` | no |
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_ptrn_openai_api_mgmt_deploy_custom_domain"></a> [ptrn\_openai\_api\_mgmt\_deploy\_custom\_domain](#input\_ptrn\_openai\_api\_mgmt\_deploy\_custom\_domain) | (Optional) Specifies if custom domain for API management should be deployed or not. | `bool` | `false` | no |
| <a name="input_ptrn_openai_api_mgmt_developer_portals"></a> [ptrn\_openai\_api\_mgmt\_developer\_portals](#input\_ptrn\_openai\_api\_mgmt\_developer\_portals) | (Optional) Array for API management developer portal deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_api_mgmt_diagnostic"></a> [ptrn\_openai\_api\_mgmt\_diagnostic](#input\_ptrn\_openai\_api\_mgmt\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_api_mgmt_enable"></a> [ptrn\_openai\_api\_mgmt\_enable](#input\_ptrn\_openai\_api\_mgmt\_enable) | (Required) set to true to enable API mgmt. | `bool` | `false` | no |
| <a name="input_ptrn_openai_api_mgmt_identity_identity_ids"></a> [ptrn\_openai\_api\_mgmt\_identity\_identity\_ids](#input\_ptrn\_openai\_api\_mgmt\_identity\_identity\_ids) | (Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned. | `list(string)` | `null` | no |
| <a name="input_ptrn_openai_api_mgmt_identity_type"></a> [ptrn\_openai\_api\_mgmt\_identity\_type](#input\_ptrn\_openai\_api\_mgmt\_identity\_type) | (Optional) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_ptrn_openai_api_mgmt_inbound_cidrs"></a> [ptrn\_openai\_api\_mgmt\_inbound\_cidrs](#input\_ptrn\_openai\_api\_mgmt\_inbound\_cidrs) | (Required) A list of CIDRs to allow to communicate with API Management. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_api_mgmt_managements"></a> [ptrn\_openai\_api\_mgmt\_managements](#input\_ptrn\_openai\_api\_mgmt\_managements) | (Optional) Array for API management managements deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_api_mgmt_portals"></a> [ptrn\_openai\_api\_mgmt\_portals](#input\_ptrn\_openai\_api\_mgmt\_portals) | (Optional) Array for API management portals deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_api_mgmt_proxies"></a> [ptrn\_openai\_api\_mgmt\_proxies](#input\_ptrn\_openai\_api\_mgmt\_proxies) | (Optional) Array for API management proxy deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    default_ssl_binding           = bool<br>    key_vault_id                  = string <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_api_mgmt_public_network_access_enabled"></a> [ptrn\_openai\_api\_mgmt\_public\_network\_access\_enabled](#input\_ptrn\_openai\_api\_mgmt\_public\_network\_access\_enabled) | n/a | `bool` | `false` | no |
| <a name="input_ptrn_openai_api_mgmt_publisher_email"></a> [ptrn\_openai\_api\_mgmt\_publisher\_email](#input\_ptrn\_openai\_api\_mgmt\_publisher\_email) | (Required) The email of publisher/company. | `string` | `""` | no |
| <a name="input_ptrn_openai_api_mgmt_publisher_name"></a> [ptrn\_openai\_api\_mgmt\_publisher\_name](#input\_ptrn\_openai\_api\_mgmt\_publisher\_name) | (Required) The name of publisher/company. | `string` | `""` | no |
| <a name="input_ptrn_openai_api_mgmt_scms"></a> [ptrn\_openai\_api\_mgmt\_scms](#input\_ptrn\_openai\_api\_mgmt\_scms) | (Optional) Array for API management SCM deployment. | <pre>map(object({<br>    host_name                     = string<br>    certificate                   = string<br>    certificate_password          = string<br>    negotiate_client_certificate  = bool<br>    key_vault_id                  = string <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_api_mgmt_sku_name"></a> [ptrn\_openai\_api\_mgmt\_sku\_name](#input\_ptrn\_openai\_api\_mgmt\_sku\_name) | (Optional) sku\_name is a string consisting of two parts separated by an underscore(\_) | `string` | `"Developer_1"` | no |
| <a name="input_ptrn_openai_api_mgmt_subnet_prefix"></a> [ptrn\_openai\_api\_mgmt\_subnet\_prefix](#input\_ptrn\_openai\_api\_mgmt\_subnet\_prefix) | (Required) The prefix of the api mgmt subnet. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_api_mgmt_subnet_service_enpoints"></a> [ptrn\_openai\_api\_mgmt\_subnet\_service\_enpoints](#input\_ptrn\_openai\_api\_mgmt\_subnet\_service\_enpoints) | (Optional) The service endpoints for the api mgmt subnet. | `list(string)` | <pre>[<br>  "Microsoft.Sql",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ServiceBus"<br>]</pre> | no |
| <a name="input_ptrn_openai_api_mgmt_subnet_vnet_name"></a> [ptrn\_openai\_api\_mgmt\_subnet\_vnet\_name](#input\_ptrn\_openai\_api\_mgmt\_subnet\_vnet\_name) | (Required) The name of the core vnet required for the Api mgmt subnet. | `string` | `""` | no |
| <a name="input_ptrn_openai_api_mgmt_subnet_vnet_rg_name"></a> [ptrn\_openai\_api\_mgmt\_subnet\_vnet\_rg\_name](#input\_ptrn\_openai\_api\_mgmt\_subnet\_vnet\_rg\_name) | (Required) The name of the resource group that the core vnet is in | `string` | `""` | no |
| <a name="input_ptrn_openai_app_gateway_additional_backend_address_pool"></a> [ptrn\_openai\_app\_gateway\_additional\_backend\_address\_pool](#input\_ptrn\_openai\_app\_gateway\_additional\_backend\_address\_pool) | (Optional) Array for additional backend address pool. | <pre>map(object({<br>    name  = string<br>    fqdns = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_additional_http_listener"></a> [ptrn\_openai\_app\_gateway\_additional\_http\_listener](#input\_ptrn\_openai\_app\_gateway\_additional\_http\_listener) | (Optional) Array for additional HTTP listeners. | <pre>map(object({<br>    name                 = string<br>    protocol             = string<br>    host_name            = string<br>    frontend_port_name   = string<br>    ssl_certificate_name = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_additional_http_settings"></a> [ptrn\_openai\_app\_gateway\_additional\_http\_settings](#input\_ptrn\_openai\_app\_gateway\_additional\_http\_settings) | (Optional) Array for additional HTTP settings. | <pre>map(object({<br>    name                                = string<br>    request_timeout                     = number<br>    probe_name                          = string<br>    host_name                           = string<br>    pick_host_name_from_backend_address = bool<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_additional_probes"></a> [ptrn\_openai\_app\_gateway\_additional\_probes](#input\_ptrn\_openai\_app\_gateway\_additional\_probes) | (Optional) Array for additional health probes. | <pre>map(object({<br>    name                = string<br>    host                = string<br>    path                = string<br>    interval            = number<br>    timeout             = number<br>    unhealthy_threshold = number<br>    protocol            = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_additional_redirect_configurations"></a> [ptrn\_openai\_app\_gateway\_additional\_redirect\_configurations](#input\_ptrn\_openai\_app\_gateway\_additional\_redirect\_configurations) | (Optional) Array for additional redirect configurations. | <pre>map(object({<br>    name                 = string<br>    redirect_type        = string<br>    target_listener_name = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_additional_route_rules"></a> [ptrn\_openai\_app\_gateway\_additional\_route\_rules](#input\_ptrn\_openai\_app\_gateway\_additional\_route\_rules) | (Optional) Array for additional routing rules. | <pre>map(object({<br>    name                                = string<br>    rule_type                           = string<br>    http_listener_name                  = string<br>    backend_address_pool                = string<br>    backend_http_settings_name          = string<br>    redirect_configuration_name         = string<br>    priority                            = number<br>    url_path_map_name                   = string   <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_additional_ssl_certificate"></a> [ptrn\_openai\_app\_gateway\_additional\_ssl\_certificate](#input\_ptrn\_openai\_app\_gateway\_additional\_ssl\_certificate) | (Optional) Array for additional ssl certificates. | <pre>map(object({<br>    name                = string<br>    data                = string<br>    password            = string<br>    key_vault_secret_id = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_backend_address"></a> [ptrn\_openai\_app\_gateway\_backend\_address](#input\_ptrn\_openai\_app\_gateway\_backend\_address) | (Optional) The backend ip or fqdns address from the address pool | `list` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_backend_host_name"></a> [ptrn\_openai\_app\_gateway\_backend\_host\_name](#input\_ptrn\_openai\_app\_gateway\_backend\_host\_name) | (Optional) Host header to be sent to the backend servers. Cannot be set if pick\_host\_name\_from\_backend\_address is set to true | `any` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_core_sa_enabled"></a> [ptrn\_openai\_app\_gateway\_core\_sa\_enabled](#input\_ptrn\_openai\_app\_gateway\_core\_sa\_enabled) | (Optional) Set to true if core module has already been deployed with Storage account for collecting NSG flow logs. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_gateway_deploy_subnet"></a> [ptrn\_openai\_app\_gateway\_deploy\_subnet](#input\_ptrn\_openai\_app\_gateway\_deploy\_subnet) | (Required) select true/false to deploy separate APP GW subnet. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_gateway_deploy_subnet_nsg"></a> [ptrn\_openai\_app\_gateway\_deploy\_subnet\_nsg](#input\_ptrn\_openai\_app\_gateway\_deploy\_subnet\_nsg) | (Required) select true/false to deploy separate APP GW subnet NSG. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_gateway_diagnostics"></a> [ptrn\_openai\_app\_gateway\_diagnostics](#input\_ptrn\_openai\_app\_gateway\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ enabled_log = list(string), metrics = list(string) })` | <pre>{<br>  "enabled_log": [<br>    "ApplicationGatewayAccessLog",<br>    "ApplicationGatewayPerformanceLog",<br>    "ApplicationGatewayFirewallLog"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_app_gateway_disable_bgp_route_propagation"></a> [ptrn\_openai\_app\_gateway\_disable\_bgp\_route\_propagation](#input\_ptrn\_openai\_app\_gateway\_disable\_bgp\_route\_propagation) | (Optional) Boolean flag which controls propagation of routes learned by BGP on that route table. True means disable | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_gateway_domain_name_label"></a> [ptrn\_openai\_app\_gateway\_domain\_name\_label](#input\_ptrn\_openai\_app\_gateway\_domain\_name\_label) | (Optional) Label for the Domain Name. Will be used to make up the FQDN. If a domain name label is specified, an A DNS record is created for the public IP in the Microsoft Azure DNS system. | `string` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_firewall_mode"></a> [ptrn\_openai\_app\_gateway\_firewall\_mode](#input\_ptrn\_openai\_app\_gateway\_firewall\_mode) | (Optional) Resource group where the Core VNet exists. | `string` | `"Detection"` | no |
| <a name="input_ptrn_openai_app_gateway_frontend_tls_cert"></a> [ptrn\_openai\_app\_gateway\_frontend\_tls\_cert](#input\_ptrn\_openai\_app\_gateway\_frontend\_tls\_cert) | (Required) The name of the ssl cert file in pfx format that exists in the same folder that TF plan/apply is executed on. The file must not be base64 encrypted. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_gateway_frontend_tls_cert_keyvault_id"></a> [ptrn\_openai\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id](#input\_ptrn\_openai\_app\_gateway\_frontend\_tls\_cert\_keyvault\_id) | (Optional) Secret Id of (base-64 encoded unencrypted pfx) Secret or Certificate object stored in Azure KeyVault. | `any` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_frontend_tls_cert_pass"></a> [ptrn\_openai\_app\_gateway\_frontend\_tls\_cert\_pass](#input\_ptrn\_openai\_app\_gateway\_frontend\_tls\_cert\_pass) | (Required) The password for the front end ssl cert file | `string` | `""` | no |
| <a name="input_ptrn_openai_app_gateway_http_listener_hostname"></a> [ptrn\_openai\_app\_gateway\_http\_listener\_hostname](#input\_ptrn\_openai\_app\_gateway\_http\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTP Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_http_settings_timeout"></a> [ptrn\_openai\_app\_gateway\_http\_settings\_timeout](#input\_ptrn\_openai\_app\_gateway\_http\_settings\_timeout) | (Optional) The timeout for HTTP response. | `number` | `600` | no |
| <a name="input_ptrn_openai_app_gateway_https_listener_hostname"></a> [ptrn\_openai\_app\_gateway\_https\_listener\_hostname](#input\_ptrn\_openai\_app\_gateway\_https\_listener\_hostname) | (Optional) The Hostname which should be used for this HTTPS Listener. Setting this value changes Listener Type to Multi site | `any` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_identity_ids"></a> [ptrn\_openai\_app\_gateway\_identity\_ids](#input\_ptrn\_openai\_app\_gateway\_identity\_ids) | (Optional) Specifies a list with a single user managed identity id to be assigned to the Application Gateway | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_app_gateway_log_analytics_solutions"></a> [ptrn\_openai\_app\_gateway\_log\_analytics\_solutions](#input\_ptrn\_openai\_app\_gateway\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "ContainerInsights": {<br>    "product": "OMSGallery/ContainerInsights",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_openai_app_gateway_max_capacity"></a> [ptrn\_openai\_app\_gateway\_max\_capacity](#input\_ptrn\_openai\_app\_gateway\_max\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `5` | no |
| <a name="input_ptrn_openai_app_gateway_min_capacity"></a> [ptrn\_openai\_app\_gateway\_min\_capacity](#input\_ptrn\_openai\_app\_gateway\_min\_capacity) | (Optional) The minimum number of app gateway units for autoscaling | `number` | `1` | no |
| <a name="input_ptrn_openai_app_gateway_nsg_flow_log_postfix"></a> [ptrn\_openai\_app\_gateway\_nsg\_flow\_log\_postfix](#input\_ptrn\_openai\_app\_gateway\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_nsg_rules"></a> [ptrn\_openai\_app\_gateway\_nsg\_rules](#input\_ptrn\_openai\_app\_gateway\_nsg\_rules) | (Optional) Define additional NSG rules for app gateway subnet. | <pre>map(object({<br>    name                         = string<br>    priority                     = number<br>    direction                    = string<br>    access                       = string<br>    protocol                     = string<br>    source_port_range            = string<br>    source_port_ranges           = list(string)<br>    destination_port_range       = string<br>    destination_port_ranges      = list(string)<br>    source_address_prefix        = string<br>    source_address_prefixes      = list(string)<br>    destination_address_prefix   = string<br>    destination_address_prefixes = list(string)<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_gateway_nsg_sa_private_dns_zone_ids"></a> [ptrn\_openai\_app\_gateway\_nsg\_sa\_private\_dns\_zone\_ids](#input\_ptrn\_openai\_app\_gateway\_nsg\_sa\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_app_gateway_pick_host_backend"></a> [ptrn\_openai\_app\_gateway\_pick\_host\_backend](#input\_ptrn\_openai\_app\_gateway\_pick\_host\_backend) | (Optional) True/false to pick the host from the backend configuration | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_gateway_pick_host_name"></a> [ptrn\_openai\_app\_gateway\_pick\_host\_name](#input\_ptrn\_openai\_app\_gateway\_pick\_host\_name) | (Optional) True/false to pick a host from backend pool or overwrite the host name. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_gateway_postfix"></a> [ptrn\_openai\_app\_gateway\_postfix](#input\_ptrn\_openai\_app\_gateway\_postfix) | (Required) The postfix for the Application Gateway. | `string` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_probe_body"></a> [ptrn\_openai\_app\_gateway\_probe\_body](#input\_ptrn\_openai\_app\_gateway\_probe\_body) | (Required) String with the Body. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_gateway_probe_host"></a> [ptrn\_openai\_app\_gateway\_probe\_host](#input\_ptrn\_openai\_app\_gateway\_probe\_host) | (Optional) The site url from the Health probes | `string` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_probe_interval"></a> [ptrn\_openai\_app\_gateway\_probe\_interval](#input\_ptrn\_openai\_app\_gateway\_probe\_interval) | (Optional) The probe interval from the Health probes | `number` | `10` | no |
| <a name="input_ptrn_openai_app_gateway_probe_name"></a> [ptrn\_openai\_app\_gateway\_probe\_name](#input\_ptrn\_openai\_app\_gateway\_probe\_name) | (Optional) The probe name from Health probes | `string` | `"https-probe"` | no |
| <a name="input_ptrn_openai_app_gateway_probe_path"></a> [ptrn\_openai\_app\_gateway\_probe\_path](#input\_ptrn\_openai\_app\_gateway\_probe\_path) | (Optional) The probe path from the Health probes | `string` | `"/"` | no |
| <a name="input_ptrn_openai_app_gateway_probe_protocol"></a> [ptrn\_openai\_app\_gateway\_probe\_protocol](#input\_ptrn\_openai\_app\_gateway\_probe\_protocol) | (Optional) The probe protocol from the Health probes | `string` | `"Https"` | no |
| <a name="input_ptrn_openai_app_gateway_probe_status_code"></a> [ptrn\_openai\_app\_gateway\_probe\_status\_code](#input\_ptrn\_openai\_app\_gateway\_probe\_status\_code) | (Required) A list of allowed status codes for this Health Probe. | `list` | <pre>[<br>  "200-405"<br>]</pre> | no |
| <a name="input_ptrn_openai_app_gateway_probe_timeout"></a> [ptrn\_openai\_app\_gateway\_probe\_timeout](#input\_ptrn\_openai\_app\_gateway\_probe\_timeout) | (Optional) The timeout from the Health probes | `number` | `30` | no |
| <a name="input_ptrn_openai_app_gateway_probe_unhealthy_threshold"></a> [ptrn\_openai\_app\_gateway\_probe\_unhealthy\_threshold](#input\_ptrn\_openai\_app\_gateway\_probe\_unhealthy\_threshold) | (Optional) The unhealthy threshold from the Health probes | `number` | `3` | no |
| <a name="input_ptrn_openai_app_gateway_public_ip_allocation_method"></a> [ptrn\_openai\_app\_gateway\_public\_ip\_allocation\_method](#input\_ptrn\_openai\_app\_gateway\_public\_ip\_allocation\_method) | (Optional) The allocation method for this IP address. Possible values are Static or Dynamic. | `string` | `"Static"` | no |
| <a name="input_ptrn_openai_app_gateway_public_ip_sku"></a> [ptrn\_openai\_app\_gateway\_public\_ip\_sku](#input\_ptrn\_openai\_app\_gateway\_public\_ip\_sku) | (Optional) The SKU of the Public IP. Accepted values are Basic and Standard | `string` | `"Standard"` | no |
| <a name="input_ptrn_openai_app_gateway_reverse_fqdn"></a> [ptrn\_openai\_app\_gateway\_reverse\_fqdn](#input\_ptrn\_openai\_app\_gateway\_reverse\_fqdn) | (Optional) A fully qualified domain name that resolves to this public IP address | `any` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_rewrite_rules"></a> [ptrn\_openai\_app\_gateway\_rewrite\_rules](#input\_ptrn\_openai\_app\_gateway\_rewrite\_rules) | (Optional) Array for rewrite rules. | <pre>list(object({<br>    name            = string<br>    rule_sequence   = number<br>    conditions = list(object({<br>      variable    = string<br>      pattern     = string<br>      ignore_case = bool<br>      negate      = bool<br>    }))<br>    request_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))<br>    response_header_configurations = list(object({<br>      header_name   = string<br>      header_value  = string<br>    }))<br>    urls  = list(object({<br>      path          = string<br>      query_string  = string<br>      reroute       = string<br>    }))<br>  }))</pre> | `[]` | no |
| <a name="input_ptrn_openai_app_gateway_rg_name"></a> [ptrn\_openai\_app\_gateway\_rg\_name](#input\_ptrn\_openai\_app\_gateway\_rg\_name) | (Required) The resource group for the Application Gateway. | `string` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_ssl_policy_name"></a> [ptrn\_openai\_app\_gateway\_ssl\_policy\_name](#input\_ptrn\_openai\_app\_gateway\_ssl\_policy\_name) | (Optional) The Name from SSL Policy | `string` | `"AppGwSslPolicy20170401S"` | no |
| <a name="input_ptrn_openai_app_gateway_ssl_policy_protocol_version"></a> [ptrn\_openai\_app\_gateway\_ssl\_policy\_protocol\_version](#input\_ptrn\_openai\_app\_gateway\_ssl\_policy\_protocol\_version) | (Optional) The Minimun Protocol Version from SSL Policy | `string` | `"TLSv1_2"` | no |
| <a name="input_ptrn_openai_app_gateway_ssl_policy_type"></a> [ptrn\_openai\_app\_gateway\_ssl\_policy\_type](#input\_ptrn\_openai\_app\_gateway\_ssl\_policy\_type) | (Optional) The Type from SSL Policy | `string` | `"Predefined"` | no |
| <a name="input_ptrn_openai_app_gateway_storage_account_nsg_flow_log_id"></a> [ptrn\_openai\_app\_gateway\_storage\_account\_nsg\_flow\_log\_id](#input\_ptrn\_openai\_app\_gateway\_storage\_account\_nsg\_flow\_log\_id) | (Optional) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_subnet_address_prefix"></a> [ptrn\_openai\_app\_gateway\_subnet\_address\_prefix](#input\_ptrn\_openai\_app\_gateway\_subnet\_address\_prefix) | (Required) The address prefix of the application gateway subnet. | `list(string)` | `null` | no |
| <a name="input_ptrn_openai_app_gateway_subnet_hostnum"></a> [ptrn\_openai\_app\_gateway\_subnet\_hostnum](#input\_ptrn\_openai\_app\_gateway\_subnet\_hostnum) | (Optional) The hostnumber from the subnet prefix for the private IP. | `number` | `15` | no |
| <a name="input_ptrn_openai_app_gateway_subnet_service_endpoints"></a> [ptrn\_openai\_app\_gateway\_subnet\_service\_endpoints](#input\_ptrn\_openai\_app\_gateway\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet | `list` | <pre>[<br>  "Microsoft.Storage",<br>  "Microsoft.KeyVault",<br>  "Microsoft.AzureActiveDirectory",<br>  "Microsoft.Web",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.Sql",<br>  "Microsoft.EventHub",<br>  "Microsoft.CognitiveServices"<br>]</pre> | no |
| <a name="input_ptrn_openai_app_insights_application_type"></a> [ptrn\_openai\_app\_insights\_application\_type](#input\_ptrn\_openai\_app\_insights\_application\_type) | (Required) Specifies the type of Application Insights to create. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_insights_content"></a> [ptrn\_openai\_app\_insights\_content](#input\_ptrn\_openai\_app\_insights\_content) | (Required) The content for the Analytics Item. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_insights_enable"></a> [ptrn\_openai\_app\_insights\_enable](#input\_ptrn\_openai\_app\_insights\_enable) | (Required) set to true to create the Application Insights component. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_insights_resource_group_name"></a> [ptrn\_openai\_app\_insights\_resource\_group\_name](#input\_ptrn\_openai\_app\_insights\_resource\_group\_name) | (Required) The name of the resource group in which to create the Application Insights component. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_insights_scope"></a> [ptrn\_openai\_app\_insights\_scope](#input\_ptrn\_openai\_app\_insights\_scope) | (Required) The scope for the Analytics Item. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_insights_type"></a> [ptrn\_openai\_app\_insights\_type](#input\_ptrn\_openai\_app\_insights\_type) | (Required) Specifies the type of Application Insights to create. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_insights_web_test"></a> [ptrn\_openai\_app\_insights\_web\_test](#input\_ptrn\_openai\_app\_insights\_web\_test) | (Optional) Define additional NSG rules | <pre>map(object({<br>    frequency           = number<br>    timeout             = number<br>    enabled             = string<br>    geo_locations       = list(string)<br>    test_method         = string<br>    test_url            = string<br>    test_response_code  = number<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_insights_web_test_kind"></a> [ptrn\_openai\_app\_insights\_web\_test\_kind](#input\_ptrn\_openai\_app\_insights\_web\_test\_kind) | (Required) The kind of web test that this web test watches. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service"></a> [ptrn\_openai\_app\_service](#input\_ptrn\_openai\_app\_service) | (Required) key value pairs for deploying diff flavors of cognitive service | <pre>map(object({<br>      ptrn_openai_app_service_always_on                    = bool<br>      ptrn_openai_app_service_app_postfix                  = string<br>      ptrn_openai_app_service_client_affinity_enabled     = bool<br>      ptrn_openai_app_service_is_linux_docker             = bool<br>      ptrn_openai_app_service_is_windows_docker           = bool<br>      ptrn_openai_app_service_linux_fx_version            = string<br>      ptrn_openai_app_service_scm_type                    = string<br>      ptrn_openai_app_service_windows_fx_version          = string<br>      ptrn_openai_app_service_settings                    = map(any)<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_service_acr_image"></a> [ptrn\_openai\_app\_service\_acr\_image](#input\_ptrn\_openai\_app\_service\_acr\_image) | (Optional) Is the Azure Container Registry image to be used. For example myapp:latest | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_acr_login_server"></a> [ptrn\_openai\_app\_service\_acr\_login\_server](#input\_ptrn\_openai\_app\_service\_acr\_login\_server) | (Optional) Is the Azure Container Registry server | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_acr_password"></a> [ptrn\_openai\_app\_service\_acr\_password](#input\_ptrn\_openai\_app\_service\_acr\_password) | (Optional) Is the Azure Container Registry password of the username to be used | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_acr_scm_type"></a> [ptrn\_openai\_app\_service\_acr\_scm\_type](#input\_ptrn\_openai\_app\_service\_acr\_scm\_type) | (Optional) Type of the source control enabled for this App Service using ACR. Defaults to VSTSRM | `string` | `"VSTSRM"` | no |
| <a name="input_ptrn_openai_app_service_acr_use_managed_identity_credentials"></a> [ptrn\_openai\_app\_service\_acr\_use\_managed\_identity\_credentials](#input\_ptrn\_openai\_app\_service\_acr\_use\_managed\_identity\_credentials) | (Optional) Are Managed Identity Credentials used for Azure Container Registry pull | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_acr_username"></a> [ptrn\_openai\_app\_service\_acr\_username](#input\_ptrn\_openai\_app\_service\_acr\_username) | (Optional) Is the Azure Container Registry username to access the repository | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_auth_settings_default_provider"></a> [ptrn\_openai\_app\_service\_auth\_settings\_default\_provider](#input\_ptrn\_openai\_app\_service\_auth\_settings\_default\_provider) | (Optional) The default provider to use when multiple providers have been set up. Possible values are AzureActiveDirectory, Facebook, Google, MicrosoftAccount and Twitter. | `string` | `"AzureActiveDirectory"` | no |
| <a name="input_ptrn_openai_app_service_auth_settings_enabled"></a> [ptrn\_openai\_app\_service\_auth\_settings\_enabled](#input\_ptrn\_openai\_app\_service\_auth\_settings\_enabled) | (Optional) Enable or disable Authentication Settings | `string` | `"false"` | no |
| <a name="input_ptrn_openai_app_service_auth_settings_unauthenticated_client_action"></a> [ptrn\_openai\_app\_service\_auth\_settings\_unauthenticated\_client\_action](#input\_ptrn\_openai\_app\_service\_auth\_settings\_unauthenticated\_client\_action) | (Optional) The action to take when an unauthenticated client attempts to access the app. Possible values are AllowAnonymous and RedirectToLoginPage. | `string` | `"AllowAnonymous"` | no |
| <a name="input_ptrn_openai_app_service_connection_strings"></a> [ptrn\_openai\_app\_service\_connection\_strings](#input\_ptrn\_openai\_app\_service\_connection\_strings) | (Optional) Connection strings for App Service. | <pre>map(object({<br>    name                  = string<br>    type                  = string<br>    value                 = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_service_cors_allowed_origins"></a> [ptrn\_openai\_app\_service\_cors\_allowed\_origins](#input\_ptrn\_openai\_app\_service\_cors\_allowed\_origins) | (Optional) A list of origins which should be able to make cross-origin calls. * can be used to allow all calls. | `list(string)` | <pre>[<br>  "*"<br>]</pre> | no |
| <a name="input_ptrn_openai_app_service_custom_domain_hostname"></a> [ptrn\_openai\_app\_service\_custom\_domain\_hostname](#input\_ptrn\_openai\_app\_service\_custom\_domain\_hostname) | (Optional) App service custom domain hostname. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_custom_domain_thumbprint"></a> [ptrn\_openai\_app\_service\_custom\_domain\_thumbprint](#input\_ptrn\_openai\_app\_service\_custom\_domain\_thumbprint) | (Optional) The app service custom domain thumbprint. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_default_documents"></a> [ptrn\_openai\_app\_service\_default\_documents](#input\_ptrn\_openai\_app\_service\_default\_documents) | (Optional) The ordering of default documents to load, if an address isn't specified. | `list` | `[]` | no |
| <a name="input_ptrn_openai_app_service_diagnostics"></a> [ptrn\_openai\_app\_service\_diagnostics](#input\_ptrn\_openai\_app\_service\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "AppServiceAntivirusScanAuditLogs",<br>    "AppServiceHTTPLogs",<br>    "AppServiceConsoleLogs",<br>    "AppServiceAppLogs",<br>    "AppServiceFileAuditLogs",<br>    "AppServiceAuditLogs",<br>    "AppServiceIPSecAuditLogs",<br>    "AppServicePlatformLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_app_service_dns_server"></a> [ptrn\_openai\_app\_service\_dns\_server](#input\_ptrn\_openai\_app\_service\_dns\_server) | (Required) Custom DNS service for app service routing. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_dotnet_framework_version"></a> [ptrn\_openai\_app\_service\_dotnet\_framework\_version](#input\_ptrn\_openai\_app\_service\_dotnet\_framework\_version) | (Optional) The version of the .net framework's CLR used in this App Service. | `string` | `"v5.0"` | no |
| <a name="input_ptrn_openai_app_service_ftps_state"></a> [ptrn\_openai\_app\_service\_ftps\_state](#input\_ptrn\_openai\_app\_service\_ftps\_state) | (Optional) State of FTP / FTPS service for this App Service. Possible values include: AllAllowed, FtpsOnly and Disabled. | `string` | `"FtpsOnly"` | no |
| <a name="input_ptrn_openai_app_service_health_check_path"></a> [ptrn\_openai\_app\_service\_health\_check\_path](#input\_ptrn\_openai\_app\_service\_health\_check\_path) | (Optional) The health check path to be pinged by App Service | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_http2_enabled"></a> [ptrn\_openai\_app\_service\_http2\_enabled](#input\_ptrn\_openai\_app\_service\_http2\_enabled) | (Optional) Is HTTP2 Enabled on this App Service? | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_https_only"></a> [ptrn\_openai\_app\_service\_https\_only](#input\_ptrn\_openai\_app\_service\_https\_only) | (Optional) Booolean to toggle if the App Service can only be accessed via HTTPS. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_identity_identity_ids"></a> [ptrn\_openai\_app\_service\_identity\_identity\_ids](#input\_ptrn\_openai\_app\_service\_identity\_identity\_ids) | (Required) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned. | `any` | `null` | no |
| <a name="input_ptrn_openai_app_service_identity_type"></a> [ptrn\_openai\_app\_service\_identity\_type](#input\_ptrn\_openai\_app\_service\_identity\_type) | (Required) Specifies the identity type of the App Service. Values are SystemAssigned or UserAssigned | `string` | `"SystemAssigned, UserAssigned"` | no |
| <a name="input_ptrn_openai_app_service_is_custom_domain_enable"></a> [ptrn\_openai\_app\_service\_is\_custom\_domain\_enable](#input\_ptrn\_openai\_app\_service\_is\_custom\_domain\_enable) | (Optional) Is the app service using a custom domain?. | `bool` | `false` | no |
| <a name="input_ptrn_openai_app_service_min_tls_version"></a> [ptrn\_openai\_app\_service\_min\_tls\_version](#input\_ptrn\_openai\_app\_service\_min\_tls\_version) | (Optional) The minimum supported TLS version for the app service | `string` | `"1.2"` | no |
| <a name="input_ptrn_openai_app_service_number_of_workers"></a> [ptrn\_openai\_app\_service\_number\_of\_workers](#input\_ptrn\_openai\_app\_service\_number\_of\_workers) | (Optional) The scaled number of workers (for per site scaling) of this App Service. | `number` | `1` | no |
| <a name="input_ptrn_openai_app_service_pe_subnet_ids"></a> [ptrn\_openai\_app\_service\_pe\_subnet\_ids](#input\_ptrn\_openai\_app\_service\_pe\_subnet\_ids) | (Required) private endpoint subnet ID for app service. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_app_service_plan_app_postfix"></a> [ptrn\_openai\_app\_service\_plan\_app\_postfix](#input\_ptrn\_openai\_app\_service\_plan\_app\_postfix) | (Required) The bespoke name of the app service plan you are deploying. | `string` | n/a | yes |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_default"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_default](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_default) | (Optional) The number of instances that are available for scaling if metrics are not available for evaluation. The default is only used if the current instance count is lower than the default. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_maximum"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_maximum](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_maximum) | (Optional) The maximum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `10` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_metric_name"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_metric\_name](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_metric\_name) | (Optional) The name of the metric that defines what the rule monitors. | `string` | `"CpuPercentage"` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_minimum"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_minimum](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_minimum) | (Optional) The minimum number of instances for this resource. Valid values are between 0 and 1000. | `number` | `1` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_scale_in_operator"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_in\_operator](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_in\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"LessThan"` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_scale_in_threshold"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_in\_threshold](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_in\_threshold) | (Optional) For scaling in only. Specifies the threshold of the metric that triggers the scale action. | `number` | `25` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_scale_out_operator"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_out\_operator](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_out\_operator) | (Optional) For scaling out only. Specifies the operator used to compare the metric data and threshold. Possible values are: Equals, NotEquals, GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual. | `string` | `"GreaterThan"` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_scale_out_threshold"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_out\_threshold](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_scale\_out\_threshold) | (Optional) For scaling out only. Specifies the threshold of the metric that triggers the scale action. | `number` | `75` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_statistic"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_statistic](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_statistic) | (Optional) Specifies how the metrics from multiple instances are combined. Possible values are Average, Min and Max. | `string` | `"Average"` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_time_aggregation"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_time\_aggregation](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_time\_aggregation) | (Optional) Specifies how the data that's collected should be combined over time. Possible values include Average, Count, Maximum, Minimum, Last and Total. | `string` | `"Average"` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_time_grain"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_time\_grain](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_time\_grain) | (Optional) Specifies the granularity of metrics that the rule monitors, which must be one of the pre-defined values returned from the metric definitions for the metric. This value must be between 1 minute and 12 hours an be formatted as an ISO 8601 string. | `string` | `"PT1M"` | no |
| <a name="input_ptrn_openai_app_service_plan_autoscale_settings_time_window"></a> [ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_time\_window](#input\_ptrn\_openai\_app\_service\_plan\_autoscale\_settings\_time\_window) | (Optional) Specifies the time range for which data is collected, which must be greater than the delay in metric collection (which varies from resource to resource). This value must be between 5 minutes and 12 hours and be formatted as an ISO 8601 string. | `string` | `"PT5M"` | no |
| <a name="input_ptrn_openai_app_service_plan_deploy_autoscale_settings"></a> [ptrn\_openai\_app\_service\_plan\_deploy\_autoscale\_settings](#input\_ptrn\_openai\_app\_service\_plan\_deploy\_autoscale\_settings) | (Optional) Choose to deploy autoscale settings or not. If the plan is serverless, this needs to be set to false | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_plan_deploy_integration_subnet"></a> [ptrn\_openai\_app\_service\_plan\_deploy\_integration\_subnet](#input\_ptrn\_openai\_app\_service\_plan\_deploy\_integration\_subnet) | (Required) A boolean that toggles the deployment of the vnet integration subnet. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_plan_deploy_rg"></a> [ptrn\_openai\_app\_service\_plan\_deploy\_rg](#input\_ptrn\_openai\_app\_service\_plan\_deploy\_rg) | (Optional) A boolean to enable/disable the deployment of a resource group for the App Service Plan. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_plan_diagnostics"></a> [ptrn\_openai\_app\_service\_plan\_diagnostics](#input\_ptrn\_openai\_app\_service\_plan\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_app_service_plan_int_subnet_user_defined_nsg_rules"></a> [ptrn\_openai\_app\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules](#input\_ptrn\_openai\_app\_service\_plan\_int\_subnet\_user\_defined\_nsg\_rules) | (Optional) A map of NSG rules for the integration subnet. | <pre>map(object({<br>        name                          = string<br>        priority                      = number<br>        direction                     = string<br>        access                        = string<br>        protocol                      = string<br>        source_port_range             = string<br>        source_port_ranges            = list(string)<br>        destination_port_range        = string<br>        destination_port_ranges       = list(string)    <br>        source_address_prefix         = string<br>        source_address_prefixes       = list(string)<br>        destination_address_prefix    = string<br>        destination_address_prefixes  = list(string)    <br>    }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_app_service_plan_integration_subnet_prefix"></a> [ptrn\_openai\_app\_service\_plan\_integration\_subnet\_prefix](#input\_ptrn\_openai\_app\_service\_plan\_integration\_subnet\_prefix) | (Required) The CIDR prefix for the app service subnet. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_plan_integration_subnet_service_endpoints"></a> [ptrn\_openai\_app\_service\_plan\_integration\_subnet\_service\_endpoints](#input\_ptrn\_openai\_app\_service\_plan\_integration\_subnet\_service\_endpoints) | (Optional) A list of service endpoints that is enabled in the subnet. cl\_app\_service\_plan\_deploy\_integration\_subnet needs to be set to true. | `list` | <pre>[<br>  "Microsoft.web",<br>  "Microsoft.ServiceBus",<br>  "Microsoft.Sql",<br>  "Microsoft.AzureCosmosDB",<br>  "Microsoft.EventHub",<br>  "Microsoft.Storage",<br>  "Microsoft.ContainerRegistry",<br>  "Microsoft.KeyVault",<br>  "Microsoft.CognitiveServices"<br>]</pre> | no |
| <a name="input_ptrn_openai_app_service_plan_kind"></a> [ptrn\_openai\_app\_service\_plan\_kind](#input\_ptrn\_openai\_app\_service\_plan\_kind) | (Required) The kind of the App Service Plan to create. Possible values are Windows (also available as App), Linux, elastic (for Premium Consumption) and FunctionApp (for a Consumption Plan). Defaults to Windows. Changing this forces a new resource to be created. | `string` | `"Linux"` | no |
| <a name="input_ptrn_openai_app_service_plan_max_elastic_workers"></a> [ptrn\_openai\_app\_service\_plan\_max\_elastic\_workers](#input\_ptrn\_openai\_app\_service\_plan\_max\_elastic\_workers) | (Optional) The maximum number of total workers allowed for this ElasticScaleEnabled App Service Plan. | `number` | `2` | no |
| <a name="input_ptrn_openai_app_service_plan_per_site_scaling"></a> [ptrn\_openai\_app\_service\_plan\_per\_site\_scaling](#input\_ptrn\_openai\_app\_service\_plan\_per\_site\_scaling) | (Optional) Can Apps assigned to this App Service Plan be scaled independently? If set to false apps assigned to this plan will scale to all instances of the plan. | `bool` | `false` | no |
| <a name="input_ptrn_openai_app_service_plan_reserved"></a> [ptrn\_openai\_app\_service\_plan\_reserved](#input\_ptrn\_openai\_app\_service\_plan\_reserved) | (Optional) Is this App Service Plan Reserved. This has to be false if the kind is Windows. | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_plan_rg_name"></a> [ptrn\_openai\_app\_service\_plan\_rg\_name](#input\_ptrn\_openai\_app\_service\_plan\_rg\_name) | (Optional) The name of the App Service Plan resource group if cl\_app\_service\_plan\_deploy\_rg = false. | `any` | `null` | no |
| <a name="input_ptrn_openai_app_service_plan_route_table_id"></a> [ptrn\_openai\_app\_service\_plan\_route\_table\_id](#input\_ptrn\_openai\_app\_service\_plan\_route\_table\_id) | (Optional) The ID of the route table that will be associated to the subnet | `string` | `""` | no |
| <a name="input_ptrn_openai_app_service_plan_sku_capacity"></a> [ptrn\_openai\_app\_service\_plan\_sku\_capacity](#input\_ptrn\_openai\_app\_service\_plan\_sku\_capacity) | (Optional) Specifies the number of workers associated with this App Service Plan. | `number` | `1` | no |
| <a name="input_ptrn_openai_app_service_plan_sku_size"></a> [ptrn\_openai\_app\_service\_plan\_sku\_size](#input\_ptrn\_openai\_app\_service\_plan\_sku\_size) | (Optional) Specifies the plan's instance size. | `string` | `"P3v2"` | no |
| <a name="input_ptrn_openai_app_service_plan_sku_tier"></a> [ptrn\_openai\_app\_service\_plan\_sku\_tier](#input\_ptrn\_openai\_app\_service\_plan\_sku\_tier) | (Optional) Specifies the plan's pricing tier. | `string` | `"PremiumV2"` | no |
| <a name="input_ptrn_openai_app_service_private_dns_zone_id"></a> [ptrn\_openai\_app\_service\_private\_dns\_zone\_id](#input\_ptrn\_openai\_app\_service\_private\_dns\_zone\_id) | (Required) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group when the private dns zone already exists. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_app_service_remote_debugging_enabled"></a> [ptrn\_openai\_app\_service\_remote\_debugging\_enabled](#input\_ptrn\_openai\_app\_service\_remote\_debugging\_enabled) | (Optional) Is Remote Debugging Enabled? | `bool` | `false` | no |
| <a name="input_ptrn_openai_app_service_remote_debugging_version"></a> [ptrn\_openai\_app\_service\_remote\_debugging\_version](#input\_ptrn\_openai\_app\_service\_remote\_debugging\_version) | (Optional) Which version of Visual Studio should the Remote Debugger be compatible with? | `string` | `"VS2017"` | no |
| <a name="input_ptrn_openai_app_service_support_cors_credentials"></a> [ptrn\_openai\_app\_service\_support\_cors\_credentials](#input\_ptrn\_openai\_app\_service\_support\_cors\_credentials) | (Optional) Are credentials supported?. | `bool` | `false` | no |
| <a name="input_ptrn_openai_app_service_use_32_bit_worker_process"></a> [ptrn\_openai\_app\_service\_use\_32\_bit\_worker\_process](#input\_ptrn\_openai\_app\_service\_use\_32\_bit\_worker\_process) | (Optional) Should the App Service run in 32 bit mode, rather than 64 bit mode? | `bool` | `true` | no |
| <a name="input_ptrn_openai_app_service_vnet_route_server"></a> [ptrn\_openai\_app\_service\_vnet\_route\_server](#input\_ptrn\_openai\_app\_service\_vnet\_route\_server) | (Optional) Should all outbound traffic to have Virtual Network Security Groups and User Defined Routes applied. | `number` | `1` | no |
| <a name="input_ptrn_openai_azure_container_registry_admin_enabled"></a> [ptrn\_openai\_azure\_container\_registry\_admin\_enabled](#input\_ptrn\_openai\_azure\_container\_registry\_admin\_enabled) | (Optional) Specifies whether the admin user is enabled. | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_container_registry_allowed_subnets"></a> [ptrn\_openai\_azure\_container\_registry\_allowed\_subnets](#input\_ptrn\_openai\_azure\_container\_registry\_allowed\_subnets) | (Required) One or more Subnet ID's which should be able to access this Container Registry. | `list(string)` | `null` | no |
| <a name="input_ptrn_openai_azure_container_registry_allowed_vnet_ids"></a> [ptrn\_openai\_azure\_container\_registry\_allowed\_vnet\_ids](#input\_ptrn\_openai\_azure\_container\_registry\_allowed\_vnet\_ids) | (Required) One or more VNET ID's which should be linked to the Private DNS Zone for ACR name resolution and access trough Private Endpoint. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_azure_container_registry_content_trust_enabled"></a> [ptrn\_openai\_azure\_container\_registry\_content\_trust\_enabled](#input\_ptrn\_openai\_azure\_container\_registry\_content\_trust\_enabled) | (Optional) Enables content trust for the sign of images being pushed to the registry | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_container_registry_diagnostics"></a> [ptrn\_openai\_azure\_container\_registry\_diagnostics](#input\_ptrn\_openai\_azure\_container\_registry\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ContainerRegistryRepositoryEvents",<br>    "ContainerRegistryLoginEvents"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_azure_container_registry_dns_zone_enabled"></a> [ptrn\_openai\_azure\_container\_registry\_dns\_zone\_enabled](#input\_ptrn\_openai\_azure\_container\_registry\_dns\_zone\_enabled) | (Optional) Enabled creation of acr dns private zone. | `bool` | `true` | no |
| <a name="input_ptrn_openai_azure_container_registry_dns_zone_name"></a> [ptrn\_openai\_azure\_container\_registry\_dns\_zone\_name](#input\_ptrn\_openai\_azure\_container\_registry\_dns\_zone\_name) | Is the private link to be associated with the Private DNS Zone. By default it uses recommended Private DNS Zone name | `string` | `"privatelink.azurecr.us"` | no |
| <a name="input_ptrn_openai_azure_container_registry_ip_rule_action"></a> [ptrn\_openai\_azure\_container\_registry\_ip\_rule\_action](#input\_ptrn\_openai\_azure\_container\_registry\_ip\_rule\_action) | (Optional) The action for the IP rule. | `string` | `"Allow"` | no |
| <a name="input_ptrn_openai_azure_container_registry_ip_rule_ranges"></a> [ptrn\_openai\_azure\_container\_registry\_ip\_rule\_ranges](#input\_ptrn\_openai\_azure\_container\_registry\_ip\_rule\_ranges) | (Optional) The CIDR range for the IP rule. | `list(string)` | <pre>[<br>  "199.206.0.0/15"<br>]</pre> | no |
| <a name="input_ptrn_openai_azure_container_registry_nacl_allowed_subnets"></a> [ptrn\_openai\_azure\_container\_registry\_nacl\_allowed\_subnets](#input\_ptrn\_openai\_azure\_container\_registry\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access the Azure Container Registry. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_container_registry_network_rule_set_default_action"></a> [ptrn\_openai\_azure\_container\_registry\_network\_rule\_set\_default\_action](#input\_ptrn\_openai\_azure\_container\_registry\_network\_rule\_set\_default\_action) | (Optional) The behaviour for requests matching no rules. Either Allow or Deny. Defaults to Deny | `string` | `"Deny"` | no |
| <a name="input_ptrn_openai_azure_container_registry_private_dns_zone_id"></a> [ptrn\_openai\_azure\_container\_registry\_private\_dns\_zone\_id](#input\_ptrn\_openai\_azure\_container\_registry\_private\_dns\_zone\_id) | (Required) existing Private Dns zone id for ACR | `string` | `null` | no |
| <a name="input_ptrn_openai_azure_container_registry_public_network_access_enabled"></a> [ptrn\_openai\_azure\_container\_registry\_public\_network\_access\_enabled](#input\_ptrn\_openai\_azure\_container\_registry\_public\_network\_access\_enabled) | (Optional) Whether public network access is allowed for the container registry. | `bool` | `true` | no |
| <a name="input_ptrn_openai_azure_container_registry_rg_name"></a> [ptrn\_openai\_azure\_container\_registry\_rg\_name](#input\_ptrn\_openai\_azure\_container\_registry\_rg\_name) | (Required) The resource group for the azure container registry. | `string` | `null` | no |
| <a name="input_ptrn_openai_azure_container_registry_sku"></a> [ptrn\_openai\_azure\_container\_registry\_sku](#input\_ptrn\_openai\_azure\_container\_registry\_sku) | (Required) Desire SKU for the Container Registry. Can be Basic, Standard or Premium. | `string` | `"Premium"` | no |
| <a name="input_ptrn_openai_azure_sql_database_LTR_week_of_year"></a> [ptrn\_openai\_azure\_sql\_database\_LTR\_week\_of\_year](#input\_ptrn\_openai\_azure\_sql\_database\_LTR\_week\_of\_year) | (Optional) The week of year to take the yearly backup in an ISO 8601 format. Value has to be between 1 and 52. | `number` | `1` | no |
| <a name="input_ptrn_openai_azure_sql_database_LTR_weekly_retention"></a> [ptrn\_openai\_azure\_sql\_database\_LTR\_weekly\_retention](#input\_ptrn\_openai\_azure\_sql\_database\_LTR\_weekly\_retention) | (Optional) The weekly retention policy for an LTR backup in an ISO 8601 format. Valid value is between 1 to 120 months. e.g. P1Y, P1M, P4W or P30D. | `string` | `"P1W"` | no |
| <a name="input_ptrn_openai_azure_sql_database_STR_retention"></a> [ptrn\_openai\_azure\_sql\_database\_STR\_retention](#input\_ptrn\_openai\_azure\_sql\_database\_STR\_retention) | (Required) Point In Time Restore configuration. Value has to be between 7 and 35. | `number` | `35` | no |
| <a name="input_ptrn_openai_azure_sql_database_audit_enabled"></a> [ptrn\_openai\_azure\_sql\_database\_audit\_enabled](#input\_ptrn\_openai\_azure\_sql\_database\_audit\_enabled) | (Optional) Boolean to enable sql db extended auditing policy resource creation | `bool` | `true` | no |
| <a name="input_ptrn_openai_azure_sql_database_audit_retention_days"></a> [ptrn\_openai\_azure\_sql\_database\_audit\_retention\_days](#input\_ptrn\_openai\_azure\_sql\_database\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `7` | no |
| <a name="input_ptrn_openai_azure_sql_database_collation"></a> [ptrn\_openai\_azure\_sql\_database\_collation](#input\_ptrn\_openai\_azure\_sql\_database\_collation) | (Optional) Specifies the collation of the database. Changing this forces a new resource to be created. | `string` | `"SQL_Latin1_General_CP1_CI_AS"` | no |
| <a name="input_ptrn_openai_azure_sql_database_create_mode"></a> [ptrn\_openai\_azure\_sql\_database\_create\_mode](#input\_ptrn\_openai\_azure\_sql\_database\_create\_mode) | (Optional) The create mode of the database. Possible values are Copy, Default, OnlineSecondary, PointInTimeRestore, Recovery, Restore, RestoreExternalBackup, RestoreExternalBackupSecondary, RestoreLongTermRetentionBackup and Secondary. | `string` | `"Default"` | no |
| <a name="input_ptrn_openai_azure_sql_database_diagnostics"></a> [ptrn\_openai\_azure\_sql\_database\_diagnostics](#input\_ptrn\_openai\_azure\_sql\_database\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "DevopsoperationsAuditLogs",<br>    "SQLSecurityAuditEvent"<br>  ],<br>  "metrics": [<br>    "Basic",<br>    "InstanceAndAppAdvanced",<br>    "WorkloadManagement"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_azure_sql_database_disabled_alerts"></a> [ptrn\_openai\_azure\_sql\_database\_disabled\_alerts](#input\_ptrn\_openai\_azure\_sql\_database\_disabled\_alerts) | (Optional) Specifies a list of alerts which should be disabled. Possible values include Access\_Anomaly, Sql\_Injection and Sql\_Injection\_Vulnerability. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_database_license"></a> [ptrn\_openai\_azure\_sql\_database\_license](#input\_ptrn\_openai\_azure\_sql\_database\_license) | (Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_ptrn_openai_azure_sql_database_postfix"></a> [ptrn\_openai\_azure\_sql\_database\_postfix](#input\_ptrn\_openai\_azure\_sql\_database\_postfix) | (Required) A string that is appended to the end of the database name to identify it. | `string` | `"sqldbopenai"` | no |
| <a name="input_ptrn_openai_azure_sql_database_read"></a> [ptrn\_openai\_azure\_sql\_database\_read](#input\_ptrn\_openai\_azure\_sql\_database\_read) | (Optional) If enabled, connections that have application intent set to readonly in their connection string may be routed to a readonly secondary replica. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_sql_database_redudant"></a> [ptrn\_openai\_azure\_sql\_database\_redudant](#input\_ptrn\_openai\_azure\_sql\_database\_redudant) | (Optional) Whether or not this database is zone redundant, which means the replicas of this database will be spread across multiple availability zones. This property is only settable for Premium and Business Critical databases. | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_sql_database_replica_count"></a> [ptrn\_openai\_azure\_sql\_database\_replica\_count](#input\_ptrn\_openai\_azure\_sql\_database\_replica\_count) | (Optional) The number of readonly secondary replicas associated with the database to which readonly application intent connections may be routed. This property is only settable for Hyperscale edition databases. | `number` | `null` | no |
| <a name="input_ptrn_openai_azure_sql_database_size"></a> [ptrn\_openai\_azure\_sql\_database\_size](#input\_ptrn\_openai\_azure\_sql\_database\_size) | (Optional) The max size of the database in gigabytes. | `number` | `1` | no |
| <a name="input_ptrn_openai_azure_sql_database_sku"></a> [ptrn\_openai\_azure\_sql\_database\_sku](#input\_ptrn\_openai\_azure\_sql\_database\_sku) | (Optional) Specifies the name of the sku used by the database. Changing this forces a new resource to be created. Single Database default value: BC\_Gen5\_2. If the database require be include in Elastic Pool group, in variable sku default value: ElasticPool. | `string` | `"BC_Gen5_2"` | no |
| <a name="input_ptrn_openai_azure_sql_database_threat_email_admins"></a> [ptrn\_openai\_azure\_sql\_database\_threat\_email\_admins](#input\_ptrn\_openai\_azure\_sql\_database\_threat\_email\_admins) | (Optional) Should the account administrators be emailed when this alert is triggered? | `string` | `"Disabled"` | no |
| <a name="input_ptrn_openai_azure_sql_database_threat_emails"></a> [ptrn\_openai\_azure\_sql\_database\_threat\_emails](#input\_ptrn\_openai\_azure\_sql\_database\_threat\_emails) | (Optional) A list of email addresses which alerts should be sent to. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_database_threat_logs_retention"></a> [ptrn\_openai\_azure\_sql\_database\_threat\_logs\_retention](#input\_ptrn\_openai\_azure\_sql\_database\_threat\_logs\_retention) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_ptrn_openai_azure_sql_database_threat_policy_state"></a> [ptrn\_openai\_azure\_sql\_database\_threat\_policy\_state](#input\_ptrn\_openai\_azure\_sql\_database\_threat\_policy\_state) | (Optional) The State of the Policy. Possible values are Enabled, Disabled or New. | `string` | `"Enabled"` | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_database_max_dtu_capacity"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_database\_max\_dtu\_capacity](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_database\_max\_dtu\_capacity) | (Optional) The maximum capacity any one database can consume in the Elastic Pool. Default to the max Elastic Pool capacity. | `string` | `"1"` | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_database_min_capacity"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_database\_min\_capacity](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_database\_min\_capacity) | (Optional) The minimum capacity all databases are guaranteed in the Elastic Pool. Defaults to 0. | `string` | `"0"` | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_diagnostic"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_diagnostic](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_diagnostic) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_enable"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_enable](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_enable) | (Required) Enable te creation for sql elastic pool | `bool` | `true` | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_license_type"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_license\_type](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_license\_type) | (Optional) Specifies the license type applied to this database. Possible values are LicenseIncluded and BasePrice. | `string` | `"BasePrice"` | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_max_size"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_max\_size](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_max\_size) | (Optional) Maximum size of the Elastic Pool in gigabytes | `string` | `"1024"` | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_postfix"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_postfix](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `string` | `"globaldb"` | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_sku"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_sku](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_sku) | (Optional) SKU for the Elastic Pool with tier and eDTUs capacity. Premium tier with zone redundancy is mandatory for high availability. Possible values for tier are Basic, Standard, or Premium. Example tier=Standard, capacity=50. See https://docs.microsoft.com/en-us/azure/sql-database/sql-database-dtu-resource-limits-elastic-pools | <pre>object({<br>    name     = string,<br>    tier     = string,<br>    family   = string,<br>    capacity = string<br>  })</pre> | <pre>{<br>  "capacity": "4",<br>  "family": "Gen5",<br>  "name": "BC_Gen5",<br>  "tier": "BusinessCritical"<br>}</pre> | no |
| <a name="input_ptrn_openai_azure_sql_elastic_pool_zone_redundant"></a> [ptrn\_openai\_azure\_sql\_elastic\_pool\_zone\_redundant](#input\_ptrn\_openai\_azure\_sql\_elastic\_pool\_zone\_redundant) | (Optional) Whether or not the Elastic Pool is zone redundant, SKU tier must be Premium to use it. This is mandatory for high availability. | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_sql_server_administrator"></a> [ptrn\_openai\_azure\_sql\_server\_administrator](#input\_ptrn\_openai\_azure\_sql\_server\_administrator) | (Required) The administrator login name for the new server. Changing this forces a new resource to be created. | `string` | `null` | no |
| <a name="input_ptrn_openai_azure_sql_server_alert_email_enabled"></a> [ptrn\_openai\_azure\_sql\_server\_alert\_email\_enabled](#input\_ptrn\_openai\_azure\_sql\_server\_alert\_email\_enabled) | (Optional) Boolean flag which specifies if the alert is sent to the account administrators or not. | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_sql_server_alert_emails"></a> [ptrn\_openai\_azure\_sql\_server\_alert\_emails](#input\_ptrn\_openai\_azure\_sql\_server\_alert\_emails) | (Optional) Specifies an array of e-mail addresses to which the alert is sent. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_alert_retention_days"></a> [ptrn\_openai\_azure\_sql\_server\_alert\_retention\_days](#input\_ptrn\_openai\_azure\_sql\_server\_alert\_retention\_days) | (Optional) Specifies the number of days to keep in the Threat Detection audit logs. | `number` | `7` | no |
| <a name="input_ptrn_openai_azure_sql_server_alert_state"></a> [ptrn\_openai\_azure\_sql\_server\_alert\_state](#input\_ptrn\_openai\_azure\_sql\_server\_alert\_state) | (Optional) Specifies the state of the policy, whether it is enabled or disabled or a policy has not been applied yet on the specific database server. Allowed values are: Disabled, Enabled. | `string` | `"Enabled"` | no |
| <a name="input_ptrn_openai_azure_sql_server_audit_enabled"></a> [ptrn\_openai\_azure\_sql\_server\_audit\_enabled](#input\_ptrn\_openai\_azure\_sql\_server\_audit\_enabled) | (Optional) Boolean to enable sql server extended auditing policy resource creation | `bool` | `true` | no |
| <a name="input_ptrn_openai_azure_sql_server_audit_retention_days"></a> [ptrn\_openai\_azure\_sql\_server\_audit\_retention\_days](#input\_ptrn\_openai\_azure\_sql\_server\_audit\_retention\_days) | (Optional) Specifies the number of days to retain logs for in the storage account. | `number` | `7` | no |
| <a name="input_ptrn_openai_azure_sql_server_azuread_login_username"></a> [ptrn\_openai\_azure\_sql\_server\_azuread\_login\_username](#input\_ptrn\_openai\_azure\_sql\_server\_azuread\_login\_username) | (Optional) The login username of the Azure AD Administrator of this SQL Server. | `string` | `null` | no |
| <a name="input_ptrn_openai_azure_sql_server_azuread_object_id"></a> [ptrn\_openai\_azure\_sql\_server\_azuread\_object\_id](#input\_ptrn\_openai\_azure\_sql\_server\_azuread\_object\_id) | (Optional) The object id of the Azure AD Administrator of this SQL Server. | `string` | `null` | no |
| <a name="input_ptrn_openai_azure_sql_server_connection_policy"></a> [ptrn\_openai\_azure\_sql\_server\_connection\_policy](#input\_ptrn\_openai\_azure\_sql\_server\_connection\_policy) | (Optional) The connection policy the server will use. Possible values are Default, Proxy, and Redirect. | `string` | `"Default"` | no |
| <a name="input_ptrn_openai_azure_sql_server_disabled_alerts"></a> [ptrn\_openai\_azure\_sql\_server\_disabled\_alerts](#input\_ptrn\_openai\_azure\_sql\_server\_disabled\_alerts) | (Optional) Specifies an array of alerts that are disabled. Allowed values are: Sql\_Injection, Sql\_Injection\_Vulnerability, Access\_Anomaly, Data\_Exfiltration, Unsafe\_Action. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_firewall_rules"></a> [ptrn\_openai\_azure\_sql\_server\_firewall\_rules](#input\_ptrn\_openai\_azure\_sql\_server\_firewall\_rules) | (Optional) Define additional firewall rules | <pre>map(object({<br>    start_ip                 = string<br>    end_ip                   = string<br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_azure_sql_server_log_analytics_solution"></a> [ptrn\_openai\_azure\_sql\_server\_log\_analytics\_solution](#input\_ptrn\_openai\_azure\_sql\_server\_log\_analytics\_solution) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureSQLAnalytics": {<br>    "product": "OMSGallery/AzureSQLAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_openai_azure_sql_server_nacl_allowed_subnets"></a> [ptrn\_openai\_azure\_sql\_server\_nacl\_allowed\_subnets](#input\_ptrn\_openai\_azure\_sql\_server\_nacl\_allowed\_subnets) | (Required) One or more Subnet ID's which should be able to access the Azure SQL Server. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_password"></a> [ptrn\_openai\_azure\_sql\_server\_password](#input\_ptrn\_openai\_azure\_sql\_server\_password) | (Required) The password associated with the cl\_azure\_sql\_server\_administrator user. | `string` | `null` | no |
| <a name="input_ptrn_openai_azure_sql_server_postfix"></a> [ptrn\_openai\_azure\_sql\_server\_postfix](#input\_ptrn\_openai\_azure\_sql\_server\_postfix) | (Required) A string that is appended to the end of the Azure SQL Server name to identify it. | `string` | `"sqlserveropenai"` | no |
| <a name="input_ptrn_openai_azure_sql_server_private_dns_zone_ids"></a> [ptrn\_openai\_azure\_sql\_server\_private\_dns\_zone\_ids](#input\_ptrn\_openai\_azure\_sql\_server\_private\_dns\_zone\_ids) | (Required) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. Resides as a centralized DNS zone within identity subscription. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_public_network_access"></a> [ptrn\_openai\_azure\_sql\_server\_public\_network\_access](#input\_ptrn\_openai\_azure\_sql\_server\_public\_network\_access) | (Optional) Whether or not public network access is allowed for this server. | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_sql_server_resource_group_name"></a> [ptrn\_openai\_azure\_sql\_server\_resource\_group\_name](#input\_ptrn\_openai\_azure\_sql\_server\_resource\_group\_name) | (Required) Specifies the Azure SQL Server resource group | `string` | `""` | no |
| <a name="input_ptrn_openai_azure_sql_server_security_email_subscription"></a> [ptrn\_openai\_azure\_sql\_server\_security\_email\_subscription](#input\_ptrn\_openai\_azure\_sql\_server\_security\_email\_subscription) | (Optional) Boolean flag which specifies if the schedule scan notification will be sent to the subscription administrators. | `bool` | `false` | no |
| <a name="input_ptrn_openai_azure_sql_server_security_emails"></a> [ptrn\_openai\_azure\_sql\_server\_security\_emails](#input\_ptrn\_openai\_azure\_sql\_server\_security\_emails) | (Optional) Specifies an array of e-mail addresses to which the scan notification is sent. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_security_scans"></a> [ptrn\_openai\_azure\_sql\_server\_security\_scans](#input\_ptrn\_openai\_azure\_sql\_server\_security\_scans) | (Optional) Boolean flag which specifies if recurring scans is enabled or disabled. | `bool` | `true` | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_blob_retention_days"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_blob\_retention\_days](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_blob\_retention\_days) | (Optional) Specifies the number of days that the blob should be retained. | `number` | `365` | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_bypass"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_bypass](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_bypass) | (Optional) Specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Valid options are any combination of Logging, Metrics, AzureServices, or None. | `list(string)` | <pre>[<br>  "None"<br>]</pre> | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_diagnostics"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_diagnostics](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_ip_rules"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_ip\_rules](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_ip\_rules) | (Required) List of public IP or IP ranges in CIDR Format. Only IPV4 addresses are allowed. Private IP address ranges (as defined in RFC 1918) are not allowed. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_network_default_action"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_network\_default\_action](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_network\_default\_action) | (Required) Specifies the default action of allow or deny when no other rules match. Valid options are Deny or Allow. | `string` | `"Deny"` | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_pe\_subnet\_ids](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_pe\_subnet\_ids) | (Required)  A list of subnet IDs the app service will create a private endpoint in. | `list` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_private\_dns\_zone\_ids](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_private\_dns\_zone\_ids) | (Required)  Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_subnet_ids"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_subnet\_ids](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_subnet\_ids) | (Required) A list of resource ids for subnets. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_storage_account_tier"></a> [ptrn\_openai\_azure\_sql\_server\_storage\_account\_tier](#input\_ptrn\_openai\_azure\_sql\_server\_storage\_account\_tier) | (Optional) The pricing tier for the storage account for Azure SQL server audit and security logging. | `string` | `"Standard"` | no |
| <a name="input_ptrn_openai_azure_sql_server_tls"></a> [ptrn\_openai\_azure\_sql\_server\_tls](#input\_ptrn\_openai\_azure\_sql\_server\_tls) | (Optional) The Minimum TLS Version for all SQL Database and SQL Data Warehouse databases associated with the server. Valid values are: 1.0, 1.1 and 1.2. | `string` | `"1.2"` | no |
| <a name="input_ptrn_openai_azure_sql_server_version"></a> [ptrn\_openai\_azure\_sql\_server\_version](#input\_ptrn\_openai\_azure\_sql\_server\_version) | (Optional) The version for the new server. Valid values are: 2.0 (for v11 server) and 12.0 (for v12 server). | `string` | `"12.0"` | no |
| <a name="input_ptrn_openai_azure_sql_server_vnet_rules"></a> [ptrn\_openai\_azure\_sql\_server\_vnet\_rules](#input\_ptrn\_openai\_azure\_sql\_server\_vnet\_rules) | (Required) Define additional virtual network rules | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_azure_sql_server_vulnerability_enabled"></a> [ptrn\_openai\_azure\_sql\_server\_vulnerability\_enabled](#input\_ptrn\_openai\_azure\_sql\_server\_vulnerability\_enabled) | n/a | `bool` | `true` | no |
| <a name="input_ptrn_openai_azure_storage_account_secondary_access_key"></a> [ptrn\_openai\_azure\_storage\_account\_secondary\_access\_key](#input\_ptrn\_openai\_azure\_storage\_account\_secondary\_access\_key) | (Optional) Specifies whether cl\_azure\_storage\_account\_access\_key value is the storage's secondary key. | `bool` | `false` | no |
| <a name="input_ptrn_openai_cl_cognitive_services_deploy_rg"></a> [ptrn\_openai\_cl\_cognitive\_services\_deploy\_rg](#input\_ptrn\_openai\_cl\_cognitive\_services\_deploy\_rg) | (Required) set to true to deploy dedicated resource group for cog services. | `bool` | `true` | no |
| <a name="input_ptrn_openai_cl_cognitive_services_nacl_allowed_subnets"></a> [ptrn\_openai\_cl\_cognitive\_services\_nacl\_allowed\_subnets](#input\_ptrn\_openai\_cl\_cognitive\_services\_nacl\_allowed\_subnets) | (Required) One or more Subnet ID's in which Azure cognitive services private endpoint should be created | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges"></a> [ptrn\_openai\_cl\_cognitive\_services\_nacls\_allowed\_ip\_ranges](#input\_ptrn\_openai\_cl\_cognitive\_services\_nacls\_allowed\_ip\_ranges) | (Required) One or more IP Addresses, or CIDR Blocks which should be able to access the Cognitive Account. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids"></a> [ptrn\_openai\_cl\_cognitive\_services\_nacls\_virtual\_network\_subnet\_ids](#input\_ptrn\_openai\_cl\_cognitive\_services\_nacls\_virtual\_network\_subnet\_ids) | (Required) The ID of the subnet which should be able to access this Cognitive Account. | `string` | `""` | no |
| <a name="input_ptrn_openai_cl_cognitive_services_openai"></a> [ptrn\_openai\_cl\_cognitive\_services\_openai](#input\_ptrn\_openai\_cl\_cognitive\_services\_openai) | ********************************************************************************************** Cognitive Search Variables ********************************************************************************************** Required | <pre>map(object({<br>    cog_service_postfix = string<br>    kind                = string<br>    sku                 = string<br>  }))</pre> | <pre>{<br>  "openai": {<br>    "cog_service_postfix": "openai",<br>    "kind": "OpenAI",<br>    "sku": "S0"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_openai_cl_cognitive_services_pe_rg_name"></a> [ptrn\_openai\_cl\_cognitive\_services\_pe\_rg\_name](#input\_ptrn\_openai\_cl\_cognitive\_services\_pe\_rg\_name) | (Required) pass in pre-existing resource group name. | `string` | `null` | no |
| <a name="input_ptrn_openai_cl_cognitive_services_private_dns_zone_ids"></a> [ptrn\_openai\_cl\_cognitive\_services\_private\_dns\_zone\_ids](#input\_ptrn\_openai\_cl\_cognitive\_services\_private\_dns\_zone\_ids) | (Required) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_cl_cognitive_services_public_network_access_enabled"></a> [ptrn\_openai\_cl\_cognitive\_services\_public\_network\_access\_enabled](#input\_ptrn\_openai\_cl\_cognitive\_services\_public\_network\_access\_enabled) | (Optional) set to true to enable public network access on cog service. | `bool` | `false` | no |
| <a name="input_ptrn_openai_cl_cognitive_services_rg_name"></a> [ptrn\_openai\_cl\_cognitive\_services\_rg\_name](#input\_ptrn\_openai\_cl\_cognitive\_services\_rg\_name) | (Required) resource group name of cognitive service | `string` | `""` | no |
| <a name="input_ptrn_openai_cl_redis_cache_enable"></a> [ptrn\_openai\_cl\_redis\_cache\_enable](#input\_ptrn\_openai\_cl\_redis\_cache\_enable) | Enable/disabled creation module Redis Cache | `bool` | `false` | no |
| <a name="input_ptrn_openai_cl_redis_cache_log_analytics_workspace_id"></a> [ptrn\_openai\_cl\_redis\_cache\_log\_analytics\_workspace\_id](#input\_ptrn\_openai\_cl\_redis\_cache\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `string` | `""` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_cluster_enable"></a> [ptrn\_openai\_cl\_redis\_enterprise\_cluster\_enable](#input\_ptrn\_openai\_cl\_redis\_enterprise\_cluster\_enable) | Enable/disabled creation module Redis Cache enterprise | `bool` | `false` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_cluster_private_dns_zone_ids"></a> [ptrn\_openai\_cl\_redis\_enterprise\_cluster\_private\_dns\_zone\_ids](#input\_ptrn\_openai\_cl\_redis\_enterprise\_cluster\_private\_dns\_zone\_ids) | (Optional) Specifies the list of Private DNS Zones to include within the private\_dns\_zone\_group. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_cluster_resource_group_name"></a> [ptrn\_openai\_cl\_redis\_enterprise\_cluster\_resource\_group\_name](#input\_ptrn\_openai\_cl\_redis\_enterprise\_cluster\_resource\_group\_name) | (Required) The name of the Resource Group where the Redis Enterprise Cluster should exist. Changing this forces a new Redis Enterprise Cluster to be created. | `string` | `""` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_cluster_sku_name"></a> [ptrn\_openai\_cl\_redis\_enterprise\_cluster\_sku\_name](#input\_ptrn\_openai\_cl\_redis\_enterprise\_cluster\_sku\_name) | (Required) The sku\_name is comprised of two segments separated by a hyphen (e.g. Enterprise\_E10-2). | `string` | `""` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_cluster_subnet"></a> [ptrn\_openai\_cl\_redis\_enterprise\_cluster\_subnet](#input\_ptrn\_openai\_cl\_redis\_enterprise\_cluster\_subnet) | (Required) The name of subnet which should be used for the Redis cluster private endpoint | `string` | `""` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_database_eviction_policy"></a> [ptrn\_openai\_cl\_redis\_enterprise\_database\_eviction\_policy](#input\_ptrn\_openai\_cl\_redis\_enterprise\_database\_eviction\_policy) | (Optional) Redis eviction policy - default is VolatileLRU. Possible values are AllKeysLFU, AllKeysLRU, AllKeysRandom, VolatileLRU, VolatileLFU, VolatileTTL, VolatileRandom and NoEviction. | `string` | `"VolatileLRU"` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_database_linked_database_group_nickname"></a> [ptrn\_openai\_cl\_redis\_enterprise\_database\_linked\_database\_group\_nickname](#input\_ptrn\_openai\_cl\_redis\_enterprise\_database\_linked\_database\_group\_nickname) | (Optional) Nickname of the group of linked databases. Changing this force a new Redis Enterprise Geo Database to be created. | `string` | `""` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_database_linked_database_id"></a> [ptrn\_openai\_cl\_redis\_enterprise\_database\_linked\_database\_id](#input\_ptrn\_openai\_cl\_redis\_enterprise\_database\_linked\_database\_id) | (Optional) A list of database resources to link with this database with a maximum of 5. | `list(string)` | `[]` | no |
| <a name="input_ptrn_openai_cl_redis_enterprise_database_module_name"></a> [ptrn\_openai\_cl\_redis\_enterprise\_database\_module\_name](#input\_ptrn\_openai\_cl\_redis\_enterprise\_database\_module\_name) | (Required) The name which should be used for this module. Possible values are RedisBloom, RedisTimeSeries, RediSearch and RedisJSON | `string` | `null` | no |
| <a name="input_ptrn_openai_core_log_analytics_workspace_name"></a> [ptrn\_openai\_core\_log\_analytics\_workspace\_name](#input\_ptrn\_openai\_core\_log\_analytics\_workspace\_name) | (Required) The name of the log analytics workspace. | `string` | `null` | no |
| <a name="input_ptrn_openai_core_log_analytics_workspace_resource_id"></a> [ptrn\_openai\_core\_log\_analytics\_workspace\_resource\_id](#input\_ptrn\_openai\_core\_log\_analytics\_workspace\_resource\_id) | (Required) Spoke log analytics workspace ID. | `string` | `""` | no |
| <a name="input_ptrn_openai_core_rg_data_name"></a> [ptrn\_openai\_core\_rg\_data\_name](#input\_ptrn\_openai\_core\_rg\_data\_name) | (Required) The name of the resource group where the api management will be deployed to. | `string` | `""` | no |
| <a name="input_ptrn_openai_core_rg_logging_name"></a> [ptrn\_openai\_core\_rg\_logging\_name](#input\_ptrn\_openai\_core\_rg\_logging\_name) | (Required) The resource group for the log analytics workspace. | `string` | `null` | no |
| <a name="input_ptrn_openai_core_rg_network_name"></a> [ptrn\_openai\_core\_rg\_network\_name](#input\_ptrn\_openai\_core\_rg\_network\_name) | (Required) name of network resource group | `string` | `""` | no |
| <a name="input_ptrn_openai_core_route_table_id"></a> [ptrn\_openai\_core\_route\_table\_id](#input\_ptrn\_openai\_core\_route\_table\_id) | (Required) The route\_table id allowed to connect to this API Mgmt. | `string` | `""` | no |
| <a name="input_ptrn_openai_core_vnet_name"></a> [ptrn\_openai\_core\_vnet\_name](#input\_ptrn\_openai\_core\_vnet\_name) | (Required) name of virtual network. | `string` | `""` | no |
| <a name="input_ptrn_openai_deploy_app_gateway"></a> [ptrn\_openai\_deploy\_app\_gateway](#input\_ptrn\_openai\_deploy\_app\_gateway) | (Required) deploy or not application gateway | `bool` | `true` | no |
| <a name="input_ptrn_openai_deploy_azure_sql_database"></a> [ptrn\_openai\_deploy\_azure\_sql\_database](#input\_ptrn\_openai\_deploy\_azure\_sql\_database) | (Required) A boolean to enable/disable the deployment of a  azure SQL DB in azure openai service pattern. | `bool` | `true` | no |
| <a name="input_ptrn_openai_deploy_azure_sql_server"></a> [ptrn\_openai\_deploy\_azure\_sql\_server](#input\_ptrn\_openai\_deploy\_azure\_sql\_server) | (Optional) A boolean to enable/disable the deployment of a  azure SQL in azure openai service pattern. | `bool` | `true` | no |
| <a name="input_ptrn_openai_deploy_container_registry"></a> [ptrn\_openai\_deploy\_container\_registry](#input\_ptrn\_openai\_deploy\_container\_registry) | (Required) set to true to enable the creation for ACR | `bool` | `true` | no |
| <a name="input_ptrn_openai_private_endpoint_subresource_names"></a> [ptrn\_openai\_private\_endpoint\_subresource\_names](#input\_ptrn\_openai\_private\_endpoint\_subresource\_names) | (Optional) A list of subresources to be included in the private endpoint. | `list(string)` | <pre>[<br>  "sqlServer"<br>]</pre> | no |
| <a name="input_ptrn_openai_set_private_ip_listener"></a> [ptrn\_openai\_set\_private\_ip\_listener](#input\_ptrn\_openai\_set\_private\_ip\_listener) | (Optional) A boolean variable indicating which environment the app gateway is being deployed into. | `bool` | `true` | no |
| <a name="input_ptrn_openai_storage_account_allowed_ips"></a> [ptrn\_openai\_storage\_account\_allowed\_ips](#input\_ptrn\_openai\_storage\_account\_allowed\_ips) | (Optional) A list of ips that can access the storage account. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_storage_account_allowed_pe_subnet_ids"></a> [ptrn\_openai\_storage\_account\_allowed\_pe\_subnet\_ids](#input\_ptrn\_openai\_storage\_account\_allowed\_pe\_subnet\_ids) | (Optional) A list of subnets to create a Private endpoint that can access the storage account. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_storage_account_allowed_vnet_subnet_ids"></a> [ptrn\_openai\_storage\_account\_allowed\_vnet\_subnet\_ids](#input\_ptrn\_openai\_storage\_account\_allowed\_vnet\_subnet\_ids) | (Optional) A list of subnets that can access the storage account. | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_storage_account_backup_policy_fileshare_id"></a> [ptrn\_openai\_storage\_account\_backup\_policy\_fileshare\_id](#input\_ptrn\_openai\_storage\_account\_backup\_policy\_fileshare\_id) | (Optional) The azure file share backup policy from the recovery service vault. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_blob_backup_policy_id"></a> [ptrn\_openai\_storage\_account\_blob\_backup\_policy\_id](#input\_ptrn\_openai\_storage\_account\_blob\_backup\_policy\_id) | (Optional) The azure blob storage backup policy id from the backup vault. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_blob_backup_vault"></a> [ptrn\_openai\_storage\_account\_blob\_backup\_vault](#input\_ptrn\_openai\_storage\_account\_blob\_backup\_vault) | (Optional) The blob storage backup vault. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_blob_backup_vault_id"></a> [ptrn\_openai\_storage\_account\_blob\_backup\_vault\_id](#input\_ptrn\_openai\_storage\_account\_blob\_backup\_vault\_id) | (Optional) The id of blob storage backup vault. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_default_to_oauth_authentication"></a> [ptrn\_openai\_storage\_account\_default\_to\_oauth\_authentication](#input\_ptrn\_openai\_storage\_account\_default\_to\_oauth\_authentication) | (Optional) Default to Azure Active Directory authorization in the Azure portal when accessing the Storage Account. The default value is false | `bool` | `true` | no |
| <a name="input_ptrn_openai_storage_account_env"></a> [ptrn\_openai\_storage\_account\_env](#input\_ptrn\_openai\_storage\_account\_env) | (required) core env used to deploy tf storage acct. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_key"></a> [ptrn\_openai\_storage\_account\_key](#input\_ptrn\_openai\_storage\_account\_key) | blob storage account key and values | <pre>map(object({<br>   ptrn_openai_storage_account_private_dns_zone_ids = list(string)<br>   ptrn_openai_storage_account_blob_enable_backup = bool<br>   ptrn_openai_storage_account_share_enabled      = bool<br>   ptrn_openai_storage_account_queue_enabled      = bool<br>   ptrn_openai_storage_account_file_shares        = map(any)<br>   ptrn_openai_storage_account_file_enable_backup = bool<br>   ptrn_openai_storage_account_large_file_share = bool  <br>   ptrn_openai_storage_account_queues           = list(string)<br>   ptrn_openai_storage_account_tier             = string<br>   ptrn_openai_storage_account_kind             = string<br>    }))</pre> | `{}` | no |
| <a name="input_ptrn_openai_storage_account_log_analytics_workspace_id"></a> [ptrn\_openai\_storage\_account\_log\_analytics\_workspace\_id](#input\_ptrn\_openai\_storage\_account\_log\_analytics\_workspace\_id) | (Required) The the log analytics workspace ID for diagnostics. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_postfix"></a> [ptrn\_openai\_storage\_account\_postfix](#input\_ptrn\_openai\_storage\_account\_postfix) | (required) core postfix used to deploy tf storage acct. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_private_dns_zone_ids"></a> [ptrn\_openai\_storage\_account\_private\_dns\_zone\_ids](#input\_ptrn\_openai\_storage\_account\_private\_dns\_zone\_ids) | n/a | `list(string)` | <pre>[<br>  ""<br>]</pre> | no |
| <a name="input_ptrn_openai_storage_account_recovery_vault_name"></a> [ptrn\_openai\_storage\_account\_recovery\_vault\_name](#input\_ptrn\_openai\_storage\_account\_recovery\_vault\_name) | (Optional) The name of backup recovery service vault. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_resource_group_name"></a> [ptrn\_openai\_storage\_account\_resource\_group\_name](#input\_ptrn\_openai\_storage\_account\_resource\_group\_name) | (Required) The name of the resource group where the storage account will be deployed to. | `string` | `""` | no |
| <a name="input_ptrn_openai_storage_account_rg_backup_name"></a> [ptrn\_openai\_storage\_account\_rg\_backup\_name](#input\_ptrn\_openai\_storage\_account\_rg\_backup\_name) | (Optional) The RG destination of the azure file share backup. | `string` | `""` | no |
| <a name="input_ptrn_openai_tfstate_select_access"></a> [ptrn\_openai\_tfstate\_select\_access](#input\_ptrn\_openai\_tfstate\_select\_access) | (Optional) Specifies the default action for selected nmtwork access on remote state storage acct. | `bool` | `true` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | (Optional) A mapping of tags to assign to all resources. | `map` | `{}` | no |

locals {
  timeout_duration = "2h"
}

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cl_api_mgmt"></a> [cl\_api\_mgmt](#output\_cl\_api\_mgmt) | n/a |
| <a name="output_cl_app_gateway"></a> [cl\_app\_gateway](#output\_cl\_app\_gateway) | n/a |
| <a name="output_cl_app_insights"></a> [cl\_app\_insights](#output\_cl\_app\_insights) | n/a |
| <a name="output_cl_app_service"></a> [cl\_app\_service](#output\_cl\_app\_service) | n/a |
| <a name="output_cl_app_service_plan"></a> [cl\_app\_service\_plan](#output\_cl\_app\_service\_plan) | n/a |
| <a name="output_cl_azure_container_registry"></a> [cl\_azure\_container\_registry](#output\_cl\_azure\_container\_registry) | n/a |
| <a name="output_cl_azure_sql_database"></a> [cl\_azure\_sql\_database](#output\_cl\_azure\_sql\_database) | n/a |
| <a name="output_cl_azure_sql_elastic_pool"></a> [cl\_azure\_sql\_elastic\_pool](#output\_cl\_azure\_sql\_elastic\_pool) | n/a |
| <a name="output_cl_azure_sql_server"></a> [cl\_azure\_sql\_server](#output\_cl\_azure\_sql\_server) | n/a |
| <a name="output_cl_cognitive_services_openai"></a> [cl\_cognitive\_services\_openai](#output\_cl\_cognitive\_services\_openai) | n/a |
| <a name="output_cl_web_application_firewall_policy"></a> [cl\_web\_application\_firewall\_policy](#output\_cl\_web\_application\_firewall\_policy) | n/a |

## Usage
```terraform
//**********************************************************************************************
module "core_openai_ptrn" {
    source                                                                              = "../dn-tads_tf-azure-component-library/patterns/ptrn_openai"
    env                                                                                 = var.env
    postfix                                                                             = var.postfix
    location                                                                            = var.location
    tags                                                                                = var.tags

# Container Registry
    ptrn_openai_deploy_container_registry                                               = true
    ptrn_openai_azure_container_registry_ip_rule_ranges                                 = var.ptrn_openai_azure_container_registry_ip_rule_ranges
    ptrn_openai_azure_container_registry_private_dns_zone_id                            = var.ptrn_openai_azure_container_registry_private_dns_zone_id
    ptrn_openai_azure_container_registry_allowed_vnet_ids                               = var.ptrn_openai_azure_container_registry_allowed_vnet_ids
    ptrn_openai_ptrn_privatelink_subnet                                                 = var.ptrn_openai_ptrn_privatelink_subnet
    ptrn_openai_core_log_analytics_workspace_resource_id                                = var.ptrn_openai_core_log_analytics_workspace_resource_id
    ptrn_openai_core_log_analytics_workspace_name                                       = var.ptrn_openai_core_log_analytics_workspace_name

# cognitive services
    ptrn_openai_cl_cognitive_services_openai                                            = var.ptrn_openai_cl_cognitive_services_openai
    ptrn_openai_cl_cognitive_services_deploy_rg                                         = true
    ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids                  = var.ptrn_openai_cl_cognitive_services_nacls_virtual_network_subnet_ids
    ptrn_openai_cl_cognitive_services_nacl_allowed_subnets                              = var.ptrn_openai_cl_cognitive_services_nacl_allowed_subnets
    ptrn_openai_cl_cognitive_services_private_dns_zone_ids                              = var.ptrn_openai_cl_cognitive_services_private_dns_zone_ids
    ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges                           = var.ptrn_openai_cl_cognitive_services_nacls_allowed_ip_ranges

# App service Plan
    ptrn_openai_app_service_plan_deploy_rg                                              = var.ptrn_openai_app_service_plan_deploy_rg
    ptrn_openai_app_service_plan_reserved                                               = var.ptrn_openai_app_service_plan_reserved
    ptrn_openai_app_service_plan_kind                                                   = var.ptrn_openai_app_service_plan_kind
    ptrn_openai_app_service_plan_deploy_integration_subnet                              = var.ptrn_openai_app_service_plan_deploy_integration_subnet
    ptrn_openai_core_rg_network_name                                                    = var.ptrn_openai_core_rg_network_name
    ptrn_openai_core_vnet_name                                                          = var.ptrn_openai_core_vnet_name
    ptrn_openai_app_service_plan_integration_subnet_prefix                              = var.ptrn_openai_app_service_plan_integration_subnet_prefix
    ptrn_openai_app_service_plan_route_table_id                                         = var.ptrn_openai_app_service_plan_route_table_id
    ptrn_openai_app_service_plan_sku_tier                                               = var.ptrn_openai_app_service_plan_sku_tier
    ptrn_openai_app_service_plan_sku_size                                               = var.ptrn_openai_app_service_plan_sku_size
    ptrn_openai_app_service_plan_sku_capacity                                           = var.ptrn_openai_app_service_plan_sku_capacity
    ptrn_openai_app_service_plan_app_postfix                                            = var.ptrn_openai_app_service_plan_app_postfix

# App Service 
    ptrn_openai_app_service                                                                 = var.ptrn_openai_app_service
    ptrn_openai_app_service_pe_subnet_ids                                                   = var.ptrn_openai_app_service_pe_subnet_ids
    ptrn_openai_app_service_settings                                                        = var.ptrn_openai_app_service_settings
    ptrn_openai_app_service_identity_identity_ids                                           = var.ptrn_openai_app_service_identity_identity_ids
    ptrn_openai_app_service_private_dns_zone_id                                             = var.ptrn_openai_app_service_private_dns_zone_id
    ptrn_openai_app_service_acr_login_server                                                = var.ptrn_openai_app_service_acr_login_server
    ptrn_openai_app_service_acr_username                                                    = var.ptrn_openai_app_service_acr_username
    ptrn_openai_app_service_acr_password                                                    = var.ptrn_openai_app_service_acr_password
    ptrn_openai_app_service_acr_image                                                       = var.ptrn_openai_app_service_acr_image
    ptrn_openai_app_service_acr_scm_type                                                    = var.ptrn_openai_app_service_acr_scm_type
    ptrn_openai_app_service_dns_server                                                      = var.ptrn_openai_app_service_dns_server
    ptrn_openai_app_service_vnet_route_server                                               = var.ptrn_openai_app_service_vnet_route_server
    ptrn_openai_app_service_auth_settings_default_provider                                  = var.ptrn_openai_app_service_auth_settings_default_provider

# App Gateway
    ptrn_openai_app_gateway_rg_name                                                         = var.ptrn_openai_app_gateway_rg_name
    ptrn_openai_core_rg_logging_name                                                        = var.ptrn_openai_core_rg_logging_name
    ptrn_openai_app_gateway_subnet_address_prefix                                           = var.ptrn_openai_app_gateway_subnet_address_prefix
    ptrn_openai_app_gateway_frontend_tls_cert                                                      = var.ptrn_openai_app_gateway_frontend_tls_cert
    ptrn_openai_app_gateway_frontend_tls_cert_pass                                                 = var.ptrn_openai_app_gateway_frontend_tls_cert_pass
    ptrn_openai_app_gateway_backend_address                                                        = var.ptrn_openai_app_gateway_backend_address
    ptrn_openai_app_gateway_backend_host_name                                                      = var.ptrn_openai_app_gateway_backend_host_name
    ptrn_openai_app_gateway_https_listener_hostname                                                = var.ptrn_openai_app_gateway_https_listener_hostname
    ptrn_openai_app_gateway_pick_host_name                                                         = var.ptrn_openai_app_gateway_pick_host_name
    ptrn_openai_app_gateway_pick_host_backend                                                      = var.ptrn_openai_app_gateway_pick_host_backend
      ptrn_openai_app_gateway_subnet_hostnum                                                       = var.ptrn_openai_app_gateway_subnet_hostnum
      ptrn_openai_app_gateway_min_capacity                                                         = var.ptrn_openai_app_gateway_min_capacity
      ptrn_openai_app_gateway_max_capacity                                                         = var.ptrn_openai_app_gateway_max_capacity
      ptrn_openai_app_gateway_probe_name                                                           = var.ptrn_openai_app_gateway_probe_name
      ptrn_openai_app_gateway_probe_host                                                           = var.ptrn_openai_app_gateway_probe_host
      ptrn_openai_app_gateway_probe_path                                                           = var.ptrn_openai_app_gateway_probe_path
      ptrn_openai_app_gateway_nsg_rules                                                            = var.ptrn_openai_app_gateway_nsg_rules
      ptrn_openai_app_gateway_probe_status_code                                                    = var.ptrn_openai_app_gateway_probe_status_code
      ptrn_openai_app_gateway_additional_backend_address_pool                                      = var.ptrn_openai_app_gateway_additional_backend_address_pool
      ptrn_openai_app_gateway_additional_http_settings                                             = var.ptrn_openai_app_gateway_additional_http_settings
      ptrn_openai_app_gateway_additional_http_listener                                             = var.ptrn_openai_app_gateway_additional_http_listener
      ptrn_openai_app_gateway_additional_route_rules                                               = var.ptrn_openai_app_gateway_additional_route_rules
      ptrn_openai_app_gateway_storage_account_nsg_flow_log_id                                      = var.ptrn_openai_app_gateway_storage_account_nsg_flow_log_id
      ptrn_openai_app_gateway_nsg_flow_log_postfix                                                 = var.ptrn_openai_app_gateway_nsg_flow_log_postfix

# SQL SERVER

  ptrn_openai_azure_sql_server_postfix                                                  = var.ptrn_openai_azure_sql_server_postfix
  ptrn_openai_azure_sql_server_resource_group_name                                      = var.ptrn_openai_azure_sql_server_resource_group_name
  ptrn_openai_azure_sql_server_administrator                                            = var.ptrn_openai_azure_sql_server_administrator
  ptrn_openai_azure_sql_server_password                                                 = var.ptrn_openai_azure_sql_server_password
  ptrn_openai_azure_sql_server_firewall_rules                                           = var.ptrn_openai_azure_sql_server_firewall_rules
  ptrn_openai_azure_sql_server_vnet_rules                                               = var.ptrn_openai_azure_sql_server_vnet_rules
  ptrn_openai_azure_sql_server_nacl_allowed_subnets                                     = var.ptrn_openai_azure_sql_server_nacl_allowed_subnets 

  ptrn_openai_azure_sql_server_storage_account_subnet_ids                               = var.ptrn_openai_azure_sql_server_storage_account_subnet_ids 
  ptrn_openai_azure_sql_server_storage_account_ip_rules                                 = var.ptrn_openai_azure_sql_server_storage_account_ip_rules


  ptrn_openai_azure_sql_server_azuread_login_username                                            = var.ptrn_openai_azure_sql_server_azuread_login_username      
  ptrn_openai_azure_sql_server_azuread_object_id                                                 = var.ptrn_openai_azure_sql_server_azuread_object_id
  ptrn_openai_azure_sql_server_private_dns_zone_ids                                              = var.ptrn_openai_azure_sql_server_private_dns_zone_ids
  ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids                                     = var.ptrn_openai_azure_sql_server_storage_account_pe_subnet_ids 
  ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids                              = var.ptrn_openai_azure_sql_server_storage_account_private_dns_zone_ids

# TF STATE
  ptrn_openai_storage_account_postfix         = var.ptrn_openai_storage_account_postfix
  ptrn_openai_storage_account_env             = var.ptrn_openai_storage_account_env

# SQL DB
  ptrn_openai_azure_sql_database_postfix        = var.ptrn_openai_azure_sql_database_postfix
  ptrn_openai_azure_sql_database_sku            = var.ptrn_openai_azure_sql_database_sku
  ptrn_openai_azure_sql_server_id               = var.ptrn_openai_azure_sql_server_id
  ptrn_openai_azure_storage_account_endpoint             = var.ptrn_openai_azure_storage_account_endpoint
  ptrn_openai_azure_storage_account_access_key           = var.ptrn_openai_azure_storage_account_access_key
  ptrn_openai_azure_sql_database_elastic_pool_id         = var.ptrn_openai_azure_sql_database_elastic_pool_id

# SQL ELASTIC 
 ptrn_openai_azure_sql_elastic_pool_enable                     = var.ptrn_openai_azure_sql_elastic_pool_enable
 ptrn_openai_azure_sql_elastic_pool_postfix                    = var.ptrn_openai_azure_sql_elastic_pool_postfix 
 ptrn_openai_core_rg_data_name                                 = var.ptrn_openai_core_rg_data_name

# API MGMT
  ptrn_openai_core_route_table_id                    = var.ptrn_openai_core_route_table_id
  ptrn_openai_api_mgmt_subnet_vnet_rg_name           = var.ptrn_openai_api_mgmt_subnet_vnet_rg_name
  ptrn_openai_api_mgmt_subnet_vnet_name              = var.ptrn_openai_api_mgmt_subnet_vnet_name
  ptrn_openai_api_mgmt_subnet_prefix                 = var.ptrn_openai_api_mgmt_subnet_prefix  
  ptrn_openai_api_mgmt_publisher_name                = var.ptrn_openai_api_mgmt_publisher_name
  ptrn_openai_api_mgmt_publisher_email               = var.ptrn_openai_api_mgmt_publisher_email
  ptrn_openai_api_mgmt_inbound_cidrs                 = var.ptrn_openai_api_mgmt_inbound_cidrs 
  ptrn_openai_api_mgmt_proxies                       = var.ptrn_openai_api_mgmt_proxies 
  ptrn_openai_api_mgmt_developer_portals             = var.ptrn_openai_api_mgmt_developer_portals  
}
//**********************************************************************************************
<!-- END_TF_DOCS -->
<!-- BEGIN_TF_DOCS -->

# Azure ETL Pattern

This is the Azure ETL pattern. It will deploy Azure Data Fabric, an ADLSv2 as storage, an Databricks Instance, a shared VNET for all components and a keyvault for store secrets.



## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group.ptrn_etl_vnet_rg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_subnet.ptrn_etl_subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_virtual_network.ptrn_etl_shared_vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_virtual_network_peering.core_vnet_peering](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.databricks_vnet_peering](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_env"></a> [env](#input\_env) | (Required) The environment where resources will be deployed into. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | (Required) The cloud region where resources will be deployed into. | `any` | n/a | yes |
| <a name="input_postfix"></a> [postfix](#input\_postfix) | (Required) A unique identifier for the deployment. Part of the naming scheme. | `any` | n/a | yes |
| <a name="input_ptrn_etl_core_vnet_id"></a> [ptrn\_etl\_core\_vnet\_id](#input\_ptrn\_etl\_core\_vnet\_id) | (Required) Core vnet id. | `string` | n/a | yes |
| <a name="input_ptrn_etl_core_vnet_name"></a> [ptrn\_etl\_core\_vnet\_name](#input\_ptrn\_etl\_core\_vnet\_name) | (Required) Core vnet name. | `string` | n/a | yes |
| <a name="input_ptrn_etl_core_vnet_rg_name"></a> [ptrn\_etl\_core\_vnet\_rg\_name](#input\_ptrn\_etl\_core\_vnet\_rg\_name) | (Required) Core vnet rg name. | `string` | n/a | yes |
| <a name="input_ptrn_etl_databricks_diagnostics"></a> [ptrn\_etl\_databricks\_diagnostics](#input\_ptrn\_etl\_databricks\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "dbfs",<br>    "clusters",<br>    "accounts",<br>    "jobs",<br>    "notebook",<br>    "ssh",<br>    "workspace",<br>    "secrets",<br>    "sqlPermissions",<br>    "instancePools"<br>  ],<br>  "metrics": []<br>}</pre> | no |
| <a name="input_ptrn_etl_databricks_log_analytics_workspace_id"></a> [ptrn\_etl\_databricks\_log\_analytics\_workspace\_id](#input\_ptrn\_etl\_databricks\_log\_analytics\_workspace\_id) | (Required) Databricks log analytics workspace id. | `string` | n/a | yes |
| <a name="input_ptrn_etl_databricks_managed_rg"></a> [ptrn\_etl\_databricks\_managed\_rg](#input\_ptrn\_etl\_databricks\_managed\_rg) | (Optional) The name of the resource group where Azure should place the managed Databricks resources. Changing this forces a new resource to be created. If this is not set Azure will create a new RG where all the managed resources will be deployed. | `string` | `null` | no |
| <a name="input_ptrn_etl_databricks_nsg_flow_log_postfix"></a> [ptrn\_etl\_databricks\_nsg\_flow\_log\_postfix](#input\_ptrn\_etl\_databricks\_nsg\_flow\_log\_postfix) | (Required) postfix name for the NSG flow log | `any` | n/a | yes |
| <a name="input_ptrn_etl_databricks_private_nsg_rules"></a> [ptrn\_etl\_databricks\_private\_nsg\_rules](#input\_ptrn\_etl\_databricks\_private\_nsg\_rules) | (Optional) Define additional NSG rules for private subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_etl_databricks_private_subnet"></a> [ptrn\_etl\_databricks\_private\_subnet](#input\_ptrn\_etl\_databricks\_private\_subnet) | (Optional) The name of the Private Subnet within the Virtual Network. Required if ptrn\_etl\_databricks\_vnet\_id is set. | `string` | `null` | no |
| <a name="input_ptrn_etl_databricks_public_ip"></a> [ptrn\_etl\_databricks\_public\_ip](#input\_ptrn\_etl\_databricks\_public\_ip) | (Optional) Are public IP Addresses not allowed? | `bool` | `true` | no |
| <a name="input_ptrn_etl_databricks_public_nsg_rules"></a> [ptrn\_etl\_databricks\_public\_nsg\_rules](#input\_ptrn\_etl\_databricks\_public\_nsg\_rules) | (Optional) Define additional NSG rules for public subnet. | <pre>map(object({<br>    name                          = string<br>    priority                      = number<br>    direction                     = string<br>    access                        = string<br>    protocol                      = string<br>    source_port_range             = string<br>    source_port_ranges            = list(string)<br>    destination_port_range        = string<br>    destination_port_ranges       = list(string)    <br>    source_address_prefix         = string<br>    source_address_prefixes       = list(string)<br>    destination_address_prefix    = string<br>    destination_address_prefixes  = list(string)    <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_etl_databricks_public_subnet"></a> [ptrn\_etl\_databricks\_public\_subnet](#input\_ptrn\_etl\_databricks\_public\_subnet) | (Optional) The name of the Public Subnet within the Virtual Network. Required if ptrn\_etl\_databricks\_vnet\_id is set. | `string` | `null` | no |
| <a name="input_ptrn_etl_databricks_sku"></a> [ptrn\_etl\_databricks\_sku](#input\_ptrn\_etl\_databricks\_sku) | (Optional) The sku to use for the Databricks Workspace. Possible values are standard, premium, or trial. Changing this can force a new resource to be created in some circumstances. | `string` | `"premium"` | no |
| <a name="input_ptrn_etl_databricks_storage_account_nsg_flow_log_id"></a> [ptrn\_etl\_databricks\_storage\_account\_nsg\_flow\_log\_id](#input\_ptrn\_etl\_databricks\_storage\_account\_nsg\_flow\_log\_id) | (Required) The ID of the Storage Account where flow logs are stored. | `string` | `null` | no |
| <a name="input_ptrn_etl_databricks_subnet_private_address_prefixes"></a> [ptrn\_etl\_databricks\_subnet\_private\_address\_prefixes](#input\_ptrn\_etl\_databricks\_subnet\_private\_address\_prefixes) | (Required) The address prefixes for the private subnet of data bricks. | `list` | n/a | yes |
| <a name="input_ptrn_etl_databricks_subnet_private_enforce_network_policies"></a> [ptrn\_etl\_databricks\_subnet\_private\_enforce\_network\_policies](#input\_ptrn\_etl\_databricks\_subnet\_private\_enforce\_network\_policies) | (Optional) Enable or Disable network policies for the private link endpoint on the private subnet. Conflicts with enforce\_private\_link\_service\_network\_policies. | `bool` | `false` | no |
| <a name="input_ptrn_etl_databricks_subnet_private_service_endpoints"></a> [ptrn\_etl\_databricks\_subnet\_private\_service\_endpoints](#input\_ptrn\_etl\_databricks\_subnet\_private\_service\_endpoints) | (Optional) The list of Service endpoints to associate with the private subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage and Microsoft.Web. | `list(string)` | `[]` | no |
| <a name="input_ptrn_etl_databricks_subnet_public_address_prefixes"></a> [ptrn\_etl\_databricks\_subnet\_public\_address\_prefixes](#input\_ptrn\_etl\_databricks\_subnet\_public\_address\_prefixes) | (Required) The address prefixes for the public subnet of data bricks. | `list` | n/a | yes |
| <a name="input_ptrn_etl_databricks_subnet_public_enforce_network_policies"></a> [ptrn\_etl\_databricks\_subnet\_public\_enforce\_network\_policies](#input\_ptrn\_etl\_databricks\_subnet\_public\_enforce\_network\_policies) | (Optional) Enable or Disable network policies for the private link endpoint on the public subnet. Conflicts with enforce\_private\_link\_service\_network\_policies. | `bool` | `false` | no |
| <a name="input_ptrn_etl_databricks_subnet_public_service_endpoints"></a> [ptrn\_etl\_databricks\_subnet\_public\_service\_endpoints](#input\_ptrn\_etl\_databricks\_subnet\_public\_service\_endpoints) | (Optional) The list of Service endpoints to associate with the public subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage and Microsoft.Web. | `list(string)` | `[]` | no |
| <a name="input_ptrn_etl_databricks_vnet_address_space"></a> [ptrn\_etl\_databricks\_vnet\_address\_space](#input\_ptrn\_etl\_databricks\_vnet\_address\_space) | (Required) The address space for virtual network of data bricks. | `list` | n/a | yes |
| <a name="input_ptrn_etl_databricks_vnet_dns_servers"></a> [ptrn\_etl\_databricks\_vnet\_dns\_servers](#input\_ptrn\_etl\_databricks\_vnet\_dns\_servers) | (Optional) Custom list of dns to be included in the vnet. | `list(string)` | `[]` | no |
| <a name="input_ptrn_etl_databricks_vnet_id"></a> [ptrn\_etl\_databricks\_vnet\_id](#input\_ptrn\_etl\_databricks\_vnet\_id) | (Optional) The ID of a Virtual Network where this Databricks Cluster should be created. | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_deploy_azure_ir"></a> [ptrn\_etl\_datafactory\_deploy\_azure\_ir](#input\_ptrn\_etl\_datafactory\_deploy\_azure\_ir) | (Optional) Deploy the azure integration runtime?. | `bool` | `true` | no |
| <a name="input_ptrn_etl_datafactory_deploy_self_hosted_ir"></a> [ptrn\_etl\_datafactory\_deploy\_self\_hosted\_ir](#input\_ptrn\_etl\_datafactory\_deploy\_self\_hosted\_ir) | (Optional) Deploy the self-hosted integration runtime?. | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_diagnostics"></a> [ptrn\_etl\_datafactory\_diagnostics](#input\_ptrn\_etl\_datafactory\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [<br>    "ActivityRuns",<br>    "PipelineRuns",<br>    "TriggerRuns",<br>    "SSISPackageEventMessages",<br>    "SSISPackageExecutableStatistics",<br>    "SSISPackageEventMessageContext",<br>    "SSISPackageExecutionComponentPhases",<br>    "SSISPackageExecutionDataStatistics",<br>    "SSISIntegrationRuntimeLogs"<br>  ],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_etl_datafactory_github_account_name"></a> [ptrn\_etl\_datafactory\_github\_account\_name](#input\_ptrn\_etl\_datafactory\_github\_account\_name) | (Optional) Specifies the GitHub account name | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_github_branch_name"></a> [ptrn\_etl\_datafactory\_github\_branch\_name](#input\_ptrn\_etl\_datafactory\_github\_branch\_name) | (Optional) Specifies the branch of the repository to get code from | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_github_git_url"></a> [ptrn\_etl\_datafactory\_github\_git\_url](#input\_ptrn\_etl\_datafactory\_github\_git\_url) | (Optional) Specifies the GitHub Enterprise host name. For example: https://github.mydomain.com. Use https://github.com for open source repositories | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_github_repository_name"></a> [ptrn\_etl\_datafactory\_github\_repository\_name](#input\_ptrn\_etl\_datafactory\_github\_repository\_name) | (Optional) Specifies the name of the git repository | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_github_root_folder"></a> [ptrn\_etl\_datafactory\_github\_root\_folder](#input\_ptrn\_etl\_datafactory\_github\_root\_folder) | (Optional) Specifies the root folder within the repository. Set to / for the top level | `string` | `"/"` | no |
| <a name="input_ptrn_etl_datafactory_log_analytics_solutions"></a> [ptrn\_etl\_datafactory\_log\_analytics\_solutions](#input\_ptrn\_etl\_datafactory\_log\_analytics\_solutions) | (Optional) A plan block | <pre>map(object({<br>    publisher = string #(Required) The publisher of the solution<br>    product   = string #(Required) The product name of the solution<br>  }))</pre> | <pre>{<br>  "AzureDataFactoryAnalytics": {<br>    "product": "OMSGallery/AzureDataFactoryAnalytics",<br>    "publisher": "Microsoft"<br>  }<br>}</pre> | no |
| <a name="input_ptrn_etl_datafactory_log_analytics_workspace_id"></a> [ptrn\_etl\_datafactory\_log\_analytics\_workspace\_id](#input\_ptrn\_etl\_datafactory\_log\_analytics\_workspace\_id) | (Required) Datafactory log analytics workspace id. | `string` | n/a | yes |
| <a name="input_ptrn_etl_datafactory_log_analytics_workspace_name"></a> [ptrn\_etl\_datafactory\_log\_analytics\_workspace\_name](#input\_ptrn\_etl\_datafactory\_log\_analytics\_workspace\_name) | (Required) Datafactory log analytics workspace name. | `string` | n/a | yes |
| <a name="input_ptrn_etl_datafactory_logging_rg_name"></a> [ptrn\_etl\_datafactory\_logging\_rg\_name](#input\_ptrn\_etl\_datafactory\_logging\_rg\_name) | (Required) Datafactory logging rg name. | `string` | n/a | yes |
| <a name="input_ptrn_etl_datafactory_managed_pe_blob_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_blob\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_blob\_enable) | (Optional) create a datafactory managed private endpoint for blob storage data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_cogsvcs_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_cogsvcs\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_cogsvcs\_enable) | (Optional) create a datafactory managed private endpoint for Cognitive Services data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_cosmosdb_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_cosmosdb\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_cosmosdb\_enable) | (Optional) create a datafactory managed private endpoint for Cosmos DB data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_dfs_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_dfs\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_dfs\_enable) | (Optional) create a datafactory managed private endpoint for data lake file storage data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_file_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_file\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_file\_enable) | (Optional) create a datafactory managed private endpoint for file storage data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_kv_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_kv\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_kv\_enable) | (Optional) create a datafactory managed private endpoint for Key Vault data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_mariadb_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_mariadb\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_mariadb\_enable) | (Optional) create a datafactory managed private endpoint for Maria DB data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_pstgsql_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_pstgsql\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_pstgsql\_enable) | (Optional) create a datafactory managed private endpoint for PostgreSQL data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_queue_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_queue\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_queue\_enable) | (Optional) create a datafactory managed private endpoint for queue storage data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_sqldb_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_sqldb\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_sqldb\_enable) | (Optional) create a datafactory managed private endpoint for SQL DB data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_synapse_analytics_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_synapse\_analytics\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_synapse\_analytics\_enable) | (Optional) create a datafactory managed private endpoint for synapse analytics data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_managed_pe_table_enable"></a> [ptrn\_etl\_datafactory\_managed\_pe\_table\_enable](#input\_ptrn\_etl\_datafactory\_managed\_pe\_table\_enable) | (Optional) create a datafactory managed private endpoint for table storage data source? | `bool` | `false` | no |
| <a name="input_ptrn_etl_datafactory_nacl_allowed_subnets"></a> [ptrn\_etl\_datafactory\_nacl\_allowed\_subnets](#input\_ptrn\_etl\_datafactory\_nacl\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this datafactory. | `list(string)` | `[]` | no |
| <a name="input_ptrn_etl_datafactory_repository_type"></a> [ptrn\_etl\_datafactory\_repository\_type](#input\_ptrn\_etl\_datafactory\_repository\_type) | (Optional) The Repository Type (vsts, github) | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_rg_name"></a> [ptrn\_etl\_datafactory\_rg\_name](#input\_ptrn\_etl\_datafactory\_rg\_name) | (Required) Datafactory rg name. | `string` | n/a | yes |
| <a name="input_ptrn_etl_datafactory_target_adls_storage_account_id"></a> [ptrn\_etl\_datafactory\_target\_adls\_storage\_account\_id](#input\_ptrn\_etl\_datafactory\_target\_adls\_storage\_account\_id) | (Optional) target resource id of data lake storage account for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_blob_storage_account_id"></a> [ptrn\_etl\_datafactory\_target\_blob\_storage\_account\_id](#input\_ptrn\_etl\_datafactory\_target\_blob\_storage\_account\_id) | (Optional) target resource id of blob storage account for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_cogsvcs_id"></a> [ptrn\_etl\_datafactory\_target\_cogsvcs\_id](#input\_ptrn\_etl\_datafactory\_target\_cogsvcs\_id) | (Optional) target resource id of cognitive services for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_cosmosdb_id"></a> [ptrn\_etl\_datafactory\_target\_cosmosdb\_id](#input\_ptrn\_etl\_datafactory\_target\_cosmosdb\_id) | (Optional) target resource id of cosmos DB for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_file_storage_account_id"></a> [ptrn\_etl\_datafactory\_target\_file\_storage\_account\_id](#input\_ptrn\_etl\_datafactory\_target\_file\_storage\_account\_id) | (Optional) target resource id of file storage account for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_kv_id"></a> [ptrn\_etl\_datafactory\_target\_kv\_id](#input\_ptrn\_etl\_datafactory\_target\_kv\_id) | (Optional) target resource id of key vault for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_mariadb_id"></a> [ptrn\_etl\_datafactory\_target\_mariadb\_id](#input\_ptrn\_etl\_datafactory\_target\_mariadb\_id) | (Optional) target resource id of maria DB for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_pstgsql_id"></a> [ptrn\_etl\_datafactory\_target\_pstgsql\_id](#input\_ptrn\_etl\_datafactory\_target\_pstgsql\_id) | (Optional) target resource id of PostgreSQL for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_queue_storage_account_id"></a> [ptrn\_etl\_datafactory\_target\_queue\_storage\_account\_id](#input\_ptrn\_etl\_datafactory\_target\_queue\_storage\_account\_id) | (Optional) target resource id of queue storage account for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_sqldb_id"></a> [ptrn\_etl\_datafactory\_target\_sqldb\_id](#input\_ptrn\_etl\_datafactory\_target\_sqldb\_id) | (Optional) target resource id of SQL DB for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_synapse_analytics_id"></a> [ptrn\_etl\_datafactory\_target\_synapse\_analytics\_id](#input\_ptrn\_etl\_datafactory\_target\_synapse\_analytics\_id) | (Optional) target resource id of synapse analytics for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_target_table_storage_account_id"></a> [ptrn\_etl\_datafactory\_target\_table\_storage\_account\_id](#input\_ptrn\_etl\_datafactory\_target\_table\_storage\_account\_id) | (Optional) target resource id of table storage account for datafactory managed private endpoint | `string` | `null` | no |
| <a name="input_ptrn_etl_datafactory_vsts_account_name"></a> [ptrn\_etl\_datafactory\_vsts\_account\_name](#input\_ptrn\_etl\_datafactory\_vsts\_account\_name) | (Optional) Specifies the VSTS account name | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_vsts_branch_name"></a> [ptrn\_etl\_datafactory\_vsts\_branch\_name](#input\_ptrn\_etl\_datafactory\_vsts\_branch\_name) | (Optional) Specifies the branch of the repository to get code from | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_vsts_project_name"></a> [ptrn\_etl\_datafactory\_vsts\_project\_name](#input\_ptrn\_etl\_datafactory\_vsts\_project\_name) | (Optional) Specifies the name of the VSTS project | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_vsts_repository_name"></a> [ptrn\_etl\_datafactory\_vsts\_repository\_name](#input\_ptrn\_etl\_datafactory\_vsts\_repository\_name) | (Optional) Specifies the name of the git repository | `string` | `""` | no |
| <a name="input_ptrn_etl_datafactory_vsts_root_folder"></a> [ptrn\_etl\_datafactory\_vsts\_root\_folder](#input\_ptrn\_etl\_datafactory\_vsts\_root\_folder) | (Optional) Specifies the root folder within the repository. Set to / for the top level. | `string` | `"/"` | no |
| <a name="input_ptrn_etl_datafactory_vsts_tenant_id"></a> [ptrn\_etl\_datafactory\_vsts\_tenant\_id](#input\_ptrn\_etl\_datafactory\_vsts\_tenant\_id) | (Optional) Specifies the Tenant ID associated with the VSTS account | `string` | `""` | no |
| <a name="input_ptrn_etl_datalake_access_tier"></a> [ptrn\_etl\_datalake\_access\_tier](#input\_ptrn\_etl\_datalake\_access\_tier) | (Optional) Defines the type of access tier to use for the data lake storage account. | `string` | `"Hot"` | no |
| <a name="input_ptrn_etl_datalake_account_kind"></a> [ptrn\_etl\_datalake\_account\_kind](#input\_ptrn\_etl\_datalake\_account\_kind) | (Optional) Defines the kind of storage account to deploy. | `string` | `"StorageV2"` | no |
| <a name="input_ptrn_etl_datalake_allowed_ips"></a> [ptrn\_etl\_datalake\_allowed\_ips](#input\_ptrn\_etl\_datalake\_allowed\_ips) | (Optional) A list of Ip addresses that can access the data lake storage account. It is recommended that you add your automation tool's IP range here. | `list` | `[]` | no |
| <a name="input_ptrn_etl_datalake_allowed_pe_subnet_ids"></a> [ptrn\_etl\_datalake\_allowed\_pe\_subnet\_ids](#input\_ptrn\_etl\_datalake\_allowed\_pe\_subnet\_ids) | (Required) A list of subnets to create a private endpoint that can access the data lake storage account. | `list(string)` | `[]` | no |
| <a name="input_ptrn_etl_datalake_backup_rsv_allowed_subnets"></a> [ptrn\_etl\_datalake\_backup\_rsv\_allowed\_subnets](#input\_ptrn\_etl\_datalake\_backup\_rsv\_allowed\_subnets) | (Optional) One or more Subnet ID's which should be able to access this RSV. | `list(string)` | `[]` | no |
| <a name="input_ptrn_etl_datalake_diagnostics"></a> [ptrn\_etl\_datalake\_diagnostics](#input\_ptrn\_etl\_datalake\_diagnostics) | (Optional) Diagnostic settings for those resources that support it. | `object({ logs = list(string), metrics = list(string) })` | <pre>{<br>  "logs": [],<br>  "metrics": [<br>    "AllMetrics"<br>  ]<br>}</pre> | no |
| <a name="input_ptrn_etl_datalake_file_share_enabled"></a> [ptrn\_etl\_datalake\_file\_share\_enabled](#input\_ptrn\_etl\_datalake\_file\_share\_enabled) | If set to true, enable file shares | `bool` | `false` | no |
| <a name="input_ptrn_etl_datalake_log_analytics_workspace_id"></a> [ptrn\_etl\_datalake\_log\_analytics\_workspace\_id](#input\_ptrn\_etl\_datalake\_log\_analytics\_workspace\_id) | (Required) Datalake log analytics workspace id. | `string` | n/a | yes |
| <a name="input_ptrn_etl_datalake_min_tls_version"></a> [ptrn\_etl\_datalake\_min\_tls\_version](#input\_ptrn\_etl\_datalake\_min\_tls\_version) | (Optional) Defines the minimum TLS version to use for the data lake storage account. | `string` | `"TLS1_2"` | no |
| <a name="input_ptrn_etl_datalake_resource_group_name"></a> [ptrn\_etl\_datalake\_resource\_group\_name](#input\_ptrn\_etl\_datalake\_resource\_group\_name) | (Required) Datalake resource group name. | `string` | n/a | yes |
| <a name="input_ptrn_etl_datalake_sa_file_shares"></a> [ptrn\_etl\_datalake\_sa\_file\_shares](#input\_ptrn\_etl\_datalake\_sa\_file\_shares) | (Optional) Array for the creation of multiple file shares. | <pre>map(object({<br>    name  = string<br>    quota  = number <br>  }))</pre> | `{}` | no |
| <a name="input_ptrn_etl_datalake_tier"></a> [ptrn\_etl\_datalake\_tier](#input\_ptrn\_etl\_datalake\_tier) | (Optional) The pricing tier for the data lake storage account. | `string` | `"Standard"` | no |
| <a name="input_ptrn_etl_enforce_private_link_endpoint_network_policies"></a> [ptrn\_etl\_enforce\_private\_link\_endpoint\_network\_policies](#input\_ptrn\_etl\_enforce\_private\_link\_endpoint\_network\_policies) | (Optional) enforce private link endpoint network policies. | `bool` | `true` | no |
| <a name="input_ptrn_etl_shared_vnet_address_space"></a> [ptrn\_etl\_shared\_vnet\_address\_space](#input\_ptrn\_etl\_shared\_vnet\_address\_space) | (Required) Shared vnet address space. | `list` | n/a | yes |
| <a name="input_ptrn_etl_subnet_address_space"></a> [ptrn\_etl\_subnet\_address\_space](#input\_ptrn\_etl\_subnet\_address\_space) | (Required) Shared vnet address space. | `list` | n/a | yes |
| <a name="input_suffix"></a> [suffix](#input\_suffix) | (Required) for private endpoints to deal with dual dns forwarders in each subscription. | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | n/a | `any` | n/a | yes |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | (Required) The tenant ID that the resources will reside in. | `any` | n/a | yes |

## Local values

```terraform
locals {
  timeout_duration = "2h"
}
```


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_ptrn_etl_azure_databricks"></a> [ptrn\_etl\_azure\_databricks](#output\_ptrn\_etl\_azure\_databricks) | n/a |
| <a name="output_ptrn_etl_datafactory"></a> [ptrn\_etl\_datafactory](#output\_ptrn\_etl\_datafactory) | n/a |
| <a name="output_ptrn_etl_datalake"></a> [ptrn\_etl\_datalake](#output\_ptrn\_etl\_datalake) | n/a |
| <a name="output_ptrn_etl_shared_vnet"></a> [ptrn\_etl\_shared\_vnet](#output\_ptrn\_etl\_shared\_vnet) | n/a |
| <a name="output_ptrn_etl_subnet"></a> [ptrn\_etl\_subnet](#output\_ptrn\_etl\_subnet) | n/a |
| <a name="output_ptrn_etl_vnet_rg"></a> [ptrn\_etl\_vnet\_rg](#output\_ptrn\_etl\_vnet\_rg) | Module Outputs ********************************************************************************************** |



## Usage

```terraform
// Azure ETL Pattern
//**********************************************************************************************
module "ptrn_etl" {
  source                                                      = "../dn-tads_tf-azure-component-library/patterns/ptrn_etl_gov"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  tenant_id                                                   = var.tenant_id
  suffix                                                      = var.suffix
  tags                                                        = var.tags
  ptrn_etl_datalake_resource_group_name                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_etl_datalake_log_analytics_workspace_id                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_etl_datalake_file_share_enabled                            = false
  ptrn_etl_datalake_sa_file_shares                                = {}
  ptrn_etl_datalake_allowed_pe_subnet_ids                         = var.ptrn_etl_datalake_allowed_pe_subnet_ids
  ptrn_etl_datalake_backup_rsv_allowed_subnets                    = var.ptrn_etl_datalake_backup_rsv_allowed_subnets
  ptrn_etl_datafactory_rg_name                                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_etl_datafactory_logging_rg_name                            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  ptrn_etl_datafactory_log_analytics_workspace_id                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_etl_datafactory_log_analytics_workspace_name               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  ptrn_etl_databricks_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id //only for premium plan
  ptrn_etl_core_vnet_name                                         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  ptrn_etl_core_vnet_id                                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  ptrn_etl_core_vnet_rg_name                                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ptrn_etl_databricks_subnet_private_address_prefixes             = ["50.0.2.0/24"]
  ptrn_etl_databricks_vnet_address_space                          = ["50.0.0.0/16"]
  ptrn_etl_databricks_subnet_public_address_prefixes              = ["50.0.1.0/24"]
  ptrn_etl_databricks_subnet_public_service_endpoints             = ["Microsoft.Storage"]
  ptrn_etl_databricks_subnet_private_service_endpoints            = ["Microsoft.Storage"]
  ptrn_etl_databricks_storage_account_nsg_flow_log_id             = var.ptrn_etl_databricks_storage_account_nsg_flow_log_id 
  ptrn_etl_databricks_nsg_flow_log_postfix                        = var.ptrn_etl_databricks_nsg_flow_log_postfix 
  ptrn_etl_shared_vnet_address_space                              = ["30.0.0.0/16"]
  ptrn_etl_subnet_address_space                                   = ["30.0.1.0/24"]
  ptrn_etl_datafactory_deploy_azure_ir                            = true/false
  ptrn_etl_datafactory_deploy_self_hosted_ir                      = true/false
}
//**********************************************************************************************
```
<!-- END_TF_DOCS -->
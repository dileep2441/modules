

## Usage

```terraform
// Azure ETL Pattern
//**********************************************************************************************
module "ptrn_etl" {
  source                                                      = "../dn-tads_tf-azure-component-library/patterns/ptrn_etl_gov"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  tenant_id                                                   = var.tenant_id
  suffix                                                      = var.suffix
  tags                                                        = var.tags
  ptrn_etl_datalake_resource_group_name                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_etl_datalake_log_analytics_workspace_id                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_etl_datalake_file_share_enabled                            = false
  ptrn_etl_datalake_sa_file_shares                                = {}
  ptrn_etl_datalake_allowed_pe_subnet_ids                         = var.ptrn_etl_datalake_allowed_pe_subnet_ids
  ptrn_etl_datalake_backup_rsv_allowed_subnets                    = var.ptrn_etl_datalake_backup_rsv_allowed_subnets
  ptrn_etl_datafactory_rg_name                                    = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
  ptrn_etl_datafactory_logging_rg_name                            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  ptrn_etl_datafactory_log_analytics_workspace_id                 = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  ptrn_etl_datafactory_log_analytics_workspace_name               = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  ptrn_etl_databricks_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id //only for premium plan
  ptrn_etl_core_vnet_name                                         = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name
  ptrn_etl_core_vnet_id                                           = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
  ptrn_etl_core_vnet_rg_name                                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  ptrn_etl_databricks_subnet_private_address_prefixes             = ["50.0.2.0/24"]
  ptrn_etl_databricks_vnet_address_space                          = ["50.0.0.0/16"]
  ptrn_etl_databricks_subnet_public_address_prefixes              = ["50.0.1.0/24"]
  ptrn_etl_databricks_subnet_public_service_endpoints             = ["Microsoft.Storage"]
  ptrn_etl_databricks_subnet_private_service_endpoints            = ["Microsoft.Storage"]
  ptrn_etl_databricks_storage_account_nsg_flow_log_id             = var.ptrn_etl_databricks_storage_account_nsg_flow_log_id 
  ptrn_etl_databricks_nsg_flow_log_postfix                        = var.ptrn_etl_databricks_nsg_flow_log_postfix 
  ptrn_etl_shared_vnet_address_space                              = ["30.0.0.0/16"]
  ptrn_etl_subnet_address_space                                   = ["30.0.1.0/24"]
  ptrn_etl_datafactory_deploy_azure_ir                            = true/false
  ptrn_etl_datafactory_deploy_self_hosted_ir                      = true/false
}
//**********************************************************************************************
```
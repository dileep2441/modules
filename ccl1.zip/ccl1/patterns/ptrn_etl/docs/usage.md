## Usage

```terraform
// Azure ETL Pattern
//**********************************************************************************************
module "ptrn_etl" {
  source                                                      = "../tf-azure-component-library/patterns/ptrn_etl/"
  env                                                         = var.env
  postfix                                                     = var.postfix
  location                                                    = var.location
  tenant_id                                                   = var.tenant_id
  ptrn_etl_datalake_resource_group_name                           = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  ptrn_etl_datalake_log_analytics_workspace_id                    = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  ptrn_etl_datafactory_rg_name                                    = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_data.name
  ptrn_etl_datafactory_logging_rg_name                            = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_logging.name
  ptrn_etl_datafactory_log_analytics_workspace_id                 = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id
  ptrn_etl_datafactory_log_analytics_workspace_name               = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.name
  ptrn_etl_databricks_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_latam_island.core_log_analytics_workspace.id //only for premium plan
  ptrn_etl_core_vnet_name                                         = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.name
  ptrn_etl_core_vnet_id                                           = data.terraform_remote_state.core.outputs.core_latam_island.core_vnet.id
  ptrn_etl_core_vnet_rg_name                                      = data.terraform_remote_state.core.outputs.core_latam_island.core_rg_network.name
  ptrn_etl_databricks_subnet_private_address_prefixes             = ["50.0.2.0/24"]
  ptrn_etl_databricks_vnet_address_space                          = ["50.0.0.0/16"]
  ptrn_etl_databricks_subnet_public_address_prefixes              = ["50.0.1.0/24"]
  ptrn_etl_databricks_subnet_public_service_endpoints             = ["Microsoft.Storage"]
  ptrn_etl_databricks_subnet_private_service_endpoints            = ["Microsoft.Storage"]
  ptrn_etl_shared_vnet_address_space                              = ["30.0.0.0/16"]
  ptrn_etl_subnet_address_space                                   = ["30.0.1.0/24"]
}
//**********************************************************************************************
```
## Usage Deploy module Iaas WebApp Patterns

```Scope
// Scope Deploy module Iaas WebApp Patterns
//***************************************************************************************************
The module Iaas WebApp Patterns was created in orde to integrate the differentes components for consume a web applicacion hosted in windows VM´s  with the security requirements, in the following pattern we will deploy an Application Gateway like front-end for external and internal webapp consumption, a windows VM to hosted the webap, an azure sql to save the webapp data. Azure Cache for Redis, SQL elastic pools and azure bastion are optional components in the Iaas pattern.  Azure bastion is only available to deploy in peninsula enviroments, also in case to desabled SQL elastic pools after being deployed is necessary to remove the databases from the elastic pool.
//***************************************************************************************************

```Jenkis Pipeline
// Certificates
//***************************************************************************************************
1. Get the valid external certificate .pfx format for the WebApp Windows VM, this certificate is will using in the Application Gateway Frond-End and the application container in windows VM for example IIS.

2 Enter in the page https://base64encode.org, upload the certificate .pfx format in encode files to base64 format option, then select encode button and finally download the txt file.

3. In Jenkins pipeline project create the credentials kind secret text, one called JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT and paste the txt file encode information. create another secret text called JENKINS_APP_GATEWAY_FRONTEND_TLS_PASS and enter the certificate private key.

4. In component factory repository you need to guarantee in pattern/scripts the funcions.sh script, and you need to guarantee in pattern/script/pattern_main.sh in terraform pattern plan the following instruction: source ./scripts/functions.sh appgw_cert.

5. Upload the certificate -pfx format in the webapp container and asign the port 443 or protocol HTTPS.

6. Create the dns external and internal with the Application Gateway public ip. 

7. The same certificate en step 1 needs to be using in the Application Gateway and Winddows VM app container for example IIS. In the patter module usage you send the dns created with the subjet name certificate for the webapp in variable ptrn_iaas_webapp_app_gateway_backend_host_name and variable ptrn_iaas_webapp_app_gateway_http_listener_hostname .

```terraform
//1. Deploy module Iaas WebApp Pattern with backup, redis cache, bastion and elastic pool modules optional enable or desabled
//***************************************************************************************************
module "ptrn_iaas_webapp" {
source                                                            = "../dn-tads_tf-azure-component-library/patterns/ptrn_iaas_webapp_gov"
env                                                               = var.env
postfix                                                           = "iaas-ptrn"
location                                                          = var.location
suffix                                                            = var.suffix
tags                                                              = var.tags
ptrn_iaas_webapp_core_rg_network_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
ptrn_iaas_webapp_core_rg_vnet_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name 
ptrn_iaas_webapp_core_rg_logging_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
ptrn_iaas_webapp_core_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
ptrn_iaas_webapp_cl_windows_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.workspace_id
ptrn_iaas_webapp_core_log_analytics_workspace_name                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
ptrn_iaas_webapp_core_rg_vnet_id                                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
ptrn_iaas_webapp_core_log_analytics_workspace_primary_shared_key  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.primary_shared_key
ptrn_iaas_webapp_core_route_table_id                              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
ptrn_iaas_webapp_core_rg_data_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
ptrn_iaas_webapp_subnet_address_prefixes                          = ["10.61.133.208/28"]
ptrn_iaas_sql_subnet_address_prefixes                             = ["10.61.133.224/28"]
ptrn_iaas_webapp_app_gateway_subnet_address_prefix                = ["10.61.133.160/27"]
ptrn_iaas_webapp_set_private_ip_listener                          = true # true peninsula / false Island
ptrn_iaas_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
ptrn_iaas_webapp_app_gateway_http_listener_hostname               = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_backend_host_name                    = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_nsg_flow_log_postfix                 = "appgw"
ptrn_iaas_webapp_app_gateway_pick_host_name                       = false
ptrn_iaas_webapp_app_gateway_pick_host_backend                    = true
ptrn_iaas_webapp_app_gateway_probe_path                           = "/"
ptrn_iaas_webapp_azure_bastion_enable                             = true # deploy required in peninsula / false in island
ptrn_iaas_webapp_azure_bastion_subnet_prefix                      = "20.141.52.148"
ptrn_iaas_webapp_windows_vm_deploy_rg                             = true
ptrn_iaas_webapp_windows_vm_enable_backup                         = true
ptrn_iaas_webapp_cl_windows_vm_image_id                           = "/subscriptions/06ccb1fb-ef2a-4326-b4ac-b711af550383/resourceGroups/rg-nprd-pr-gov-ss-image_gallery/providers/Microsoft.Compute/galleries/ignprdprgovssgvnp/images/image-2019-r1-std"
ptrn_iaas_webapp_cl_windows_vm_app_name                           = "webappiaaspattern"
ptrn_iaas_webapp_cl_windows_computer_name                         = "webappvm1"
ptrn_iaas_webapp_cl_windows_vm_admin_user                         = "adminame"
ptrn_iaas_webapp_cl_windows_vm_admin_pass                         = "Abc1234567890"
ptrn_iaas_webapp_windows_vm_domain_name                           = var.ptrn_iaas_webapp_windows_vm_domain_name
ptrn_iaas_webapp_windows_vm_ou_path                               = var.ptrn_iaas_webapp_windows_vm_ou_path
ptrn_iaas_webapp_windows_vm_domain_user_upn                       = var.ptrn_iaas_webapp_windows_vm_domain_user_upn
ptrn_iaas_webapp_windows_vm_domain_password                       = var.PTRN_IAAS_WEBAPP_WINDOWS_VM_DOMAIN_PASSWORD
ptrn_iaas_webapp_cl_windows_vm_availability_zone                  = "2"
ptrn_iaas_webapp_windows_vm_bastion_enable                        = true
ptrn_iaas_webapp_windows_vm_deploy_subnet_nsg                     = true
ptrn_iaas_webapp_windows_vm_enable_devops_agent                   = false
ptrn_iaas_webapp_azure_sql_server_postfix                         = "global"
ptrn_iaas_webapp_azure_sql_server_administrator                   = "sqladmin"
ptrn_iaas_webapp_azure_sql_server_password                        = "Portal123456!"
ptrn_iaas_webapp_azure_sql_database_postfix                       = "globaldb"
ptrn_iaas_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_iaas_webapp_azure_sql_elastic_pool_enable in false dont send values for variable sku ptrn_iaas_webapp_azure_sql_database_sku
ptrn_iaas_webapp_azure_sql_elastic_pool_enable                    = true # true deploy module / false not deploy module
ptrn_iaas_webapp_azure_sql_elastic_pool_postfix                   = "globaldb"
ptrn_iaas_webapp_redis_cache_enable                               = true # true deploy module / false not deploy module
ptrn_iaas_webapp_redis_cache_postfix                              = "WebApp1"
ptrn_iaas_webapp_redis_cache_allowed_subnets                      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_login_username                  = "xxxxx@kpmg"
ptrn_iaas_webapp_azure_sql_server_object_id                       = ""
ptrn_iaas_webapp_storage_account_nsg_flow_log_id                  = var.ptrn_iaas_webapp_storage_account_nsg_flow_log_id
ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets                    = var.ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets
}
//***************************************************************************************************
```

```terraform
//2. Deploy module Iaas WebApp Pattern with key vault to save Application Gateway certificates and Managed Identity asigned
//***************************************************************************************************
//Get the current client config
//***************************************************************************************************
data "azurerm_client_config" "current" {}

//Get the Principle(Object) Id of Application Gateway's Managed Identity
//***************************************************************************************************
resource "azurerm_user_assigned_identity" "appgateway_keyvault_integration" {
  name                = "ptrn-iaas-webap-pappgwy-msi"
  location            = var.location
  resource_group_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
}

//Deploy Key vault
//Note: KeyVault Adminstrator role needs to be granted to SPN on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//Note:  KeyVault Secrets user/crypto user/certificates officer role needs to be granted to Application Gateway's Managed Identitity on the KV IAM. (No need for access policies, RBAC auth enabled for KV)
//***************************************************************************************************
module "cl_keyvault" {
  source                                   = "../dn-tads_tf-azure-component-library/components/cl_keyvault"
  env                                      = var.env
  postfix                                  = var.postfix
  location                                 = var.location
  tenant_id                                = var.tenant_id
  suffix                                   = var.suffix
  tags                                     = var.tags
  cl_keyvault_rg_name                      = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name
  cl_keyvault_logging_rg_name              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
  cl_keyvault_log_analytics_workspace_id   = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
  cl_keyvault_log_analytics_workspace_name = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
  cl_keyvault_nacl_allowed_ips             = ["199.206.0.0/15"]
  // ToDo: Remove app gateway subnet if dependency fails
  cl_keyvault_nacl_allowed_subnets         = [module.ptrn_iaas_webapp.ptrn_privatelink_subnet.id]
  cl_keyvault_allowed_pe_subnet_ids        = [module.ptrn_iaas_webapp.ptrn_privatelink_subnet.id]
}

//Add secrets/certificates to keyvault
//***************************************************************************************************
resource "azurerm_key_vault_certificate" "appgateway_cert" {
  name         = "ptrn-iaas-webapp-appgateway-cert"
  key_vault_id = module.cl_keyvault.cl_keyvault.id

  certificate {
    contents = filebase64(var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA)
    password = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
  }

  certificate_policy {
    issuer_parameters {
      name = "Unknown"
    }

    key_properties {
      exportable = true
      key_size   = 2048
      key_type   = "RSA"
      reuse_key  = false
    }

    secret_properties {
      content_type = "application/x-pkcs12"
    }
  }
}

//Deploy Iaas pattern webapp
//***************************************************************************************************
module "ptrn_iaas_webapp" {
source                                                            = "../dn-tads_tf-azure-component-library/patterns/ptrn_iaas_webapp_gov"
env                                                               = var.env
postfix                                                           = "iaas-ptrn"
location                                                          = var.location
suffix                                                            = var.suffix
tags                                                              = var.tags
ptrn_iaas_webapp_core_rg_network_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_network.name 
ptrn_iaas_webapp_core_rg_vnet_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.name 
ptrn_iaas_webapp_core_rg_logging_name                             = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_logging.name
ptrn_iaas_webapp_core_log_analytics_workspace_id                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.id
ptrn_iaas_webapp_cl_windows_log_analytics_workspace_id            = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.workspace_id
ptrn_iaas_webapp_core_log_analytics_workspace_name                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.name
ptrn_iaas_webapp_core_rg_vnet_id                                  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_vnet.id
ptrn_iaas_webapp_core_log_analytics_workspace_primary_shared_key  = data.terraform_remote_state.core.outputs.core_us_peninsula.core_log_analytics_workspace.cl_log_analytics_workspace.primary_shared_key
ptrn_iaas_webapp_core_route_table_id                              = data.terraform_remote_state.core.outputs.core_us_peninsula.core_route_table.id
ptrn_iaas_webapp_core_rg_data_name                                = data.terraform_remote_state.core.outputs.core_us_peninsula.core_rg_data.name
ptrn_iaas_webapp_subnet_address_prefixes                          = ["10.61.133.208/28"]
ptrn_iaas_sql_subnet_address_prefixes                             = ["10.61.133.224/28"]
ptrn_iaas_webapp_app_gateway_subnet_address_prefix                = ["10.61.133.160/27"]
ptrn_iaas_webapp_set_private_ip_listener                          = true # true peninsula / false Island
ptrn_iaas_webapp_app_gateway_frontend_tls_cert                    = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PFXA
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_pass               = var.JENKINS_APP_GATEWAY_FRONTEND_TLS_CERT_PASSA
ptrn_iaas_webapp_app_gateway_http_listener_hostname               = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_backend_host_name                    = "webapp.ati.kpmg.com.br"
ptrn_iaas_webapp_app_gateway_nsg_flow_log_postfix                 = "appgw"
ptrn_iaas_webapp_app_gateway_pick_host_name                       = false
ptrn_iaas_webapp_app_gateway_pick_host_backend                    = true
ptrn_iaas_webapp_app_gateway_probe_path                           = "/"
ptrn_iaas_webapp_azure_bastion_enable                             = true # deploy required in peninsula / false in island
ptrn_iaas_webapp_azure_bastion_subnet_prefix                      = "20.141.52.148"
ptrn_iaas_webapp_windows_vm_deploy_rg                             = true
ptrn_iaas_webapp_windows_vm_enable_backup                         = true
ptrn_iaas_webapp_cl_windows_vm_image_id                           = "/subscriptions/06ccb1fb-ef2a-4326-b4ac-b711af550383/resourceGroups/rg-nprd-pr-gov-ss-image_gallery/providers/Microsoft.Compute/galleries/ignprdprgovssgvnp/images/image-2019-r1-std"
ptrn_iaas_webapp_cl_windows_vm_app_name                           = "webappiaaspattern"
ptrn_iaas_webapp_cl_windows_computer_name                         = "webappvm1"
ptrn_iaas_webapp_cl_windows_vm_admin_user                         = "adminame"
ptrn_iaas_webapp_cl_windows_vm_admin_pass                         = "Abc1234567890"
ptrn_iaas_webapp_windows_vm_domain_name                           = var.ptrn_iaas_webapp_windows_vm_domain_name
ptrn_iaas_webapp_windows_vm_ou_path                               = var.ptrn_iaas_webapp_windows_vm_ou_path
ptrn_iaas_webapp_windows_vm_domain_user_upn                       = var.ptrn_iaas_webapp_windows_vm_domain_user_upn
ptrn_iaas_webapp_windows_vm_domain_password                       = var.PTRN_IAAS_WEBAPP_WINDOWS_VM_DOMAIN_PASSWORD
ptrn_iaas_webapp_cl_windows_vm_availability_zone                  = "2"
ptrn_iaas_webapp_windows_vm_bastion_enable                        = true
ptrn_iaas_webapp_windows_vm_deploy_subnet_nsg                     = true
ptrn_iaas_webapp_windows_vm_enable_devops_agent                   = false
ptrn_iaas_webapp_azure_sql_server_postfix                         = "global"
ptrn_iaas_webapp_azure_sql_server_administrator                   = "sqladmin"
ptrn_iaas_webapp_azure_sql_server_password                        = "Portal123456!"
ptrn_iaas_webapp_azure_sql_database_postfix                       = "globaldb"
ptrn_iaas_webapp_azure_sql_database_sku                           = "ElasticPool" # sku required with elastic pool enabled / varialbe ptrn_iaas_webapp_azure_sql_elastic_pool_enable in false dont send values for variable sku ptrn_iaas_webapp_azure_sql_database_sku
ptrn_iaas_webapp_azure_sql_elastic_pool_enable                    = true # true deploy module / false not deploy module
ptrn_iaas_webapp_azure_sql_elastic_pool_postfix                   = "globaldb"
ptrn_iaas_webapp_redis_cache_enable                               = true # true deploy module / false not deploy module
ptrn_iaas_webapp_redis_cache_postfix                              = "WebApp1"
ptrn_iaas_webapp_redis_cache_allowed_subnets                      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_vnet_subnet_ids      = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_sa_allowed_pe_subnet_ids        = [data.terraform_remote_state.core.outputs.core_us_peninsula.core_private_link_subnet[0].id]
ptrn_iaas_webapp_azure_sql_server_login_username                  = "xxxxx-@kpmg"
ptrn_iaas_webapp_azure_sql_server_object_id                       = ""
ptrn_iaas_webapp_storage_account_nsg_flow_log_id                  = var.ptrn_iaas_webapp_storage_account_nsg_flow_log_id
ptrn_iaas_webapp_app_gateway_identity_ids                         = [azurerm_user_assigned_identity.appgateway_keyvault_integration.id]
ptrn_iaas_webapp_app_gateway_frontend_tls_cert_keyvault_id        = azurerm_key_vault_certificate.appgateway_cert.secret_id
ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets                    = var.ptrn_iaas_webapp_azure_backup_rsv_allowed_subnets
}
//***************************************************************************************************
```
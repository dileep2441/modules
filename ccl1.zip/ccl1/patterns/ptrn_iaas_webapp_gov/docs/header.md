# Iaas WebApp Patterns

The module Iaas WebApp Patterns was created in orde to integrate the differentes components for consume a web applicacion hosted in windows VM´s  with the security requirements, in the following pattern we will deploy an Application Gateway like front-end for external and internal webapp consumption, a windows VM to hosted the webap, an azure sql to save the webapp data. Azure Cache for Redis, SQL elastic pools and azure bastion are optional components in the Iaas pattern.  Azure bastion is only available to deploy in peninsula enviroments, also in case to desabled SQL elastic pools after being deployed is necessary to remove the databases from the elastic pool.



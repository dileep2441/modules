
# set up satellite repos
curl --connect-timeout 5  -sL "http://useomlxp00008.nix.us.kworld.kpmg.com" -o /dev/null
resultx=$?
if [ $resultx -eq 28 ] || [ $resultx -eq 7 ]; then
  SAT_SERVER="useomlxp00010.nix.us.kworld.kpmg.com"
else
  SAT_SERVER="useomlxp00008.nix.us.kworld.kpmg.com"
fi
echo "SAT_SERVER = $SAT_SERVER"
curl http://$SAT_SERVER/pub/bootstrap.sh | bash -s - -r -c 1-rhn-rhel7-x86_64 1-puppet;

# start salt bootstrap
SALT_USER='salt'
SALT_DIRS="
  /etc/salt/pki/minion
  /var/cache/salt
  /var/log/salt
  /var/run/salt
"

declare -A SALT_ENVS
SALT_ENVS=(
['strap_np']='usmdclxp00533.nix.us.kworld.kpmg.com'
['strap_sh']='usmdcspcm00001.nix.us.kworld.kpmg.com'
)

declare -A SECONDARY_MASTERS
SECONDARY_MASTERS=(
['strap_np']='usmdclxp00534.nix.us.kworld.kpmg.com'
['strap_sh']='usmdclxp00528.nix.us.kworld.kpmg.com'
)

# clear salt
rm -rf /var/cache/salt/*
rm -rf /var/run/salt/*
rm -rf /etc/salt/pki/minion/*

# Installing salt-minion
yum install libyaml -y --disablerepo=saltstack
yum install salt-minion -y

MASTER="${SALT_ENVS["$STRAP_ENV"]}"
MASTER2="${SECONDARY_MASTERS["$STRAP_ENV"]}"
echo "STRAP_ENV = $STRAP_ENV"
echo "Master = $MASTER"
echo "Secondary Master = $MASTER2"

# Creating service account
if ! getent passwd salt > /dev/null
then
    useradd ${SALT_USER}
fi

# Creating sudoers file
echo "${SALT_USER}	ALL=(root)	NOPASSWD: /usr/bin/salt-call,  /bin/salt-call" > /tmp/salt-sudo
chown root:root /tmp/salt-sudo
visudo -cf /tmp/salt-sudo && mv /tmp/salt-sudo /etc/sudoers.d/salt-sudo

# Creating salt dirs
for DIR in ${SALT_DIRS}
do
    mkdir -p ${DIR}
    chown ${SALT_USER}:${SALT_USER} ${DIR}
done

# Downloading master pubkey
KEY_NAME="${STRAP_ENV}_sign.pub"
echo "https://${SAT_SERVER}/salt/master_signing_keys/${KEY_NAME}"
curl -k https://${SAT_SERVER}/salt/master_signing_keys/${KEY_NAME} -o /etc/salt/pki/minion/master_sign.pub
chown ${SALT_USER}:${SALT_USER} /etc/salt/pki/minion/master_sign.pub

# Downloading minion config
MINION_CONFIG="${STRAP_ENV}_minion"
curl -k https://${SAT_SERVER}/salt/minion_configs/${MINION_CONFIG} -o /etc/salt/minion
# upper case minion id
host_name=`hostname`
echo "id: ${host_name^^}"|cat - /etc/salt/minion > /tmp/minionconf
mv /tmp/minionconf /etc/salt/minion
chown ${SALT_USER}:${SALT_USER} /etc/salt/minion
if [ $MASTER2 =='' ]
then
    sed -i "s/{{ master }}/${MASTER}/" /etc/salt/minion
else
    sed -i "s/{{ master }}/\n  - ${MASTER}\n  - ${MASTER2}/" /etc/salt/minion
fi
sed -i "s/{{ salt_user }}/${SALT_USER}/" /etc/salt/minion
echo "# configure startup state" >> /etc/salt/minion
echo "startup_states: highstate" >> /etc/salt/minion

# Downloading minion unit file
curl -k https://${SAT_SERVER}/salt/minion_configs/salt-minion.service -o /usr/lib/systemd/system/salt-minion.service
chown ${SALT_USER}:${SALT_USER} /usr/lib/systemd/system/salt-minion.service
sed -i "s/{{ salt_user }}/${SALT_USER}/" /usr/lib/systemd/system/salt-minion.service

# Reload systemd config
systemctl daemon-reload

# Update permissions for saltstack files
for DIR in ${SALT_DIRS}
do
    chown -R ${SALT_USER}:${SALT_USER} ${DIR}
done

ISFIREWALLDENABLED=`systemctl status firewalld.service | grep Loaded | awk '{print $4}' - | sed s,\;,,`
if [ $ISFIREWALLDENABLED == "enabled" ]; then
  firewall-cmd --permanent --zone=public --add-port=4505/udp
  firewall-cmd --permanent --zone=public --add-port=4505/tcp
  firewall-cmd --permanent --zone=public --add-port=4506/udp
  firewall-cmd --permanent --zone=public --add-port=4506/tcp
  systemctl restart firewalld.service
fi

# set autoaccept key
echo "AutoAcceptKey: $AUTO_KEY" >> /etc/salt/grains
echo 'is_linux_cloud_vm: True' >> /etc/salt/grains
echo 'autosign_grains:' > /etc/salt/minion.d/autosign_minion.conf
echo '  - AutoAcceptKey' >> /etc/salt/minion.d/autosign_minion.conf

systemctl enable salt-minion
systemctl start salt-minion
infoblox_user="$1"
infoblox_password="$2"
host_name="$3"

echo "infoblox_user: $infoblox_user"
echo "host_name: $host_name"

curl -k -u "${infoblox_user}":"${infoblox_password}" -H 'content-type:application/json' -X POST "https://gm01.us.kworld.kpmg.com/wapi/v2.7.3/request" \
    -d "[{\"method\": \"STATE:ASSIGN\",\"data\":{\"host_name\":\"${host_name}\"}},{\"method\":\"GET\",\"object\": \"record:host\",\"data\": {\"name:\":\"##STATE:host_name:##\"},\"assign_state\": {\"host_ref\": \"_ref\"},\"enable_substitution\": true,\"discard\": true},{ \"method\": \"DELETE\", \"object\": \"##STATE:host_ref:##\",\"enable_substitution\": true,\"discard\": true},{\"method\": \"STATE:DISPLAY\"}]"

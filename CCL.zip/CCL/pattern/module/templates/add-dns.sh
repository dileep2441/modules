infoblox_user="$1"
infoblox_password="$2"
host_name="$3"
ip_address="$4"


if [[ -z "$infoblox_user" ]]; then
   echo "Infoblox credentials not provided, skipping dns registration"
   exit 0
fi
if [[ -z "$infoblox_password" ]]; then
    echo "Infoblox credentials not provided, skipping dns registration"
    exit 0
fi
if [[ -z "$host_name" ]]; then
    echo "Hostname not provided, skipping dns registration"
    exit 0
fi
if [[ -z "$ip_address" ]]; then
    echo "IP address not provided, skipping dns registration"
    exit 0
fi

echo "infoblox_user: $infoblox_user"
echo "host_name: $host_name"
echo "ip_address: $ip_address"

curl -k1 -u "${infoblox_user}":"${infoblox_password}" -X POST 'https://gm01.us.kworld.kpmg.com/wapi/v1.0/record:host' -H "Content-Type: application/json" -d \
    "{\"ipv4addrs\":[{\"ipv4addr\":\"${ip_address}\"}],\"name\":\"${host_name}\"}"

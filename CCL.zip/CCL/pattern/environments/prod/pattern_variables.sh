CL_REPOSITORY="dn-tads_tf-azure-component-library"
echo "CL_REPOSITORY=$CL_REPOSITORY" >> $GITHUB_ENV

CL_VERSION="v1.7.2"
echo $CL_VERSION
echo "CL_VERSION=$CL_VERSION" >> $GITHUB_ENV

PVDR_VERSION="3.59.0"
echo "PVDR_VERSION=$PVDR_VERSION" >> $GITHUB_ENV
#**********************************************************************************************

# Terraform Version
#**********************************************************************************************
TF_VERSION="1.5.0"
echo "TF_VERSION=$TF_VERSION" >> $GITHUB_ENV
#**********************************************************************************************

# Common Variables
#**********************************************************************************************
TF_VAR_postfix="adtgpt"
TF_VAR_env="prod-pr"
echo "TF_VAR_postfix=$TF_VAR_postfix" >> $GITHUB_ENV
#**********************************************************************************************

# Required Azure Variables
#**********************************************************************************************
TF_VAR_location="eastus"
echo "TF_VAR_location=$TF_VAR_location" >> $GITHUB_ENV
TF_VAR_tenant_id=""
echo "TF_VAR_tenant_id=$TF_VAR_tenant_id" >> $GITHUB_ENV
#**********************************************************************************************

# set +ax #Disables the 'set -a' command

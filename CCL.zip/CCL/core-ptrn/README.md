# github_templates_poc
repository core templates

#!/bin/bash


set -a #Make all following local variables environment variables 


# Component Library Version
#**********************************************************************************************
CL_REPOSITORY="dn-tads_tf-azure-component-library"
echo "CL_REPOSITORY=$CL_REPOSITORY" >> $GITHUB_ENV

CL_VERSION="v1.7.2"
#CL_VERSION="feature/storage_error"
echo "CL_VERSION=$CL_VERSION" >> $GITHUB_ENV
#**********************************************************************************************

# Terraform Version
#**********************************************************************************************
TF_VERSION="1.2.4"
echo "TF_VERSION=$TF_VERSION" >> $GITHUB_ENV
#**********************************************************************************************

# Common Variables
#**********************************************************************************************
TF_VAR_env="prod-pr"
TF_VAR_postfix="chtgpt"
#**********************************************************************************************


# Required Azure Variables
#**********************************************************************************************
TF_VAR_location="eastus"
TF_VAR_subscription_id="9c1f9cf3-d595-484d-845a-e95d4f944244" #SandBox Shared Services
TF_VAR_tenant_id="9353a0b7-1ab1-4a3e-b0cb-0620ff5c4e82" #Sandbox Tenant
#**********************************************************************************************


set +a #Disables the 'set -a' command

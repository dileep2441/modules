#!/bin/bash


#**********************************************************************************************
# This script creates environment variables based on input arguments passed in from automation.
# All variables will be set to null if they are not passed in.
#**********************************************************************************************


set -a #Make all following local variables environment variables 


# Default values for variables set to null in case they are not passed in
#**********************************************************************************************
TERRAFORM_ACTION=${TERRAFORM_ACTION:-null}
AUTOMATION_USERNAME=${AUTOMATION_USERNAME:-null}
AUTOMATION_PASSWORD=${AUTOMATION_PASSWORD:-null}
#**********************************************************************************************


# Loops over each input argument that starts with '--' and assigns
# the very next argument to the current argument
#**********************************************************************************************
while [ $# -gt 0 ]; do
   if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
   fi
  shift
done
#**********************************************************************************************


set +a #Disables the 'set -a' command


# Runs the main.sh script while preserving all environment variables
#**********************************************************************************************
source ./main.sh
#**********************************************************************************************
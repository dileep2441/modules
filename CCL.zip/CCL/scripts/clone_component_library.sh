#!/bin/bash


echo "Cloning Component Library"
echo "**********************************************************************************************"
git clone ssh://git@git.us.kworld.kpmg.com:7999/ktechcloud/dn-tads_tf-azure-component-library.git
cd dn-tads_tf-azure-component-library
git checkout $CL_VERSION
cd ..
echo "**********************************************************************************************"

#!/bin/bash

# Initialization instructions
echo "Logging into azure..."
echo "**********************************************************************************************"
if [ "$USE_USER_ASSIGNED_MI" = true ]; then
    az login --identity -u $ARM_CLIENT_ID
    az account set -s=$TF_VAR_subscription_id
    az security setting update -n "WDATP" --enabled false
else
    az login --service-principal -u=$ARM_CLIENT_ID -p=$ARM_CLIENT_SECRET --tenant=$TF_VAR_tenant_id
    az account set -s=$TF_VAR_subscription_id
    az security setting update -n "WDATP" --enabled false
fi

echo "**********************************************************************************************"

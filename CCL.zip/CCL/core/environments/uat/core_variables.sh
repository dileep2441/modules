CL_REPOSITORY="dn-tads_tf-azure-component-library"
echo "CL_REPOSITORY=$CL_REPOSITORY" >> $GITHUB_ENV

CL_VERSION="feature/core-acr-sql"
echo $CL_VERSION
echo "CL_VERSION=$CL_VERSION" >> $GITHUB_ENV

PVDR_VERSION="3.59.0"
echo "PVDR_VERSION=$PVDR_VERSION" >> $GITHUB_ENV
#**********************************************************************************************

# Terraform Version
#**********************************************************************************************
TF_VERSION="1.5.0"
echo "TF_VERSION=$TF_VERSION" >> $GITHUB_ENV
#**********************************************************************************************

# Common Variables
#**********************************************************************************************
TF_VAR_env="prod-pr"
echo "TF_VAR_env=$TF_VAR_env" >> $GITHUB_ENV
TF_VAR_postfix="chtgpt-uat"
echo "TF_VAR_postfix=$TF_VAR_postfix" >> $GITHUB_ENV
#**********************************************************************************************

# Required Azure Variables
#**********************************************************************************************
TF_VAR_location="eastus"
echo "TF_VAR_location=$TF_VAR_location" >> $GITHUB_ENV
TF_VAR_tenant_id="deff24bb-2089-4400-8c8e-f71e680378b2"
echo "TF_VAR_tenant_id=$TF_VAR_tenant_id" >> $GITHUB_ENV
TF_VAR_subscription_id="24958185-72e5-4f8e-ae4b-2f737edb0ca0"
echo "TF_VAR_subscription_id=$TF_VAR_subscription_id" >> $GITHUB_ENV
#**********************************************************************************************

# set +ax #Disables the 'set -a' command